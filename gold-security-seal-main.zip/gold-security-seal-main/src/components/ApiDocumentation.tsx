import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  Code,
  Copy,
  ExternalLink,
  Key,
  Shield,
  Database,
  BarChart3,
  Webhook,
  CheckCircle,
  Loader2,
} from "lucide-react";

const ApiDocumentation = () => {
  const { user } = useAuth();
  const [testResult, setTestResult] = useState<string>("");
  const [isTesting, setIsTesting] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState("");

  const baseUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1`;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const testVerifyEndpoint = async () => {
    setIsTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke("api-verify", {
        body: null,
      });
      
      // Since it needs an ID, show the expected response format
      setTestResult(JSON.stringify({
        note: "Use ?id=CERT-XXXX to verify a certificate",
        example_response: {
          success: true,
          verified: true,
          certificate: {
            id: "CERT-EXAMPLE",
            website: "example.com",
            score: 85,
          }
        }
      }, null, 2));
    } catch (err) {
      setTestResult(JSON.stringify({ error: "Test failed" }, null, 2));
    } finally {
      setIsTesting(false);
    }
  };

  const testWebhook = async () => {
    if (!webhookUrl) {
      toast.error("Enter a webhook URL first");
      return;
    }

    setIsTesting(true);
    try {
      const { data, error } = await supabase.functions.invoke("api-webhooks", {
        body: { action: "test", webhook_url: webhookUrl },
      });

      if (error) throw error;
      toast.success(data?.message || "Webhook test sent");
      setTestResult(JSON.stringify(data, null, 2));
    } catch (err) {
      toast.error("Webhook test failed");
    } finally {
      setIsTesting(false);
    }
  };

  const CodeBlock = ({ code, language = "bash" }: { code: string; language?: string }) => (
    <div className="relative">
      <pre className="bg-secondary p-4 rounded-lg overflow-x-auto text-sm">
        <code className="text-foreground">{code}</code>
      </pre>
      <Button
        variant="ghost"
        size="icon"
        className="absolute top-2 right-2"
        onClick={() => copyToClipboard(code)}
      >
        <Copy className="w-4 h-4" />
      </Button>
    </div>
  );

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Code className="w-5 h-5 text-primary" />
          API Documentation
        </CardTitle>
        <CardDescription>
          Integrate SecureAudit with your applications
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="verify" className="w-full">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="verify" className="gap-1">
              <Shield className="w-3 h-3" />
              <span className="hidden sm:inline">Verify</span>
            </TabsTrigger>
            <TabsTrigger value="certificates" className="gap-1">
              <Database className="w-3 h-3" />
              <span className="hidden sm:inline">CRUD</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-1">
              <BarChart3 className="w-3 h-3" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="webhooks" className="gap-1">
              <Webhook className="w-3 h-3" />
              <span className="hidden sm:inline">Webhooks</span>
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[400px] mt-4">
            <TabsContent value="verify" className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Badge className="bg-warning/20 text-warning">AUTH REQUIRED</Badge>
                  Verify Certificate
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Programmatically verify a certificate's authenticity. Requires API key with <code className="bg-secondary px-1 rounded">verify</code> permission.
                </p>
                
                <CodeBlock code={`GET ${baseUrl}/api-verify?id=CERT-XXXX
Authorization: Bearer sck_your_api_key`} />
                
                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Response</h4>
                  <CodeBlock
                    code={`{
  "success": true,
  "verified": true,
  "certificate": {
    "id": "CERT-M5K2J",
    "website": "example.com",
    "owner": "John Doe",
    "score": 85,
    "risk_level": "low",
    "status": "active",
    "issue_date": "2024-01-15",
    "expiry_date": "2025-01-15",
    "is_expired": false,
    "days_until_expiry": 365
  },
  "verified_at": "2024-01-20T10:30:00Z"
}`}
                  />
                </div>

                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Error Responses</h4>
                  <CodeBlock
                    code={`// 401 Unauthorized
{ "success": false, "error": "Invalid API key" }

// 404 Not Found
{ "success": false, "verified": false, "error": "Certificate not found" }

// 400 Bad Request
{ "success": false, "error": "Certificate ID required. Use ?id=CERT-XXXX" }`}
                  />
                </div>

                <Button onClick={testVerifyEndpoint} disabled={isTesting} className="mt-4">
                  {isTesting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ExternalLink className="w-4 h-4 mr-2" />}
                  Test Endpoint
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="certificates" className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Badge className="bg-warning/20 text-warning">AUTH REQUIRED</Badge>
                  Certificate CRUD API
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Create, read, update, and delete certificates. Requires Bearer token.
                </p>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">List Certificates</h4>
                    <CodeBlock code={`GET ${baseUrl}/api-certificates
Authorization: Bearer YOUR_TOKEN

# Optional query params:
# ?limit=50&offset=0&status=valid&risk=high`} />
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Create Certificate</h4>
                    <CodeBlock code={`POST ${baseUrl}/api-certificates
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "website_name": "example.com",
  "owner_name": "John Doe",
  "score": 85,
  "risk_level": "low",
  "expiry_date": "2025-01-15",
  "ssl_score": 90,
  "dns_score": 85,
  "server_score": 80
}`} />
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Update Certificate</h4>
                    <CodeBlock code={`PUT ${baseUrl}/api-certificates?id=UUID
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "score": 90,
  "status": "valid"
}`} />
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Delete Certificate</h4>
                    <CodeBlock code={`DELETE ${baseUrl}/api-certificates?id=UUID
Authorization: Bearer YOUR_TOKEN`} />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Badge className="bg-warning/20 text-warning">AUTH REQUIRED</Badge>
                  Analytics API
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Get certificate statistics and trends.
                </p>

                <CodeBlock code={`GET ${baseUrl}/api-analytics
Authorization: Bearer YOUR_TOKEN`} />

                <div className="mt-4">
                  <h4 className="text-sm font-medium mb-2">Response</h4>
                  <CodeBlock code={`{
  "success": true,
  "analytics": {
    "summary": {
      "total": 150,
      "by_status": { "valid": 120, "expired": 20, "revoked": 10 },
      "by_risk": { "low": 80, "medium": 50, "high": 20 },
      "expiring_soon": 15,
      "average_score": 72,
      "score_distribution": {
        "excellent": 30,
        "good": 60,
        "fair": 40,
        "poor": 20
      }
    },
    "monthly_trends": [
      { "month": "Aug 2024", "issued": 25, "average_score": 75 }
    ]
  }
}`} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="webhooks" className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Badge className="bg-warning/20 text-warning">AUTH REQUIRED</Badge>
                  Webhooks API
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Receive notifications when certificate events occur.
                </p>

                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Available Events</h4>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">certificate.created</Badge>
                      <Badge variant="outline">certificate.updated</Badge>
                      <Badge variant="outline">certificate.renewed</Badge>
                      <Badge variant="outline">certificate.revoked</Badge>
                      <Badge variant="outline">certificate.expired</Badge>
                      <Badge variant="outline">certificate.expiring_soon</Badge>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Test Your Webhook</h4>
                    <div className="flex gap-2">
                      <Input
                        placeholder="https://your-webhook-url.com"
                        value={webhookUrl}
                        onChange={(e) => setWebhookUrl(e.target.value)}
                      />
                      <Button onClick={testWebhook} disabled={isTesting}>
                        {isTesting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Test"}
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-medium mb-2">Webhook Payload</h4>
                    <CodeBlock code={`{
  "event": "certificate.created",
  "certificate_id": "CERT-M5K2J",
  "website_name": "example.com",
  "timestamp": "2024-01-20T10:30:00Z",
  "data": {
    "owner": "John Doe",
    "score": 85,
    "risk_level": "low",
    "status": "valid",
    "expiry_date": "2025-01-15"
  }
}`} />
                  </div>
                </div>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>

        {testResult && (
          <div className="mt-4">
            <h4 className="text-sm font-medium mb-2">Test Result</h4>
            <pre className="bg-secondary p-4 rounded-lg overflow-x-auto text-xs max-h-32">
              <code className="text-foreground">{testResult}</code>
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ApiDocumentation;