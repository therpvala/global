import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import {
  Bell,
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  RefreshCw,
  Trash2,
  Loader2,
} from "lucide-react";

interface Notification {
  id: string;
  type: "expiring" | "expired" | "renewed" | "created" | "revoked";
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  certificate_id?: string;
}

interface NotificationsPanelProps {
  onNotificationClick?: (certificateId: string) => void;
}

const NotificationsPanel = ({ onNotificationClick }: NotificationsPanelProps) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    generateNotifications();
  }, []);

  const generateNotifications = async () => {
    setIsLoading(true);
    try {
      const { data: certificates } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false });

      const now = new Date();
      const notifs: Notification[] = [];

      (certificates || []).forEach((cert) => {
        const expiryDate = new Date(cert.expiry_date);
        const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

        // Expiring soon notifications
        if (daysUntilExpiry > 0 && daysUntilExpiry <= 30) {
          notifs.push({
            id: `expiring-${cert.id}`,
            type: "expiring",
            title: "Certificate Expiring Soon",
            message: `${cert.website_name} expires in ${daysUntilExpiry} days`,
            timestamp: new Date(cert.expiry_date),
            read: false,
            certificate_id: cert.id,
          });
        }

        // Expired notifications
        if (daysUntilExpiry < 0) {
          notifs.push({
            id: `expired-${cert.id}`,
            type: "expired",
            title: "Certificate Expired",
            message: `${cert.website_name} expired ${Math.abs(daysUntilExpiry)} days ago`,
            timestamp: expiryDate,
            read: false,
            certificate_id: cert.id,
          });
        }

        // Recently created (last 7 days)
        const createdDate = new Date(cert.created_at);
        const daysSinceCreated = Math.ceil((now.getTime() - createdDate.getTime()) / (1000 * 60 * 60 * 24));
        if (daysSinceCreated <= 7) {
          notifs.push({
            id: `created-${cert.id}`,
            type: "created",
            title: "New Certificate Issued",
            message: `${cert.website_name} was certified`,
            timestamp: createdDate,
            read: true,
            certificate_id: cert.id,
          });
        }

        // Revoked
        if (cert.status === "revoked") {
          notifs.push({
            id: `revoked-${cert.id}`,
            type: "revoked",
            title: "Certificate Revoked",
            message: `${cert.website_name} has been revoked`,
            timestamp: new Date(cert.updated_at),
            read: true,
            certificate_id: cert.id,
          });
        }
      });

      // Sort by timestamp (most recent first)
      notifs.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      setNotifications(notifs.slice(0, 20));
    } catch (err) {
      console.error("Failed to load notifications:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "expiring":
        return <Clock className="w-4 h-4 text-warning" />;
      case "expired":
        return <AlertTriangle className="w-4 h-4 text-destructive" />;
      case "renewed":
        return <RefreshCw className="w-4 h-4 text-success" />;
      case "created":
        return <Shield className="w-4 h-4 text-primary" />;
      case "revoked":
        return <Trash2 className="w-4 h-4 text-muted-foreground" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "Just now";
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-primary" />
              Notifications
              {unreadCount > 0 && (
                <Badge variant="destructive" className="ml-2">
                  {unreadCount}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>Recent activity and alerts</CardDescription>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={generateNotifications}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>No notifications</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-2">
              {notifications.map((notif, index) => (
                <div key={notif.id}>
                  <div
                    className={`p-3 rounded-lg transition-colors cursor-pointer ${
                      !notif.read ? "bg-primary/5" : "hover:bg-muted/50"
                    }`}
                    onClick={() => notif.certificate_id && onNotificationClick?.(notif.certificate_id)}
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5">{getIcon(notif.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className={`text-sm font-medium ${!notif.read ? "text-foreground" : "text-muted-foreground"}`}>
                            {notif.title}
                          </p>
                          <span className="text-xs text-muted-foreground">
                            {formatTimeAgo(notif.timestamp)}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground truncate">
                          {notif.message}
                        </p>
                      </div>
                      {!notif.read && (
                        <div className="w-2 h-2 bg-primary rounded-full shrink-0" />
                      )}
                    </div>
                  </div>
                  {index < notifications.length - 1 && <Separator className="my-1" />}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};

export default NotificationsPanel;