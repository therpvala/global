import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from "recharts";
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval } from "date-fns";

interface Certificate {
  id: string;
  certificate_id: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
}

interface CertificateAnalyticsProps {
  certificates: Certificate[];
}

const CertificateAnalytics = ({ certificates }: CertificateAnalyticsProps) => {
  // Monthly certificate issuance (last 6 months)
  const monthlyData = useMemo(() => {
    const now = new Date();
    const months = [];
    
    for (let i = 5; i >= 0; i--) {
      const monthStart = startOfMonth(subMonths(now, i));
      const monthEnd = endOfMonth(subMonths(now, i));
      
      const count = certificates.filter((cert) => {
        const issueDate = new Date(cert.issue_date);
        return isWithinInterval(issueDate, { start: monthStart, end: monthEnd });
      }).length;
      
      months.push({
        month: format(monthStart, "MMM"),
        certificates: count,
      });
    }
    
    return months;
  }, [certificates]);

  // Risk level distribution
  const riskData = useMemo(() => {
    const low = certificates.filter((c) => c.risk_level === "low").length;
    const medium = certificates.filter((c) => c.risk_level === "medium").length;
    const high = certificates.filter((c) => c.risk_level === "high").length;
    
    return [
      { name: "Low", value: low, fill: "hsl(var(--success))" },
      { name: "Medium", value: medium, fill: "hsl(var(--warning))" },
      { name: "High", value: high, fill: "hsl(var(--destructive))" },
    ].filter((d) => d.value > 0);
  }, [certificates]);

  // Status distribution
  const statusData = useMemo(() => {
    const valid = certificates.filter((c) => c.status === "valid").length;
    const expired = certificates.filter((c) => c.status === "expired").length;
    const revoked = certificates.filter((c) => c.status === "revoked").length;
    
    return [
      { name: "Valid", value: valid, fill: "hsl(var(--success))" },
      { name: "Expired", value: expired, fill: "hsl(var(--destructive))" },
      { name: "Revoked", value: revoked, fill: "hsl(var(--muted-foreground))" },
    ].filter((d) => d.value > 0);
  }, [certificates]);

  // Score distribution
  const scoreData = useMemo(() => {
    const ranges = [
      { range: "0-20", min: 0, max: 20 },
      { range: "21-40", min: 21, max: 40 },
      { range: "41-60", min: 41, max: 60 },
      { range: "61-80", min: 61, max: 80 },
      { range: "81-100", min: 81, max: 100 },
    ];
    
    return ranges.map(({ range, min, max }) => ({
      range,
      count: certificates.filter((c) => c.score >= min && c.score <= max).length,
    }));
  }, [certificates]);

  // Average score trend (last 6 months)
  const scoreTrendData = useMemo(() => {
    const now = new Date();
    const months = [];
    
    for (let i = 5; i >= 0; i--) {
      const monthStart = startOfMonth(subMonths(now, i));
      const monthEnd = endOfMonth(subMonths(now, i));
      
      const monthCerts = certificates.filter((cert) => {
        const issueDate = new Date(cert.issue_date);
        return isWithinInterval(issueDate, { start: monthStart, end: monthEnd });
      });
      
      const avgScore = monthCerts.length > 0
        ? Math.round(monthCerts.reduce((sum, c) => sum + c.score, 0) / monthCerts.length)
        : null;
      
      months.push({
        month: format(monthStart, "MMM"),
        score: avgScore,
      });
    }
    
    return months;
  }, [certificates]);

  const chartConfig = {
    certificates: { label: "Certificates", color: "hsl(var(--primary))" },
    count: { label: "Count", color: "hsl(var(--primary))" },
    score: { label: "Avg Score", color: "hsl(var(--primary))" },
  };

  if (certificates.length === 0) {
    return null;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      {/* Monthly Issuance Chart */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Certificates Issued</CardTitle>
          <CardDescription>Last 6 months</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="colorCerts" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Area
                type="monotone"
                dataKey="certificates"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                fill="url(#colorCerts)"
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Average Score Trend */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Average Security Score</CardTitle>
          <CardDescription>Monthly trend</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <LineChart data={scoreTrendData}>
              <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line
                type="monotone"
                dataKey="score"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--primary))", strokeWidth: 0, r: 4 }}
                connectNulls
              />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Risk Distribution */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Risk Distribution</CardTitle>
          <CardDescription>By risk level</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <ChartContainer config={chartConfig} className="h-[160px] w-[160px]">
              <PieChart>
                <Pie
                  data={riskData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={70}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {riskData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ChartContainer>
            <div className="flex flex-col gap-2">
              {riskData.map((item) => (
                <div key={item.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }} />
                  <span className="text-sm text-muted-foreground">{item.name}</span>
                  <span className="text-sm font-medium text-foreground">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Score Distribution */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-medium">Score Distribution</CardTitle>
          <CardDescription>By score range</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[200px] w-full">
            <BarChart data={scoreData}>
              <XAxis dataKey="range" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} allowDecimals={false} />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default CertificateAnalytics;
