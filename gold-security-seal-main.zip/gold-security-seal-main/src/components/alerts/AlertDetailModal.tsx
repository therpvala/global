import { useState, useEffect, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertTriangle,
  Clock,
  Shield,
  Bug,
  Activity,
  TrendingUp,
  CheckCircle2,
  Eye,
  FileText,
  History,
  Save,
  X,
  ArrowRight,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Alert } from "@/hooks/useRealtimeAlerts";
import type { Json } from "@/integrations/supabase/types";

interface AlertHistory {
  id: string;
  alert_id: string;
  user_id: string | null;
  action: string;
  previous_value: Json;
  new_value: Json;
  notes: string | null;
  created_at: string;
}

interface AlertDetailModalProps {
  alert: Alert | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStatusChange: (alertId: string, status: string) => Promise<void>;
}

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "critical":
      return "bg-destructive text-destructive-foreground";
    case "high":
      return "bg-orange-500 text-white";
    case "medium":
      return "bg-yellow-500 text-black";
    case "low":
      return "bg-blue-500 text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "active":
      return "bg-destructive/10 text-destructive border-destructive/20";
    case "investigating":
      return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
    case "resolved":
    case "dismissed":
      return "bg-green-500/10 text-green-600 border-green-500/20";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getAlertTypeIcon = (type: string) => {
  switch (type) {
    case "malware":
      return <Bug className="h-5 w-5" />;
    case "backdoor":
      return <Shield className="h-5 w-5" />;
    case "uptime":
      return <Activity className="h-5 w-5" />;
    default:
      return <AlertTriangle className="h-5 w-5" />;
  }
};

const getActionIcon = (action: string) => {
  switch (action) {
    case "status_changed":
      return <CheckCircle2 className="h-4 w-4 text-green-500" />;
    case "escalated":
      return <TrendingUp className="h-4 w-4 text-orange-500" />;
    case "notes_updated":
      return <FileText className="h-4 w-4 text-blue-500" />;
    default:
      return <History className="h-4 w-4 text-muted-foreground" />;
  }
};

const getActionLabel = (action: string) => {
  switch (action) {
    case "status_changed":
      return "Status Changed";
    case "escalated":
      return "Alert Escalated";
    case "notes_updated":
      return "Notes Updated";
    case "updated":
      return "Alert Updated";
    default:
      return action;
  }
};

const formatTimestamp = (timestamp: string) => {
  return new Date(timestamp).toLocaleString();
};

const formatRelativeTime = (timestamp: string) => {
  const now = new Date();
  const date = new Date(timestamp);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${diffDays}d ago`;
};

export function AlertDetailModal({
  alert,
  open,
  onOpenChange,
  onStatusChange,
}: AlertDetailModalProps) {
  const [history, setHistory] = useState<AlertHistory[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [resolutionNotes, setResolutionNotes] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("");
  const { toast } = useToast();

  // Fetch alert history
  const fetchHistory = useCallback(async () => {
    if (!alert) return;

    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from("alert_history")
        .select("*")
        .eq("alert_id", alert.id)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setHistory((data as AlertHistory[]) || []);
    } catch (err) {
      console.error("Error fetching alert history:", err);
    } finally {
      setLoadingHistory(false);
    }
  }, [alert]);

  useEffect(() => {
    if (open && alert) {
      fetchHistory();
      setResolutionNotes((alert as Alert & { resolution_notes?: string }).resolution_notes || "");
      setSelectedStatus(alert.status);
    }
  }, [open, alert, fetchHistory]);

  const handleSaveNotes = async () => {
    if (!alert) return;

    setIsSaving(true);
    try {
      const { error } = await supabase
        .from("alerts")
        .update({ resolution_notes: resolutionNotes })
        .eq("id", alert.id);

      if (error) throw error;

      toast({
        title: "Notes Saved",
        description: "Resolution notes have been updated",
      });
      fetchHistory();
    } catch (err) {
      console.error("Error saving notes:", err);
      toast({
        title: "Error",
        description: "Failed to save resolution notes",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleStatusChange = async () => {
    if (!alert || selectedStatus === alert.status) return;

    await onStatusChange(alert.id, selectedStatus);
    fetchHistory();
  };

  if (!alert) return null;

  const alertWithNotes = alert as Alert & { 
    resolution_notes?: string; 
    original_severity?: string;
    escalation_count?: number;
    escalated_at?: string;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-muted">
              {getAlertTypeIcon(alert.alert_type)}
            </div>
            <div className="flex-1">
              <DialogTitle className="text-xl">{alert.title}</DialogTitle>
              <DialogDescription className="mt-1">
                {alert.description}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-6 py-4">
            {/* Alert Info */}
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Severity</p>
                      <div className="flex items-center gap-2">
                        <Badge className={getSeverityColor(alert.severity)}>
                          {alert.severity.toUpperCase()}
                        </Badge>
                        {alertWithNotes.original_severity && alertWithNotes.original_severity !== alert.severity && (
                          <>
                            <span className="text-xs text-muted-foreground">from</span>
                            <Badge variant="outline" className="text-xs">
                              {alertWithNotes.original_severity.toUpperCase()}
                            </Badge>
                          </>
                        )}
                      </div>
                    </div>
                    {alertWithNotes.escalation_count && alertWithNotes.escalation_count > 0 && (
                      <div className="flex items-center gap-1 text-orange-500">
                        <TrendingUp className="h-4 w-4" />
                        <span className="text-sm font-medium">
                          Escalated {alertWithNotes.escalation_count}x
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground mb-1">Status</p>
                  <div className="flex items-center gap-2">
                    <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                      <SelectTrigger className="w-36 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="investigating">Investigating</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="dismissed">Dismissed</SelectItem>
                      </SelectContent>
                    </Select>
                    {selectedStatus !== alert.status && (
                      <Button size="sm" onClick={handleStatusChange}>
                        Update
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Metadata */}
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Source</p>
                    <p className="font-medium">{alert.source}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Type</p>
                    <p className="font-medium capitalize">{alert.alert_type}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Created</p>
                    <p className="font-medium">{formatTimestamp(alert.created_at)}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Last Updated</p>
                    <p className="font-medium">{formatTimestamp(alert.updated_at)}</p>
                  </div>
                  {alertWithNotes.escalated_at && (
                    <div>
                      <p className="text-muted-foreground">Last Escalated</p>
                      <p className="font-medium">{formatTimestamp(alertWithNotes.escalated_at)}</p>
                    </div>
                  )}
                  {alert.resolved_at && (
                    <div>
                      <p className="text-muted-foreground">Resolved</p>
                      <p className="font-medium">{formatTimestamp(alert.resolved_at)}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Resolution Notes */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Resolution Notes
              </Label>
              <Textarea
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                placeholder="Add notes about how this alert was investigated or resolved..."
                rows={4}
              />
              <div className="flex justify-end">
                <Button 
                  size="sm" 
                  onClick={handleSaveNotes} 
                  disabled={isSaving || resolutionNotes === (alertWithNotes.resolution_notes || "")}
                >
                  <Save className="h-3 w-3 mr-1" />
                  {isSaving ? "Saving..." : "Save Notes"}
                </Button>
              </div>
            </div>

            <Separator />

            {/* Timeline / History */}
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <History className="h-4 w-4" />
                Activity Timeline
              </Label>

              {loadingHistory ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-4 w-32 mb-1" />
                        <Skeleton className="h-3 w-48" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : history.length > 0 ? (
                <div className="space-y-3">
                  {history.map((entry, index) => (
                    <div key={entry.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className="p-2 rounded-full bg-muted">
                          {getActionIcon(entry.action)}
                        </div>
                        {index < history.length - 1 && (
                          <div className="w-px h-full bg-border mt-2" />
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">
                            {getActionLabel(entry.action)}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {formatRelativeTime(entry.created_at)}
                          </span>
                        </div>
                        {entry.action === "status_changed" && entry.previous_value && entry.new_value && (
                          <div className="flex items-center gap-2 mt-1 text-xs">
                            <Badge variant="outline" className="capitalize">
                              {(entry.previous_value as { status?: string })?.status || "unknown"}
                            </Badge>
                            <ArrowRight className="h-3 w-3 text-muted-foreground" />
                            <Badge variant="outline" className={`capitalize ${getStatusColor((entry.new_value as { status?: string })?.status || "")}`}>
                              {(entry.new_value as { status?: string })?.status || "unknown"}
                            </Badge>
                          </div>
                        )}
                        {entry.action === "escalated" && entry.previous_value && entry.new_value && (
                          <div className="flex items-center gap-2 mt-1 text-xs">
                            <Badge className={getSeverityColor((entry.previous_value as { severity?: string })?.severity || "")}>
                              {((entry.previous_value as { severity?: string })?.severity || "").toUpperCase()}
                            </Badge>
                            <ArrowRight className="h-3 w-3 text-muted-foreground" />
                            <Badge className={getSeverityColor((entry.new_value as { severity?: string })?.severity || "")}>
                              {((entry.new_value as { severity?: string })?.severity || "").toUpperCase()}
                            </Badge>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">
                          {formatTimestamp(entry.created_at)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6 text-muted-foreground">
                  <History className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No activity history yet</p>
                </div>
              )}

              {/* Initial creation event */}
              <div className="flex gap-3 opacity-60">
                <div className="p-2 rounded-full bg-muted">
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">Alert Created</span>
                    <span className="text-xs text-muted-foreground">
                      {formatRelativeTime(alert.created_at)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {formatTimestamp(alert.created_at)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

export default AlertDetailModal;
