import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  TrendingUp,
  Plus,
  Pencil,
  Trash2,
  Clock,
  Mail,
  MessageSquare,
  Zap,
  AlertTriangle,
  Shield,
  Bug,
  Activity,
  RefreshCw,
} from "lucide-react";
import { useEscalationRules, type EscalationRule, type CreateEscalationRuleData } from "@/hooks/useEscalationRules";

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "critical":
      return "bg-destructive text-destructive-foreground";
    case "high":
      return "bg-orange-500 text-white";
    case "medium":
      return "bg-yellow-500 text-black";
    case "low":
      return "bg-blue-500 text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getAlertTypeIcon = (type: string) => {
  switch (type) {
    case "malware":
      return <Bug className="h-4 w-4" />;
    case "backdoor":
      return <Shield className="h-4 w-4" />;
    case "uptime":
      return <Activity className="h-4 w-4" />;
    default:
      return <AlertTriangle className="h-4 w-4" />;
  }
};

interface RuleFormData {
  name: string;
  description: string;
  severity: string;
  alert_type: string;
  threshold_minutes: number;
  escalate_to_severity: string;
  notify_email: boolean;
  notify_slack: boolean;
}

const initialFormData: RuleFormData = {
  name: "",
  description: "",
  severity: "high",
  alert_type: "all",
  threshold_minutes: 30,
  escalate_to_severity: "critical",
  notify_email: true,
  notify_slack: false,
};

interface RuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: CreateEscalationRuleData) => Promise<void>;
  initialData?: RuleFormData;
  isEdit?: boolean;
}

const RuleDialog = ({ open, onOpenChange, onSubmit, initialData = initialFormData, isEdit = false }: RuleDialogProps) => {
  const [formData, setFormData] = useState<RuleFormData>(initialData);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    setIsSubmitting(true);
    await onSubmit(formData);
    setIsSubmitting(false);
    onOpenChange(false);
    if (!isEdit) {
      setFormData(initialFormData);
    }
  };

  const isValid = formData.name.trim() !== "" && formData.threshold_minutes > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Escalation Rule" : "Create Escalation Rule"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Modify the escalation rule settings."
              : "Define when and how unresolved alerts should be escalated."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Rule Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Critical Alert Escalation"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what this rule does..."
              rows={2}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Alert Severity</Label>
              <Select
                value={formData.severity}
                onValueChange={(value) => setFormData({ ...formData, severity: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Alert Type</Label>
              <Select
                value={formData.alert_type}
                onValueChange={(value) => setFormData({ ...formData, alert_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="malware">Malware</SelectItem>
                  <SelectItem value="backdoor">Backdoor</SelectItem>
                  <SelectItem value="uptime">Uptime</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Threshold (Minutes)</Label>
              <Input
                type="number"
                min={1}
                value={formData.threshold_minutes}
                onChange={(e) =>
                  setFormData({ ...formData, threshold_minutes: parseInt(e.target.value) || 30 })
                }
              />
            </div>
            <div className="grid gap-2">
              <Label>Escalate To</Label>
              <Select
                value={formData.escalate_to_severity}
                onValueChange={(value) => setFormData({ ...formData, escalate_to_severity: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-3">
            <Label>Notification Channels</Label>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Email Notification</span>
              </div>
              <Switch
                checked={formData.notify_email}
                onCheckedChange={(checked) => setFormData({ ...formData, notify_email: checked })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">Slack Notification</span>
              </div>
              <Switch
                checked={formData.notify_slack}
                onCheckedChange={(checked) => setFormData({ ...formData, notify_slack: checked })}
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!isValid || isSubmitting}>
            {isSubmitting ? "Saving..." : isEdit ? "Save Changes" : "Create Rule"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

interface RuleCardProps {
  rule: EscalationRule;
  onToggle: (id: string, isActive: boolean) => void;
  onEdit: (rule: EscalationRule) => void;
  onDelete: (id: string) => void;
}

const RuleCard = ({ rule, onToggle, onEdit, onDelete }: RuleCardProps) => (
  <Card className={`transition-opacity ${!rule.is_active ? "opacity-60" : ""}`}>
    <CardContent className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <Badge className={getSeverityColor(rule.severity)} variant="secondary">
              {rule.severity.toUpperCase()}
            </Badge>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
            <Badge className={getSeverityColor(rule.escalate_to_severity)} variant="secondary">
              {rule.escalate_to_severity.toUpperCase()}
            </Badge>
            <div className="flex items-center gap-1 text-muted-foreground">
              {getAlertTypeIcon(rule.alert_type)}
              <span className="text-xs capitalize">{rule.alert_type}</span>
            </div>
          </div>
          <h4 className="font-medium text-foreground">{rule.name}</h4>
          {rule.description && (
            <p className="text-sm text-muted-foreground mt-1 line-clamp-1">{rule.description}</p>
          )}
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground flex-wrap">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              After {rule.threshold_minutes} min
            </span>
            {rule.notify_email && (
              <span className="flex items-center gap-1">
                <Mail className="h-3 w-3" />
                Email
              </span>
            )}
            {rule.notify_slack && (
              <span className="flex items-center gap-1">
                <MessageSquare className="h-3 w-3" />
                Slack
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col gap-2 items-end">
          <Switch
            checked={rule.is_active}
            onCheckedChange={(checked) => onToggle(rule.id, checked)}
          />
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => onEdit(rule)}>
              <Pencil className="h-3 w-3" />
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                  <Trash2 className="h-3 w-3" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Escalation Rule</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete "{rule.name}"? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => onDelete(rule.id)}
                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </CardContent>
  </Card>
);

export function EscalationRulesPanel() {
  const {
    rules,
    loading,
    activeRulesCount,
    createRule,
    updateRule,
    toggleRuleActive,
    deleteRule,
    triggerEscalationCheck,
  } = useEscalationRules();

  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<EscalationRule | null>(null);

  const handleEdit = (rule: EscalationRule) => {
    setEditingRule(rule);
    setEditDialogOpen(true);
  };

  const handleUpdate = async (data: CreateEscalationRuleData) => {
    if (editingRule) {
      await updateRule(editingRule.id, data);
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                Escalation Rules
                {activeRulesCount > 0 && (
                  <Badge variant="outline" className="text-xs">
                    {activeRulesCount} Active
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>Auto-escalate unresolved alerts based on thresholds</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={triggerEscalationCheck}>
              <RefreshCw className="h-3 w-3 mr-1" />
              Run Check
            </Button>
            <Button size="sm" onClick={() => setCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-1" />
              Add Rule
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 pt-0">
        <ScrollArea className="h-[400px] pr-4">
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : rules.length > 0 ? (
            <div className="space-y-3">
              {rules.map((rule) => (
                <RuleCard
                  key={rule.id}
                  rule={rule}
                  onToggle={toggleRuleActive}
                  onEdit={handleEdit}
                  onDelete={deleteRule}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <Zap className="h-8 w-8 mb-2" />
              <p className="text-center">No escalation rules configured</p>
              <p className="text-sm text-center">Create a rule to auto-escalate unresolved alerts</p>
            </div>
          )}
        </ScrollArea>
      </CardContent>

      {/* Create Dialog */}
      <RuleDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        onSubmit={createRule}
      />

      {/* Edit Dialog */}
      {editingRule && (
        <RuleDialog
          open={editDialogOpen}
          onOpenChange={(open) => {
            setEditDialogOpen(open);
            if (!open) setEditingRule(null);
          }}
          onSubmit={handleUpdate}
          initialData={{
            name: editingRule.name,
            description: editingRule.description || "",
            severity: editingRule.severity,
            alert_type: editingRule.alert_type,
            threshold_minutes: editingRule.threshold_minutes,
            escalate_to_severity: editingRule.escalate_to_severity,
            notify_email: editingRule.notify_email,
            notify_slack: editingRule.notify_slack,
          }}
          isEdit
        />
      )}
    </Card>
  );
}

export default EscalationRulesPanel;
