import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { TrendingUp, AlertTriangle, Clock, ArrowUpRight, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useRealtimeAlerts, Alert } from "@/hooks/useRealtimeAlerts";
import { formatDistanceToNow } from "date-fns";

const EscalationStatsWidget = () => {
  const navigate = useNavigate();
  const { alerts, loading } = useRealtimeAlerts();

  const escalatedAlerts = useMemo(() => {
    return alerts.filter((a) => (a.escalation_count ?? 0) > 0);
  }, [alerts]);

  const recentEscalations = useMemo(() => {
    return escalatedAlerts
      .filter((a) => a.escalated_at)
      .sort((a, b) => new Date(b.escalated_at!).getTime() - new Date(a.escalated_at!).getTime())
      .slice(0, 4);
  }, [escalatedAlerts]);

  const stats = useMemo(() => {
    const total = escalatedAlerts.length;
    const activeEscalated = escalatedAlerts.filter((a) => a.status === "active").length;
    const resolvedEscalated = escalatedAlerts.filter((a) => a.status === "resolved").length;
    const criticalEscalated = escalatedAlerts.filter((a) => a.severity === "critical").length;

    return { total, activeEscalated, resolvedEscalated, criticalEscalated };
  }, [escalatedAlerts]);

  const getSeverityBadge = (severity: Alert["severity"]) => {
    switch (severity) {
      case "critical":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Critical</Badge>;
      case "high":
        return <Badge className="bg-warning/10 text-warning border-warning/20">High</Badge>;
      case "medium":
        return <Badge className="bg-primary/10 text-primary border-primary/20">Medium</Badge>;
      default:
        return <Badge variant="secondary">Low</Badge>;
    }
  };

  const getOriginalSeverityLabel = (alert: Alert) => {
    if (alert.original_severity && alert.original_severity !== alert.severity) {
      return `from ${alert.original_severity}`;
    }
    return null;
  };

  if (loading) {
    return (
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold">Escalation Statistics</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-warning" />
              Escalation Statistics
            </CardTitle>
            <CardDescription>Auto-escalated alerts overview</CardDescription>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate("/customer/alerts")}
            className="gap-1"
          >
            View All
            <ArrowUpRight className="h-3 w-3" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <p className="text-2xl font-bold text-foreground">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Escalated</p>
          </div>
          <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-3 text-center">
            <p className="text-2xl font-bold text-destructive">{stats.activeEscalated}</p>
            <p className="text-xs text-muted-foreground">Active</p>
          </div>
          <div className="rounded-lg bg-warning/5 border border-warning/20 p-3 text-center">
            <p className="text-2xl font-bold text-warning">{stats.criticalEscalated}</p>
            <p className="text-xs text-muted-foreground">Critical</p>
          </div>
          <div className="rounded-lg bg-success/5 border border-success/20 p-3 text-center">
            <p className="text-2xl font-bold text-success">{stats.resolvedEscalated}</p>
            <p className="text-xs text-muted-foreground">Resolved</p>
          </div>
        </div>

        {/* Recent Escalations */}
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">Recent Escalations</p>
          {recentEscalations.length === 0 ? (
            <div className="flex items-center gap-3 p-3 rounded-lg bg-success/5 border border-success/20">
              <CheckCircle className="h-4 w-4 text-success" />
              <p className="text-sm text-muted-foreground">No recent escalations</p>
            </div>
          ) : (
            <div className="space-y-2">
              {recentEscalations.map((alert) => (
                <div
                  key={alert.id}
                  className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 border border-border hover:bg-muted/80 transition-colors cursor-pointer"
                  onClick={() => navigate("/customer/alerts")}
                >
                  <AlertTriangle className={`h-4 w-4 shrink-0 ${
                    alert.severity === "critical" ? "text-destructive" : "text-warning"
                  }`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{alert.title}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {alert.escalated_at && formatDistanceToNow(new Date(alert.escalated_at), { addSuffix: true })}
                      {getOriginalSeverityLabel(alert) && (
                        <span className="text-warning">• Escalated {getOriginalSeverityLabel(alert)}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {getSeverityBadge(alert.severity)}
                    {(alert.escalation_count ?? 0) > 1 && (
                      <Badge variant="outline" className="text-xs">
                        ×{alert.escalation_count}
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default EscalationStatsWidget;
