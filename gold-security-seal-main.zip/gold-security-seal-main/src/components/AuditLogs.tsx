import { useState, useEffect } from "react";
import { History, Shield, Loader2, FileText, UserCog, RefreshCw, Filter } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface AuditLog {
  id: string;
  user_id: string | null;
  user_name: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  entity_name: string | null;
  details: Record<string, unknown>;
  created_at: string;
}

const AuditLogs = () => {
  const { user } = useAuth();
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [filter, setFilter] = useState<string>("all");

  useEffect(() => {
    if (!user) return;
    checkAdminAndFetchLogs();
  }, [user]);

  const checkAdminAndFetchLogs = async () => {
    if (!user) return;

    const { data: roleData } = await supabase.rpc("has_role", {
      _user_id: user.id,
      _role: "admin",
    });

    setIsAdmin(roleData === true);

    if (roleData === true) {
      await fetchLogs();
    }
    setIsLoading(false);
  };

  const fetchLogs = async () => {
    let query = supabase
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100);

    if (filter !== "all") {
      query = query.eq("entity_type", filter);
    }

    const { data, error } = await query;

    if (error) {
      toast.error("Failed to load audit logs");
      console.error(error);
      return;
    }

    setLogs((data as AuditLog[]) || []);
  };

  useEffect(() => {
    if (isAdmin) {
      fetchLogs();
    }
  }, [filter, isAdmin]);

  const getActionBadgeVariant = (action: string) => {
    switch (action) {
      case "created":
      case "role_assigned":
        return "default";
      case "updated":
      case "role_changed":
      case "status_changed":
        return "secondary";
      case "deleted":
      case "role_removed":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getEntityIcon = (entityType: string) => {
    switch (entityType) {
      case "certificate":
        return <FileText className="w-4 h-4" />;
      case "user_role":
        return <UserCog className="w-4 h-4" />;
      default:
        return <History className="w-4 h-4" />;
    }
  };

  const formatAction = (action: string) => {
    return action
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const formatDetails = (log: AuditLog) => {
    const details = log.details;
    const parts: string[] = [];

    if (details.certificate_id) {
      parts.push(`ID: ${details.certificate_id}`);
    }
    if (details.old_role && details.new_role) {
      parts.push(`${details.old_role} → ${details.new_role}`);
    } else if (details.new_role) {
      parts.push(`Role: ${details.new_role}`);
    } else if (details.old_role) {
      parts.push(`Was: ${details.old_role}`);
    }
    if (details.old_status && details.old_status !== details.status) {
      parts.push(`${details.old_status} → ${details.status}`);
    } else if (details.status) {
      parts.push(`Status: ${details.status}`);
    }

    return parts.join(" • ");
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  if (!isAdmin) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <Shield className="w-12 h-12 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You need administrator privileges to view audit logs.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <History className="w-5 h-5 text-primary" />
              Audit Logs
            </CardTitle>
            <CardDescription>
              Track all actions performed in the system
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-[140px]">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Actions</SelectItem>
                <SelectItem value="certificate">Certificates</SelectItem>
                <SelectItem value="user_role">User Roles</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={fetchLogs}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <History className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No Logs Yet</h3>
            <p className="text-muted-foreground">
              Actions will be recorded here as they happen.
            </p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/30 hover:bg-muted/50 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                    {getEntityIcon(log.entity_type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-foreground">
                        {log.user_name || "System"}
                      </span>
                      <Badge variant={getActionBadgeVariant(log.action)} className="text-xs">
                        {formatAction(log.action)}
                      </Badge>
                      <span className="text-muted-foreground text-sm">
                        {log.entity_type === "certificate" ? "certificate" : "user"}
                      </span>
                    </div>
                    <p className="text-sm text-foreground mt-1 truncate">
                      {log.entity_name || log.entity_id}
                    </p>
                    {formatDetails(log) && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDetails(log)}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatTime(log.created_at)}
                  </span>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};

export default AuditLogs;
