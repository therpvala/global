import { useState, useEffect, useRef } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Camera, X, SwitchCamera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

interface QRCodeScannerProps {
  onScan: (data: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const QRCodeScanner = ({ onScan, isOpen, onClose }: QRCodeScannerProps) => {
  const [isScanning, setIsScanning] = useState(false);
  const [cameras, setCameras] = useState<{ id: string; label: string }[]>([]);
  const [currentCameraIndex, setCurrentCameraIndex] = useState(0);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      Html5Qrcode.getCameras()
        .then((devices) => {
          if (devices && devices.length > 0) {
            setCameras(devices);
            startScanner(devices[0].id);
          } else {
            toast.error("No camera found on this device");
          }
        })
        .catch((err) => {
          console.error("Error getting cameras:", err);
          toast.error("Unable to access camera. Please check permissions.");
        });
    }

    return () => {
      stopScanner();
    };
  }, [isOpen]);

  const startScanner = async (cameraId: string) => {
    try {
      if (scannerRef.current) {
        await stopScanner();
      }

      scannerRef.current = new Html5Qrcode("qr-reader");
      setIsScanning(true);

      await scannerRef.current.start(
        cameraId,
        {
          fps: 10,
          qrbox: { width: 250, height: 250 },
          aspectRatio: 1,
        },
        (decodedText) => {
          // Extract certificate ID from the scanned data
          let certificateId = decodedText;
          
          // Check if it's a URL with an id parameter
          try {
            const url = new URL(decodedText);
            const idParam = url.searchParams.get("id");
            if (idParam) {
              certificateId = idParam;
            }
          } catch {
            // Not a URL, use the raw scanned text
          }

          onScan(certificateId);
          stopScanner();
          onClose();
          toast.success("QR Code scanned successfully!");
        },
        () => {
          // Ignore errors during scanning (no QR found in frame)
        }
      );
    } catch (err) {
      console.error("Error starting scanner:", err);
      toast.error("Failed to start camera scanner");
      setIsScanning(false);
    }
  };

  const stopScanner = async () => {
    if (scannerRef.current && scannerRef.current.isScanning) {
      try {
        await scannerRef.current.stop();
        scannerRef.current.clear();
      } catch (err) {
        console.error("Error stopping scanner:", err);
      }
    }
    setIsScanning(false);
  };

  const switchCamera = async () => {
    if (cameras.length <= 1) return;
    
    const nextIndex = (currentCameraIndex + 1) % cameras.length;
    setCurrentCameraIndex(nextIndex);
    await startScanner(cameras[nextIndex].id);
  };

  const handleClose = async () => {
    await stopScanner();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-foreground">
            <Camera className="w-5 h-5 text-primary" />
            Scan QR Code
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          <div 
            id="qr-reader" 
            ref={containerRef}
            className="w-full rounded-lg overflow-hidden bg-muted/50"
            style={{ minHeight: "300px" }}
          />

          {/* Scanner overlay with corners */}
          {isScanning && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="relative w-[250px] h-[250px]">
                {/* Corner indicators */}
                <div className="absolute top-0 left-0 w-8 h-8 border-l-4 border-t-4 border-primary rounded-tl-lg" />
                <div className="absolute top-0 right-0 w-8 h-8 border-r-4 border-t-4 border-primary rounded-tr-lg" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-l-4 border-b-4 border-primary rounded-bl-lg" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-r-4 border-b-4 border-primary rounded-br-lg" />
                
                {/* Scanning line animation */}
                <div className="absolute inset-x-2 top-0 h-0.5 bg-primary/80 animate-pulse" 
                     style={{ animation: "scanLine 2s ease-in-out infinite" }} />
              </div>
            </div>
          )}
        </div>

        <p className="text-sm text-muted-foreground text-center">
          Position the QR code within the frame to scan
        </p>

        <div className="flex gap-3 justify-center">
          {cameras.length > 1 && (
            <Button
              variant="outline"
              size="sm"
              onClick={switchCamera}
              className="gap-2 border-border"
            >
              <SwitchCamera className="w-4 h-4" />
              Switch Camera
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={handleClose}
            className="gap-2 border-border"
          >
            <X className="w-4 h-4" />
            Cancel
          </Button>
        </div>

        <style>{`
          @keyframes scanLine {
            0%, 100% { transform: translateY(0); opacity: 1; }
            50% { transform: translateY(248px); opacity: 0.5; }
          }
          #qr-reader video {
            border-radius: 0.5rem;
          }
          #qr-reader__scan_region {
            background: transparent !important;
          }
          #qr-reader__dashboard {
            display: none !important;
          }
        `}</style>
      </DialogContent>
    </Dialog>
  );
};

export default QRCodeScanner;
