import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Profile } from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { addYears, format } from "date-fns";

interface CertificateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profile: Profile | null;
  onSuccess: () => void;
}

export function CertificateDialog({ open, onOpenChange, profile, onSuccess }: CertificateDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [scores, setScores] = useState({ ssl: 85, server: 80, dns: 90 });

  const generateCertificateId = () => {
    const prefix = "CERT";
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${prefix}-${timestamp}-${random}`;
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const websiteName = formData.get("websiteName") as string;
    const ownerName = formData.get("ownerName") as string;
    const riskLevel = formData.get("riskLevel") as string;
    const validityYears = parseInt(formData.get("validityYears") as string);

    const overallScore = Math.round((scores.ssl + scores.server + scores.dns) / 3);
    const expiryDate = addYears(new Date(), validityYears);

    const { error } = await supabase.from("certificates").insert({
      certificate_id: generateCertificateId(),
      website_name: websiteName,
      owner_name: ownerName,
      score: overallScore,
      ssl_score: scores.ssl,
      server_score: scores.server,
      dns_score: scores.dns,
      risk_level: riskLevel,
      status: "active",
      expiry_date: format(expiryDate, "yyyy-MM-dd"),
      auditor_name: profile?.full_name || "Unknown",
      auditor_initials: profile?.initials || "XX",
      auditor_title: profile?.title || "Auditor",
    });

    setLoading(false);

    if (error) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } else {
      onSuccess();
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Create New Certificate</DialogTitle>
          <DialogDescription>
            Issue a new security certificate for a website
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="websiteName">Website Name</Label>
              <Input id="websiteName" name="websiteName" placeholder="example.com" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ownerName">Owner Name</Label>
              <Input id="ownerName" name="ownerName" placeholder="Company Inc." required />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="riskLevel">Risk Level</Label>
              <Select name="riskLevel" defaultValue="low">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="validityYears">Validity (Years)</Label>
              <Select name="validityYears" defaultValue="1">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Year</SelectItem>
                  <SelectItem value="2">2 Years</SelectItem>
                  <SelectItem value="3">3 Years</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t">
            <h4 className="font-medium">Security Scores</h4>
            <ScoreSlider
              label="SSL/TLS Score"
              value={scores.ssl}
              onChange={(v) => setScores((s) => ({ ...s, ssl: v }))}
            />
            <ScoreSlider
              label="Server Security Score"
              value={scores.server}
              onChange={(v) => setScores((s) => ({ ...s, server: v }))}
            />
            <ScoreSlider
              label="DNS Security Score"
              value={scores.dns}
              onChange={(v) => setScores((s) => ({ ...s, dns: v }))}
            />
            <div className="flex justify-between items-center p-3 bg-muted rounded-lg">
              <span className="font-medium">Overall Score</span>
              <span className="text-2xl font-bold text-primary">
                {Math.round((scores.ssl + scores.server + scores.dns) / 3)}/100
              </span>
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Create Certificate
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ScoreSlider({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between">
        <Label>{label}</Label>
        <span className="text-sm font-medium">{value}/100</span>
      </div>
      <Slider
        value={[value]}
        onValueChange={([v]) => onChange(v)}
        max={100}
        min={0}
        step={1}
      />
    </div>
  );
}
