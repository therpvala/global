import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  expiry_date: string;
}

interface EditCertificateDialogProps {
  certificate: Certificate | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (id: string, updates: Partial<Certificate>) => Promise<void>;
}

const EditCertificateDialog = ({ certificate, open, onOpenChange, onSave }: EditCertificateDialogProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    website_name: "",
    owner_name: "",
    score: 0,
    risk_level: "low",
    expiry_date: "",
  });

  // Update form when certificate changes
  useState(() => {
    if (certificate) {
      setFormData({
        website_name: certificate.website_name,
        owner_name: certificate.owner_name,
        score: certificate.score,
        risk_level: certificate.risk_level,
        expiry_date: certificate.expiry_date.split("T")[0],
      });
    }
  });

  const handleOpenChange = (newOpen: boolean) => {
    if (newOpen && certificate) {
      setFormData({
        website_name: certificate.website_name,
        owner_name: certificate.owner_name,
        score: certificate.score,
        risk_level: certificate.risk_level,
        expiry_date: certificate.expiry_date.split("T")[0],
      });
    }
    onOpenChange(newOpen);
  };

  const handleSave = async () => {
    if (!certificate) return;
    
    setIsLoading(true);
    await onSave(certificate.id, formData);
    setIsLoading(false);
    onOpenChange(false);
  };

  if (!certificate) return null;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Edit Certificate</DialogTitle>
          <DialogDescription>
            Update certificate {certificate.certificate_id}
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="website_name">Website Name</Label>
            <Input
              id="website_name"
              value={formData.website_name}
              onChange={(e) => setFormData({ ...formData, website_name: e.target.value })}
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="owner_name">Owner Name</Label>
            <Input
              id="owner_name"
              value={formData.owner_name}
              onChange={(e) => setFormData({ ...formData, owner_name: e.target.value })}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="score">Security Score</Label>
              <Input
                id="score"
                type="number"
                min="0"
                max="100"
                value={formData.score}
                onChange={(e) => setFormData({ ...formData, score: parseInt(e.target.value) || 0 })}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="risk_level">Risk Level</Label>
              <Select value={formData.risk_level} onValueChange={(value) => setFormData({ ...formData, risk_level: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="expiry_date">Expiry Date</Label>
            <Input
              id="expiry_date"
              type="date"
              value={formData.expiry_date}
              onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Save Changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditCertificateDialog;
