import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield, Globe, User, Calendar, ArrowRight, Sparkles } from "lucide-react";
import ShieldWatermark from "../certificate/ShieldWatermark";
import { useAuth } from "@/hooks/useAuth";

const certificateFormSchema = z.object({
  websiteName: z
    .string()
    .trim()
    .min(2, { message: "Website name must be at least 2 characters" })
    .max(100, { message: "Website name must be less than 100 characters" })
    .regex(/^[a-zA-Z0-9\s\-_.]+$/, { message: "Only letters, numbers, spaces, hyphens, underscores, and dots allowed" }),
  ownerName: z
    .string()
    .trim()
    .min(2, { message: "Owner name must be at least 2 characters" })
    .max(100, { message: "Owner name must be less than 100 characters" })
    .regex(/^[a-zA-Z\s\-'.]+$/, { message: "Only letters, spaces, hyphens, apostrophes allowed" }),
  securityScore: z
    .number()
    .min(0, { message: "Score must be at least 0" })
    .max(100, { message: "Score must be at most 100" }),
  sslScore: z
    .number()
    .min(0)
    .max(100),
  dnsScore: z
    .number()
    .min(0)
    .max(100),
  serverScore: z
    .number()
    .min(0)
    .max(100),
  validityPeriod: z
    .string()
    .min(1, { message: "Please select a validity period" }),
  auditorInitials: z
    .string()
    .trim()
    .min(1, { message: "Initials required" })
    .max(5, { message: "Initials must be 5 characters or less" })
    .regex(/^[A-Z]+$/, { message: "Only uppercase letters allowed" }),
  auditorName: z
    .string()
    .trim()
    .min(2, { message: "Auditor name must be at least 2 characters" })
    .max(100, { message: "Auditor name must be less than 100 characters" })
    .regex(/^[a-zA-Z\s\-'.]+$/, { message: "Only letters, spaces, hyphens, apostrophes allowed" }),
  auditorTitle: z
    .string()
    .trim()
    .min(2, { message: "Title must be at least 2 characters" })
    .max(100, { message: "Title must be less than 100 characters" }),
});

export type CertificateFormData = z.infer<typeof certificateFormSchema>;

interface CertificateGeneratorFormProps {
  onGenerate: (data: CertificateFormData) => void;
}

const CertificateGeneratorForm = ({ onGenerate }: CertificateGeneratorFormProps) => {
  const { profile } = useAuth();
  
  const form = useForm<CertificateFormData>({
    resolver: zodResolver(certificateFormSchema),
    defaultValues: {
      websiteName: "",
      ownerName: "",
      securityScore: 85,
      sslScore: 80,
      dnsScore: 60,
      serverScore: 75,
      validityPeriod: "12",
      auditorInitials: profile?.initials || "NA",
      auditorName: profile?.full_name || "New Auditor",
      auditorTitle: profile?.title || "Security Auditor",
    },
  });

  // Update form when profile loads
  useEffect(() => {
    if (profile) {
      form.setValue('auditorInitials', profile.initials);
      form.setValue('auditorName', profile.full_name);
      form.setValue('auditorTitle', profile.title);
    }
  }, [profile, form]);

  const getRiskLevel = (score: number): "low" | "medium" | "high" => {
    if (score >= 70) return "low";
    if (score >= 40) return "medium";
    return "high";
  };

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-success";
    if (score >= 40) return "text-warning";
    return "text-destructive";
  };

  const onSubmit = (data: CertificateFormData) => {
    onGenerate(data);
  };

  return (
    <div className="certificate-page min-h-screen py-8 px-4">
      <ShieldWatermark />
      
      <div className="max-w-3xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex justify-center items-center gap-4 mb-4">
            <Sparkles className="w-8 h-8 text-primary" />
            <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              CERTIFICATE GENERATOR
            </h1>
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
          <p className="text-muted-foreground">
            Generate custom security verification certificates
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Website Details Card */}
            <Card className="gradient-card shadow-card animate-slide-up border-0">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center">
                    <Globe className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-card-foreground">Website Details</CardTitle>
                    <CardDescription>Enter the website or application information</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="websiteName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-card-foreground">Website / App Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., TechSecure Solutions" 
                          className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground placeholder:text-muted-foreground"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="ownerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-card-foreground">Owner / Manager Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., John Anderson" 
                          className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground placeholder:text-muted-foreground"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Security Scores Card */}
            <Card className="gradient-card shadow-card animate-slide-up animation-delay-100 border-0">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center">
                    <Shield className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-card-foreground">Security Scores</CardTitle>
                    <CardDescription>Set the security assessment scores</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <FormField
                  control={form.control}
                  name="securityScore"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex justify-between items-center mb-2">
                        <FormLabel className="text-card-foreground">Overall Security Score</FormLabel>
                        <span className={`text-2xl font-bold ${getRiskColor(field.value)}`}>
                          {field.value}/100
                        </span>
                      </div>
                      <FormControl>
                        <Slider
                          value={[field.value]}
                          onValueChange={(value) => field.onChange(value[0])}
                          max={100}
                          step={1}
                          className="w-full"
                        />
                      </FormControl>
                      <FormDescription className={getRiskColor(field.value)}>
                        Risk Level: {getRiskLevel(field.value).toUpperCase()}
                      </FormDescription>
                    </FormItem>
                  )}
                />

                <div className="grid md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="sslScore"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center mb-2">
                          <FormLabel className="text-card-foreground text-sm">SSL Score</FormLabel>
                          <span className="font-semibold text-card-foreground">{field.value}%</span>
                        </div>
                        <FormControl>
                          <Slider
                            value={[field.value]}
                            onValueChange={(value) => field.onChange(value[0])}
                            max={100}
                            step={1}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="dnsScore"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center mb-2">
                          <FormLabel className="text-card-foreground text-sm">DNS Score</FormLabel>
                          <span className="font-semibold text-card-foreground">{field.value}%</span>
                        </div>
                        <FormControl>
                          <Slider
                            value={[field.value]}
                            onValueChange={(value) => field.onChange(value[0])}
                            max={100}
                            step={1}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="serverScore"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center mb-2">
                          <FormLabel className="text-card-foreground text-sm">Server Score</FormLabel>
                          <span className="font-semibold text-card-foreground">{field.value}%</span>
                        </div>
                        <FormControl>
                          <Slider
                            value={[field.value]}
                            onValueChange={(value) => field.onChange(value[0])}
                            max={100}
                            step={1}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Certificate Settings Card */}
            <Card className="gradient-card shadow-card animate-slide-up animation-delay-200 border-0">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center">
                    <Calendar className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-card-foreground">Certificate Settings</CardTitle>
                    <CardDescription>Configure validity and certification details</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="validityPeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-card-foreground">Validity Period</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground">
                            <SelectValue placeholder="Select validity period" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="3">3 Months</SelectItem>
                          <SelectItem value="6">6 Months</SelectItem>
                          <SelectItem value="12">12 Months</SelectItem>
                          <SelectItem value="24">24 Months</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>

            {/* Auditor Details Card */}
            <Card className="gradient-card shadow-card animate-slide-up animation-delay-300 border-0">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center">
                    <User className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-card-foreground">Auditor Details</CardTitle>
                    <CardDescription>Signature and certification authority</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="auditorInitials"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-card-foreground">Initials</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="MK" 
                            className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground placeholder:text-muted-foreground uppercase"
                            maxLength={5}
                            {...field}
                            onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="auditorName"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <FormLabel className="text-card-foreground">Full Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Manoj Kumar" 
                            className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground placeholder:text-muted-foreground"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="auditorTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-card-foreground">Title / Position</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Chief Security Auditor" 
                          className="bg-card-foreground/5 border-card-foreground/20 text-card-foreground placeholder:text-muted-foreground"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Signature Preview */}
                <div className="mt-4 p-4 bg-card-foreground/5 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-2">Signature Preview</p>
                  <div className="flex flex-col items-end">
                    <div className="font-signature text-4xl text-primary">
                      {form.watch("auditorInitials") || "MK"}
                    </div>
                    <div className="w-24 h-px bg-card-foreground/30 my-1" />
                    <p className="text-sm font-semibold text-card-foreground">
                      {form.watch("auditorName") || "Manoj Kumar"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {form.watch("auditorTitle") || "Chief Security Auditor"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Submit Button */}
            <Button 
              type="submit" 
              size="lg"
              className="w-full gradient-gold text-primary-foreground hover:opacity-90 shadow-gold font-semibold text-lg py-6"
            >
              Generate Certificate
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
};

export default CertificateGeneratorForm;
