import ShieldWatermark from "../certificate/ShieldWatermark";
import SignatureBlock from "../certificate/SignatureBlock";
import { Shield, Server, Globe, Lock, Database, Calendar, Star } from "lucide-react";

interface ActionItem {
  text: string;
}

interface ActionSection {
  icon: React.ReactNode;
  title: string;
  items: ActionItem[];
}

interface SafetyActionPlanProps {
  auditorInitials?: string;
  auditorName?: string;
  auditorTitle?: string;
}

const SafetyActionPlan = ({
  auditorInitials = "MK",
  auditorName = "Manoj Kumar",
  auditorTitle = "Chief Security Auditor",
}: SafetyActionPlanProps) => {
  const sections: ActionSection[] = [
    {
      icon: <Server className="w-5 h-5" />,
      title: "SERVER",
      items: [
        { text: "Enable daily encrypted backup" },
        { text: "Limit SSH to IP whitelist" },
        { text: "Update firewall rules quarterly" },
      ],
    },
    {
      icon: <Globe className="w-5 h-5" />,
      title: "WEBSITE / APPLICATION",
      items: [
        { text: "Upgrade CSRF security tokens" },
        { text: "Enable WAF protection" },
        { text: "Remove unused scripts & plugins" },
        { text: "Enable 2FA for admin" },
      ],
    },
    {
      icon: <Shield className="w-5 h-5" />,
      title: "DOMAIN & DNS",
      items: [
        { text: "Enable DNSSEC" },
        { text: "Configure failover DNS" },
        { text: "Lock nameserver changes" },
        { text: "Activate WHOIS privacy" },
      ],
    },
    {
      icon: <Lock className="w-5 h-5" />,
      title: "SSL & API",
      items: [
        { text: "Upgrade to Wildcard or EV SSL" },
        { text: "Enable auto SSL renewal" },
        { text: "Add API rate limiting" },
      ],
    },
    {
      icon: <Database className="w-5 h-5" />,
      title: "DATA PROTECTION",
      items: [
        { text: "Encrypt sensitive tables" },
        { text: "Enable intrusion alerts" },
        { text: "Maintain audit logs" },
      ],
    },
  ];

  const getNextAuditDate = () => {
    const date = new Date();
    date.setMonth(date.getMonth() + 1);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  return (
    <div className="certificate-page min-h-screen py-8 px-4">
      <ShieldWatermark />
      
      <div className="max-w-4xl mx-auto relative z-10 space-y-6">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex justify-center items-center gap-4 mb-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              SAFETY ACTION PLAN
            </h1>
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-lg md:text-xl font-semibold text-primary">
            & SUGGESTIONS
          </h2>
        </div>

        {/* Action Sections */}
        {sections.map((section, sectionIndex) => (
          <div 
            key={sectionIndex} 
            className="gradient-card rounded-xl shadow-card p-6 animate-slide-up"
            style={{ animationDelay: `${sectionIndex * 0.1}s` }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg gradient-gold flex items-center justify-center text-primary-foreground">
                {section.icon}
              </div>
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                  {sectionIndex + 1}
                </span>
                <h3 className="text-lg font-bold text-card-foreground">{section.title}</h3>
              </div>
            </div>
            <ul className="space-y-3 ml-12">
              {section.items.map((item, itemIndex) => (
                <li key={itemIndex} className="flex items-start gap-3">
                  <span className="w-2 h-2 mt-2 rounded-full bg-primary" />
                  <span className="text-card-foreground">{item.text}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}

        {/* Recommendation Box */}
        <div className="gradient-gold rounded-xl shadow-gold p-6 text-center animate-scale-in animation-delay-500">
          <div className="flex justify-center mb-3">
            <Star className="w-8 h-8 text-primary-foreground" />
          </div>
          <h3 className="text-xl font-bold text-primary-foreground mb-2">
            RECOMMENDED PLAN
          </h3>
          <p className="text-2xl font-bold text-primary-foreground">
            GOLD MONTHLY SECURITY
          </p>
        </div>

        {/* Next Audit Date */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-fade-in animation-delay-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="w-6 h-6 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Next Scheduled Audit</p>
                <p className="text-lg font-bold text-card-foreground">{getNextAuditDate()}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wider">Frequency</p>
              <p className="text-sm font-semibold text-primary">Monthly</p>
            </div>
          </div>
        </div>

        {/* Signature */}
        <div className="flex justify-end mt-8 animate-fade-in animation-delay-500">
          <SignatureBlock 
            initials={auditorInitials}
            name={auditorName}
            title={auditorTitle}
          />
        </div>

        {/* Footer */}
        <div className="text-center mt-8 animate-fade-in animation-delay-500">
          <p className="text-lg font-bold text-primary tracking-wider">SECUREAUDIT</p>
          <p className="text-xs text-muted-foreground uppercase tracking-widest">
            Official Cyber Security Verification Authority
          </p>
        </div>
      </div>
    </div>
  );
};

export default SafetyActionPlan;
