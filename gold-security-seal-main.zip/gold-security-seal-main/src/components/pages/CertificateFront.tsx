import ShieldWatermark from "../certificate/ShieldWatermark";
import GoldBadge from "../certificate/GoldBadge";
import SecurityChecklist from "../certificate/SecurityChecklist";
import ScoreDisplay from "../certificate/ScoreDisplay";
import StatusBadge from "../certificate/StatusBadge";
import SignatureBlock from "../certificate/SignatureBlock";
import QRCodeSection from "../certificate/QRCodeSection";
import { Shield } from "lucide-react";

interface CertificateFrontProps {
  websiteName: string;
  ownerName: string;
  score: number;
  riskLevel: "low" | "medium" | "high";
  certificateId: string;
  issueDate: string;
  expiryDate: string;
  auditorInitials?: string;
  auditorName?: string;
  auditorTitle?: string;
}

const CertificateFront = ({
  websiteName,
  ownerName,
  score,
  riskLevel,
  certificateId,
  issueDate,
  expiryDate,
  auditorInitials = "MK",
  auditorName = "Manoj Kumar",
  auditorTitle = "Chief Security Auditor",
}: CertificateFrontProps) => {
  const getSecurityChecks = (): { label: string; status: "pass" | "partial" | "fail" }[] => {
    return [
      { label: "Malware & Injection Scan", status: score >= 50 ? "pass" : "fail" },
      { label: "Developer Backdoor Detection", status: score >= 40 ? "pass" : "fail" },
      { label: "SSL Security Validation", status: score >= 60 ? "pass" : "partial" },
      { label: "DNS & Nameserver Check", status: score >= 55 ? "pass" : "partial" },
      { label: "Admin Panel Safety", status: score >= 70 ? "pass" : "partial" },
      { label: "File Integrity Test", status: score >= 65 ? "pass" : "partial" },
      { label: "Server Health Audit", status: score >= 75 ? "pass" : "partial" },
    ];
  };

  const getCertificateLevel = () => {
    if (score >= 85) return "PLATINUM";
    if (score >= 70) return "GOLD";
    if (score >= 50) return "SILVER";
    return "BRONZE";
  };

  const getStatus = () => {
    if (score >= 60) return "certified";
    if (score >= 40) return "warning";
    return "failed";
  };

  return (
    <div className="certificate-page min-h-screen py-8 px-4">
      <ShieldWatermark />
      
      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex justify-center items-center gap-4 mb-4">
            <Shield className="w-10 h-10 text-primary" />
            <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
              CYBER SECURITY
            </h1>
            <Shield className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-xl md:text-2xl font-semibold text-primary">
            VERIFICATION CERTIFICATE
          </h2>
        </div>

        {/* Gold Badge - Top Right */}
        <div className="absolute top-4 right-4 md:right-8 animate-scale-in">
          <GoldBadge type="shield" size="md" />
        </div>

        {/* Main Certificate Card */}
        <div className="gradient-card rounded-2xl shadow-card p-6 md:p-10 animate-slide-up">
          {/* Award Header */}
          <div className="text-center mb-8">
            <p className="text-sm uppercase tracking-widest text-muted-foreground mb-2">
              This Certificate is Awarded To
            </p>
            <h3 className="text-3xl md:text-4xl font-bold text-card-foreground mb-4">
              {websiteName}
            </h3>
            <p className="text-sm text-muted-foreground">
              Owned & Managed By
            </p>
            <p className="text-lg font-semibold text-card-foreground">
              {ownerName}
            </p>
          </div>

          {/* Main Content Grid */}
          <div className="grid md:grid-cols-2 gap-8 mb-8">
            {/* Left Section - Status & Checklist */}
            <div className="space-y-6">
              <StatusBadge status={getStatus()} />
              <div className="bg-card-foreground/5 rounded-xl p-5">
                <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">
                  Security Checks
                </h4>
                <SecurityChecklist items={getSecurityChecks()} />
              </div>
            </div>

            {/* Right Section - Score & Badge */}
            <div className="flex flex-col items-center justify-center space-y-6">
              <ScoreDisplay score={score} riskLevel={riskLevel} />
              
              <div className="text-center">
                <div className="w-24 h-24 rounded-full gradient-gold flex items-center justify-center shadow-gold mx-auto mb-2">
                  <div className="text-center">
                    <span className="block text-lg font-bold text-primary-foreground leading-tight">
                      {getCertificateLevel()}
                    </span>
                  </div>
                </div>
                <p className="text-xs font-bold uppercase tracking-wider text-primary">
                  Security Certificate
                </p>
              </div>
            </div>
          </div>

          {/* Bottom Section */}
          <div className="border-t border-card-foreground/10 pt-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
              <QRCodeSection 
                certificateId={certificateId}
                issueDate={issueDate}
                expiryDate={expiryDate}
              />
              <SignatureBlock 
                initials={auditorInitials}
                name={auditorName}
                title={auditorTitle}
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 animate-fade-in animation-delay-500">
          <p className="text-lg font-bold text-primary tracking-wider">SECUREAUDIT</p>
          <p className="text-xs text-muted-foreground uppercase tracking-widest">
            Official Cyber Security Verification Authority
          </p>
        </div>
      </div>
    </div>
  );
};

export default CertificateFront;
