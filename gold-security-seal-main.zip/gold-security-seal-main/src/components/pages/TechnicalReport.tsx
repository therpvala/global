import ShieldWatermark from "../certificate/ShieldWatermark";
import ProgressBar from "../certificate/ProgressBar";
import SignatureBlock from "../certificate/SignatureBlock";
import { Shield, Lock, Globe, Server, Code, Bug, AlertTriangle } from "lucide-react";

interface VulnerabilityScan {
  name: string;
  status: "PASS" | "PARTIAL" | "FAIL" | "BLOCKED";
}

interface TechnicalReportProps {
  sslScore?: number;
  dnsScore?: number;
  serverScore?: number;
  auditorInitials?: string;
  auditorName?: string;
  auditorTitle?: string;
}

const TechnicalReport = ({
  sslScore = 80,
  dnsScore = 60,
  serverScore = 75,
  auditorInitials = "MK",
  auditorName = "Manoj Kumar",
  auditorTitle = "Chief Security Auditor",
}: TechnicalReportProps) => {
  const sslData = {
    status: sslScore >= 70 ? "Active" : "Partial",
    chain: sslScore >= 60 ? "Valid" : "Issues Found",
    redirect: sslScore >= 50 ? "Enabled" : "Disabled",
    strength: sslScore >= 80 ? "High" : sslScore >= 50 ? "Medium" : "Low",
    score: sslScore,
  };

  const dnsData = {
    dnssec: dnsScore >= 60 ? "Enabled" : "Disabled",
    nameserver: dnsScore >= 50 ? "OK" : "Issues",
    subdomain: dnsScore >= 70 ? "None" : "Potential Leak",
    score: dnsScore,
  };

  const serverData = {
    firewall: serverScore >= 60 ? "Enabled" : "Partial",
    hardening: serverScore >= 80 ? "Complete" : serverScore >= 50 ? "Partial" : "Weak",
    malware: serverScore >= 40 ? "None" : "Detected",
    ports: "22, 443",
    score: serverScore,
  };

  const getVulnerabilities = (): VulnerabilityScan[] => {
    const avgScore = (sslScore + dnsScore + serverScore) / 3;
    return [
      { name: "SQL Injection", status: avgScore >= 50 ? "PASS" : "FAIL" },
      { name: "XSS", status: avgScore >= 45 ? "PASS" : "PARTIAL" },
      { name: "CSRF", status: avgScore >= 70 ? "PASS" : "PARTIAL" },
      { name: "File Upload", status: avgScore >= 55 ? "PASS" : "PARTIAL" },
      { name: "API Abuse", status: avgScore >= 60 ? "PASS" : "PARTIAL" },
      { name: "Admin Panel Brute", status: avgScore >= 40 ? "BLOCKED" : "FAIL" },
    ];
  };

  const backdoorChecks = [
    { name: "Hidden Admin", status: "None" },
    { name: "Cron Scripts", status: "None" },
    { name: "FTP/SFTP Hidden", status: "None" },
    { name: "SSH Injection", status: "None" },
  ];

  const getIssues = () => {
    const issues = [];
    if (dnsScore < 70) issues.push("DNS failover not configured");
    if (sslScore < 80) issues.push("SSL certificate needs upgrade");
    if (serverScore < 75) issues.push("Server hardening incomplete");
    if (issues.length === 0) issues.push("No critical issues found");
    return issues;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PASS":
      case "BLOCKED":
        return "bg-success text-white";
      case "PARTIAL":
        return "bg-warning text-white";
      case "FAIL":
        return "bg-destructive text-white";
      default:
        return "bg-success/20 text-success";
    }
  };

  const getScoreColor = (score: number): "success" | "warning" | "primary" => {
    if (score >= 70) return "success";
    if (score >= 50) return "warning";
    return "primary";
  };

  return (
    <div className="certificate-page min-h-screen py-8 px-4">
      <ShieldWatermark />
      
      <div className="max-w-4xl mx-auto relative z-10 space-y-6">
        {/* Header */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex justify-center items-center gap-4 mb-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-2xl md:text-3xl font-bold text-foreground tracking-tight">
              COMPLETE SECURITY
            </h1>
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-lg md:text-xl font-semibold text-primary">
            DIAGNOSTIC REPORT
          </h2>
        </div>

        {/* SSL Security Card */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-slide-up">
          <div className="flex items-center gap-3 mb-4">
            <Lock className="w-6 h-6 text-primary" />
            <h3 className="text-lg font-bold text-card-foreground">SSL SECURITY CHECK</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div>
              <p className="text-xs text-muted-foreground">SSL Status</p>
              <p className={`font-semibold ${sslData.status === "Active" ? "text-success" : "text-warning"}`}>
                {sslData.status}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Certificate Chain</p>
              <p className="font-semibold text-card-foreground">{sslData.chain}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">HTTPS Redirect</p>
              <p className="font-semibold text-card-foreground">{sslData.redirect}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">TLS Strength</p>
              <p className="font-semibold text-card-foreground">{sslData.strength}</p>
            </div>
          </div>
          <ProgressBar value={sslData.score} label="SSL Score" color={getScoreColor(sslData.score)} />
        </div>

        {/* DNS Security Card */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-slide-up animation-delay-100">
          <div className="flex items-center gap-3 mb-4">
            <Globe className="w-6 h-6 text-primary" />
            <h3 className="text-lg font-bold text-card-foreground">DNS & DOMAIN SECURITY</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div>
              <p className="text-xs text-muted-foreground">DNSSEC</p>
              <p className={`font-semibold ${dnsData.dnssec === "Enabled" ? "text-success" : "text-warning"}`}>
                {dnsData.dnssec}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Nameserver Matching</p>
              <p className={`font-semibold ${dnsData.nameserver === "OK" ? "text-success" : "text-warning"}`}>
                {dnsData.nameserver}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Subdomain Leak</p>
              <p className="font-semibold text-card-foreground">{dnsData.subdomain}</p>
            </div>
          </div>
          <ProgressBar value={dnsData.score} label="DNS Security Score" color={getScoreColor(dnsData.score)} />
        </div>

        {/* Server Security Card */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-slide-up animation-delay-200">
          <div className="flex items-center gap-3 mb-4">
            <Server className="w-6 h-6 text-primary" />
            <h3 className="text-lg font-bold text-card-foreground">HOSTING & SERVER SECURITY</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <div>
              <p className="text-xs text-muted-foreground">Firewall</p>
              <p className={`font-semibold ${serverData.firewall === "Enabled" ? "text-success" : "text-warning"}`}>
                {serverData.firewall}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Server Hardening</p>
              <p className={`font-semibold ${serverData.hardening === "Complete" ? "text-success" : "text-warning"}`}>
                {serverData.hardening}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Malware Files</p>
              <p className={`font-semibold ${serverData.malware === "None" ? "text-success" : "text-destructive"}`}>
                {serverData.malware}
              </p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Open Ports</p>
              <p className="font-semibold text-card-foreground font-mono">{serverData.ports}</p>
            </div>
          </div>
          <ProgressBar value={serverData.score} label="Server Score" color={getScoreColor(serverData.score)} />
        </div>

        {/* Vulnerability Scan Card */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-slide-up animation-delay-300">
          <div className="flex items-center gap-3 mb-4">
            <Code className="w-6 h-6 text-primary" />
            <h3 className="text-lg font-bold text-card-foreground">APPLICATION VULNERABILITY SCAN</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-card-foreground/10">
                  <th className="text-left py-2 text-sm text-muted-foreground font-medium">Vulnerability</th>
                  <th className="text-right py-2 text-sm text-muted-foreground font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {getVulnerabilities().map((item, index) => (
                  <tr key={index} className="border-b border-card-foreground/5">
                    <td className="py-3 text-sm font-medium text-card-foreground">{item.name}</td>
                    <td className="py-3 text-right">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Backdoor Check Card */}
        <div className="gradient-card rounded-xl shadow-card p-6 animate-slide-up animation-delay-400">
          <div className="flex items-center gap-3 mb-4">
            <Bug className="w-6 h-6 text-primary" />
            <h3 className="text-lg font-bold text-card-foreground">DEVELOPER BACKDOOR CHECK</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            {backdoorChecks.map((check, index) => (
              <div key={index}>
                <p className="text-xs text-muted-foreground">{check.name}</p>
                <p className="font-semibold text-success">{check.status}</p>
              </div>
            ))}
          </div>
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-success/10 border border-success/30">
            <span className="text-sm font-bold text-success">Overall Backdoor Risk: SAFE</span>
          </div>
        </div>

        {/* Issues Alert */}
        <div className="bg-warning/10 border border-warning/30 rounded-xl p-6 animate-slide-up animation-delay-500">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-6 h-6 text-warning" />
            <h3 className="text-lg font-bold text-warning">ISSUES & RECOMMENDATIONS</h3>
          </div>
          <ul className="space-y-2">
            {getIssues().map((issue, index) => (
              <li key={index} className="flex items-center gap-2 text-foreground">
                <span className="w-2 h-2 rounded-full bg-warning" />
                <span className="text-sm">{issue}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Signature */}
        <div className="flex justify-end mt-8 animate-fade-in animation-delay-500">
          <SignatureBlock 
            initials={auditorInitials}
            name={auditorName}
            title={auditorTitle}
          />
        </div>
      </div>
    </div>
  );
};

export default TechnicalReport;
