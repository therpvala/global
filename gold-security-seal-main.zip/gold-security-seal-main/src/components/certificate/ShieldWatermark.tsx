import { Shield } from "lucide-react";

const ShieldWatermark = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <Shield 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] text-foreground/[0.02]" 
        strokeWidth={0.5}
      />
      <div className="absolute top-10 left-10 w-32 h-32 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-20 right-20 w-40 h-40 rounded-full bg-primary/5 blur-3xl" />
    </div>
  );
};

export default ShieldWatermark;
