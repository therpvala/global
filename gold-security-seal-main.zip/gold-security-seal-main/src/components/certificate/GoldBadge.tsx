import { Shield, Award } from "lucide-react";

interface GoldBadgeProps {
  type?: "shield" | "award";
  size?: "sm" | "md" | "lg";
  label?: string;
}

const GoldBadge = ({ type = "shield", size = "md", label }: GoldBadgeProps) => {
  const sizeClasses = {
    sm: "w-12 h-12",
    md: "w-20 h-20",
    lg: "w-28 h-28",
  };

  const iconSizes = {
    sm: 24,
    md: 40,
    lg: 56,
  };

  const Icon = type === "shield" ? Shield : Award;

  return (
    <div className="relative inline-flex flex-col items-center">
      <div 
        className={`${sizeClasses[size]} rounded-full gradient-gold flex items-center justify-center shadow-gold animate-pulse-gold`}
      >
        <Icon size={iconSizes[size]} className="text-primary-foreground" strokeWidth={1.5} />
      </div>
      {label && (
        <span className="mt-2 text-xs font-semibold text-primary uppercase tracking-wider text-center max-w-[100px]">
          {label}
        </span>
      )}
    </div>
  );
};

export default GoldBadge;
