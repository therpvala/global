interface ProgressBarProps {
  value: number;
  label: string;
  color?: "success" | "warning" | "primary";
}

const ProgressBar = ({ value, label, color = "primary" }: ProgressBarProps) => {
  const colorClasses = {
    success: "bg-success",
    warning: "bg-warning",
    primary: "bg-primary",
  };

  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-sm">
        <span className="text-card-foreground font-medium">{label}</span>
        <span className="text-muted-foreground font-semibold">{value}%</span>
      </div>
      <div className="progress-bar">
        <div 
          className={`progress-fill ${colorClasses[color]}`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
};

export default ProgressBar;
