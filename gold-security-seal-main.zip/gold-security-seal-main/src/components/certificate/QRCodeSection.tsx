import { QrCode, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";

interface QRCodeSectionProps {
  certificateId: string;
  issueDate: string;
  expiryDate: string;
}

const QRCodeSection = ({ certificateId, issueDate, expiryDate }: QRCodeSectionProps) => {
  const verifyUrl = `/verify?id=${encodeURIComponent(certificateId)}`;

  return (
    <div className="flex items-center gap-6">
      <div className="flex flex-col items-center">
        <Link 
          to={verifyUrl}
          className="w-24 h-24 bg-card-foreground/5 rounded-lg flex items-center justify-center border-2 border-dashed border-card-foreground/20 hover:border-primary/50 hover:bg-primary/5 transition-colors cursor-pointer"
        >
          <QrCode className="w-16 h-16 text-card-foreground/40" />
        </Link>
        <Link 
          to={verifyUrl}
          className="mt-2 text-xs text-muted-foreground flex items-center gap-1 hover:text-primary transition-colors"
        >
          VERIFY CERTIFICATE <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
      
      <div className="space-y-2 text-sm">
        <div>
          <span className="text-muted-foreground">Certificate ID:</span>
          <Link to={verifyUrl} className="ml-2 font-mono font-semibold text-card-foreground hover:text-primary transition-colors">
            {certificateId}
          </Link>
        </div>
        <div>
          <span className="text-muted-foreground">Issue Date:</span>
          <span className="ml-2 font-semibold text-card-foreground">{issueDate}</span>
        </div>
        <div>
          <span className="text-muted-foreground">Expiry Date:</span>
          <span className="ml-2 font-semibold text-card-foreground">{expiryDate}</span>
        </div>
      </div>
    </div>
  );
};

export default QRCodeSection;
