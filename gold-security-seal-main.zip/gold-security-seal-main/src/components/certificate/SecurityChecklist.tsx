import { Check, AlertTriangle, X } from "lucide-react";

interface CheckItem {
  label: string;
  status: "pass" | "partial" | "fail";
}

interface SecurityChecklistProps {
  items: CheckItem[];
}

const SecurityChecklist = ({ items }: SecurityChecklistProps) => {
  const getStatusIcon = (status: CheckItem["status"]) => {
    switch (status) {
      case "pass":
        return <Check className="w-4 h-4 text-success" />;
      case "partial":
        return <AlertTriangle className="w-4 h-4 text-warning" />;
      case "fail":
        return <X className="w-4 h-4 text-destructive" />;
    }
  };

  const getStatusColor = (status: CheckItem["status"]) => {
    switch (status) {
      case "pass":
        return "bg-success";
      case "partial":
        return "bg-warning";
      case "fail":
        return "bg-destructive";
    }
  };

  return (
    <div className="space-y-3">
      {items.map((item, index) => (
        <div 
          key={index} 
          className="flex items-center gap-3 animate-fade-in"
          style={{ animationDelay: `${index * 0.1}s` }}
        >
          <div className={`w-6 h-6 rounded-full ${getStatusColor(item.status)} flex items-center justify-center`}>
            {getStatusIcon(item.status)}
          </div>
          <span className="text-sm font-medium text-card-foreground">{item.label}</span>
        </div>
      ))}
    </div>
  );
};

export default SecurityChecklist;
