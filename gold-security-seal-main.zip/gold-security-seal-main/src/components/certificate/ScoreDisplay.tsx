interface ScoreDisplayProps {
  score: number;
  maxScore?: number;
  riskLevel: "low" | "medium" | "high";
}

const ScoreDisplay = ({ score, maxScore = 100, riskLevel }: ScoreDisplayProps) => {
  const riskColors = {
    low: "text-risk-low",
    medium: "text-risk-medium",
    high: "text-risk-high",
  };

  const riskBgColors = {
    low: "bg-risk-low",
    medium: "bg-risk-medium",
    high: "bg-risk-high",
  };

  const riskLabels = {
    low: "LOW RISK",
    medium: "MEDIUM RISK",
    high: "HIGH RISK",
  };

  const circumference = 2 * Math.PI * 45;
  const progress = (score / maxScore) * circumference;

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-32 h-32">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="64"
            cy="64"
            r="45"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            className="text-muted/30"
          />
          <circle
            cx="64"
            cy="64"
            r="45"
            stroke="currentColor"
            strokeWidth="8"
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - progress}
            strokeLinecap="round"
            className={riskColors[riskLevel]}
            style={{ transition: "stroke-dashoffset 1.5s ease-out" }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-3xl font-bold text-card-foreground">{score}</span>
          <span className="text-xs text-muted-foreground">/ {maxScore}</span>
        </div>
      </div>
      <div className={`mt-3 px-4 py-1.5 rounded-full ${riskBgColors[riskLevel]} text-white text-xs font-bold uppercase tracking-wider`}>
        {riskLabels[riskLevel]}
      </div>
    </div>
  );
};

export default ScoreDisplay;
