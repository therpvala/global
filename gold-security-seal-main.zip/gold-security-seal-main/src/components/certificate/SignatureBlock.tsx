interface SignatureBlockProps {
  initials: string;
  name: string;
  title: string;
}

const SignatureBlock = ({ initials, name, title }: SignatureBlockProps) => {
  return (
    <div className="flex flex-col items-end">
      <div className="font-signature text-5xl text-primary mb-1">{initials}</div>
      <div className="w-32 h-px bg-card-foreground/30 mb-2" />
      <p className="text-sm font-semibold text-card-foreground">{name}</p>
      <p className="text-xs text-muted-foreground">{title}</p>
    </div>
  );
};

export default SignatureBlock;
