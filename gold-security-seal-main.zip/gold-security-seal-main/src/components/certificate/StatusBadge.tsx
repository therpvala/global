import { ShieldCheck, AlertTriangle, ShieldX } from "lucide-react";

interface StatusBadgeProps {
  status: "certified" | "warning" | "failed";
  label?: string;
}

const StatusBadge = ({ status, label }: StatusBadgeProps) => {
  const configs = {
    certified: {
      icon: ShieldCheck,
      bg: "bg-success/10",
      border: "border-success/30",
      text: "text-success",
      label: label || "CERTIFIED & VERIFIED",
    },
    warning: {
      icon: AlertTriangle,
      bg: "bg-warning/10",
      border: "border-warning/30",
      text: "text-warning",
      label: label || "NEEDS ATTENTION",
    },
    failed: {
      icon: ShieldX,
      bg: "bg-destructive/10",
      border: "border-destructive/30",
      text: "text-destructive",
      label: label || "SECURITY FAILED",
    },
  };

  const config = configs[status];
  const Icon = config.icon;

  return (
    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${config.bg} border ${config.border}`}>
      <Icon className={`w-5 h-5 ${config.text}`} />
      <span className={`text-sm font-bold uppercase tracking-wider ${config.text}`}>
        {config.label}
      </span>
    </div>
  );
};

export default StatusBadge;
