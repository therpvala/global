import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2, RefreshCw } from "lucide-react";
import { format, addMonths, addYears } from "date-fns";
import { cn } from "@/lib/utils";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  expiry_date: string;
}

interface RenewCertificateDialogProps {
  certificate: Certificate | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onRenew: (id: string, newExpiryDate: string) => Promise<void>;
}

const RenewCertificateDialog = ({ certificate, open, onOpenChange, onRenew }: RenewCertificateDialogProps) => {
  const [isLoading, setIsLoading] = useState(false);
  const [renewalPeriod, setRenewalPeriod] = useState("1year");
  const [customDate, setCustomDate] = useState<Date | undefined>(undefined);

  const getNewExpiryDate = (): Date => {
    const currentExpiry = certificate ? new Date(certificate.expiry_date) : new Date();
    const baseDate = currentExpiry > new Date() ? currentExpiry : new Date();

    switch (renewalPeriod) {
      case "3months":
        return addMonths(baseDate, 3);
      case "6months":
        return addMonths(baseDate, 6);
      case "1year":
        return addYears(baseDate, 1);
      case "2years":
        return addYears(baseDate, 2);
      case "custom":
        return customDate || addYears(baseDate, 1);
      default:
        return addYears(baseDate, 1);
    }
  };

  const handleRenew = async () => {
    if (!certificate) return;

    setIsLoading(true);
    const newExpiryDate = getNewExpiryDate().toISOString().split("T")[0];
    await onRenew(certificate.id, newExpiryDate);
    setIsLoading(false);
    onOpenChange(false);
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setRenewalPeriod("1year");
      setCustomDate(undefined);
    }
    onOpenChange(newOpen);
  };

  if (!certificate) return null;

  const currentExpiry = new Date(certificate.expiry_date);
  const isExpired = currentExpiry < new Date();
  const newExpiryDate = getNewExpiryDate();

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[450px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-primary" />
            Renew Certificate
          </DialogTitle>
          <DialogDescription>
            Extend the expiry date for {certificate.certificate_id}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="p-4 rounded-lg bg-muted/50 border border-border">
            <p className="text-sm text-muted-foreground mb-1">Website</p>
            <p className="font-medium text-foreground">{certificate.website_name}</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-muted/50 border border-border">
              <p className="text-sm text-muted-foreground mb-1">Current Expiry</p>
              <p className={cn("font-medium", isExpired ? "text-destructive" : "text-foreground")}>
                {format(currentExpiry, "dd MMM yyyy")}
                {isExpired && <span className="text-xs ml-1">(Expired)</span>}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-primary/10 border border-primary/30">
              <p className="text-sm text-muted-foreground mb-1">New Expiry</p>
              <p className="font-medium text-primary">{format(newExpiryDate, "dd MMM yyyy")}</p>
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="renewal_period">Renewal Period</Label>
            <Select value={renewalPeriod} onValueChange={setRenewalPeriod}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3months">3 Months</SelectItem>
                <SelectItem value="6months">6 Months</SelectItem>
                <SelectItem value="1year">1 Year</SelectItem>
                <SelectItem value="2years">2 Years</SelectItem>
                <SelectItem value="custom">Custom Date</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {renewalPeriod === "custom" && (
            <div className="grid gap-2">
              <Label>Custom Expiry Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !customDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {customDate ? format(customDate, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={customDate}
                    onSelect={setCustomDate}
                    disabled={(date) => date < new Date()}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isLoading}>
            Cancel
          </Button>
          <Button onClick={handleRenew} disabled={isLoading || (renewalPeriod === "custom" && !customDate)}>
            {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
            Renew Certificate
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RenewCertificateDialog;
