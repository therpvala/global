import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles, Shield, AlertTriangle, CheckCircle, ArrowRight, History, Clock, GitCompare } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ScrollArea } from "@/components/ui/scroll-area";
import AIAnalysisComparison from "./AIAnalysisComparison";
interface Certificate {
  id?: string;
  certificate_id?: string;
  website_name: string;
  owner_name?: string;
  score: number;
  risk_level: string;
  status?: string;
  expiry_date?: string;
  ssl_score?: number;
  dns_score?: number;
  server_score?: number;
}

interface Recommendation {
  priority: "high" | "medium" | "low";
  category: string;
  title: string;
  description: string;
}

interface AnalysisResult {
  summary: string;
  risk_assessment: string;
  recommendations: Recommendation[];
  immediate_actions: string[];
  long_term_improvements: string[];
}

interface SavedAnalysis {
  id: string;
  analysis: AnalysisResult;
  created_at: string;
}

interface AISecurityAnalysisProps {
  certificate: Certificate;
  onClose?: () => void;
}

const AISecurityAnalysis = ({ certificate, onClose }: AISecurityAnalysisProps) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [pastAnalyses, setPastAnalyses] = useState<SavedAnalysis[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [selectedHistoryId, setSelectedHistoryId] = useState<string | null>(null);

  // Load past analyses when component mounts
  useEffect(() => {
    if (certificate.id) {
      loadPastAnalyses();
    }
  }, [certificate.id]);

  const loadPastAnalyses = async () => {
    if (!certificate.id) return;
    
    setIsLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from("certificate_analyses")
        .select("id, analysis, created_at")
        .eq("certificate_id", certificate.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) throw error;
      
      // Map data to our interface
      const mappedData: SavedAnalysis[] = (data || []).map((item) => ({
        id: item.id,
        analysis: item.analysis as unknown as AnalysisResult,
        created_at: item.created_at,
      }));
      
      setPastAnalyses(mappedData);
      
      // Auto-load most recent analysis if available
      if (mappedData.length > 0) {
        setAnalysis(mappedData[0].analysis);
        setSelectedHistoryId(mappedData[0].id);
      }
    } catch (err) {
      console.error("Failed to load past analyses:", err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const saveAnalysis = async (analysisData: AnalysisResult) => {
    if (!certificate.id) return;

    try {
      const { data: userData } = await supabase.auth.getUser();
      
      const { error } = await supabase
        .from("certificate_analyses")
        .insert([{
          certificate_id: certificate.id,
          analysis: JSON.parse(JSON.stringify(analysisData)),
          created_by: userData.user?.id || null,
        }]);

      if (error) throw error;
      
      // Reload past analyses
      loadPastAnalyses();
    } catch (err) {
      console.error("Failed to save analysis:", err);
    }
  };

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const { data, error } = await supabase.functions.invoke("analyze-certificate", {
        body: {
          certificate: {
            website_name: certificate.website_name,
            owner_name: certificate.owner_name || "Unknown",
            score: certificate.score,
            risk_level: certificate.risk_level,
            ssl_score: certificate.ssl_score || 0,
            dns_score: certificate.dns_score || 0,
            server_score: certificate.server_score || 0,
            status: certificate.status || "valid",
            expiry_date: certificate.expiry_date || new Date().toISOString(),
          },
        },
      });

      if (error) {
        throw error;
      }

      if (data?.error) {
        toast.error(data.error);
        return;
      }

      const analysisResult = data.analysis as AnalysisResult;
      setAnalysis(analysisResult);
      setSelectedHistoryId(null);
      
      // Save to database if we have a certificate ID
      if (certificate.id) {
        await saveAnalysis(analysisResult);
        toast.success("AI analysis complete and saved");
      } else {
        toast.success("AI analysis complete");
      }
    } catch (err) {
      console.error("Analysis error:", err);
      toast.error("Failed to analyze certificate");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const selectHistoryItem = (item: SavedAnalysis) => {
    setAnalysis(item.analysis);
    setSelectedHistoryId(item.id);
    setShowHistory(false);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive">High Priority</Badge>;
      case "medium":
        return <Badge className="bg-warning text-warning-foreground">Medium</Badge>;
      default:
        return <Badge variant="secondary">Low</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk.toLowerCase()) {
      case "critical":
        return <Badge variant="destructive">Critical Risk</Badge>;
      case "high":
        return <Badge variant="destructive">High Risk</Badge>;
      case "medium":
        return <Badge className="bg-warning text-warning-foreground">Medium Risk</Badge>;
      default:
        return <Badge className="bg-success text-success-foreground">Low Risk</Badge>;
    }
  };

  // Comparison view
  if (showComparison && certificate.id) {
    return (
      <AIAnalysisComparison
        certificateId={certificate.id}
        certificateName={certificate.website_name}
        onClose={() => setShowComparison(false)}
      />
    );
  }

  // History panel
  if (showHistory) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5 text-primary" />
              Analysis History
            </CardTitle>
            <div className="flex items-center gap-2">
              {pastAnalyses.length >= 2 && (
                <Button variant="outline" size="sm" onClick={() => { setShowHistory(false); setShowComparison(true); }}>
                  <GitCompare className="w-4 h-4 mr-1" />
                  Compare
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={() => setShowHistory(false)}>
                Back
              </Button>
            </div>
          </div>
          <CardDescription>{certificate.website_name}</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingHistory ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : pastAnalyses.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <History className="w-10 h-10 mx-auto mb-3 opacity-50" />
              <p>No past analyses found</p>
            </div>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-2">
                {pastAnalyses.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => selectHistoryItem(item)}
                    className={`w-full p-3 rounded-lg border text-left transition-colors ${
                      selectedHistoryId === item.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50 hover:bg-muted/50"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm font-medium">{formatDate(item.created_at)}</span>
                      </div>
                      {getRiskBadge(item.analysis.risk_assessment)}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {item.analysis.summary}
                    </p>
                  </button>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    );
  }

  if (!analysis) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              AI Security Analysis
            </CardTitle>
            {pastAnalyses.length > 0 && (
              <Button variant="outline" size="sm" onClick={() => setShowHistory(true)}>
                <History className="w-4 h-4 mr-1" />
                History ({pastAnalyses.length})
              </Button>
            )}
          </div>
          <CardDescription>
            Get AI-powered security recommendations for {certificate.website_name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground mb-4">
              Analyze this certificate to get personalized security recommendations powered by AI.
            </p>
            <Button onClick={handleAnalyze} disabled={isAnalyzing}>
              {isAnalyzing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Generate AI Analysis
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            AI Security Analysis
          </CardTitle>
          <div className="flex items-center gap-2">
            {pastAnalyses.length >= 2 && (
              <Button variant="outline" size="sm" onClick={() => setShowComparison(true)}>
                <GitCompare className="w-4 h-4 mr-1" />
                Compare
              </Button>
            )}
            {pastAnalyses.length > 0 && (
              <Button variant="outline" size="sm" onClick={() => setShowHistory(true)}>
                <History className="w-4 h-4 mr-1" />
                History ({pastAnalyses.length})
              </Button>
            )}
            {getRiskBadge(analysis.risk_assessment)}
          </div>
        </div>
        <CardDescription>
          {certificate.website_name}
          {selectedHistoryId && (
            <span className="text-xs text-muted-foreground ml-2">
              (from saved analysis)
            </span>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary */}
        <div className="p-4 rounded-lg bg-muted/50">
          <p className="text-sm">{analysis.summary}</p>
        </div>

        {/* Immediate Actions */}
        {analysis.immediate_actions.length > 0 && (
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-warning" />
              Immediate Actions
            </h4>
            <ul className="space-y-2">
              {analysis.immediate_actions.map((action, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <ArrowRight className="w-4 h-4 text-warning shrink-0 mt-0.5" />
                  {action}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Recommendations */}
        {analysis.recommendations.length > 0 && (
          <div>
            <h4 className="font-medium mb-3">Recommendations</h4>
            <div className="space-y-3">
              {analysis.recommendations.map((rec, i) => (
                <div key={i} className="p-3 rounded-lg border bg-background">
                  <div className="flex items-center gap-2 mb-2">
                    {getPriorityBadge(rec.priority)}
                    <Badge variant="outline">{rec.category}</Badge>
                  </div>
                  <h5 className="font-medium text-sm mb-1">{rec.title}</h5>
                  <p className="text-sm text-muted-foreground">{rec.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Long Term Improvements */}
        {analysis.long_term_improvements.length > 0 && (
          <div>
            <h4 className="font-medium mb-3 flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-success" />
              Long-term Improvements
            </h4>
            <ul className="space-y-2">
              {analysis.long_term_improvements.map((improvement, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <CheckCircle className="w-4 h-4 text-muted-foreground shrink-0 mt-0.5" />
                  {improvement}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" onClick={handleAnalyze} disabled={isAnalyzing}>
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : "New Analysis"}
          </Button>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              Close
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AISecurityAnalysis;