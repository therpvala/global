import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Clock, RefreshCw, AlertTriangle, ChevronRight } from "lucide-react";
import { differenceInDays, format } from "date-fns";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  expiry_date: string;
  status: string;
}

interface ExpiringSoonWidgetProps {
  certificates: Certificate[];
  onRenew: (cert: Certificate) => void;
}

const ExpiringSoonWidget = ({ certificates, onRenew }: ExpiringSoonWidgetProps) => {
  const today = new Date();
  
  const expiringSoon = certificates
    .filter((cert) => {
      if (cert.status === "revoked") return false;
      const expiryDate = new Date(cert.expiry_date);
      const daysUntilExpiry = differenceInDays(expiryDate, today);
      return daysUntilExpiry >= 0 && daysUntilExpiry <= 30;
    })
    .sort((a, b) => new Date(a.expiry_date).getTime() - new Date(b.expiry_date).getTime());

  const getUrgencyBadge = (expiryDate: string) => {
    const days = differenceInDays(new Date(expiryDate), today);
    if (days <= 7) {
      return <Badge variant="destructive" className="text-xs">Critical - {days}d</Badge>;
    } else if (days <= 14) {
      return <Badge className="bg-warning text-warning-foreground text-xs">Urgent - {days}d</Badge>;
    } else {
      return <Badge variant="secondary" className="text-xs">{days} days left</Badge>;
    }
  };

  if (expiringSoon.length === 0) {
    return (
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Clock className="w-5 h-5 text-muted-foreground" />
            Expiring Soon
          </CardTitle>
          <CardDescription>Certificates expiring within 30 days</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground">
            <Clock className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">No certificates expiring soon</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <AlertTriangle className="w-5 h-5 text-warning" />
          Expiring Soon
          <Badge variant="outline" className="ml-auto">{expiringSoon.length}</Badge>
        </CardTitle>
        <CardDescription>Certificates expiring within 30 days</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {expiringSoon.slice(0, 5).map((cert) => (
          <div
            key={cert.id}
            className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
          >
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-medium text-sm truncate">{cert.website_name}</span>
                {getUrgencyBadge(cert.expiry_date)}
              </div>
              <p className="text-xs text-muted-foreground">
                Expires {format(new Date(cert.expiry_date), "MMM d, yyyy")}
              </p>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="ghost" className="text-primary hover:text-primary">
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Renew Certificate?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Renew the certificate for <strong>{cert.website_name}</strong>? This will open the renewal dialog where you can select a new expiry date.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => onRenew(cert)}>
                    Continue to Renew
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        ))}
        {expiringSoon.length > 5 && (
          <div className="text-center pt-2">
            <Button variant="ghost" size="sm" className="text-muted-foreground">
              +{expiringSoon.length - 5} more expiring soon
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ExpiringSoonWidget;
