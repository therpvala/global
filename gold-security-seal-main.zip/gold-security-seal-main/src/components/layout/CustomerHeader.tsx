import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Shield, Search, Bell, ChevronDown, LogOut, User, Settings } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

const routeModuleNames: Record<string, string> = {
  "/customer/dashboard": "Dashboard",
  "/customer/scan": "Run Security Scan",
  "/customer/certificates": "Certificates",
  "/customer/reports": "Audit Reports",
  "/customer/alerts": "Alerts & Monitoring",
  "/customer/backdoor-status": "Backdoor Status",
  "/customer/billing": "Plans & Billing",
  "/customer/marketplace": "Marketplace",
  "/customer/support": "Support",
  "/customer/settings": "Settings",
  "/verify": "Verify Certificate",
};

export default function CustomerHeader() {
  const location = useLocation();
  const navigate = useNavigate();
  const { profile, signOut } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const currentModule = routeModuleNames[location.pathname] || "Dashboard";

  const handleSignOut = async () => {
    await signOut();
    toast.success("Signed out successfully");
    navigate("/auth");
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      toast.info(`Searching for: ${searchQuery}`);
    }
  };

  return (
    <header className="sticky top-0 z-50 h-14 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="flex h-full items-center justify-between px-4 gap-4">
        {/* Left: Logo & Platform Name */}
        <div className="flex items-center gap-3 min-w-[200px]">
          <Shield className="h-7 w-7 text-primary shrink-0" />
          <div className="hidden sm:block">
            <h1 className="text-sm font-bold text-foreground leading-tight">SECUREAUDIT</h1>
            <p className="text-[10px] text-muted-foreground leading-tight">Security Platform</p>
          </div>
        </div>

        {/* Center: Current Module Name */}
        <div className="flex-1 flex justify-center">
          <div className="bg-primary/5 border border-primary/20 rounded-lg px-4 py-1.5">
            <span className="text-sm font-semibold text-foreground">{currentModule}</span>
          </div>
        </div>

        {/* Right: Search, Notifications, Profile */}
        <div className="flex items-center gap-3 min-w-[300px] justify-end">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="hidden md:block">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-48 pl-8 h-9 bg-background/50 border-border focus:bg-background"
              />
            </div>
          </form>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative h-9 w-9"
            onClick={() => navigate("/customer/alerts")}
          >
            <Bell className="h-4 w-4" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-4 w-4 p-0 flex items-center justify-center text-[10px]"
            >
              2
            </Badge>
          </Button>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center gap-2 h-9 px-2">
                <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-xs font-semibold text-primary">
                    {profile?.initials || profile?.full_name?.charAt(0) || "U"}
                  </span>
                </div>
                <span className="hidden lg:block text-sm font-medium max-w-[100px] truncate">
                  {profile?.full_name || "Customer"}
                </span>
                <ChevronDown className="h-3 w-3 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <div className="px-2 py-1.5">
                <p className="text-sm font-medium">{profile?.full_name}</p>
                <p className="text-xs text-muted-foreground">Customer Account</p>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate("/customer/settings")}>
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate("/customer/settings")}>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Sign Out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
