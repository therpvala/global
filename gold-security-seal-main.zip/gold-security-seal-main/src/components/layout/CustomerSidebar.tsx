import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Shield,
  LayoutDashboard,
  FileText,
  Settings,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Scan,
  Activity,
  Download,
  CheckCircle,
  History,
  QrCode,
  FileCode,
  AlertTriangle,
  Bug,
  Clock,
  Server,
  Eye,
  Terminal,
  CreditCard,
  Wallet,
  Receipt,
  TrendingUp,
  ShoppingCart,
  Lock,
  Trash2,
  Globe,
  HeadphonesIcon,
  MessageSquare,
  BookOpen,
  Ticket,
  User,
  Bell,
  Link,
  Smartphone,
  HardDrive,
  Gauge,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useAuth } from "@/hooks/useAuth";

interface SubItem {
  title: string;
  href: string;
  icon: React.ElementType;
}

interface NavItem {
  title: string;
  icon: React.ElementType;
  href?: string;
  subItems?: SubItem[];
}

const customerMenuItems: NavItem[] = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    subItems: [
      { title: "Overview", href: "/customer/dashboard", icon: LayoutDashboard },
      { title: "Security Score", href: "/customer/dashboard", icon: Gauge },
    ],
  },
  {
    title: "Run Security Scan",
    icon: Scan,
    subItems: [
      { title: "Website Scan", href: "/customer/scan?type=website", icon: Globe },
      { title: "App / APK Scan", href: "/customer/scan?type=app", icon: Smartphone },
      { title: "Server Scan", href: "/customer/scan?type=server", icon: HardDrive },
    ],
  },
  {
    title: "Certificates",
    icon: FileText,
    subItems: [
      { title: "Active Certificate", href: "/customer/certificates", icon: CheckCircle },
      { title: "Download Certificate", href: "/customer/certificates", icon: Download },
      { title: "Certificate History", href: "/customer/certificates?tab=history", icon: History },
      { title: "Verify Certificate", href: "/verify", icon: QrCode },
    ],
  },
  {
    title: "Audit Reports",
    icon: FileCode,
    subItems: [
      { title: "Technical Audit", href: "/customer/reports?tab=technical", icon: FileCode },
      { title: "Action Plan", href: "/customer/reports?tab=action", icon: FileText },
    ],
  },
  {
    title: "Alerts & Monitoring",
    icon: AlertTriangle,
    subItems: [
      { title: "Malware Alerts", href: "/customer/alerts?type=malware", icon: Bug },
      { title: "Backdoor Alerts", href: "/customer/alerts?type=backdoor", icon: Eye },
      { title: "Uptime Alerts", href: "/customer/alerts?type=uptime", icon: Clock },
    ],
  },
  {
    title: "Developer Backdoor Status",
    icon: Terminal,
    subItems: [
      { title: "Hidden Admin Check", href: "/customer/backdoor-status", icon: Eye },
      { title: "Script & Cron Check", href: "/customer/backdoor-status", icon: Terminal },
      { title: "Access Logs", href: "/customer/backdoor-status", icon: Server },
    ],
  },
  {
    title: "Plans & Billing",
    icon: CreditCard,
    subItems: [
      { title: "Current Plan", href: "/customer/billing", icon: CreditCard },
      { title: "Upgrade Plan", href: "/customer/billing?tab=upgrade", icon: TrendingUp },
      { title: "Invoice History", href: "/customer/billing?tab=invoices", icon: Receipt },
    ],
  },
  {
    title: "Marketplace",
    icon: ShoppingCart,
    subItems: [
      { title: "Buy SSL", href: "/customer/marketplace?category=ssl", icon: Lock },
      { title: "Firewall", href: "/customer/marketplace?category=firewall", icon: Shield },
      { title: "Malware Removal", href: "/customer/marketplace?category=malware", icon: Trash2 },
      { title: "VPN Services", href: "/customer/marketplace?category=vpn", icon: Globe },
    ],
  },
  {
    title: "Support",
    icon: HeadphonesIcon,
    subItems: [
      { title: "Raise Ticket", href: "/customer/support", icon: Ticket },
      { title: "Chat Support", href: "/customer/support?tab=chat", icon: MessageSquare },
      { title: "Documentation", href: "/customer/support?tab=docs", icon: BookOpen },
    ],
  },
  {
    title: "Settings",
    icon: Settings,
    subItems: [
      { title: "Profile Settings", href: "/customer/settings", icon: User },
      { title: "Domain Settings", href: "/customer/settings?tab=domains", icon: Link },
      { title: "Notification Settings", href: "/customer/settings?tab=notifications", icon: Bell },
    ],
  },
];

export default function CustomerSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [openMenus, setOpenMenus] = useState<string[]>(["Dashboard"]);

  const isActive = (href: string) => {
    if (href.includes("?")) {
      return location.pathname + location.search === href;
    }
    return location.pathname === href;
  };

  const isMenuActive = (item: NavItem) => {
    if (item.href) return isActive(item.href);
    return item.subItems?.some((sub) => location.pathname === sub.href.split("?")[0]);
  };

  const toggleMenu = (title: string) => {
    setOpenMenus((prev) =>
      prev.includes(title)
        ? prev.filter((t) => t !== title)
        : [...prev, title]
    );
  };

  const handleNavigate = (href: string) => {
    navigate(href);
  };

  return (
    <aside
      className={cn(
        "relative flex flex-col h-screen bg-card border-r border-border transition-all duration-300",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      {/* Navigation */}
      <ScrollArea className="flex-1 py-2">
        <div className="px-2 space-y-1">
          {customerMenuItems.map((item) => {
            const hasSubItems = item.subItems && item.subItems.length > 0;
            const isOpen = openMenus.includes(item.title);
            const isItemActive = isMenuActive(item);

            if (isCollapsed) {
              return (
                <Button
                  key={item.title}
                  variant={isItemActive ? "secondary" : "ghost"}
                  size="icon"
                  className={cn(
                    "w-full h-10",
                    isItemActive && "bg-primary/10 text-primary"
                  )}
                  onClick={() => {
                    if (item.href) {
                      handleNavigate(item.href);
                    } else if (item.subItems?.[0]) {
                      handleNavigate(item.subItems[0].href);
                    }
                  }}
                  title={item.title}
                >
                  <item.icon className="h-4 w-4" />
                </Button>
              );
            }

            if (!hasSubItems) {
              return (
                <Button
                  key={item.title}
                  variant={isItemActive ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 h-10",
                    isItemActive && "bg-primary/10 text-primary border-l-2 border-primary rounded-l-none"
                  )}
                  onClick={() => item.href && handleNavigate(item.href)}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  <span className="truncate">{item.title}</span>
                </Button>
              );
            }

            return (
              <Collapsible
                key={item.title}
                open={isOpen}
                onOpenChange={() => toggleMenu(item.title)}
              >
                <CollapsibleTrigger asChild>
                  <Button
                    variant={isItemActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-between h-10 pr-2",
                      isItemActive && "bg-primary/5 text-primary"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{item.title}</span>
                    </div>
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 shrink-0 transition-transform duration-200",
                        isOpen && "rotate-180"
                      )}
                    />
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-1 space-y-0.5">
                  {item.subItems?.map((subItem) => (
                    <Button
                      key={subItem.title}
                      variant={isActive(subItem.href) ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start gap-3 h-9 pl-9 text-sm",
                        isActive(subItem.href) && "bg-primary/10 text-primary border-l-2 border-primary rounded-l-none"
                      )}
                      onClick={() => handleNavigate(subItem.href)}
                    >
                      <subItem.icon className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{subItem.title}</span>
                    </Button>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>
      </ScrollArea>

      {/* User Section */}
      <div className="mt-auto border-t border-border p-3">
        {profile && !isCollapsed && (
          <div className="flex items-center gap-3 px-2">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <span className="text-xs font-semibold text-primary">
                {profile.initials || profile.full_name?.charAt(0) || "U"}
              </span>
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-sm font-medium text-foreground truncate">{profile.full_name}</p>
              <p className="text-xs text-muted-foreground">Customer</p>
            </div>
          </div>
        )}
        {isCollapsed && profile && (
          <div className="flex justify-center">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-xs font-semibold text-primary">
                {profile.initials || profile.full_name?.charAt(0) || "U"}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Collapse Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-3 top-6 h-6 w-6 rounded-full border border-border bg-background shadow-sm hover:bg-accent"
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        {isCollapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </Button>
    </aside>
  );
}
