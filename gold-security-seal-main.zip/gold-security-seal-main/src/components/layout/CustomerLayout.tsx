import { ReactNode, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Loader2, Home, ChevronRight } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import CustomerSidebar from "./CustomerSidebar";
import CustomerHeader from "./CustomerHeader";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Link } from "react-router-dom";

interface CustomerLayoutProps {
  children: ReactNode;
}

const routeLabels: Record<string, string> = {
  "customer": "Home",
  "dashboard": "Dashboard",
  "scan": "Security Scan",
  "certificates": "Certificates",
  "reports": "Audit Reports",
  "alerts": "Alerts",
  "backdoor-status": "Backdoor Status",
  "billing": "Plans & Billing",
  "marketplace": "Marketplace",
  "support": "Support",
  "settings": "Settings",
};

export default function CustomerLayout({ children }: CustomerLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const pathSegments = location.pathname.split("/").filter(Boolean);

  return (
    <div className="flex min-h-screen w-full bg-background">
      <CustomerSidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <CustomerHeader />
        <main className="flex-1 overflow-auto">
          <div className="border-b border-border bg-muted/30 px-6 py-2">
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem>
                  <BreadcrumbLink asChild>
                    <Link to="/customer/dashboard" className="flex items-center gap-1.5">
                      <Home className="h-4 w-4" />
                      <span className="hidden sm:inline">Home</span>
                    </Link>
                  </BreadcrumbLink>
                </BreadcrumbItem>
                {pathSegments.slice(1).map((segment, index) => {
                  const isLast = index === pathSegments.length - 2;
                  const path = "/" + pathSegments.slice(0, index + 2).join("/");
                  const label = routeLabels[segment] || segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, " ");

                  return (
                    <BreadcrumbItem key={path}>
                      <BreadcrumbSeparator />
                      {isLast ? (
                        <BreadcrumbPage>{label}</BreadcrumbPage>
                      ) : (
                        <BreadcrumbLink asChild>
                          <Link to={path}>{label}</Link>
                        </BreadcrumbLink>
                      )}
                    </BreadcrumbItem>
                  );
                })}
              </BreadcrumbList>
            </Breadcrumb>
          </div>
          <div className="p-0">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
