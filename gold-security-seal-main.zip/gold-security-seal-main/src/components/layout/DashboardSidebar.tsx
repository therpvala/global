import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Shield,
  LayoutDashboard,
  FileText,
  Key,
  Settings,
  Users,
  History,
  BarChart3,
  Bell,
  Code2,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Plus,
  Scan,
  Clock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  FileCheck,
  Download,
  Eye,
  Server,
  Bug,
  Terminal,
  Wifi,
  Flag,
  UserCheck,
  CreditCard,
  Percent,
  ShoppingCart,
  Lock,
  Trash2,
  Globe,
  Activity,
  Mail,
  FileCode,
  ShieldCheck,
  Package,
  Wallet,
  Building,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

interface SubItem {
  title: string;
  href: string;
  icon: React.ElementType;
}

interface NavItem {
  title: string;
  icon: React.ElementType;
  href?: string;
  subItems?: SubItem[];
  roles?: ("admin" | "moderator" | "user")[];
}

const menuItems: NavItem[] = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    subItems: [
      { title: "Overview", href: "/dashboard", icon: BarChart3 },
      { title: "Live Alerts", href: "/notifications", icon: Bell },
      { title: "Security Stats", href: "/analytics", icon: Activity },
    ],
  },
  {
    title: "Security Audit",
    icon: Shield,
    subItems: [
      { title: "Run New Scan", href: "/", icon: Scan },
      { title: "Scan History", href: "/audit-logs", icon: Clock },
      { title: "Risk Reports", href: "/analytics", icon: AlertTriangle },
    ],
  },
  {
    title: "Certificates",
    icon: FileText,
    subItems: [
      { title: "Issue Certificate", href: "/", icon: Plus },
      { title: "Active Certificates", href: "/certificates?status=valid", icon: CheckCircle },
      { title: "Expired Certificates", href: "/certificates?status=expired", icon: XCircle },
      { title: "Verification Logs", href: "/audit-logs", icon: FileCheck },
    ],
  },
  {
    title: "Reports",
    icon: Download,
    subItems: [
      { title: "Technical Audit", href: "/?tab=report", icon: FileCode },
      { title: "Action Plan", href: "/?tab=action", icon: FileText },
      { title: "PDF Downloads", href: "/certificates", icon: Download },
    ],
  },
  {
    title: "Developer Backdoor",
    icon: Bug,
    roles: ["admin"],
    subItems: [
      { title: "Hidden Admin Logs", href: "/audit-logs", icon: Eye },
      { title: "Cron & Script Scan", href: "/audit-logs", icon: Terminal },
      { title: "SSH / FTP Detection", href: "/audit-logs", icon: Wifi },
      { title: "Risk Flags", href: "/notifications", icon: Flag },
    ],
  },
  {
    title: "Customers",
    icon: Users,
    roles: ["admin", "moderator"],
    subItems: [
      { title: "All Customers", href: "/users", icon: Users },
      { title: "Active Plans", href: "/users", icon: UserCheck },
      { title: "Scan Status", href: "/analytics", icon: Activity },
    ],
  },
  {
    title: "Plans & Pricing",
    icon: CreditCard,
    roles: ["admin"],
    subItems: [
      { title: "One-Time", href: "/settings", icon: CreditCard },
      { title: "Monthly", href: "/settings", icon: Wallet },
      { title: "Yearly", href: "/settings", icon: Package },
      { title: "Discounts", href: "/settings", icon: Percent },
    ],
  },
  {
    title: "Marketplace",
    icon: ShoppingCart,
    roles: ["admin"],
    subItems: [
      { title: "SSL Orders", href: "/certificates", icon: Lock },
      { title: "Firewall Services", href: "/settings", icon: Shield },
      { title: "Malware Removal", href: "/settings", icon: Trash2 },
      { title: "VPN Orders", href: "/settings", icon: Globe },
    ],
  },
  {
    title: "Reseller Panel",
    icon: Building,
    roles: ["admin"],
    subItems: [
      { title: "Reseller List", href: "/users", icon: Users },
      { title: "Commission", href: "/analytics", icon: Percent },
      { title: "Reseller Certificates", href: "/certificates", icon: FileText },
    ],
  },
  {
    title: "Logs & Monitoring",
    icon: Server,
    roles: ["admin", "moderator"],
    subItems: [
      { title: "Server Logs", href: "/audit-logs", icon: Server },
      { title: "API Logs", href: "/audit-logs", icon: Code2 },
      { title: "Admin Activity Logs", href: "/audit-logs", icon: History },
    ],
  },
  {
    title: "Settings",
    icon: Settings,
    subItems: [
      { title: "Platform Settings", href: "/settings", icon: Settings },
      { title: "Email Templates", href: "/settings", icon: Mail },
      { title: "Certificate Templates", href: "/settings", icon: FileText },
      { title: "Security Rules", href: "/settings", icon: ShieldCheck },
    ],
  },
];

export default function DashboardSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [userRole, setUserRole] = useState<"admin" | "moderator" | "user">("user");
  const [openMenus, setOpenMenus] = useState<string[]>(["Dashboard"]);

  useEffect(() => {
    const fetchUserRole = async () => {
      if (!user) return;
      
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      if (data && !error) {
        setUserRole(data.role as "admin" | "moderator" | "user");
      }
    };

    fetchUserRole();
  }, [user]);

  const canAccessItem = (item: NavItem) => {
    if (!item.roles) return true;
    return item.roles.includes(userRole);
  };

  const isActive = (href: string) => {
    if (href.includes("?")) {
      return location.pathname + location.search === href;
    }
    return location.pathname === href;
  };

  const isMenuActive = (item: NavItem) => {
    if (item.href) return isActive(item.href);
    return item.subItems?.some((sub) => isActive(sub.href));
  };

  const toggleMenu = (title: string) => {
    setOpenMenus((prev) =>
      prev.includes(title)
        ? prev.filter((t) => t !== title)
        : [...prev, title]
    );
  };

  const handleNavigate = (href: string) => {
    navigate(href);
  };

  return (
    <aside
      className={cn(
        "relative flex flex-col h-screen bg-card border-r border-border transition-all duration-300",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      {/* Navigation */}
      <ScrollArea className="flex-1 py-2">
        <div className="px-2 space-y-1">
          {menuItems.map((item) => {
            if (!canAccessItem(item)) return null;

            const hasSubItems = item.subItems && item.subItems.length > 0;
            const isOpen = openMenus.includes(item.title);
            const isItemActive = isMenuActive(item);

            if (isCollapsed) {
              return (
                <Button
                  key={item.title}
                  variant={isItemActive ? "secondary" : "ghost"}
                  size="icon"
                  className={cn(
                    "w-full h-10",
                    isItemActive && "bg-primary/10 text-primary"
                  )}
                  onClick={() => {
                    if (item.href) {
                      handleNavigate(item.href);
                    } else if (item.subItems?.[0]) {
                      handleNavigate(item.subItems[0].href);
                    }
                  }}
                  title={item.title}
                >
                  <item.icon className="h-4 w-4" />
                </Button>
              );
            }

            if (!hasSubItems) {
              return (
                <Button
                  key={item.title}
                  variant={isItemActive ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start gap-3 h-10",
                    isItemActive && "bg-primary/10 text-primary border-l-2 border-primary rounded-l-none"
                  )}
                  onClick={() => item.href && handleNavigate(item.href)}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  <span className="truncate">{item.title}</span>
                </Button>
              );
            }

            return (
              <Collapsible
                key={item.title}
                open={isOpen}
                onOpenChange={() => toggleMenu(item.title)}
              >
                <CollapsibleTrigger asChild>
                  <Button
                    variant={isItemActive ? "secondary" : "ghost"}
                    className={cn(
                      "w-full justify-between h-10 pr-2",
                      isItemActive && "bg-primary/5 text-primary"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="h-4 w-4 shrink-0" />
                      <span className="truncate">{item.title}</span>
                    </div>
                    <ChevronDown
                      className={cn(
                        "h-4 w-4 shrink-0 transition-transform duration-200",
                        isOpen && "rotate-180"
                      )}
                    />
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent className="pt-1 space-y-0.5">
                  {item.subItems?.map((subItem) => (
                    <Button
                      key={subItem.title}
                      variant={isActive(subItem.href) ? "secondary" : "ghost"}
                      className={cn(
                        "w-full justify-start gap-3 h-9 pl-9 text-sm",
                        isActive(subItem.href) && "bg-primary/10 text-primary border-l-2 border-primary rounded-l-none"
                      )}
                      onClick={() => handleNavigate(subItem.href)}
                    >
                      <subItem.icon className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{subItem.title}</span>
                    </Button>
                  ))}
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>
      </ScrollArea>

      {/* User Section */}
      <div className="mt-auto border-t border-border p-3">
        {profile && !isCollapsed && (
          <div className="flex items-center gap-3 px-2">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
              <span className="text-xs font-semibold text-primary">
                {profile.initials || profile.full_name?.charAt(0) || "U"}
              </span>
            </div>
            <div className="overflow-hidden flex-1">
              <p className="text-sm font-medium text-foreground truncate">{profile.full_name}</p>
              <p className="text-xs text-muted-foreground capitalize">{userRole}</p>
            </div>
          </div>
        )}
        {isCollapsed && profile && (
          <div className="flex justify-center">
            <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-xs font-semibold text-primary">
                {profile.initials || profile.full_name?.charAt(0) || "U"}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Collapse Toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-3 top-6 h-6 w-6 rounded-full border border-border bg-background shadow-sm hover:bg-accent"
        onClick={() => setIsCollapsed(!isCollapsed)}
      >
        {isCollapsed ? (
          <ChevronRight className="h-3 w-3" />
        ) : (
          <ChevronLeft className="h-3 w-3" />
        )}
      </Button>
    </aside>
  );
}
