import { useState } from "react";
import { Share2, Copy, Check, Twitter, Linkedin, Facebook, Link2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

interface ShareCertificateProps {
  certificateId: string;
  websiteName: string;
  score: number;
  status: string;
}

const ShareCertificate = ({ certificateId, websiteName, score, status }: ShareCertificateProps) => {
  const [copied, setCopied] = useState(false);

  const shareUrl = `${window.location.origin}/verify?id=${encodeURIComponent(certificateId)}`;
  const shareTitle = `${websiteName} - Security Certificate Verified`;
  const shareText = `✅ ${websiteName} has been verified with a security score of ${score}/100. Certificate ID: ${certificateId}`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      toast.success("Link copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy link");
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl,
        });
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          toast.error("Failed to share");
        }
      }
    } else {
      handleCopyLink();
    }
  };

  const shareToTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
    window.open(twitterUrl, "_blank", "noopener,noreferrer");
  };

  const shareToLinkedIn = () => {
    const linkedInUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
    window.open(linkedInUrl, "_blank", "noopener,noreferrer");
  };

  const shareToFacebook = () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
    window.open(facebookUrl, "_blank", "noopener,noreferrer");
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="outline" 
          className="gap-2 border-border"
        >
          <Share2 className="w-4 h-4" />
          Share
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="center" className="w-56 bg-card border-border">
        <DropdownMenuItem 
          onClick={handleCopyLink}
          className="gap-3 cursor-pointer"
        >
          {copied ? (
            <Check className="w-4 h-4 text-success" />
          ) : (
            <Copy className="w-4 h-4" />
          )}
          <span>{copied ? "Link Copied!" : "Copy Link"}</span>
        </DropdownMenuItem>
        
        {navigator.share && (
          <DropdownMenuItem 
            onClick={handleNativeShare}
            className="gap-3 cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            <span>Share via...</span>
          </DropdownMenuItem>
        )}
        
        <DropdownMenuSeparator className="bg-border" />
        
        <DropdownMenuItem 
          onClick={shareToTwitter}
          className="gap-3 cursor-pointer"
        >
          <Twitter className="w-4 h-4" />
          <span>Share on X (Twitter)</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem 
          onClick={shareToLinkedIn}
          className="gap-3 cursor-pointer"
        >
          <Linkedin className="w-4 h-4" />
          <span>Share on LinkedIn</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem 
          onClick={shareToFacebook}
          className="gap-3 cursor-pointer"
        >
          <Facebook className="w-4 h-4" />
          <span>Share on Facebook</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator className="bg-border" />
        
        <div className="px-2 py-2">
          <p className="text-xs text-muted-foreground mb-2">Verification Link</p>
          <div className="flex items-center gap-2 p-2 bg-muted/50 rounded-md">
            <Link2 className="w-3 h-3 text-muted-foreground flex-shrink-0" />
            <span className="text-xs text-foreground truncate font-mono">
              {shareUrl.replace(window.location.origin, "").slice(0, 30)}...
            </span>
          </div>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ShareCertificate;
