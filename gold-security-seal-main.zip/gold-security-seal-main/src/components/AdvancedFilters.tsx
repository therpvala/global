import { useState, useMemo } from "react";
import { CalendarIcon, Filter, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface Certificate {
  id: string;
  auditor_name: string;
  issue_date: string;
  expiry_date: string;
  score: number;
}

interface AdvancedFiltersProps {
  certificates: Certificate[];
  onFiltersChange: (filters: FilterState) => void;
}

export interface FilterState {
  issueDateFrom: Date | undefined;
  issueDateTo: Date | undefined;
  expiryDateFrom: Date | undefined;
  expiryDateTo: Date | undefined;
  scoreMin: number | undefined;
  scoreMax: number | undefined;
  auditor: string;
}

const initialFilters: FilterState = {
  issueDateFrom: undefined,
  issueDateTo: undefined,
  expiryDateFrom: undefined,
  expiryDateTo: undefined,
  scoreMin: undefined,
  scoreMax: undefined,
  auditor: "all",
};

const AdvancedFilters = ({ certificates, onFiltersChange }: AdvancedFiltersProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>(initialFilters);

  const uniqueAuditors = useMemo(() => {
    const auditors = new Set(certificates.map((c) => c.auditor_name));
    return Array.from(auditors).sort();
  }, [certificates]);

  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.issueDateFrom || filters.issueDateTo) count++;
    if (filters.expiryDateFrom || filters.expiryDateTo) count++;
    if (filters.scoreMin !== undefined || filters.scoreMax !== undefined) count++;
    if (filters.auditor !== "all") count++;
    return count;
  }, [filters]);

  const updateFilter = <K extends keyof FilterState>(key: K, value: FilterState[K]) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearFilters = () => {
    setFilters(initialFilters);
    onFiltersChange(initialFilters);
  };

  const DatePickerButton = ({
    date,
    placeholder,
    onSelect,
  }: {
    date: Date | undefined;
    placeholder: string;
    onSelect: (date: Date | undefined) => void;
  }) => (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          className={cn(
            "w-full justify-start text-left font-normal h-9",
            !date && "text-muted-foreground"
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4" />
          {date ? format(date, "dd MMM yyyy") : placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={date}
          onSelect={onSelect}
          initialFocus
        />
      </PopoverContent>
    </Popover>
  );

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="flex items-center gap-2 mb-4">
        <CollapsibleTrigger asChild>
          <Button variant="outline" size="sm" className="gap-2">
            <Filter className="w-4 h-4" />
            Advanced Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {activeFilterCount}
              </Badge>
            )}
          </Button>
        </CollapsibleTrigger>
        {activeFilterCount > 0 && (
          <Button variant="ghost" size="sm" onClick={clearFilters} className="gap-1 text-muted-foreground hover:text-destructive">
            <X className="w-4 h-4" />
            Clear
          </Button>
        )}
      </div>

      <CollapsibleContent className="space-y-4 pb-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-secondary/30 rounded-lg border border-border">
          {/* Issue Date Range */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-muted-foreground">Issue Date Range</Label>
            <div className="flex gap-2">
              <DatePickerButton
                date={filters.issueDateFrom}
                placeholder="From"
                onSelect={(date) => updateFilter("issueDateFrom", date)}
              />
              <DatePickerButton
                date={filters.issueDateTo}
                placeholder="To"
                onSelect={(date) => updateFilter("issueDateTo", date)}
              />
            </div>
          </div>

          {/* Expiry Date Range */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-muted-foreground">Expiry Date Range</Label>
            <div className="flex gap-2">
              <DatePickerButton
                date={filters.expiryDateFrom}
                placeholder="From"
                onSelect={(date) => updateFilter("expiryDateFrom", date)}
              />
              <DatePickerButton
                date={filters.expiryDateTo}
                placeholder="To"
                onSelect={(date) => updateFilter("expiryDateTo", date)}
              />
            </div>
          </div>

          {/* Score Range */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-muted-foreground">Score Range (0-100)</Label>
            <div className="flex gap-2">
              <Input
                type="number"
                placeholder="Min"
                min={0}
                max={100}
                value={filters.scoreMin ?? ""}
                onChange={(e) => updateFilter("scoreMin", e.target.value ? Number(e.target.value) : undefined)}
                className="h-9"
              />
              <Input
                type="number"
                placeholder="Max"
                min={0}
                max={100}
                value={filters.scoreMax ?? ""}
                onChange={(e) => updateFilter("scoreMax", e.target.value ? Number(e.target.value) : undefined)}
                className="h-9"
              />
            </div>
          </div>

          {/* Auditor Filter */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-muted-foreground">Auditor</Label>
            <Select value={filters.auditor} onValueChange={(value) => updateFilter("auditor", value)}>
              <SelectTrigger className="h-9">
                <SelectValue placeholder="Select auditor" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Auditors</SelectItem>
                {uniqueAuditors.map((auditor) => (
                  <SelectItem key={auditor} value={auditor}>
                    {auditor}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default AdvancedFilters;
