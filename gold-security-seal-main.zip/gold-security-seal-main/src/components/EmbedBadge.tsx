import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Code, Copy, Check, ExternalLink } from "lucide-react";
import { toast } from "sonner";

interface EmbedBadgeProps {
  certificateId: string;
}

type BadgeSize = "small" | "medium" | "large";
type BadgeTheme = "light" | "dark";

const EmbedBadge = ({ certificateId }: EmbedBadgeProps) => {
  const [size, setSize] = useState<BadgeSize>("medium");
  const [theme, setTheme] = useState<BadgeTheme>("light");
  const [copied, setCopied] = useState(false);

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  
  const sizes = {
    small: { width: 180, height: 60 },
    medium: { width: 240, height: 80 },
    large: { width: 320, height: 100 },
  };

  const embedCode = `<iframe src="${supabaseUrl}/functions/v1/embed-badge?id=${certificateId}&size=${size}&theme=${theme}" width="${sizes[size].width}" height="${sizes[size].height}" frameborder="0" scrolling="no" style="border:none;overflow:hidden;" title="CyberSec Verified Badge"></iframe>`;

  const previewUrl = `${supabaseUrl}/functions/v1/embed-badge?id=${certificateId}&size=${size}&theme=${theme}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(embedCode);
      setCopied(true);
      toast.success("Embed code copied to clipboard!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Failed to copy embed code");
    }
  };

  return (
    <Card className="border-border/50">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Code className="w-5 h-5 text-primary" />
          Embeddable Trust Badge
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Preview */}
        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">Preview</Label>
          <div className={`p-4 rounded-lg border ${theme === "dark" ? "bg-slate-800" : "bg-slate-50"} flex items-center justify-center`}>
            <iframe
              src={previewUrl}
              width={sizes[size].width}
              height={sizes[size].height}
              frameBorder="0"
              scrolling="no"
              style={{ border: "none", overflow: "hidden" }}
              title="Badge Preview"
            />
          </div>
        </div>

        {/* Size Selection */}
        <div className="space-y-3">
          <Label className="text-sm text-muted-foreground">Badge Size</Label>
          <RadioGroup
            value={size}
            onValueChange={(v) => setSize(v as BadgeSize)}
            className="flex gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="small" id="size-small" />
              <Label htmlFor="size-small" className="cursor-pointer">Small</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="medium" id="size-medium" />
              <Label htmlFor="size-medium" className="cursor-pointer">Medium</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="large" id="size-large" />
              <Label htmlFor="size-large" className="cursor-pointer">Large</Label>
            </div>
          </RadioGroup>
        </div>

        {/* Theme Selection */}
        <div className="space-y-3">
          <Label className="text-sm text-muted-foreground">Theme</Label>
          <RadioGroup
            value={theme}
            onValueChange={(v) => setTheme(v as BadgeTheme)}
            className="flex gap-4"
          >
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="light" id="theme-light" />
              <Label htmlFor="theme-light" className="cursor-pointer">Light</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="dark" id="theme-dark" />
              <Label htmlFor="theme-dark" className="cursor-pointer">Dark</Label>
            </div>
          </RadioGroup>
        </div>

        {/* Embed Code */}
        <div className="space-y-2">
          <Label className="text-sm text-muted-foreground">Embed Code</Label>
          <div className="relative">
            <pre className="p-4 pr-12 bg-muted/50 rounded-lg text-xs overflow-x-auto border border-border/50">
              <code className="text-foreground/80 break-all whitespace-pre-wrap">
                {embedCode}
              </code>
            </pre>
            <Button
              size="icon"
              variant="ghost"
              className="absolute top-2 right-2 h-8 w-8"
              onClick={handleCopy}
            >
              {copied ? (
                <Check className="w-4 h-4 text-success" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={handleCopy}
          >
            {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
            Copy Code
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => window.open(previewUrl, "_blank")}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Open Badge
          </Button>
        </div>

        <p className="text-xs text-muted-foreground text-center">
          Add this code to your website to display your verified security badge.
          The badge updates automatically with your certificate status.
        </p>
      </CardContent>
    </Card>
  );
};

export default EmbedBadge;
