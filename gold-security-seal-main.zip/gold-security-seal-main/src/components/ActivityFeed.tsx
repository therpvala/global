import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import {
  Activity,
  Shield,
  Pencil,
  Trash2,
  RefreshCw,
  Ban,
  Loader2,
  Clock,
  User,
} from "lucide-react";

interface ActivityItem {
  id: string;
  action: string;
  entity_type: string;
  entity_name: string | null;
  user_name: string | null;
  created_at: string;
  details: Record<string, unknown> | null;
}

const ActivityFeed = () => {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadActivities();
  }, []);

  const loadActivities = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from("audit_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(30);

      if (error) throw error;
      setActivities((data as ActivityItem[]) || []);
    } catch (err) {
      console.error("Failed to load activities:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case "created":
        return <Shield className="w-4 h-4 text-success" />;
      case "updated":
        return <Pencil className="w-4 h-4 text-primary" />;
      case "deleted":
        return <Trash2 className="w-4 h-4 text-destructive" />;
      case "status_changed":
        return <RefreshCw className="w-4 h-4 text-warning" />;
      case "role_assigned":
      case "role_changed":
        return <User className="w-4 h-4 text-primary" />;
      default:
        return <Activity className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getActionBadge = (action: string) => {
    switch (action) {
      case "created":
        return <Badge className="bg-success/20 text-success">Created</Badge>;
      case "updated":
        return <Badge className="bg-primary/20 text-primary">Updated</Badge>;
      case "deleted":
        return <Badge className="bg-destructive/20 text-destructive">Deleted</Badge>;
      case "status_changed":
        return <Badge className="bg-warning/20 text-warning">Status Changed</Badge>;
      case "role_assigned":
        return <Badge className="bg-primary/20 text-primary">Role Assigned</Badge>;
      case "role_changed":
        return <Badge className="bg-warning/20 text-warning">Role Changed</Badge>;
      default:
        return <Badge variant="outline">{action}</Badge>;
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days > 7) {
      return date.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
    } else if (days > 0) {
      return `${days}d ago`;
    } else if (hours > 0) {
      return `${hours}h ago`;
    } else {
      return "Just now";
    }
  };

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Recent Activity
            </CardTitle>
            <CardDescription>Audit log of recent actions</CardDescription>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={loadActivities}
            disabled={isLoading}
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>No recent activity</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-4">
              {activities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-3 p-2 rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="mt-1">{getActionIcon(activity.action)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium text-foreground">
                        {activity.user_name || "System"}
                      </span>
                      {getActionBadge(activity.action)}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {activity.entity_type === "certificate" && (
                        <>Certificate: <span className="text-foreground">{activity.entity_name}</span></>
                      )}
                      {activity.entity_type === "user_role" && (
                        <>User: <span className="text-foreground">{activity.entity_name}</span></>
                      )}
                      {activity.details && (activity.details as Record<string, unknown>).old_status && (activity.details as Record<string, unknown>).old_status !== null && (
                        <span className="text-xs ml-2">
                          ({(activity.details as Record<string, unknown>).old_status as string} → {(activity.details as Record<string, unknown>).status as string})
                        </span>
                      )}
                    </p>
                    <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {formatTime(activity.created_at)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;