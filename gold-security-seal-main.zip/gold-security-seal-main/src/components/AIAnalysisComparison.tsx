import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Loader2,
  GitCompare,
  Clock,
  ArrowRight,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Minus,
  Download,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { exportComparisonPDF } from "@/lib/pdfExport";

interface Recommendation {
  priority: "high" | "medium" | "low";
  category: string;
  title: string;
  description: string;
}

interface AnalysisResult {
  summary: string;
  risk_assessment: string;
  recommendations: Recommendation[];
  immediate_actions: string[];
  long_term_improvements: string[];
}

interface SavedAnalysis {
  id: string;
  analysis: AnalysisResult;
  created_at: string;
}

interface AIAnalysisComparisonProps {
  certificateId: string;
  certificateName: string;
  onClose?: () => void;
}

const AIAnalysisComparison = ({ certificateId, certificateName, onClose }: AIAnalysisComparisonProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [analyses, setAnalyses] = useState<SavedAnalysis[]>([]);
  const [leftId, setLeftId] = useState<string>("");
  const [rightId, setRightId] = useState<string>("");

  useEffect(() => {
    loadAnalyses();
  }, [certificateId]);

  const loadAnalyses = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from("certificate_analyses")
        .select("id, analysis, created_at")
        .eq("certificate_id", certificateId)
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) throw error;

      const mappedData: SavedAnalysis[] = (data || []).map((item) => ({
        id: item.id,
        analysis: item.analysis as unknown as AnalysisResult,
        created_at: item.created_at,
      }));

      setAnalyses(mappedData);

      // Auto-select the two most recent analyses
      if (mappedData.length >= 2) {
        setLeftId(mappedData[1].id);
        setRightId(mappedData[0].id);
      } else if (mappedData.length === 1) {
        setLeftId(mappedData[0].id);
      }
    } catch (err) {
      console.error("Failed to load analyses:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getSelectedAnalysis = (id: string): SavedAnalysis | undefined => {
    return analyses.find((a) => a.id === id);
  };

  const getRiskLevel = (risk: string): number => {
    const levels: Record<string, number> = {
      low: 1,
      medium: 2,
      high: 3,
      critical: 4,
    };
    return levels[risk.toLowerCase()] || 0;
  };

  const getRiskBadge = (risk: string) => {
    switch (risk.toLowerCase()) {
      case "critical":
        return <Badge variant="destructive">Critical Risk</Badge>;
      case "high":
        return <Badge variant="destructive">High Risk</Badge>;
      case "medium":
        return <Badge className="bg-warning text-warning-foreground">Medium Risk</Badge>;
      default:
        return <Badge className="bg-success text-success-foreground">Low Risk</Badge>;
    }
  };

  const getTrendIcon = () => {
    const left = getSelectedAnalysis(leftId);
    const right = getSelectedAnalysis(rightId);
    if (!left || !right) return null;

    const leftLevel = getRiskLevel(left.analysis.risk_assessment);
    const rightLevel = getRiskLevel(right.analysis.risk_assessment);

    if (rightLevel < leftLevel) {
      return (
        <div className="flex items-center gap-1 text-success">
          <TrendingUp className="w-4 h-4" />
          <span className="text-xs">Improved</span>
        </div>
      );
    } else if (rightLevel > leftLevel) {
      return (
        <div className="flex items-center gap-1 text-destructive">
          <TrendingDown className="w-4 h-4" />
          <span className="text-xs">Worsened</span>
        </div>
      );
    }
    return (
      <div className="flex items-center gap-1 text-muted-foreground">
        <Minus className="w-4 h-4" />
        <span className="text-xs">No Change</span>
      </div>
    );
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (analyses.length < 2) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GitCompare className="w-5 h-5 text-primary" />
            Compare Analyses
          </CardTitle>
          <CardDescription>{certificateName}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <GitCompare className="w-12 h-12 mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground mb-4">
              You need at least 2 analyses to compare.
              <br />
              Currently have: {analyses.length}
            </p>
            {onClose && (
              <Button variant="outline" onClick={onClose}>
                Go Back
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  const leftAnalysis = getSelectedAnalysis(leftId);
  const rightAnalysis = getSelectedAnalysis(rightId);

  return (
    <Card className="bg-card border-border">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <GitCompare className="w-5 h-5 text-primary" />
              Compare Analyses
            </CardTitle>
            <CardDescription>{certificateName}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {getTrendIcon()}
            {leftAnalysis && rightAnalysis && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => exportComparisonPDF({
                  certificateName,
                  leftAnalysis: {
                    id: leftAnalysis.id,
                    created_at: leftAnalysis.created_at,
                    analysis: leftAnalysis.analysis,
                  },
                  rightAnalysis: {
                    id: rightAnalysis.id,
                    created_at: rightAnalysis.created_at,
                    analysis: rightAnalysis.analysis,
                  },
                })}
              >
                <Download className="w-4 h-4 mr-1" />
                Export PDF
              </Button>
            )}
            {onClose && (
              <Button variant="ghost" size="sm" onClick={onClose}>
                Close
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Selectors */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Earlier Analysis
            </label>
            <Select value={leftId} onValueChange={setLeftId}>
              <SelectTrigger>
                <SelectValue placeholder="Select analysis" />
              </SelectTrigger>
              <SelectContent>
                {analyses.map((a) => (
                  <SelectItem key={a.id} value={a.id} disabled={a.id === rightId}>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      {formatDate(a.created_at)}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">
              Later Analysis
            </label>
            <Select value={rightId} onValueChange={setRightId}>
              <SelectTrigger>
                <SelectValue placeholder="Select analysis" />
              </SelectTrigger>
              <SelectContent>
                {analyses.map((a) => (
                  <SelectItem key={a.id} value={a.id} disabled={a.id === leftId}>
                    <div className="flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      {formatDate(a.created_at)}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        {/* Comparison View */}
        <ScrollArea className="h-[400px]">
          <div className="grid grid-cols-2 gap-4">
            {/* Left Column */}
            <div className="space-y-4">
              {leftAnalysis && (
                <AnalysisPanel analysis={leftAnalysis} formatDate={formatDate} getRiskBadge={getRiskBadge} />
              )}
            </div>

            {/* Right Column */}
            <div className="space-y-4">
              {rightAnalysis && (
                <AnalysisPanel analysis={rightAnalysis} formatDate={formatDate} getRiskBadge={getRiskBadge} />
              )}
            </div>
          </div>
        </ScrollArea>

        {/* Comparison Summary */}
        {leftAnalysis && rightAnalysis && (
          <div className="p-4 bg-muted/50 rounded-lg">
            <h4 className="font-medium mb-2">Changes Summary</h4>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div>
                <span className="text-muted-foreground">Recommendations</span>
                <p className="font-medium">
                  {leftAnalysis.analysis.recommendations.length} → {rightAnalysis.analysis.recommendations.length}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Immediate Actions</span>
                <p className="font-medium">
                  {leftAnalysis.analysis.immediate_actions.length} → {rightAnalysis.analysis.immediate_actions.length}
                </p>
              </div>
              <div>
                <span className="text-muted-foreground">Risk Level</span>
                <p className="font-medium capitalize">
                  {leftAnalysis.analysis.risk_assessment} → {rightAnalysis.analysis.risk_assessment}
                </p>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

function AnalysisPanel({
  analysis,
  formatDate,
  getRiskBadge,
}: {
  analysis: SavedAnalysis;
  formatDate: (date: string) => string;
  getRiskBadge: (risk: string) => JSX.Element;
}) {
  return (
    <>
      {/* Header */}
      <div className="p-3 bg-muted/50 rounded-lg">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs text-muted-foreground">{formatDate(analysis.created_at)}</span>
          {getRiskBadge(analysis.analysis.risk_assessment)}
        </div>
        <p className="text-sm">{analysis.analysis.summary}</p>
      </div>

      {/* Immediate Actions */}
      {analysis.analysis.immediate_actions.length > 0 && (
        <div className="p-3 border rounded-lg">
          <h5 className="text-xs font-medium text-warning flex items-center gap-1 mb-2">
            <AlertTriangle className="w-3 h-3" />
            Immediate Actions ({analysis.analysis.immediate_actions.length})
          </h5>
          <ul className="space-y-1">
            {analysis.analysis.immediate_actions.slice(0, 3).map((action, i) => (
              <li key={i} className="text-xs text-muted-foreground flex items-start gap-1">
                <ArrowRight className="w-3 h-3 shrink-0 mt-0.5" />
                <span className="line-clamp-2">{action}</span>
              </li>
            ))}
            {analysis.analysis.immediate_actions.length > 3 && (
              <li className="text-xs text-muted-foreground">
                +{analysis.analysis.immediate_actions.length - 3} more...
              </li>
            )}
          </ul>
        </div>
      )}

      {/* Recommendations Count */}
      <div className="p-3 border rounded-lg">
        <h5 className="text-xs font-medium mb-2">Recommendations</h5>
        <div className="flex gap-2">
          <Badge variant="destructive" className="text-xs">
            High: {analysis.analysis.recommendations.filter((r) => r.priority === "high").length}
          </Badge>
          <Badge className="bg-warning text-warning-foreground text-xs">
            Med: {analysis.analysis.recommendations.filter((r) => r.priority === "medium").length}
          </Badge>
          <Badge variant="secondary" className="text-xs">
            Low: {analysis.analysis.recommendations.filter((r) => r.priority === "low").length}
          </Badge>
        </div>
      </div>

      {/* Long Term */}
      {analysis.analysis.long_term_improvements.length > 0 && (
        <div className="p-3 border rounded-lg">
          <h5 className="text-xs font-medium text-success flex items-center gap-1 mb-2">
            <CheckCircle className="w-3 h-3" />
            Long-term ({analysis.analysis.long_term_improvements.length})
          </h5>
          <ul className="space-y-1">
            {analysis.analysis.long_term_improvements.slice(0, 2).map((item, i) => (
              <li key={i} className="text-xs text-muted-foreground flex items-start gap-1">
                <CheckCircle className="w-3 h-3 shrink-0 mt-0.5" />
                <span className="line-clamp-2">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </>
  );
}

export default AIAnalysisComparison;
