import { useEffect } from "react";

interface UseDynamicMetaProps {
  title?: string;
  description?: string;
  image?: string;
  type?: string;
}

const useDynamicMeta = ({ title, description, image, type = "website" }: UseDynamicMetaProps) => {
  useEffect(() => {
    // Store original values
    const originalTitle = document.title;
    const originalDescription = document.querySelector('meta[name="description"]')?.getAttribute("content");
    const originalOgTitle = document.querySelector('meta[property="og:title"]')?.getAttribute("content");
    const originalOgDescription = document.querySelector('meta[property="og:description"]')?.getAttribute("content");
    const originalOgImage = document.querySelector('meta[property="og:image"]')?.getAttribute("content");
    const originalTwitterTitle = document.querySelector('meta[name="twitter:title"]')?.getAttribute("content");
    const originalTwitterDescription = document.querySelector('meta[name="twitter:description"]')?.getAttribute("content");
    const originalTwitterImage = document.querySelector('meta[name="twitter:image"]')?.getAttribute("content");

    // Update meta tags
    if (title) {
      document.title = title;
      updateMetaTag('meta[property="og:title"]', "property", "og:title", title);
      updateMetaTag('meta[name="twitter:title"]', "name", "twitter:title", title);
    }

    if (description) {
      updateMetaTag('meta[name="description"]', "name", "description", description);
      updateMetaTag('meta[property="og:description"]', "property", "og:description", description);
      updateMetaTag('meta[name="twitter:description"]', "name", "twitter:description", description);
    }

    if (image) {
      updateMetaTag('meta[property="og:image"]', "property", "og:image", image);
      updateMetaTag('meta[name="twitter:image"]', "name", "twitter:image", image);
    }

    if (type) {
      updateMetaTag('meta[property="og:type"]', "property", "og:type", type);
    }

    // Cleanup function to restore original values
    return () => {
      if (originalTitle) document.title = originalTitle;
      if (originalDescription) updateMetaTag('meta[name="description"]', "name", "description", originalDescription);
      if (originalOgTitle) updateMetaTag('meta[property="og:title"]', "property", "og:title", originalOgTitle);
      if (originalOgDescription) updateMetaTag('meta[property="og:description"]', "property", "og:description", originalOgDescription);
      if (originalOgImage) updateMetaTag('meta[property="og:image"]', "property", "og:image", originalOgImage);
      if (originalTwitterTitle) updateMetaTag('meta[name="twitter:title"]', "name", "twitter:title", originalTwitterTitle);
      if (originalTwitterDescription) updateMetaTag('meta[name="twitter:description"]', "name", "twitter:description", originalTwitterDescription);
      if (originalTwitterImage) updateMetaTag('meta[name="twitter:image"]', "name", "twitter:image", originalTwitterImage);
    };
  }, [title, description, image, type]);
};

const updateMetaTag = (selector: string, attrName: string, attrValue: string, content: string) => {
  let element = document.querySelector(selector);
  
  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attrName, attrValue);
    document.head.appendChild(element);
  }
  
  element.setAttribute("content", content);
};

export default useDynamicMeta;
