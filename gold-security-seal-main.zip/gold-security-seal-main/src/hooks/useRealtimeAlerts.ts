import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Json } from "@/integrations/supabase/types";

export interface Alert {
  id: string;
  user_id: string | null;
  title: string;
  description: string;
  severity: "critical" | "high" | "medium" | "low";
  status: "active" | "investigating" | "resolved" | "dismissed";
  alert_type: "malware" | "backdoor" | "uptime";
  source: string;
  metadata: Json;
  resolved_at: string | null;
  created_at: string;
  updated_at: string;
  resolution_notes?: string | null;
  original_severity?: string | null;
  escalation_count?: number | null;
  escalated_at?: string | null;
}

type AlertStatus = Alert["status"];

export function useRealtimeAlerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch initial alerts
  const fetchAlerts = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from("alerts")
        .select("*")
        .order("created_at", { ascending: false });

      if (fetchError) throw fetchError;
      setAlerts((data as Alert[]) || []);
      setError(null);
    } catch (err) {
      console.error("Error fetching alerts:", err);
      setError("Failed to fetch alerts");
    } finally {
      setLoading(false);
    }
  }, []);

  // Subscribe to realtime updates
  useEffect(() => {
    fetchAlerts();

    const channel = supabase
      .channel("alerts-realtime")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "alerts",
        },
        (payload) => {
          console.log("Realtime alert update:", payload);

          if (payload.eventType === "INSERT") {
            const newAlert = payload.new as Alert;
            setAlerts((prev) => [newAlert, ...prev]);
            
            // Show toast notification for new alerts
            toast({
              title: `New ${newAlert.alert_type} Alert`,
              description: newAlert.title,
              variant: newAlert.severity === "critical" ? "destructive" : "default",
            });
          } else if (payload.eventType === "UPDATE") {
            const updatedAlert = payload.new as Alert;
            setAlerts((prev) =>
              prev.map((alert) =>
                alert.id === updatedAlert.id ? updatedAlert : alert
              )
            );
          } else if (payload.eventType === "DELETE") {
            const deletedAlert = payload.old as { id: string };
            setAlerts((prev) =>
              prev.filter((alert) => alert.id !== deletedAlert.id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchAlerts, toast]);

  // Update alert status
  const updateAlertStatus = useCallback(
    async (alertId: string, status: AlertStatus) => {
      try {
        const updates: { status: string; resolved_at?: string } = { status };
        if (status === "resolved") {
          updates.resolved_at = new Date().toISOString();
        }

        const { error: updateError } = await supabase
          .from("alerts")
          .update(updates)
          .eq("id", alertId);

        if (updateError) throw updateError;

        toast({
          title: "Alert Updated",
          description: `Alert status changed to ${status}`,
        });
      } catch (err) {
        console.error("Error updating alert:", err);
        toast({
          title: "Error",
          description: "Failed to update alert status",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Dismiss alert
  const dismissAlert = useCallback(
    async (alertId: string) => {
      await updateAlertStatus(alertId, "dismissed");
    },
    [updateAlertStatus]
  );

  // Resolve alert
  const resolveAlert = useCallback(
    async (alertId: string) => {
      await updateAlertStatus(alertId, "resolved");
    },
    [updateAlertStatus]
  );

  // Delete alert
  const deleteAlert = useCallback(
    async (alertId: string) => {
      try {
        const { error: deleteError } = await supabase
          .from("alerts")
          .delete()
          .eq("id", alertId);

        if (deleteError) throw deleteError;

        toast({
          title: "Alert Deleted",
          description: "Alert has been removed",
        });
      } catch (err) {
        console.error("Error deleting alert:", err);
        toast({
          title: "Error",
          description: "Failed to delete alert",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Create a new alert (for testing/demo)
  const createAlert = useCallback(
    async (alertData: {
      title: string;
      description: string;
      severity: string;
      alert_type: string;
      source: string;
      status?: string;
      metadata?: Json;
    }) => {
      try {
        const { data: userData } = await supabase.auth.getUser();
        
        const { error: insertError } = await supabase.from("alerts").insert({
          title: alertData.title,
          description: alertData.description,
          severity: alertData.severity,
          alert_type: alertData.alert_type,
          source: alertData.source,
          status: alertData.status || "active",
          metadata: alertData.metadata || {},
          user_id: userData.user?.id,
        });

        if (insertError) throw insertError;

        toast({
          title: "Alert Created",
          description: "New alert has been added",
        });
      } catch (err) {
        console.error("Error creating alert:", err);
        toast({
          title: "Error",
          description: "Failed to create alert",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Filter alerts by type
  const malwareAlerts = alerts.filter((a) => a.alert_type === "malware");
  const backdoorAlerts = alerts.filter((a) => a.alert_type === "backdoor");
  const uptimeAlerts = alerts.filter((a) => a.alert_type === "uptime");

  // Count active alerts
  const activeCount = alerts.filter((a) => a.status === "active").length;
  const criticalCount = alerts.filter(
    (a) => a.severity === "critical" && a.status === "active"
  ).length;

  return {
    alerts,
    malwareAlerts,
    backdoorAlerts,
    uptimeAlerts,
    loading,
    error,
    activeCount,
    criticalCount,
    fetchAlerts,
    updateAlertStatus,
    dismissAlert,
    resolveAlert,
    deleteAlert,
    createAlert,
  };
}
