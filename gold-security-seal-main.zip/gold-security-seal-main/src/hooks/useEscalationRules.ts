import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export interface EscalationRule {
  id: string;
  user_id: string | null;
  name: string;
  description: string | null;
  severity: "critical" | "high" | "medium" | "low";
  alert_type: "malware" | "backdoor" | "uptime" | "all";
  threshold_minutes: number;
  escalate_to_severity: "critical" | "high" | "medium";
  notify_email: boolean;
  notify_slack: boolean;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CreateEscalationRuleData {
  name: string;
  description?: string;
  severity: string;
  alert_type: string;
  threshold_minutes: number;
  escalate_to_severity: string;
  notify_email?: boolean;
  notify_slack?: boolean;
  is_active?: boolean;
}

export function useEscalationRules() {
  const [rules, setRules] = useState<EscalationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  // Fetch escalation rules
  const fetchRules = useCallback(async () => {
    try {
      setLoading(true);
      const { data, error: fetchError } = await supabase
        .from("alert_escalation_rules")
        .select("*")
        .order("created_at", { ascending: false });

      if (fetchError) throw fetchError;
      setRules((data as EscalationRule[]) || []);
      setError(null);
    } catch (err) {
      console.error("Error fetching escalation rules:", err);
      setError("Failed to fetch escalation rules");
    } finally {
      setLoading(false);
    }
  }, []);

  // Subscribe to realtime updates
  useEffect(() => {
    fetchRules();

    const channel = supabase
      .channel("escalation-rules-realtime")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "alert_escalation_rules",
        },
        (payload) => {
          console.log("Realtime escalation rule update:", payload);

          if (payload.eventType === "INSERT") {
            const newRule = payload.new as EscalationRule;
            setRules((prev) => [newRule, ...prev]);
          } else if (payload.eventType === "UPDATE") {
            const updatedRule = payload.new as EscalationRule;
            setRules((prev) =>
              prev.map((rule) =>
                rule.id === updatedRule.id ? updatedRule : rule
              )
            );
          } else if (payload.eventType === "DELETE") {
            const deletedRule = payload.old as { id: string };
            setRules((prev) =>
              prev.filter((rule) => rule.id !== deletedRule.id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchRules]);

  // Create a new escalation rule
  const createRule = useCallback(
    async (ruleData: CreateEscalationRuleData) => {
      try {
        const { data: userData } = await supabase.auth.getUser();
        
        const { error: insertError } = await supabase
          .from("alert_escalation_rules")
          .insert({
            name: ruleData.name,
            description: ruleData.description || null,
            severity: ruleData.severity,
            alert_type: ruleData.alert_type,
            threshold_minutes: ruleData.threshold_minutes,
            escalate_to_severity: ruleData.escalate_to_severity,
            notify_email: ruleData.notify_email ?? true,
            notify_slack: ruleData.notify_slack ?? false,
            is_active: ruleData.is_active ?? true,
            user_id: userData.user?.id,
          });

        if (insertError) throw insertError;

        toast({
          title: "Rule Created",
          description: "Escalation rule has been added",
        });
      } catch (err) {
        console.error("Error creating escalation rule:", err);
        toast({
          title: "Error",
          description: "Failed to create escalation rule",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Update an escalation rule
  const updateRule = useCallback(
    async (ruleId: string, updates: Partial<CreateEscalationRuleData>) => {
      try {
        const { error: updateError } = await supabase
          .from("alert_escalation_rules")
          .update(updates)
          .eq("id", ruleId);

        if (updateError) throw updateError;

        toast({
          title: "Rule Updated",
          description: "Escalation rule has been updated",
        });
      } catch (err) {
        console.error("Error updating escalation rule:", err);
        toast({
          title: "Error",
          description: "Failed to update escalation rule",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Toggle rule active status
  const toggleRuleActive = useCallback(
    async (ruleId: string, isActive: boolean) => {
      try {
        const { error: updateError } = await supabase
          .from("alert_escalation_rules")
          .update({ is_active: isActive })
          .eq("id", ruleId);

        if (updateError) throw updateError;

        toast({
          title: isActive ? "Rule Enabled" : "Rule Disabled",
          description: `Escalation rule has been ${isActive ? "enabled" : "disabled"}`,
        });
      } catch (err) {
        console.error("Error toggling escalation rule:", err);
        toast({
          title: "Error",
          description: "Failed to update escalation rule",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Delete an escalation rule
  const deleteRule = useCallback(
    async (ruleId: string) => {
      try {
        const { error: deleteError } = await supabase
          .from("alert_escalation_rules")
          .delete()
          .eq("id", ruleId);

        if (deleteError) throw deleteError;

        toast({
          title: "Rule Deleted",
          description: "Escalation rule has been removed",
        });
      } catch (err) {
        console.error("Error deleting escalation rule:", err);
        toast({
          title: "Error",
          description: "Failed to delete escalation rule",
          variant: "destructive",
        });
      }
    },
    [toast]
  );

  // Manually trigger escalation check
  const triggerEscalationCheck = useCallback(async () => {
    try {
      const { error: rpcError } = await supabase.rpc("check_and_escalate_alerts");

      if (rpcError) throw rpcError;

      toast({
        title: "Escalation Check Complete",
        description: "Alerts have been checked and escalated if necessary",
      });
    } catch (err) {
      console.error("Error running escalation check:", err);
      toast({
        title: "Error",
        description: "Failed to run escalation check",
        variant: "destructive",
      });
    }
  }, [toast]);

  const activeRulesCount = rules.filter((r) => r.is_active).length;

  return {
    rules,
    loading,
    error,
    activeRulesCount,
    fetchRules,
    createRule,
    updateRule,
    toggleRuleActive,
    deleteRule,
    triggerEscalationCheck,
  };
}
