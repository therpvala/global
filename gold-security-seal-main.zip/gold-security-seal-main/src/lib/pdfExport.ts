import jsPDF from "jspdf";

interface CertificateData {
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  auditor_name: string;
  auditor_title: string;
  auditor_initials: string;
  ssl_score?: number;
  dns_score?: number;
  server_score?: number;
  ai_recommendations?: string;
}

const getCertificateLevel = (score: number): string => {
  if (score >= 85) return "PLATINUM";
  if (score >= 70) return "GOLD";
  if (score >= 50) return "SILVER";
  return "BRONZE";
};

const getSecurityChecks = (score: number) => {
  return [
    { label: "Malware & Injection Scan", status: score >= 50 ? "PASS" : "FAIL" },
    { label: "Developer Backdoor Detection", status: score >= 40 ? "PASS" : "FAIL" },
    { label: "SSL Security Validation", status: score >= 60 ? "PASS" : "PARTIAL" },
    { label: "DNS & Nameserver Check", status: score >= 55 ? "PASS" : "PARTIAL" },
    { label: "Admin Panel Safety", status: score >= 70 ? "PASS" : "PARTIAL" },
    { label: "File Integrity Test", status: score >= 65 ? "PASS" : "PARTIAL" },
    { label: "Server Health Audit", status: score >= 75 ? "PASS" : "PARTIAL" },
  ];
};

const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
};

export const exportCertificatePDF = (certificate: CertificateData): void => {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  
  // Colors
  const primaryColor: [number, number, number] = [212, 175, 55]; // Gold
  const darkColor: [number, number, number] = [30, 30, 35];
  const grayColor: [number, number, number] = [120, 120, 130];
  const successColor: [number, number, number] = [34, 197, 94];
  const warningColor: [number, number, number] = [234, 179, 8];
  const dangerColor: [number, number, number] = [239, 68, 68];

  // Background
  doc.setFillColor(248, 248, 250);
  doc.rect(0, 0, pageWidth, pageHeight, "F");

  // Header border
  doc.setDrawColor(...primaryColor);
  doc.setLineWidth(2);
  doc.rect(margin - 5, margin - 5, pageWidth - 2 * margin + 10, pageHeight - 2 * margin + 10);
  doc.setLineWidth(0.5);
  doc.rect(margin - 2, margin - 2, pageWidth - 2 * margin + 4, pageHeight - 2 * margin + 4);

  // Shield icons (simplified as decorative elements)
  doc.setFillColor(...primaryColor);
  doc.circle(margin + 10, 35, 5, "F");
  doc.circle(pageWidth - margin - 10, 35, 5, "F");

  // Title
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.setTextColor(...darkColor);
  doc.text("CYBER SECURITY", pageWidth / 2, 35, { align: "center" });

  doc.setFontSize(16);
  doc.setTextColor(...primaryColor);
  doc.text("VERIFICATION CERTIFICATE", pageWidth / 2, 45, { align: "center" });

  // Award text
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...grayColor);
  doc.text("This Certificate is Awarded To", pageWidth / 2, 60, { align: "center" });

  // Website name
  doc.setFont("helvetica", "bold");
  doc.setFontSize(22);
  doc.setTextColor(...darkColor);
  doc.text(certificate.website_name, pageWidth / 2, 72, { align: "center" });

  // Owner
  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...grayColor);
  doc.text("Owned & Managed By", pageWidth / 2, 82, { align: "center" });

  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.setTextColor(...darkColor);
  doc.text(certificate.owner_name, pageWidth / 2, 90, { align: "center" });

  // Divider
  doc.setDrawColor(...primaryColor);
  doc.setLineWidth(0.5);
  doc.line(margin + 20, 98, pageWidth - margin - 20, 98);

  // Two columns section
  const leftColX = margin + 10;
  const rightColX = pageWidth / 2 + 10;
  let currentY = 108;

  // Left column - Status & Security Checks
  const getStatusLabel = () => {
    if (certificate.score >= 60) return "CERTIFIED";
    if (certificate.score >= 40) return "WARNING";
    return "FAILED";
  };

  const statusColor = certificate.score >= 60 ? successColor : certificate.score >= 40 ? warningColor : dangerColor;
  
  // Status badge
  doc.setFillColor(...statusColor);
  doc.roundedRect(leftColX, currentY, 60, 10, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text(getStatusLabel(), leftColX + 30, currentY + 7, { align: "center" });

  currentY += 18;

  // Security Checks
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...grayColor);
  doc.text("SECURITY CHECKS", leftColX, currentY);
  currentY += 8;

  const checks = getSecurityChecks(certificate.score);
  doc.setFontSize(8);
  checks.forEach((check) => {
    const checkColor = check.status === "PASS" ? successColor : check.status === "PARTIAL" ? warningColor : dangerColor;
    
    // Status indicator
    doc.setFillColor(...checkColor);
    doc.circle(leftColX + 3, currentY - 1, 2, "F");
    
    doc.setFont("helvetica", "normal");
    doc.setTextColor(...darkColor);
    doc.text(check.label, leftColX + 8, currentY);
    
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...checkColor);
    doc.text(check.status, leftColX + 60, currentY);
    
    currentY += 6;
  });

  // Right column - Score circle
  const scoreY = 130;
  const scoreRadius = 25;
  
  // Score circle background
  const scoreColor = certificate.score >= 70 ? successColor : certificate.score >= 40 ? warningColor : dangerColor;
  doc.setDrawColor(...scoreColor);
  doc.setLineWidth(3);
  doc.circle(rightColX + 30, scoreY, scoreRadius);
  
  // Score text
  doc.setFont("helvetica", "bold");
  doc.setFontSize(28);
  doc.setTextColor(...scoreColor);
  doc.text(certificate.score.toString(), rightColX + 30, scoreY + 5, { align: "center" });
  
  doc.setFontSize(10);
  doc.setTextColor(...grayColor);
  doc.text("/ 100", rightColX + 30, scoreY + 12, { align: "center" });

  // Risk level
  doc.setFontSize(10);
  doc.setTextColor(...grayColor);
  doc.text("RISK LEVEL", rightColX + 30, scoreY + 25, { align: "center" });
  
  const riskColor = certificate.risk_level === "low" ? successColor : certificate.risk_level === "medium" ? warningColor : dangerColor;
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...riskColor);
  doc.text(certificate.risk_level.toUpperCase(), rightColX + 30, scoreY + 32, { align: "center" });

  // Certificate level badge
  const level = getCertificateLevel(certificate.score);
  doc.setFillColor(...primaryColor);
  doc.circle(rightColX + 30, scoreY + 55, 18, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(level, rightColX + 30, scoreY + 56, { align: "center" });
  
  doc.setFontSize(7);
  doc.setTextColor(...primaryColor);
  doc.text("SECURITY CERTIFICATE", rightColX + 30, scoreY + 72, { align: "center" });

  // Bottom section divider
  currentY = 210;
  doc.setDrawColor(...primaryColor);
  doc.setLineWidth(0.3);
  doc.line(margin, currentY, pageWidth - margin, currentY);

  // Bottom info section
  currentY += 10;
  
  // QR placeholder and certificate info
  doc.setFillColor(240, 240, 245);
  doc.roundedRect(leftColX, currentY, 35, 35, 2, 2, "F");
  doc.setFontSize(7);
  doc.setTextColor(...grayColor);
  doc.text("QR CODE", leftColX + 17.5, currentY + 20, { align: "center" });

  // Certificate details next to QR
  const infoX = leftColX + 42;
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...grayColor);
  doc.text("Certificate ID:", infoX, currentY + 8);
  doc.text("Issue Date:", infoX, currentY + 16);
  doc.text("Expiry Date:", infoX, currentY + 24);
  doc.text("Verification:", infoX, currentY + 32);

  doc.setFont("helvetica", "bold");
  doc.setTextColor(...darkColor);
  doc.text(certificate.certificate_id, infoX + 25, currentY + 8);
  doc.text(formatDate(certificate.issue_date), infoX + 25, currentY + 16);
  doc.text(formatDate(certificate.expiry_date), infoX + 25, currentY + 24);
  doc.text("secureaudit.com/verify", infoX + 25, currentY + 32);

  // Signature block (right side)
  const sigX = rightColX + 10;
  
  // Initials circle
  doc.setFillColor(...primaryColor);
  doc.circle(sigX + 15, currentY + 12, 10, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(255, 255, 255);
  doc.text(certificate.auditor_initials, sigX + 15, currentY + 16, { align: "center" });

  // Signature line and info
  doc.setDrawColor(...darkColor);
  doc.setLineWidth(0.5);
  doc.line(sigX + 30, currentY + 22, sigX + 65, currentY + 22);
  
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(...darkColor);
  doc.text(certificate.auditor_name, sigX + 47.5, currentY + 28, { align: "center" });
  
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(...grayColor);
  doc.text(certificate.auditor_title, sigX + 47.5, currentY + 33, { align: "center" });

  // Footer
  doc.setFont("helvetica", "bold");
  doc.setFontSize(12);
  doc.setTextColor(...primaryColor);
  doc.text("SECUREAUDIT", pageWidth / 2, pageHeight - 20, { align: "center" });
  
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(...grayColor);
  doc.text("OFFICIAL CYBER SECURITY VERIFICATION AUTHORITY", pageWidth / 2, pageHeight - 15, { align: "center" });

  // Page 2 - AI Security Recommendations (if available)
  if (certificate.ai_recommendations) {
    doc.addPage();
    
    // Background
    doc.setFillColor(248, 248, 250);
    doc.rect(0, 0, pageWidth, pageHeight, "F");
    
    // Border
    doc.setDrawColor(...primaryColor);
    doc.setLineWidth(2);
    doc.rect(margin - 5, margin - 5, pageWidth - 2 * margin + 10, pageHeight - 2 * margin + 10);
    doc.setLineWidth(0.5);
    doc.rect(margin - 2, margin - 2, pageWidth - 2 * margin + 4, pageHeight - 2 * margin + 4);
    
    // Header
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(...darkColor);
    doc.text("AI SECURITY ANALYSIS", pageWidth / 2, 35, { align: "center" });
    
    doc.setFontSize(11);
    doc.setTextColor(...primaryColor);
    doc.text("Powered by Lovable AI", pageWidth / 2, 43, { align: "center" });
    
    // Certificate reference
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...grayColor);
    doc.text(`Certificate: ${certificate.certificate_id} | Website: ${certificate.website_name}`, pageWidth / 2, 52, { align: "center" });
    
    // Divider
    doc.setDrawColor(...primaryColor);
    doc.setLineWidth(0.5);
    doc.line(margin + 10, 58, pageWidth - margin - 10, 58);
    
    // Recommendations content
    let recY = 68;
    const maxWidth = pageWidth - 2 * margin - 10;
    
    // Split recommendations into sections
    const lines = certificate.ai_recommendations.split('\n');
    
    for (const line of lines) {
      if (recY > pageHeight - 30) break; // Prevent overflow
      
      const trimmedLine = line.trim();
      if (!trimmedLine) {
        recY += 4;
        continue;
      }
      
      // Check if it's a header (starts with number and dot, or is uppercase)
      const isHeader = /^\d+\./.test(trimmedLine) || /^[A-Z\s]+:$/.test(trimmedLine);
      const isBullet = trimmedLine.startsWith('-') || trimmedLine.startsWith('•');
      
      if (isHeader) {
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10);
        doc.setTextColor(...darkColor);
        recY += 4;
      } else if (isBullet) {
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(...grayColor);
        // Add bullet point indicator
        doc.setFillColor(...primaryColor);
        doc.circle(margin + 8, recY - 1, 1.5, "F");
      } else {
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9);
        doc.setTextColor(...darkColor);
      }
      
      // Wrap text to fit width
      const textX = isBullet ? margin + 14 : margin + 5;
      const availableWidth = isBullet ? maxWidth - 9 : maxWidth;
      const splitText = doc.splitTextToSize(trimmedLine.replace(/^[-•]\s*/, ''), availableWidth);
      
      for (const textLine of splitText) {
        if (recY > pageHeight - 30) break;
        doc.text(textLine, textX, recY);
        recY += 5;
      }
    }
    
    // Footer
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(...grayColor);
    doc.text("This AI analysis is generated automatically and should be reviewed by security professionals.", pageWidth / 2, pageHeight - 20, { align: "center" });
    
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...primaryColor);
    doc.text("SECUREAUDIT", pageWidth / 2, pageHeight - 12, { align: "center" });
  }

  // Save PDF
  doc.save(`SecureAudit-Certificate-${certificate.certificate_id}.pdf`);
};

interface ComparisonAnalysis {
  id: string;
  created_at: string;
  analysis: {
    summary: string;
    risk_assessment: string;
    recommendations: Array<{ priority: string; category: string; title: string; description: string }>;
    immediate_actions: string[];
    long_term_improvements: string[];
  };
}

interface ComparisonData {
  certificateName: string;
  leftAnalysis: ComparisonAnalysis;
  rightAnalysis: ComparisonAnalysis;
}

export const exportComparisonPDF = (data: ComparisonData): void => {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 15;
  
  // Colors
  const primaryColor: [number, number, number] = [212, 175, 55];
  const darkColor: [number, number, number] = [30, 30, 35];
  const grayColor: [number, number, number] = [120, 120, 130];
  const successColor: [number, number, number] = [34, 197, 94];
  const warningColor: [number, number, number] = [234, 179, 8];
  const dangerColor: [number, number, number] = [239, 68, 68];

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getRiskColor = (risk: string): [number, number, number] => {
    switch (risk.toLowerCase()) {
      case "critical":
      case "high":
        return dangerColor;
      case "medium":
        return warningColor;
      default:
        return successColor;
    }
  };

  const getRiskLevel = (risk: string): number => {
    const levels: Record<string, number> = { low: 1, medium: 2, high: 3, critical: 4 };
    return levels[risk.toLowerCase()] || 0;
  };

  // Background
  doc.setFillColor(248, 248, 250);
  doc.rect(0, 0, pageWidth, pageHeight, "F");

  // Border
  doc.setDrawColor(...primaryColor);
  doc.setLineWidth(2);
  doc.rect(margin - 3, margin - 3, pageWidth - 2 * margin + 6, pageHeight - 2 * margin + 6);

  // Header
  doc.setFont("helvetica", "bold");
  doc.setFontSize(20);
  doc.setTextColor(...darkColor);
  doc.text("AI ANALYSIS COMPARISON", pageWidth / 2, 30, { align: "center" });

  doc.setFontSize(12);
  doc.setTextColor(...primaryColor);
  doc.text("Security Trend Report", pageWidth / 2, 38, { align: "center" });

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(...grayColor);
  doc.text(data.certificateName, pageWidth / 2, 46, { align: "center" });

  // Trend indicator
  const leftLevel = getRiskLevel(data.leftAnalysis.analysis.risk_assessment);
  const rightLevel = getRiskLevel(data.rightAnalysis.analysis.risk_assessment);
  let trendText = "No Change";
  let trendColor = grayColor;
  if (rightLevel < leftLevel) {
    trendText = "↑ Security Improved";
    trendColor = successColor;
  } else if (rightLevel > leftLevel) {
    trendText = "↓ Security Worsened";
    trendColor = dangerColor;
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(...trendColor);
  doc.text(trendText, pageWidth / 2, 56, { align: "center" });

  // Divider
  doc.setDrawColor(...primaryColor);
  doc.setLineWidth(0.5);
  doc.line(margin, 62, pageWidth - margin, 62);

  // Column headers
  let currentY = 72;
  const colWidth = (pageWidth - 2 * margin - 10) / 2;
  const leftColX = margin;
  const rightColX = margin + colWidth + 10;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...grayColor);
  doc.text("EARLIER ANALYSIS", leftColX, currentY);
  doc.text("LATER ANALYSIS", rightColX, currentY);

  currentY += 6;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text(formatDate(data.leftAnalysis.created_at), leftColX, currentY);
  doc.text(formatDate(data.rightAnalysis.created_at), rightColX, currentY);

  currentY += 10;

  // Risk Level boxes
  const drawRiskBox = (x: number, y: number, risk: string) => {
    const color = getRiskColor(risk);
    doc.setFillColor(...color);
    doc.roundedRect(x, y, 40, 8, 2, 2, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text(risk.toUpperCase() + " RISK", x + 20, y + 5.5, { align: "center" });
  };

  drawRiskBox(leftColX, currentY, data.leftAnalysis.analysis.risk_assessment);
  drawRiskBox(rightColX, currentY, data.rightAnalysis.analysis.risk_assessment);

  currentY += 14;

  // Summary sections
  const drawSection = (title: string, leftContent: string, rightContent: string, y: number): number => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...darkColor);
    doc.text(title, leftColX, y);
    
    y += 5;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(...grayColor);
    
    const leftLines = doc.splitTextToSize(leftContent, colWidth - 5);
    const rightLines = doc.splitTextToSize(rightContent, colWidth - 5);
    
    leftLines.slice(0, 4).forEach((line: string, i: number) => {
      doc.text(line, leftColX, y + i * 4);
    });
    
    rightLines.slice(0, 4).forEach((line: string, i: number) => {
      doc.text(line, rightColX, y + i * 4);
    });
    
    return y + Math.max(leftLines.length, rightLines.length, 4) * 4 + 4;
  };

  currentY = drawSection("Summary", data.leftAnalysis.analysis.summary, data.rightAnalysis.analysis.summary, currentY);

  // Recommendations comparison
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...darkColor);
  doc.text("Recommendations", leftColX, currentY);
  currentY += 6;

  const drawRecommendationStats = (x: number, recs: Array<{ priority: string }>) => {
    const high = recs.filter(r => r.priority === "high").length;
    const medium = recs.filter(r => r.priority === "medium").length;
    const low = recs.filter(r => r.priority === "low").length;
    
    doc.setFontSize(7);
    
    // High
    doc.setFillColor(...dangerColor);
    doc.roundedRect(x, currentY, 22, 6, 1, 1, "F");
    doc.setTextColor(255, 255, 255);
    doc.text(`High: ${high}`, x + 11, currentY + 4.2, { align: "center" });
    
    // Medium
    doc.setFillColor(...warningColor);
    doc.roundedRect(x + 24, currentY, 22, 6, 1, 1, "F");
    doc.setTextColor(30, 30, 35);
    doc.text(`Med: ${medium}`, x + 35, currentY + 4.2, { align: "center" });
    
    // Low
    doc.setFillColor(200, 200, 210);
    doc.roundedRect(x + 48, currentY, 22, 6, 1, 1, "F");
    doc.setTextColor(60, 60, 70);
    doc.text(`Low: ${low}`, x + 59, currentY + 4.2, { align: "center" });
  };

  drawRecommendationStats(leftColX, data.leftAnalysis.analysis.recommendations);
  drawRecommendationStats(rightColX, data.rightAnalysis.analysis.recommendations);
  currentY += 12;

  // Immediate Actions
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...darkColor);
  doc.text("Immediate Actions", leftColX, currentY);
  currentY += 5;

  const drawActionList = (x: number, actions: string[], maxY: number): number => {
    let y = currentY;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(...grayColor);
    
    actions.slice(0, 4).forEach((action, i) => {
      if (y > maxY) return;
      doc.setFillColor(...warningColor);
      doc.circle(x + 2, y, 1, "F");
      const lines = doc.splitTextToSize(action, colWidth - 10);
      lines.slice(0, 2).forEach((line: string, j: number) => {
        if (y + j * 3.5 <= maxY) {
          doc.text(line, x + 6, y + j * 3.5);
        }
      });
      y += lines.slice(0, 2).length * 3.5 + 2;
    });
    return y;
  };

  const leftY = drawActionList(leftColX, data.leftAnalysis.analysis.immediate_actions, 180);
  const rightY = drawActionList(rightColX, data.rightAnalysis.analysis.immediate_actions, 180);
  currentY = Math.max(leftY, rightY) + 6;

  // Long-term Improvements
  if (currentY < 200) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(...darkColor);
    doc.text("Long-term Improvements", leftColX, currentY);
    currentY += 5;

    const drawImprovementList = (x: number, items: string[], maxY: number): number => {
      let y = currentY;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(7);
      doc.setTextColor(...grayColor);
      
      items.slice(0, 3).forEach((item) => {
        if (y > maxY) return;
        doc.setFillColor(...successColor);
        doc.circle(x + 2, y, 1, "F");
        const lines = doc.splitTextToSize(item, colWidth - 10);
        lines.slice(0, 2).forEach((line: string, j: number) => {
          if (y + j * 3.5 <= maxY) {
            doc.text(line, x + 6, y + j * 3.5);
          }
        });
        y += lines.slice(0, 2).length * 3.5 + 2;
      });
      return y;
    };

    const lY = drawImprovementList(leftColX, data.leftAnalysis.analysis.long_term_improvements, 230);
    const rY = drawImprovementList(rightColX, data.rightAnalysis.analysis.long_term_improvements, 230);
    currentY = Math.max(lY, rY);
  }

  // Changes Summary Box
  currentY = Math.max(currentY + 8, 235);
  
  doc.setFillColor(240, 240, 245);
  doc.roundedRect(margin, currentY, pageWidth - 2 * margin, 25, 3, 3, "F");
  
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(...darkColor);
  doc.text("CHANGES SUMMARY", margin + 5, currentY + 6);
  
  const summaryY = currentY + 13;
  const summaryColW = (pageWidth - 2 * margin - 20) / 3;
  
  doc.setFontSize(7);
  doc.setTextColor(...grayColor);
  doc.text("Recommendations", margin + 5, summaryY);
  doc.text("Immediate Actions", margin + 5 + summaryColW, summaryY);
  doc.text("Risk Level", margin + 5 + summaryColW * 2, summaryY);
  
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(...darkColor);
  doc.text(`${data.leftAnalysis.analysis.recommendations.length} → ${data.rightAnalysis.analysis.recommendations.length}`, margin + 5, summaryY + 5);
  doc.text(`${data.leftAnalysis.analysis.immediate_actions.length} → ${data.rightAnalysis.analysis.immediate_actions.length}`, margin + 5 + summaryColW, summaryY + 5);
  doc.text(`${data.leftAnalysis.analysis.risk_assessment} → ${data.rightAnalysis.analysis.risk_assessment}`, margin + 5 + summaryColW * 2, summaryY + 5);

  // Footer
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(...primaryColor);
  doc.text("SECUREAUDIT", pageWidth / 2, pageHeight - 18, { align: "center" });
  
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(...grayColor);
  doc.text(`Generated: ${new Date().toLocaleDateString("en-GB")}`, pageWidth / 2, pageHeight - 13, { align: "center" });

  // Save
  doc.save(`SecureAudit-Comparison-${data.certificateName.replace(/[^a-zA-Z0-9]/g, "-")}.pdf`);
};
