import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import CertificateAnalytics from "@/components/CertificateAnalytics";
import DashboardLayout from "@/components/layout/DashboardLayout";

interface Certificate {
  id: string;
  certificate_id: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
}

const Analytics = () => {
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    
    const fetchCertificates = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("id, certificate_id, score, risk_level, status, issue_date, expiry_date, created_at")
        .order("created_at", { ascending: false });

      if (error) {
        toast.error("Failed to load analytics data");
        console.error(error);
      } else {
        setCertificates(data || []);
      }
      setIsLoading(false);
    };

    fetchCertificates();
  }, [user]);

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics</h1>
          <p className="text-muted-foreground">Certificate performance and security trends</p>
        </div>

        <CertificateAnalytics certificates={certificates} />
      </div>
    </DashboardLayout>
  );
};

export default Analytics;
