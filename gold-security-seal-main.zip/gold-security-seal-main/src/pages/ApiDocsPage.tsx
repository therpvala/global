import DashboardLayout from "@/components/layout/DashboardLayout";
import ApiDocumentation from "@/components/ApiDocumentation";

const ApiDocsPage = () => {
  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">API Documentation</h1>
          <p className="text-muted-foreground">Learn how to integrate with our API</p>
        </div>

        <ApiDocumentation />
      </div>
    </DashboardLayout>
  );
};

export default ApiDocsPage;
