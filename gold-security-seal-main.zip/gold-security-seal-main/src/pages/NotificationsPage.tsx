import { useState, useEffect } from "react";
import { Loader2, ShieldAlert, Bell, Send, Save } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import NotificationsPanel from "@/components/NotificationsPanel";
import DashboardLayout from "@/components/layout/DashboardLayout";
import type { Json } from "@/integrations/supabase/types";

interface NotificationSettings {
  email_enabled: boolean;
  expiry_reminder_days: number[];
  admin_email: string;
}

const NotificationsPage = () => {
  const { user } = useAuth();
  const [hasAccess, setHasAccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isSendingNotifications, setIsSendingNotifications] = useState(false);

  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    email_enabled: false,
    expiry_reminder_days: [30, 14, 7],
    admin_email: "",
  });

  useEffect(() => {
    const checkAccessAndFetch = async () => {
      if (!user) return;

      const { data: roleData, error: roleError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .single();

      if (roleData && !roleError) {
        const access = roleData.role === "admin" || roleData.role === "moderator";
        setHasAccess(access);

        if (access) {
          const { data, error } = await supabase
            .from("app_settings")
            .select("*")
            .eq("key", "notifications")
            .single();

          if (data && !error) {
            setNotificationSettings(data.value as unknown as NotificationSettings);
          }
        }
      }
      setIsLoading(false);
    };

    checkAccessAndFetch();
  }, [user]);

  const handleSave = async () => {
    setIsSaving(true);
    const { error } = await supabase
      .from("app_settings")
      .update({ value: JSON.parse(JSON.stringify(notificationSettings)) as Json })
      .eq("key", "notifications");

    if (error) {
      toast.error("Failed to save settings");
      console.error(error);
    } else {
      toast.success("Notification settings saved");
    }
    setIsSaving(false);
  };

  const handleSendNotifications = async () => {
    setIsSendingNotifications(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-expiry-notifications");
      
      if (error) {
        toast.error(`Failed to send notifications: ${error.message}`);
        console.error(error);
      } else if (data?.error) {
        toast.error(data.error);
      } else {
        toast.success(data?.message || "Notifications sent successfully");
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to trigger notifications");
    }
    setIsSendingNotifications(false);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  if (!hasAccess) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <Card className="max-w-md">
            <CardHeader className="text-center">
              <ShieldAlert className="w-12 h-12 mx-auto text-destructive mb-4" />
              <CardTitle>Access Denied</CardTitle>
              <CardDescription>
                You don't have permission to manage notifications. This feature is only available to administrators and moderators.
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
          <p className="text-muted-foreground">Manage notification settings and alerts</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Notification Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Bell className="w-5 h-5 text-primary" />
                Notification Settings
              </CardTitle>
              <CardDescription>
                Configure email notifications and alerts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between rounded-lg border border-border p-4">
                <div className="space-y-0.5">
                  <Label htmlFor="email-enabled">Email Notifications</Label>
                  <p className="text-xs text-muted-foreground">
                    Enable email notifications for certificate expiry
                  </p>
                </div>
                <Switch
                  id="email-enabled"
                  checked={notificationSettings.email_enabled}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({
                      ...notificationSettings,
                      email_enabled: checked,
                    })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="admin-email">Admin Email</Label>
                <Input
                  id="admin-email"
                  type="email"
                  value={notificationSettings.admin_email}
                  onChange={(e) =>
                    setNotificationSettings({
                      ...notificationSettings,
                      admin_email: e.target.value,
                    })
                  }
                  placeholder="admin@example.com"
                  disabled={!notificationSettings.email_enabled}
                />
              </div>

              <div className="space-y-2">
                <Label>Expiry Reminder Schedule</Label>
                <div className="flex flex-wrap gap-2">
                  {[30, 14, 7, 3, 1].map((days) => (
                    <Button
                      key={days}
                      variant={
                        notificationSettings.expiry_reminder_days.includes(days)
                          ? "default"
                          : "outline"
                      }
                      size="sm"
                      disabled={!notificationSettings.email_enabled}
                      onClick={() => {
                        const current = notificationSettings.expiry_reminder_days;
                        const updated = current.includes(days)
                          ? current.filter((d) => d !== days)
                          : [...current, days].sort((a, b) => b - a);
                        setNotificationSettings({
                          ...notificationSettings,
                          expiry_reminder_days: updated,
                        });
                      }}
                    >
                      {days} day{days !== 1 ? "s" : ""}
                    </Button>
                  ))}
                </div>
              </div>

              <Separator />

              <div className="flex flex-wrap gap-3">
                <Button onClick={handleSave} disabled={isSaving}>
                  {isSaving ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 mr-2" />
                  )}
                  Save Settings
                </Button>
                
                <Button
                  variant="outline"
                  onClick={handleSendNotifications}
                  disabled={isSendingNotifications || !notificationSettings.email_enabled}
                >
                  {isSendingNotifications ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Send Test Notifications
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Notifications */}
          <NotificationsPanel />
        </div>
      </div>
    </DashboardLayout>
  );
};

export default NotificationsPage;
