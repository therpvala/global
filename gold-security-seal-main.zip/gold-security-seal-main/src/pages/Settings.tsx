import { useState, useEffect } from "react";
import { Save, Loader2, Building2, FileText, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import ProfileSettings from "@/components/ProfileSettings";
import DashboardLayout from "@/components/layout/DashboardLayout";
import type { Json } from "@/integrations/supabase/types";

interface CompanySettings {
  name: string;
  tagline: string;
  logo_url: string;
}

interface CertificateSettings {
  default_validity_days: number;
  auto_expire_warning_days: number;
  require_signature: boolean;
}

const Settings = () => {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const [companySettings, setCompanySettings] = useState<CompanySettings>({
    name: "SecureAudit",
    tagline: "Professional Security Certification",
    logo_url: "",
  });

  const [certificateSettings, setCertificateSettings] = useState<CertificateSettings>({
    default_validity_days: 365,
    auto_expire_warning_days: 30,
    require_signature: true,
  });

  useEffect(() => {
    if (!user) return;

    const fetchSettings = async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("*");

      if (error) {
        toast.error("Failed to load settings");
        console.error(error);
      } else if (data) {
        data.forEach((setting) => {
          const value = setting.value as Record<string, unknown>;
          switch (setting.key) {
            case "company":
              setCompanySettings(value as unknown as CompanySettings);
              break;
            case "certificate":
              setCertificateSettings(value as unknown as CertificateSettings);
              break;
          }
        });
      }
      setIsLoading(false);
    };

    fetchSettings();
  }, [user]);

  const handleSave = async (key: string, value: CompanySettings | CertificateSettings) => {
    setIsSaving(true);
    const { error } = await supabase
      .from("app_settings")
      .update({ value: JSON.parse(JSON.stringify(value)) as Json })
      .eq("key", key);

    if (error) {
      toast.error("Failed to save settings");
      console.error(error);
    } else {
      toast.success("Settings saved successfully");
    }
    setIsSaving(false);
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6 max-w-4xl">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Configure your application</p>
        </div>

        <div className="grid gap-6">
          {/* Profile Settings */}
          <ProfileSettings />

          {/* Company Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <Palette className="w-5 h-5 text-primary" />
                Branding & Company
              </CardTitle>
              <CardDescription>
                Configure your company information and branding
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="company-name">Company Name</Label>
                <Input
                  id="company-name"
                  value={companySettings.name}
                  onChange={(e) =>
                    setCompanySettings({ ...companySettings, name: e.target.value })
                  }
                  placeholder="Your Company Name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tagline">Tagline</Label>
                <Input
                  id="tagline"
                  value={companySettings.tagline}
                  onChange={(e) =>
                    setCompanySettings({ ...companySettings, tagline: e.target.value })
                  }
                  placeholder="Your company tagline"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="logo-url">Logo URL</Label>
                <Input
                  id="logo-url"
                  value={companySettings.logo_url}
                  onChange={(e) =>
                    setCompanySettings({ ...companySettings, logo_url: e.target.value })
                  }
                  placeholder="https://example.com/logo.png"
                />
              </div>

              <Separator />

              <Button
                onClick={() => handleSave("company", companySettings)}
                disabled={isSaving}
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Save Company Settings
              </Button>
            </CardContent>
          </Card>

          {/* Certificate Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-card-foreground">
                <FileText className="w-5 h-5 text-primary" />
                Certificate Configuration
              </CardTitle>
              <CardDescription>
                Configure default settings for certificate generation
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="validity-days">Default Validity (Days)</Label>
                <Input
                  id="validity-days"
                  type="number"
                  min={1}
                  max={3650}
                  value={certificateSettings.default_validity_days}
                  onChange={(e) =>
                    setCertificateSettings({
                      ...certificateSettings,
                      default_validity_days: Number(e.target.value),
                    })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="warning-days">Expiry Warning (Days)</Label>
                <Input
                  id="warning-days"
                  type="number"
                  min={1}
                  max={365}
                  value={certificateSettings.auto_expire_warning_days}
                  onChange={(e) =>
                    setCertificateSettings({
                      ...certificateSettings,
                      auto_expire_warning_days: Number(e.target.value),
                    })
                  }
                />
              </div>

              <div className="flex items-center justify-between rounded-lg border border-border p-4">
                <div className="space-y-0.5">
                  <Label htmlFor="require-signature">Require Auditor Signature</Label>
                  <p className="text-xs text-muted-foreground">
                    Require digital signature on all certificates
                  </p>
                </div>
                <Switch
                  id="require-signature"
                  checked={certificateSettings.require_signature}
                  onCheckedChange={(checked) =>
                    setCertificateSettings({
                      ...certificateSettings,
                      require_signature: checked,
                    })
                  }
                />
              </div>

              <Separator />

              <Button
                onClick={() => handleSave("certificate", certificateSettings)}
                disabled={isSaving}
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-2" />
                )}
                Save Certificate Settings
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Settings;
