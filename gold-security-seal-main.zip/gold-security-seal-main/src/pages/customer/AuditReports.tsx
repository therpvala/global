import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import {
  FileCode,
  FileText,
  Download,
  Eye,
  CheckCircle,
  AlertTriangle,
  Shield,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import CustomerLayout from "@/components/layout/CustomerLayout";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  score: number;
  risk_level: string;
  ssl_score: number;
  dns_score: number;
  server_score: number;
}

const AuditReports = () => {
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const activeTab = searchParams.get("tab") || "technical";

  useEffect(() => {
    if (!user) return;

    const fetchLatestCertificate = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      if (error) {
        console.error(error);
      } else {
        setCertificate(data);
      }
      setIsLoading(false);
    };

    fetchLatestCertificate();
  }, [user]);

  const technicalFindings = [
    { category: "SSL/TLS Configuration", status: "pass", score: certificate?.ssl_score || 85, details: "Valid SSL certificate with strong encryption" },
    { category: "DNS Security", status: "warning", score: certificate?.dns_score || 70, details: "DNSSEC not fully configured" },
    { category: "Server Security", status: "pass", score: certificate?.server_score || 90, details: "Server headers properly configured" },
    { category: "Cookie Security", status: "pass", score: 88, details: "Secure and HttpOnly flags set" },
    { category: "XSS Protection", status: "warning", score: 75, details: "Content-Security-Policy could be stricter" },
    { category: "CORS Policy", status: "pass", score: 95, details: "Properly restricted cross-origin requests" },
  ];

  const actionItems = [
    { priority: "High", title: "Enable DNSSEC", description: "Configure DNSSEC at your DNS provider to prevent DNS spoofing attacks", status: "pending" },
    { priority: "High", title: "Implement HSTS", description: "Add HTTP Strict Transport Security header with preload directive", status: "pending" },
    { priority: "Medium", title: "Update CSP", description: "Strengthen Content-Security-Policy to block inline scripts", status: "in_progress" },
    { priority: "Medium", title: "Enable SRI", description: "Add Subresource Integrity checks for external scripts", status: "pending" },
    { priority: "Low", title: "Review Cookie Policy", description: "Consider SameSite=Strict for sensitive cookies", status: "completed" },
    { priority: "Low", title: "Add Security.txt", description: "Create /.well-known/security.txt for responsible disclosure", status: "pending" },
  ];

  if (isLoading) {
    return (
      <CustomerLayout>
        <div className="flex items-center justify-center h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </CustomerLayout>
    );
  }

  return (
    <CustomerLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Audit Reports</h1>
            <p className="text-muted-foreground">
              {certificate ? `Latest report for ${certificate.website_name}` : "No reports available"}
            </p>
          </div>
          <Button className="gap-2">
            <Download className="h-4 w-4" />
            Download Full Report
          </Button>
        </div>

        <Tabs defaultValue={activeTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="technical" className="gap-2">
              <FileCode className="h-4 w-4" />
              Technical Audit
            </TabsTrigger>
            <TabsTrigger value="action" className="gap-2">
              <FileText className="h-4 w-4" />
              Action Plan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="technical" className="space-y-6">
            {/* Score Overview */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Overall Score</p>
                    <p className={`text-3xl font-bold ${
                      (certificate?.score || 0) >= 80 ? "text-success" : (certificate?.score || 0) >= 50 ? "text-warning" : "text-destructive"
                    }`}>
                      {certificate?.score || 0}%
                    </p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">SSL Score</p>
                    <p className="text-3xl font-bold text-success">{certificate?.ssl_score || 85}%</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">DNS Score</p>
                    <p className="text-3xl font-bold text-warning">{certificate?.dns_score || 70}%</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Server Score</p>
                    <p className="text-3xl font-bold text-success">{certificate?.server_score || 90}%</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Technical Findings */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Technical Findings</CardTitle>
                <CardDescription>Detailed security analysis results</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {technicalFindings.map((finding, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-muted/50 border border-border">
                    <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
                      finding.status === "pass" ? "bg-success/10" : "bg-warning/10"
                    }`}>
                      {finding.status === "pass" ? (
                        <CheckCircle className="h-4 w-4 text-success" />
                      ) : (
                        <AlertTriangle className="h-4 w-4 text-warning" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{finding.category}</h4>
                        <Badge variant="outline" className={
                          finding.score >= 80 ? "border-success/20 text-success" : "border-warning/20 text-warning"
                        }>
                          {finding.score}%
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{finding.details}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="action" className="space-y-6">
            {/* Action Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Pending Actions</p>
                      <p className="text-2xl font-bold text-foreground">
                        {actionItems.filter(a => a.status === "pending").length}
                      </p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
                      <AlertTriangle className="h-5 w-5 text-destructive" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">In Progress</p>
                      <p className="text-2xl font-bold text-foreground">
                        {actionItems.filter(a => a.status === "in_progress").length}
                      </p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-warning/10 flex items-center justify-center">
                      <Shield className="h-5 w-5 text-warning" />
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">Completed</p>
                      <p className="text-2xl font-bold text-foreground">
                        {actionItems.filter(a => a.status === "completed").length}
                      </p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-success/10 flex items-center justify-center">
                      <CheckCircle className="h-5 w-5 text-success" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Action Items List */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-lg">Safety Action Plan</CardTitle>
                <CardDescription>Recommended security improvements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {actionItems.map((item, index) => (
                  <div key={index} className={`flex items-start gap-4 p-4 rounded-lg border ${
                    item.status === "completed" ? "bg-success/5 border-success/20" : 
                    item.status === "in_progress" ? "bg-warning/5 border-warning/20" : "bg-muted/50 border-border"
                  }`}>
                    <div className={`h-6 w-6 rounded-full flex items-center justify-center shrink-0 ${
                      item.priority === "High" ? "bg-destructive/10" : 
                      item.priority === "Medium" ? "bg-warning/10" : "bg-success/10"
                    }`}>
                      <span className={`text-xs font-bold ${
                        item.priority === "High" ? "text-destructive" : 
                        item.priority === "Medium" ? "text-warning" : "text-success"
                      }`}>
                        {index + 1}
                      </span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{item.title}</h4>
                        <Badge variant="outline" className={`text-xs ${
                          item.priority === "High" ? "border-destructive/20 text-destructive" : 
                          item.priority === "Medium" ? "border-warning/20 text-warning" : "border-success/20 text-success"
                        }`}>
                          {item.priority}
                        </Badge>
                        <Badge variant="secondary" className={`text-xs ${
                          item.status === "completed" ? "bg-success/10 text-success" : 
                          item.status === "in_progress" ? "bg-warning/10 text-warning" : ""
                        }`}>
                          {item.status === "in_progress" ? "In Progress" : item.status === "completed" ? "Completed" : "Pending"}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                    </div>
                    {item.status !== "completed" && (
                      <Button variant="ghost" size="sm">
                        <Eye className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Signature */}
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Certified By</p>
                    <p className="font-signature text-3xl text-primary mt-1">MK</p>
                    <p className="text-sm text-muted-foreground">Manoj Kumar, Chief Security Auditor</p>
                  </div>
                  <Badge className="bg-primary/10 text-primary border-primary/20">
                    Verified Report
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </CustomerLayout>
  );
};

export default AuditReports;
