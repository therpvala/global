import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import {
  Globe,
  Smartphone,
  HardDrive,
  Play,
  Clock,
  CheckCircle,
  Loader2,
  Upload,
  AlertTriangle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import CustomerLayout from "@/components/layout/CustomerLayout";

const RunScan = () => {
  const [searchParams] = useSearchParams();
  const initialType = searchParams.get("type") || "website";
  
  const [activeTab, setActiveTab] = useState(initialType);
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [serverIp, setServerIp] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);

  const handleStartScan = () => {
    if (activeTab === "website" && !websiteUrl) {
      toast.error("Please enter a website URL");
      return;
    }
    if (activeTab === "server" && !serverIp) {
      toast.error("Please enter a server IP address");
      return;
    }

    setIsScanning(true);
    setScanProgress(0);

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          toast.success("Scan completed successfully!");
          return 100;
        }
        return prev + 10;
      });
    }, 500);
  };

  const scanTypes = [
    {
      id: "website",
      title: "Website Scan",
      description: "Scan your website for security vulnerabilities",
      icon: Globe,
      estimatedTime: "2-5 minutes",
    },
    {
      id: "app",
      title: "App / APK Scan",
      description: "Upload and scan mobile applications",
      icon: Smartphone,
      estimatedTime: "5-10 minutes",
    },
    {
      id: "server",
      title: "Server Scan",
      description: "Scan server for open ports and vulnerabilities",
      icon: HardDrive,
      estimatedTime: "3-7 minutes",
    },
  ];

  return (
    <CustomerLayout>
      <div className="p-6 space-y-6">
        {/* Scan Type Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {scanTypes.map((scan) => (
            <Card
              key={scan.id}
              className={`cursor-pointer transition-all hover:shadow-md ${
                activeTab === scan.id
                  ? "border-primary bg-primary/5 ring-1 ring-primary"
                  : "border-border hover:border-primary/50"
              }`}
              onClick={() => setActiveTab(scan.id)}
            >
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className={`h-12 w-12 rounded-lg flex items-center justify-center ${
                    activeTab === scan.id ? "bg-primary/20" : "bg-muted"
                  }`}>
                    <scan.icon className={`h-6 w-6 ${activeTab === scan.id ? "text-primary" : "text-muted-foreground"}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{scan.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{scan.description}</p>
                    <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      <span>{scan.estimatedTime}</span>
                    </div>
                  </div>
                  {activeTab === scan.id && (
                    <CheckCircle className="h-5 w-5 text-primary shrink-0" />
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Scan Input Section */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">
              {activeTab === "website" && "Website URL"}
              {activeTab === "app" && "Upload Application"}
              {activeTab === "server" && "Server IP Address"}
            </CardTitle>
            <CardDescription>
              {activeTab === "website" && "Enter the full URL of the website you want to scan"}
              {activeTab === "app" && "Upload your APK or IPA file for security analysis"}
              {activeTab === "server" && "Enter the IP address of your server"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeTab === "website" && (
              <div className="space-y-2">
                <Label htmlFor="website-url">Website URL</Label>
                <Input
                  id="website-url"
                  type="url"
                  placeholder="https://example.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  className="max-w-lg"
                />
              </div>
            )}

            {activeTab === "app" && (
              <div className="space-y-4">
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                  <Upload className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-sm font-medium text-foreground">
                    Drag and drop your APK/IPA file here
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    or click to browse files
                  </p>
                  <Button variant="outline" className="mt-4">
                    Select File
                  </Button>
                </div>
                <div className="flex items-start gap-2 p-3 rounded-lg bg-warning/5 border border-warning/20">
                  <AlertTriangle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground">
                    Maximum file size: 100MB. Supported formats: APK, IPA
                  </p>
                </div>
              </div>
            )}

            {activeTab === "server" && (
              <div className="space-y-2">
                <Label htmlFor="server-ip">Server IP Address</Label>
                <Input
                  id="server-ip"
                  type="text"
                  placeholder="192.168.1.1"
                  value={serverIp}
                  onChange={(e) => setServerIp(e.target.value)}
                  className="max-w-lg"
                />
              </div>
            )}

            {/* Scan Progress */}
            {isScanning && (
              <div className="space-y-3 mt-6">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Scanning in progress...</span>
                  <span className="text-sm text-muted-foreground">{scanProgress}%</span>
                </div>
                <Progress value={scanProgress} className="h-2" />
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Analyzing security configurations...</span>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-4">
              <Button
                onClick={handleStartScan}
                disabled={isScanning}
                className="gap-2"
              >
                {isScanning ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4" />
                    Start Scan
                  </>
                )}
              </Button>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>Estimated time: {scanTypes.find(s => s.id === activeTab)?.estimatedTime}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Scans */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg">Recent Scan History</CardTitle>
            <CardDescription>Your previous security scans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { url: "example.com", type: "Website", status: "completed", score: 85, date: "2 hours ago" },
                { url: "myapp.apk", type: "App", status: "completed", score: 72, date: "1 day ago" },
                { url: "192.168.1.100", type: "Server", status: "completed", score: 91, date: "3 days ago" },
              ].map((scan, index) => (
                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border">
                  <div className="flex items-center gap-3">
                    {scan.type === "Website" && <Globe className="h-4 w-4 text-muted-foreground" />}
                    {scan.type === "App" && <Smartphone className="h-4 w-4 text-muted-foreground" />}
                    {scan.type === "Server" && <HardDrive className="h-4 w-4 text-muted-foreground" />}
                    <div>
                      <p className="text-sm font-medium">{scan.url}</p>
                      <p className="text-xs text-muted-foreground">{scan.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="bg-success/10 text-success border-success/20">
                      {scan.score}%
                    </Badge>
                    <Badge variant="secondary">{scan.type}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </CustomerLayout>
  );
};

export default RunScan;
