import { useState } from "react";
import CustomerLayout from "@/components/layout/CustomerLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Bug, 
  Shield, 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Eye,
  Bell,
  BellOff,
  RefreshCw,
  Filter,
  Download,
  Plus,
  Wifi,
  WifiOff,
  Zap
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useRealtimeAlerts, type Alert } from "@/hooks/useRealtimeAlerts";
import { EscalationRulesPanel } from "@/components/alerts/EscalationRulesPanel";
import { AlertDetailModal } from "@/components/alerts/AlertDetailModal";

// Fallback demo data when no database alerts exist
const demoMalwareAlerts: Alert[] = [
  {
    id: "demo-m1",
    user_id: null,
    title: "Suspicious File Detected",
    description: "Potential malware signature found in /uploads/doc.exe",
    severity: "critical",
    status: "active",
    alert_type: "malware",
    created_at: "2024-01-15T14:32:00Z",
    updated_at: "2024-01-15T14:32:00Z",
    resolved_at: null,
    source: "File Scanner",
    metadata: {}
  },
  {
    id: "demo-m2",
    user_id: null,
    title: "JavaScript Injection Attempt",
    description: "XSS payload detected in form submission",
    severity: "high",
    status: "investigating",
    alert_type: "malware",
    created_at: "2024-01-15T12:15:00Z",
    updated_at: "2024-01-15T12:15:00Z",
    resolved_at: null,
    source: "WAF",
    metadata: {}
  }
];

const demoBackdoorAlerts: Alert[] = [
  {
    id: "demo-b1",
    user_id: null,
    title: "Hidden Admin Panel Found",
    description: "Unauthorized admin access point at /wp-admin-hidden/",
    severity: "critical",
    status: "active",
    alert_type: "backdoor",
    created_at: "2024-01-15T11:00:00Z",
    updated_at: "2024-01-15T11:00:00Z",
    resolved_at: null,
    source: "Backdoor Scanner",
    metadata: {}
  }
];

const demoUptimeAlerts: Alert[] = [
  {
    id: "demo-u1",
    user_id: null,
    title: "Server Response Slow",
    description: "Response time exceeded 3000ms threshold",
    severity: "medium",
    status: "active",
    alert_type: "uptime",
    created_at: "2024-01-15T15:00:00Z",
    updated_at: "2024-01-15T15:00:00Z",
    resolved_at: null,
    source: "Uptime Monitor",
    metadata: {}
  }
];

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "critical":
      return "bg-destructive text-destructive-foreground";
    case "high":
      return "bg-orange-500 text-white";
    case "medium":
      return "bg-yellow-500 text-black";
    case "low":
      return "bg-blue-500 text-white";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "active":
      return "bg-destructive/10 text-destructive border-destructive/20";
    case "investigating":
      return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
    case "resolved":
    case "dismissed":
      return "bg-green-500/10 text-green-600 border-green-500/20";
    default:
      return "bg-muted text-muted-foreground";
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case "active":
      return <AlertTriangle className="h-3 w-3" />;
    case "investigating":
      return <Clock className="h-3 w-3" />;
    case "resolved":
    case "dismissed":
      return <CheckCircle2 className="h-3 w-3" />;
    default:
      return null;
  }
};

const formatTimestamp = (timestamp: string) => {
  return new Date(timestamp).toLocaleString();
};

interface AlertCardProps {
  alert: Alert;
  onView: (alert: Alert) => void;
  onDismiss: (id: string) => void;
  isDemo?: boolean;
}

const AlertCard = ({ alert, onView, onDismiss, isDemo = false }: AlertCardProps) => (
  <Card className="mb-3 hover:shadow-md transition-shadow">
    <CardContent className="p-4">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <Badge className={getSeverityColor(alert.severity)} variant="secondary">
              {alert.severity.toUpperCase()}
            </Badge>
            <Badge variant="outline" className={getStatusColor(alert.status)}>
              {getStatusIcon(alert.status)}
              <span className="ml-1">{alert.status}</span>
            </Badge>
            {isDemo && (
              <Badge variant="outline" className="text-xs">Demo</Badge>
            )}
          </div>
          <h4 className="font-medium text-foreground truncate">{alert.title}</h4>
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{alert.description}</p>
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground flex-wrap">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatTimestamp(alert.created_at)}
            </span>
            <span className="flex items-center gap-1">
              <Shield className="h-3 w-3" />
              {alert.source}
            </span>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <Button variant="outline" size="sm" onClick={() => onView(alert)}>
            <Eye className="h-3 w-3 mr-1" />
            View
          </Button>
          {alert.status !== "resolved" && alert.status !== "dismissed" && !isDemo && (
            <Button variant="ghost" size="sm" onClick={() => onDismiss(alert.id)}>
              <BellOff className="h-3 w-3 mr-1" />
              Dismiss
            </Button>
          )}
        </div>
      </div>
    </CardContent>
  </Card>
);

interface AlertPanelProps {
  title: string;
  description: string;
  icon: React.ElementType;
  alerts: Alert[];
  iconColor: string;
  loading?: boolean;
  onDismiss: (id: string) => void;
  onRefresh: () => void;
  onViewAlert: (alert: Alert) => void;
  isDemo?: boolean;
}

const AlertPanel = ({ 
  title, 
  description, 
  icon: Icon, 
  alerts, 
  iconColor,
  loading = false,
  onDismiss,
  onRefresh,
  onViewAlert,
  isDemo = false
}: AlertPanelProps) => {
  const [filter, setFilter] = useState("all");
  
  const filteredAlerts = alerts.filter(alert => {
    if (filter === "all") return true;
    return alert.status === filter;
  });

  const activeCount = alerts.filter(a => a.status === "active").length;
  const investigatingCount = alerts.filter(a => a.status === "investigating").length;

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${iconColor}`}>
              <Icon className="h-5 w-5 text-white" />
            </div>
            <div>
              <CardTitle className="text-lg flex items-center gap-2 flex-wrap">
                {title}
                {activeCount > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {activeCount} Active
                  </Badge>
                )}
                {investigatingCount > 0 && (
                  <Badge variant="outline" className="text-xs bg-yellow-500/10 text-yellow-600">
                    {investigatingCount} Investigating
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>{description}</CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Select value={filter} onValueChange={setFilter}>
              <SelectTrigger className="w-32 h-8">
                <Filter className="h-3 w-3 mr-1" />
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Alerts</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="investigating">Investigating</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="flex-1 pt-0">
        <ScrollArea className="h-[400px] pr-4">
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="mb-3">
                  <CardContent className="p-4">
                    <Skeleton className="h-4 w-24 mb-2" />
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredAlerts.length > 0 ? (
            filteredAlerts.map(alert => (
              <AlertCard 
                key={alert.id} 
                alert={alert} 
                onView={onViewAlert}
                onDismiss={onDismiss}
                isDemo={isDemo}
              />
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-32 text-muted-foreground">
              <CheckCircle2 className="h-8 w-8 mb-2" />
              <p>No alerts matching filter</p>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

const CreateAlertDialog = ({ onCreateAlert }: { onCreateAlert: (data: {
  title: string;
  description: string;
  severity: string;
  alert_type: string;
  source: string;
}) => Promise<void> }) => {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    severity: "medium",
    alert_type: "malware",
    source: "Manual Entry"
  });

  const handleSubmit = async () => {
    await onCreateAlert(formData);
    setOpen(false);
    setFormData({
      title: "",
      description: "",
      severity: "medium",
      alert_type: "malware",
      source: "Manual Entry"
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Test Alert
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create Test Alert</DialogTitle>
          <DialogDescription>
            Create a test alert to verify realtime notifications are working.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Alert title..."
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Alert description..."
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Severity</Label>
              <Select
                value={formData.severity}
                onValueChange={(value) => setFormData({ ...formData, severity: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label>Type</Label>
              <Select
                value={formData.alert_type}
                onValueChange={(value) => setFormData({ ...formData, alert_type: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="malware">Malware</SelectItem>
                  <SelectItem value="backdoor">Backdoor</SelectItem>
                  <SelectItem value="uptime">Uptime</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!formData.title || !formData.description}>
            Create Alert
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const AlertsMonitoring = () => {
  const {
    alerts,
    malwareAlerts,
    backdoorAlerts,
    uptimeAlerts,
    loading,
    activeCount,
    fetchAlerts,
    dismissAlert,
    createAlert,
    updateAlertStatus
  } = useRealtimeAlerts();

  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  // Use demo data if no real alerts exist
  const hasRealAlerts = alerts.length > 0;
  const displayMalwareAlerts = hasRealAlerts ? malwareAlerts : demoMalwareAlerts;
  const displayBackdoorAlerts = hasRealAlerts ? backdoorAlerts : demoBackdoorAlerts;
  const displayUptimeAlerts = hasRealAlerts ? uptimeAlerts : demoUptimeAlerts;
  
  const totalActive = hasRealAlerts 
    ? activeCount 
    : [...demoMalwareAlerts, ...demoBackdoorAlerts, ...demoUptimeAlerts].filter(a => a.status === "active").length;

  const handleViewAlert = (alert: Alert) => {
    setSelectedAlert(alert);
    setDetailModalOpen(true);
  };

  const handleStatusChange = async (alertId: string, status: string) => {
    await updateAlertStatus(alertId, status as Alert["status"]);
  };

  return (
    <CustomerLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-foreground">Alerts & Monitoring</h1>
              <Badge variant="outline" className="flex items-center gap-1">
                <Wifi className="h-3 w-3 text-green-500" />
                Live
              </Badge>
            </div>
            <p className="text-muted-foreground">Monitor security threats and system status in real-time</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
            <CreateAlertDialog onCreateAlert={createAlert} />
            <Button variant="outline">
              <Bell className="h-4 w-4 mr-2" />
              Configure
            </Button>
          </div>
        </div>

        {/* Realtime Status Banner */}
        {!hasRealAlerts && !loading && (
          <Card className="border-dashed">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <WifiOff className="h-5 w-5" />
                <div>
                  <p className="font-medium">Showing Demo Data</p>
                  <p className="text-sm">Create a test alert or wait for real alerts to see live updates.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Active Alerts</p>
                  <p className="text-2xl font-bold text-destructive">{totalActive}</p>
                </div>
                <div className="p-3 bg-destructive/10 rounded-full">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Malware Threats</p>
                  <p className="text-2xl font-bold">{displayMalwareAlerts.filter(a => a.status === "active").length}</p>
                </div>
                <div className="p-3 bg-orange-500/10 rounded-full">
                  <Bug className="h-6 w-6 text-orange-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Backdoor Alerts</p>
                  <p className="text-2xl font-bold">{displayBackdoorAlerts.filter(a => a.status === "active").length}</p>
                </div>
                <div className="p-3 bg-purple-500/10 rounded-full">
                  <Shield className="h-6 w-6 text-purple-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">System Uptime</p>
                  <p className="text-2xl font-bold text-green-500">99.8%</p>
                </div>
                <div className="p-3 bg-green-500/10 rounded-full">
                  <Activity className="h-6 w-6 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alert Panels */}
        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Alerts</TabsTrigger>
            <TabsTrigger value="malware">Malware</TabsTrigger>
            <TabsTrigger value="backdoor">Backdoor</TabsTrigger>
            <TabsTrigger value="uptime">Uptime</TabsTrigger>
            <TabsTrigger value="escalation" className="flex items-center gap-1">
              <Zap className="h-3 w-3" />
              Escalation Rules
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <AlertPanel
                title="Malware Alerts"
                description="Virus, trojan, and malicious code detection"
                icon={Bug}
                alerts={displayMalwareAlerts}
                iconColor="bg-orange-500"
                loading={loading}
                onDismiss={dismissAlert}
                onRefresh={fetchAlerts}
                onViewAlert={handleViewAlert}
                isDemo={!hasRealAlerts}
              />
              <AlertPanel
                title="Backdoor Alerts"
                description="Hidden access and unauthorized entry points"
                icon={Shield}
                alerts={displayBackdoorAlerts}
                iconColor="bg-purple-500"
                loading={loading}
                onDismiss={dismissAlert}
                onRefresh={fetchAlerts}
                onViewAlert={handleViewAlert}
                isDemo={!hasRealAlerts}
              />
              <AlertPanel
                title="Uptime Alerts"
                description="Server health and availability monitoring"
                icon={Activity}
                alerts={displayUptimeAlerts}
                iconColor="bg-blue-500"
                loading={loading}
                onDismiss={dismissAlert}
                onRefresh={fetchAlerts}
                onViewAlert={handleViewAlert}
                isDemo={!hasRealAlerts}
              />
            </div>
          </TabsContent>

          <TabsContent value="malware">
            <AlertPanel
              title="Malware Alerts"
              description="Virus, trojan, and malicious code detection"
              icon={Bug}
              alerts={displayMalwareAlerts}
              iconColor="bg-orange-500"
              loading={loading}
              onDismiss={dismissAlert}
              onRefresh={fetchAlerts}
              onViewAlert={handleViewAlert}
              isDemo={!hasRealAlerts}
            />
          </TabsContent>

          <TabsContent value="backdoor">
            <AlertPanel
              title="Backdoor Alerts"
              description="Hidden access and unauthorized entry points"
              icon={Shield}
              alerts={displayBackdoorAlerts}
              iconColor="bg-purple-500"
              loading={loading}
              onDismiss={dismissAlert}
              onRefresh={fetchAlerts}
              onViewAlert={handleViewAlert}
              isDemo={!hasRealAlerts}
            />
          </TabsContent>

          <TabsContent value="uptime">
            <AlertPanel
              title="Uptime Alerts"
              description="Server health and availability monitoring"
              icon={Activity}
              alerts={displayUptimeAlerts}
              iconColor="bg-blue-500"
              loading={loading}
              onDismiss={dismissAlert}
              onRefresh={fetchAlerts}
              onViewAlert={handleViewAlert}
              isDemo={!hasRealAlerts}
            />
          </TabsContent>

          <TabsContent value="escalation">
            <EscalationRulesPanel />
          </TabsContent>
        </Tabs>
      </div>

      {/* Alert Detail Modal */}
      <AlertDetailModal
        alert={selectedAlert}
        open={detailModalOpen}
        onOpenChange={setDetailModalOpen}
        onStatusChange={handleStatusChange}
      />
    </CustomerLayout>
  );
};

export default AlertsMonitoring;
