import { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import {
  FileText,
  Download,
  QrCode,
  RefreshCw,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  History,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import CustomerLayout from "@/components/layout/CustomerLayout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
  auditor_name: string;
}

const CustomerCertificates = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCert, setSelectedCert] = useState<Certificate | null>(null);
  
  const activeTab = searchParams.get("tab") || "active";

  useEffect(() => {
    if (!user) return;

    const fetchCertificates = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        toast.error("Failed to load certificates");
        console.error(error);
      } else {
        setCertificates(data || []);
        if (data && data.length > 0) {
          setSelectedCert(data[0]);
        }
      }
      setIsLoading(false);
    };

    fetchCertificates();
  }, [user]);

  const activeCerts = certificates.filter(c => c.status === "valid");
  const historyCerts = certificates;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "valid":
        return <Badge className="bg-success/10 text-success border-success/20">Active</Badge>;
      case "expired":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Expired</Badge>;
      case "revoked":
        return <Badge className="bg-muted text-muted-foreground">Revoked</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <CustomerLayout>
        <div className="flex items-center justify-center h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </CustomerLayout>
    );
  }

  return (
    <CustomerLayout>
      <div className="p-6 space-y-6">
        <Tabs defaultValue={activeTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="active" className="gap-2">
              <CheckCircle className="h-4 w-4" />
              Active Certificates
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="h-4 w-4" />
              Certificate History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Certificate List */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Your Certificates</CardTitle>
                  <CardDescription>Select a certificate to view details</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y divide-border">
                    {activeCerts.map((cert) => (
                      <div
                        key={cert.id}
                        className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors ${
                          selectedCert?.id === cert.id ? "bg-primary/5 border-l-2 border-primary" : ""
                        }`}
                        onClick={() => setSelectedCert(cert)}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{cert.website_name}</p>
                            <p className="text-sm text-muted-foreground">ID: {cert.certificate_id}</p>
                          </div>
                          {getStatusBadge(cert.status)}
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          <span>Score: {cert.score}%</span>
                          <span>Expires: {new Date(cert.expiry_date).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))}
                    {activeCerts.length === 0 && (
                      <div className="p-8 text-center text-muted-foreground">
                        <FileText className="h-10 w-10 mx-auto mb-3 opacity-50" />
                        <p>No active certificates</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Certificate Preview */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Certificate Preview</CardTitle>
                  <CardDescription>
                    {selectedCert ? selectedCert.website_name : "Select a certificate"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedCert ? (
                    <div className="space-y-6">
                      {/* Certificate Visual */}
                      <div className="border border-border rounded-lg p-6 bg-gradient-to-br from-primary/5 to-transparent">
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <FileText className="h-6 w-6 text-primary" />
                            <span className="font-semibold text-lg">Security Certificate</span>
                          </div>
                          {getStatusBadge(selectedCert.status)}
                        </div>
                        
                        <div className="space-y-3">
                          <div>
                            <p className="text-xs text-muted-foreground uppercase">Website</p>
                            <p className="font-medium">{selectedCert.website_name}</p>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-xs text-muted-foreground uppercase">Certificate ID</p>
                              <p className="font-mono text-sm">{selectedCert.certificate_id}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground uppercase">Security Score</p>
                              <p className={`font-bold text-lg ${
                                selectedCert.score >= 80 ? "text-success" : selectedCert.score >= 50 ? "text-warning" : "text-destructive"
                              }`}>
                                {selectedCert.score}%
                              </p>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-xs text-muted-foreground uppercase">Issue Date</p>
                              <p className="text-sm">{new Date(selectedCert.issue_date).toLocaleDateString()}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground uppercase">Expiry Date</p>
                              <p className="text-sm">{new Date(selectedCert.expiry_date).toLocaleDateString()}</p>
                            </div>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground uppercase">Auditor</p>
                            <p className="text-sm">{selectedCert.auditor_name}</p>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex flex-wrap gap-2">
                        <Button className="gap-2">
                          <Download className="h-4 w-4" />
                          Download PDF
                        </Button>
                        <Button variant="outline" className="gap-2" onClick={() => navigate("/verify")}>
                          <QrCode className="h-4 w-4" />
                          Verify QR
                        </Button>
                        <Button variant="outline" className="gap-2">
                          <RefreshCw className="h-4 w-4" />
                          Renew
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12 text-muted-foreground">
                      <Eye className="h-10 w-10 mx-auto mb-3 opacity-50" />
                      <p>Select a certificate to preview</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="history">
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Certificate History</CardTitle>
                <CardDescription>All your certificates including expired ones</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="pl-6">Certificate ID</TableHead>
                      <TableHead>Website</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Issue Date</TableHead>
                      <TableHead>Expiry Date</TableHead>
                      <TableHead className="pr-6">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {historyCerts.map((cert) => (
                      <TableRow key={cert.id}>
                        <TableCell className="pl-6 font-mono text-sm">{cert.certificate_id}</TableCell>
                        <TableCell className="font-medium">{cert.website_name}</TableCell>
                        <TableCell>
                          <span className={cert.score >= 80 ? "text-success" : cert.score >= 50 ? "text-warning" : "text-destructive"}>
                            {cert.score}%
                          </span>
                        </TableCell>
                        <TableCell>{getStatusBadge(cert.status)}</TableCell>
                        <TableCell>{new Date(cert.issue_date).toLocaleDateString()}</TableCell>
                        <TableCell>{new Date(cert.expiry_date).toLocaleDateString()}</TableCell>
                        <TableCell className="pr-6">
                          <Button variant="ghost" size="sm" className="gap-1">
                            <Download className="h-3 w-3" />
                            PDF
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {historyCerts.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                          No certificates found
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </CustomerLayout>
  );
};

export default CustomerCertificates;
