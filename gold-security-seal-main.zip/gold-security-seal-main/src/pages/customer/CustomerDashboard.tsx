import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Shield,
  CheckCircle,
  AlertTriangle,
  Calendar,
  TrendingUp,
  Activity,
  Clock,
  Lightbulb,
  ArrowRight,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import CustomerLayout from "@/components/layout/CustomerLayout";
import EscalationStatsWidget from "@/components/EscalationStatsWidget";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
}

const CustomerDashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const fetchCertificates = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10);

      if (error) {
        toast.error("Failed to load data");
        console.error(error);
      } else {
        setCertificates(data || []);
      }
      setIsLoading(false);
    };

    fetchCertificates();
  }, [user]);

  const latestCert = certificates[0];
  const securityScore = latestCert?.score || 0;
  const riskLevel = latestCert?.risk_level || "unknown";
  const certStatus = latestCert?.status || "none";

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "low": return "text-success";
      case "medium": return "text-warning";
      case "high": return "text-destructive";
      default: return "text-muted-foreground";
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "low":
        return <Badge className="bg-success/10 text-success border-success/20">Low Risk</Badge>;
      case "medium":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Medium Risk</Badge>;
      case "high":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">High Risk</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const suggestions = [
    { title: "Enable HSTS", description: "Add HTTP Strict Transport Security headers", priority: "High" },
    { title: "Update SSL Certificate", description: "Your SSL certificate expires in 30 days", priority: "Medium" },
    { title: "Enable CSP", description: "Add Content Security Policy headers", priority: "Medium" },
    { title: "Review Open Ports", description: "Close unnecessary network ports", priority: "Low" },
  ];

  if (isLoading) {
    return (
      <CustomerLayout>
        <div className="flex items-center justify-center h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </CustomerLayout>
    );
  }

  return (
    <CustomerLayout>
      <div className="p-6 space-y-6">
        {/* Top Row - 4 Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Security Score */}
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Security Score</p>
                  <div className="flex items-baseline gap-1">
                    <p className={`text-3xl font-bold ${securityScore >= 80 ? "text-success" : securityScore >= 50 ? "text-warning" : "text-destructive"}`}>
                      {securityScore}
                    </p>
                    <span className="text-lg text-muted-foreground">/100</span>
                  </div>
                </div>
                <div className="relative h-16 w-16">
                  <svg className="h-16 w-16 -rotate-90">
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="6"
                      className="text-muted/20"
                    />
                    <circle
                      cx="32"
                      cy="32"
                      r="28"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="6"
                      strokeDasharray={`${(securityScore / 100) * 176} 176`}
                      className={securityScore >= 80 ? "text-success" : securityScore >= 50 ? "text-warning" : "text-destructive"}
                      strokeLinecap="round"
                    />
                  </svg>
                  <Shield className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Level */}
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">Risk Level</p>
                  {getRiskBadge(riskLevel)}
                  <p className="text-xs text-muted-foreground mt-2">Based on latest scan</p>
                </div>
                <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                  riskLevel === "low" ? "bg-success/10" : riskLevel === "medium" ? "bg-warning/10" : "bg-destructive/10"
                }`}>
                  <AlertTriangle className={`h-6 w-6 ${getRiskColor(riskLevel)}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Certificate Status */}
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Certificate Status</p>
                  <Badge className={certStatus === "valid" ? "bg-success/10 text-success border-success/20" : "bg-destructive/10 text-destructive border-destructive/20"}>
                    {certStatus === "valid" ? "Active" : certStatus === "expired" ? "Expired" : "No Certificate"}
                  </Badge>
                  {latestCert && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Expires: {new Date(latestCert.expiry_date).toLocaleDateString()}
                    </p>
                  )}
                </div>
                <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                  certStatus === "valid" ? "bg-success/10" : "bg-destructive/10"
                }`}>
                  <CheckCircle className={`h-6 w-6 ${certStatus === "valid" ? "text-success" : "text-destructive"}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Next Scan Date */}
          <Card className="bg-card border-border">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Next Scan Date</p>
                  <p className="text-lg font-semibold text-foreground">
                    {latestCert 
                      ? new Date(new Date(latestCert.created_at).getTime() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString()
                      : "Not scheduled"
                    }
                  </p>
                  <p className="text-xs text-muted-foreground">Auto-scheduled monthly</p>
                </div>
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Second Row: Scan Timeline & Recent Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Scan Status Timeline */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Scan Status Timeline</CardTitle>
                  <CardDescription>Recent security scan activity</CardDescription>
                </div>
                <Badge variant="outline" className="gap-1">
                  <Activity className="h-3 w-3" />
                  Active
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {certificates.slice(0, 4).map((cert, index) => (
                <div key={cert.id} className="flex items-start gap-3">
                  <div className={`h-2 w-2 rounded-full mt-2 ${
                    cert.status === "valid" ? "bg-success" : "bg-destructive"
                  }`} />
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium">{cert.website_name}</p>
                      <span className="text-xs text-muted-foreground">
                        {new Date(cert.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Score: {cert.score}% • Risk: {cert.risk_level}
                    </p>
                    {index < certificates.length - 1 && <div className="h-4 w-px bg-border ml-0.5" />}
                  </div>
                </div>
              ))}
              {certificates.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">No scans yet</p>
              )}
            </CardContent>
          </Card>

          {/* Recent Alerts */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Recent Alerts</CardTitle>
                  <CardDescription>Security issues requiring attention</CardDescription>
                </div>
                <Badge variant="destructive" className="gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  {certificates.filter(c => c.risk_level === "high").length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {certificates.filter(c => c.risk_level === "high" || c.status === "expired").slice(0, 4).map((alert) => (
                <div key={alert.id} className="flex items-center gap-3 p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                  <AlertTriangle className="h-4 w-4 text-destructive shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{alert.website_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {alert.status === "expired" ? "Certificate expired" : "High risk detected"}
                    </p>
                  </div>
                  <Button size="sm" variant="outline" className="shrink-0">
                    Review
                  </Button>
                </div>
              ))}
              {certificates.filter(c => c.risk_level === "high" || c.status === "expired").length === 0 && (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-success/5 border border-success/20">
                  <CheckCircle className="h-4 w-4 text-success" />
                  <p className="text-sm text-muted-foreground">No active alerts</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Third Row: Last Scan Summary & AI Suggestions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Last Scan Summary */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Last Scan Summary</CardTitle>
                  <CardDescription>Detailed results from latest scan</CardDescription>
                </div>
                <Button size="sm" variant="outline" onClick={() => navigate("/customer/scan")}>
                  New Scan
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-6">Website</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Risk</TableHead>
                    <TableHead className="pr-6">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {certificates.slice(0, 5).map((cert) => (
                    <TableRow key={cert.id}>
                      <TableCell className="pl-6 font-medium">{cert.website_name}</TableCell>
                      <TableCell>
                        <span className={cert.score >= 80 ? "text-success" : cert.score >= 50 ? "text-warning" : "text-destructive"}>
                          {cert.score}%
                        </span>
                      </TableCell>
                      <TableCell>{getRiskBadge(cert.risk_level)}</TableCell>
                      <TableCell className="pr-6">
                        <Badge variant={cert.status === "valid" ? "default" : "destructive"} className={cert.status === "valid" ? "bg-success/10 text-success" : ""}>
                          {cert.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                  {certificates.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        No scan results yet
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* AI Suggestions */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-warning" />
                    Security Improvements
                  </CardTitle>
                  <CardDescription>AI-powered recommendations</CardDescription>
                </div>
                <Badge variant="outline" className="gap-1">
                  <TrendingUp className="h-3 w-3" />
                  AI
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 border border-border hover:bg-muted/80 transition-colors cursor-pointer">
                  <div className={`h-6 w-6 rounded-full flex items-center justify-center shrink-0 ${
                    suggestion.priority === "High" ? "bg-destructive/10" : suggestion.priority === "Medium" ? "bg-warning/10" : "bg-success/10"
                  }`}>
                    <span className={`text-xs font-bold ${
                      suggestion.priority === "High" ? "text-destructive" : suggestion.priority === "Medium" ? "text-warning" : "text-success"
                    }`}>
                      {index + 1}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{suggestion.title}</p>
                    <p className="text-xs text-muted-foreground">{suggestion.description}</p>
                  </div>
                  <Badge variant="outline" className={`shrink-0 ${
                    suggestion.priority === "High" ? "border-destructive/20 text-destructive" : 
                    suggestion.priority === "Medium" ? "border-warning/20 text-warning" : "border-success/20 text-success"
                  }`}>
                    {suggestion.priority}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Fourth Row: Escalation Stats */}
        <EscalationStatsWidget />
      </div>
    </CustomerLayout>
  );
};

export default CustomerDashboard;
