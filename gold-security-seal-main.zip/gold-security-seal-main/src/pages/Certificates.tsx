import { useState, useEffect } from "react";
import { Search, Eye, Trash2, Loader2, AlertTriangle, CheckCircle, XCircle, Download, Pencil, Ban, RefreshCw, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { exportCertificatePDF } from "@/lib/pdfExport";
import EditCertificateDialog from "@/components/EditCertificateDialog";
import RenewCertificateDialog from "@/components/RenewCertificateDialog";
import BulkRenewDialog from "@/components/BulkRenewDialog";
import AdvancedFilters from "@/components/AdvancedFilters";

export interface FilterState {
  issueDateFrom: Date | undefined;
  issueDateTo: Date | undefined;
  expiryDateFrom: Date | undefined;
  expiryDateTo: Date | undefined;
  scoreMin: number | undefined;
  scoreMax: number | undefined;
  auditor: string;
}
import ExpiringSoonWidget from "@/components/ExpiringSoonWidget";
import AISecurityAnalysis from "@/components/AISecurityAnalysis";
import DashboardLayout from "@/components/layout/DashboardLayout";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
  auditor_name: string;
  auditor_title: string;
  auditor_initials: string;
  ssl_score?: number;
  dns_score?: number;
  server_score?: number;
}

const Certificates = () => {
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [filteredCertificates, setFilteredCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");
  const [editingCertificate, setEditingCertificate] = useState<Certificate | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [renewingCertificate, setRenewingCertificate] = useState<Certificate | null>(null);
  const [isRenewDialogOpen, setIsRenewDialogOpen] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBulkRenewOpen, setIsBulkRenewOpen] = useState(false);
  const [isBulkProcessing, setIsBulkProcessing] = useState(false);
  const [exportingPdfId, setExportingPdfId] = useState<string | null>(null);
  const [advancedFilters, setAdvancedFilters] = useState<FilterState>({
    issueDateFrom: undefined,
    issueDateTo: undefined,
    expiryDateFrom: undefined,
    expiryDateTo: undefined,
    scoreMin: undefined,
    scoreMax: undefined,
    auditor: "all",
  });

  useEffect(() => {
    if (!user) return;
    
    const fetchCertificates = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        toast.error("Failed to load certificates");
        console.error(error);
      } else {
        setCertificates(data || []);
        setFilteredCertificates(data || []);
      }
      setIsLoading(false);
    };

    fetchCertificates();
  }, [user]);

  useEffect(() => {
    let filtered = certificates;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (cert) =>
          cert.website_name.toLowerCase().includes(query) ||
          cert.owner_name.toLowerCase().includes(query) ||
          cert.certificate_id.toLowerCase().includes(query)
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter((cert) => cert.status === statusFilter);
    }

    if (riskFilter !== "all") {
      filtered = filtered.filter((cert) => cert.risk_level === riskFilter);
    }

    const { issueDateFrom, issueDateTo, expiryDateFrom, expiryDateTo, scoreMin, scoreMax, auditor } = advancedFilters;

    if (issueDateFrom) {
      filtered = filtered.filter((cert) => new Date(cert.issue_date) >= issueDateFrom);
    }
    if (issueDateTo) {
      filtered = filtered.filter((cert) => new Date(cert.issue_date) <= issueDateTo);
    }
    if (expiryDateFrom) {
      filtered = filtered.filter((cert) => new Date(cert.expiry_date) >= expiryDateFrom);
    }
    if (expiryDateTo) {
      filtered = filtered.filter((cert) => new Date(cert.expiry_date) <= expiryDateTo);
    }
    if (scoreMin !== undefined) {
      filtered = filtered.filter((cert) => cert.score >= scoreMin);
    }
    if (scoreMax !== undefined) {
      filtered = filtered.filter((cert) => cert.score <= scoreMax);
    }
    if (auditor !== "all") {
      filtered = filtered.filter((cert) => cert.auditor_name === auditor);
    }

    setFilteredCertificates(filtered);
  }, [searchQuery, statusFilter, riskFilter, certificates, advancedFilters]);

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from("certificates").delete().eq("id", id);

    if (error) {
      toast.error("Failed to delete certificate");
      console.error(error);
    } else {
      setCertificates((prev) => prev.filter((cert) => cert.id !== id));
      toast.success("Certificate deleted");
    }
  };

  const handleEdit = (cert: Certificate) => {
    setEditingCertificate(cert);
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = async (id: string, updates: Partial<Certificate>) => {
    const { error } = await supabase
      .from("certificates")
      .update(updates)
      .eq("id", id);

    if (error) {
      toast.error("Failed to update certificate");
      console.error(error);
    } else {
      setCertificates((prev) =>
        prev.map((cert) => (cert.id === id ? { ...cert, ...updates } : cert))
      );
      toast.success("Certificate updated");
    }
  };

  const handleRevoke = async (id: string, certificateId: string) => {
    const { error } = await supabase
      .from("certificates")
      .update({ status: "revoked" })
      .eq("id", id);

    if (error) {
      toast.error("Failed to revoke certificate");
      console.error(error);
    } else {
      setCertificates((prev) =>
        prev.map((cert) => (cert.id === id ? { ...cert, status: "revoked" } : cert))
      );
      toast.success(`Certificate ${certificateId} revoked`);
    }
  };

  const handleRenew = (cert: Certificate) => {
    setRenewingCertificate(cert);
    setIsRenewDialogOpen(true);
  };

  const handleSaveRenew = async (id: string, newExpiryDate: string) => {
    const { error } = await supabase
      .from("certificates")
      .update({ expiry_date: newExpiryDate, status: "valid" })
      .eq("id", id);

    if (error) {
      toast.error("Failed to renew certificate");
      console.error(error);
    } else {
      setCertificates((prev) =>
        prev.map((cert) => (cert.id === id ? { ...cert, expiry_date: newExpiryDate, status: "valid" } : cert))
      );
      toast.success("Certificate renewed successfully");
    }
  };

  const handleExportPDF = async (cert: Certificate) => {
    setExportingPdfId(cert.id);
    
    try {
      const { data, error } = await supabase.functions.invoke('analyze-certificate', {
        body: {
          certificate: {
            website_name: cert.website_name,
            score: cert.score,
            risk_level: cert.risk_level,
            ssl_score: cert.ssl_score || Math.round(cert.score * 0.9),
            dns_score: cert.dns_score || Math.round(cert.score * 0.95),
            server_score: cert.server_score || Math.round(cert.score * 0.85),
          }
        }
      });

      let aiRecommendations: string | undefined;
      if (!error && data?.analysis) {
        aiRecommendations = data.analysis;
      }

      exportCertificatePDF({ ...cert, ai_recommendations: aiRecommendations });
      toast.success(`Certificate ${cert.certificate_id} exported as PDF${aiRecommendations ? ' with AI analysis' : ''}`);
    } catch (err) {
      console.error('Failed to fetch AI analysis:', err);
      exportCertificatePDF(cert);
      toast.success(`Certificate ${cert.certificate_id} exported as PDF`);
    } finally {
      setExportingPdfId(null);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredCertificates.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredCertificates.map((c) => c.id)));
    }
  };

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const getSelectedCertificates = () => {
    return certificates.filter((c) => selectedIds.has(c.id));
  };

  const handleBulkExport = () => {
    const selected = getSelectedCertificates();
    selected.forEach((cert) => {
      exportCertificatePDF(cert);
    });
    toast.success(`Exported ${selected.length} certificate${selected.length !== 1 ? "s" : ""} as PDF`);
    setSelectedIds(new Set());
  };

  const handleBulkRevoke = async () => {
    setIsBulkProcessing(true);
    const ids = Array.from(selectedIds);
    
    const { error } = await supabase
      .from("certificates")
      .update({ status: "revoked" })
      .in("id", ids);

    if (error) {
      toast.error("Failed to revoke certificates");
      console.error(error);
    } else {
      setCertificates((prev) =>
        prev.map((cert) => (selectedIds.has(cert.id) ? { ...cert, status: "revoked" } : cert))
      );
      toast.success(`Revoked ${ids.length} certificate${ids.length !== 1 ? "s" : ""}`);
      setSelectedIds(new Set());
    }
    setIsBulkProcessing(false);
  };

  const handleBulkRenew = async (newExpiryDate: string) => {
    setIsBulkProcessing(true);
    const ids = Array.from(selectedIds);
    
    const { error } = await supabase
      .from("certificates")
      .update({ expiry_date: newExpiryDate, status: "valid" })
      .in("id", ids);

    if (error) {
      toast.error("Failed to renew certificates");
      console.error(error);
    } else {
      setCertificates((prev) =>
        prev.map((cert) => 
          selectedIds.has(cert.id) ? { ...cert, expiry_date: newExpiryDate, status: "valid" } : cert
        )
      );
      toast.success(`Renewed ${ids.length} certificate${ids.length !== 1 ? "s" : ""}`);
      setSelectedIds(new Set());
    }
    setIsBulkProcessing(false);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "valid":
        return <Badge className="bg-success/20 text-success border-success/30"><CheckCircle className="w-3 h-3 mr-1" /> Valid</Badge>;
      case "expired":
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30"><XCircle className="w-3 h-3 mr-1" /> Expired</Badge>;
      case "revoked":
        return <Badge className="bg-muted text-muted-foreground border-muted-foreground/30"><XCircle className="w-3 h-3 mr-1" /> Revoked</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "low":
        return <Badge className="bg-success/20 text-success border-success/30">Low Risk</Badge>;
      case "medium":
        return <Badge className="bg-warning/20 text-warning border-warning/30">Medium Risk</Badge>;
      case "high":
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30">High Risk</Badge>;
      default:
        return <Badge variant="outline">{risk}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Certificates</h1>
            <p className="text-muted-foreground">Manage all security certificates</p>
          </div>
        </div>

        {/* Expiring Soon Widget */}
        <ExpiringSoonWidget 
          certificates={certificates} 
          onRenew={handleRenew}
        />

        {/* Filters */}
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search certificates..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="valid">Valid</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="revoked">Revoked</SelectItem>
                </SelectContent>
              </Select>
              <Select value={riskFilter} onValueChange={setRiskFilter}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Risk" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Risk</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
              <AdvancedFilters 
                onFiltersChange={setAdvancedFilters}
                certificates={certificates.map(c => ({
                  id: c.id,
                  auditor_name: c.auditor_name,
                  issue_date: c.issue_date,
                  expiry_date: c.expiry_date,
                  score: c.score
                }))}
              />
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {selectedIds.size > 0 && (
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="py-3 flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">
                {selectedIds.size} certificate{selectedIds.size !== 1 ? "s" : ""} selected
              </span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={handleBulkExport}>
                  <Download className="w-4 h-4 mr-1" /> Export
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button size="sm" variant="outline" className="text-warning" disabled={isBulkProcessing}>
                      <Ban className="w-4 h-4 mr-1" /> Revoke
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Revoke {selectedIds.size} Certificates?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will mark all selected certificates as revoked. This action can be undone by renewing.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={handleBulkRevoke}>Revoke All</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
                <Button size="sm" onClick={() => setIsBulkRenewOpen(true)} disabled={isBulkProcessing}>
                  <RefreshCw className="w-4 h-4 mr-1" /> Renew
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Certificates Table */}
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedIds.size === filteredCertificates.length && filteredCertificates.length > 0}
                      onCheckedChange={toggleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Certificate ID</TableHead>
                  <TableHead>Website</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Risk</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Expiry</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCertificates.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                      No certificates found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCertificates.map((cert) => (
                    <TableRow key={cert.id} className="border-border">
                      <TableCell>
                        <Checkbox
                          checked={selectedIds.has(cert.id)}
                          onCheckedChange={() => toggleSelect(cert.id)}
                        />
                      </TableCell>
                      <TableCell className="font-mono text-xs">{cert.certificate_id}</TableCell>
                      <TableCell className="font-medium">{cert.website_name}</TableCell>
                      <TableCell>{cert.owner_name}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-12 h-2 bg-secondary rounded-full overflow-hidden">
                            <div
                              className={`h-full ${
                                cert.score >= 80
                                  ? "bg-success"
                                  : cert.score >= 50
                                  ? "bg-warning"
                                  : "bg-destructive"
                              }`}
                              style={{ width: `${cert.score}%` }}
                            />
                          </div>
                          <span className="text-sm">{cert.score}</span>
                        </div>
                      </TableCell>
                      <TableCell>{getRiskBadge(cert.risk_level)}</TableCell>
                      <TableCell>{getStatusBadge(cert.status)}</TableCell>
                      <TableCell className="text-muted-foreground">{formatDate(cert.expiry_date)}</TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-1">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8" title="AI Analysis">
                                <Sparkles className="w-4 h-4 text-primary" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                              <AISecurityAnalysis certificate={cert} />
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleExportPDF(cert)}
                            disabled={exportingPdfId === cert.id}
                            title="Export PDF"
                          >
                            {exportingPdfId === cert.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Download className="w-4 h-4" />
                            )}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleEdit(cert)}
                            title="Edit"
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => handleRenew(cert)}
                            title="Renew"
                          >
                            <RefreshCw className="w-4 h-4" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-warning"
                                disabled={cert.status === "revoked"}
                                title="Revoke"
                              >
                                <Ban className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Revoke Certificate?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will mark certificate {cert.certificate_id} as revoked.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleRevoke(cert.id, cert.certificate_id)}>
                                  Revoke
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" title="Delete">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Certificate?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. The certificate will be permanently deleted.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDelete(cert.id)}
                                  className="bg-destructive hover:bg-destructive/90"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Dialogs */}
        <EditCertificateDialog
          certificate={editingCertificate}
          open={isEditDialogOpen}
          onOpenChange={setIsEditDialogOpen}
          onSave={handleSaveEdit}
        />
        <RenewCertificateDialog
          certificate={renewingCertificate ? {
            id: renewingCertificate.id,
            certificate_id: renewingCertificate.certificate_id,
            website_name: renewingCertificate.website_name,
            expiry_date: renewingCertificate.expiry_date
          } : null}
          open={isRenewDialogOpen}
          onOpenChange={setIsRenewDialogOpen}
          onRenew={handleSaveRenew}
        />
        <BulkRenewDialog
          open={isBulkRenewOpen}
          onOpenChange={setIsBulkRenewOpen}
          onRenew={handleBulkRenew}
          count={selectedIds.size}
        />
      </div>
    </DashboardLayout>
  );
};

export default Certificates;
