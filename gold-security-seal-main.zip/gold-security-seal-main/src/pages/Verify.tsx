import { useState, useEffect, useMemo } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Shield, Search, CheckCircle, XCircle, AlertCircle, QrCode, Loader2, Download, Sparkles, FileText, HelpCircle, ChevronDown, ChevronUp, Lock, Server, Globe, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { supabase } from "@/integrations/supabase/client";
import { exportCertificatePDF } from "@/lib/pdfExport";
import { toast } from "sonner";
import AISecurityAnalysis from "@/components/AISecurityAnalysis";
import QRCodeScanner from "@/components/QRCodeScanner";
import ShareCertificate from "@/components/ShareCertificate";
import EmbedBadge from "@/components/EmbedBadge";
import useDynamicMeta from "@/hooks/useDynamicMeta";

interface Certificate {
  certificate_id: string;
  websiteName: string;
  ownerName: string;
  score: number;
  riskLevel: "low" | "medium" | "high";
  issueDate: string;
  expiryDate: string;
  auditorName: string;
  auditorTitle: string;
  auditorInitials: string;
  status: "valid" | "expired" | "revoked";
  ssl_score?: number;
  dns_score?: number;
  server_score?: number;
}

const Verify = () => {
  const [searchParams] = useSearchParams();
  const initialId = searchParams.get("id") || "";
  const [certificateId, setCertificateId] = useState(initialId);
  const [websiteName, setWebsiteName] = useState("");
  const [searchedId, setSearchedId] = useState(initialId);
  const [hasSearched, setHasSearched] = useState(false);
  const [certificate, setCertificate] = useState<Certificate | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [securityDetailsOpen, setSecurityDetailsOpen] = useState(false);
  const [scannerOpen, setScannerOpen] = useState(false);

  const handleQRScan = (scannedData: string) => {
    setCertificateId(scannedData);
    setSearchedId(scannedData);
    fetchCertificate(scannedData);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const fetchCertificate = async (id: string) => {
    if (!id.trim()) return;
    
    setIsLoading(true);
    setHasSearched(true);
    
    const { data, error } = await supabase
      .from("certificates")
      .select("*")
      .eq("certificate_id", id.toUpperCase())
      .maybeSingle();

    if (error) {
      console.error("Error fetching certificate:", error);
      setCertificate(null);
    } else if (data) {
      setCertificate({
        certificate_id: data.certificate_id,
        websiteName: data.website_name,
        ownerName: data.owner_name,
        score: data.score,
        riskLevel: data.risk_level as "low" | "medium" | "high",
        issueDate: data.issue_date,
        expiryDate: data.expiry_date,
        auditorName: data.auditor_name,
        auditorTitle: data.auditor_title,
        auditorInitials: data.auditor_initials,
        status: data.status as "valid" | "expired" | "revoked",
        ssl_score: data.ssl_score,
        dns_score: data.dns_score,
        server_score: data.server_score,
      });
    } else {
      setCertificate(null);
    }
    
    setIsLoading(false);
  };

  useEffect(() => {
    if (initialId) {
      setSearchedId(initialId);
      fetchCertificate(initialId);
    }
  }, [initialId]);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchedId(certificateId);
    fetchCertificate(certificateId);
  };

  const getCertificateLevel = (score: number) => {
    if (score >= 85) return { level: "PLATINUM", color: "bg-gradient-to-r from-slate-400 to-slate-200" };
    if (score >= 70) return { level: "GOLD", color: "bg-gradient-to-r from-primary to-yellow-400" };
    if (score >= 50) return { level: "SILVER", color: "bg-gradient-to-r from-gray-400 to-gray-300" };
    return { level: "BRONZE", color: "bg-gradient-to-r from-amber-700 to-amber-500" };
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case "valid":
        return {
          icon: CheckCircle,
          color: "text-success",
          bg: "bg-success/10",
          border: "border-success/30",
          label: "CERTIFICATE VERIFIED",
          badgeVariant: "default" as const,
        };
      case "expired":
        return {
          icon: AlertCircle,
          color: "text-warning",
          bg: "bg-warning/10",
          border: "border-warning/30",
          label: "EXPIRED",
          badgeVariant: "secondary" as const,
        };
      case "revoked":
        return {
          icon: XCircle,
          color: "text-destructive",
          bg: "bg-destructive/10",
          border: "border-destructive/30",
          label: "REVOKED",
          badgeVariant: "destructive" as const,
        };
      default:
        return {
          icon: XCircle,
          color: "text-destructive",
          bg: "bg-destructive/10",
          border: "border-destructive/30",
          label: "NOT FOUND",
          badgeVariant: "destructive" as const,
        };
    }
  };

  const getRiskBadge = (level: string) => {
    switch (level) {
      case "low":
        return <Badge className="bg-success/20 text-success border-success/30">Low Risk</Badge>;
      case "medium":
        return <Badge className="bg-warning/20 text-warning border-warning/30">Medium Risk</Badge>;
      case "high":
        return <Badge className="bg-destructive/20 text-destructive border-destructive/30">High Risk</Badge>;
      default:
        return null;
    }
  };

  const getSecurityChecks = (cert: Certificate) => {
    const ssl = cert.ssl_score || Math.round(cert.score * 0.9);
    const dns = cert.dns_score || Math.round(cert.score * 0.95);
    const server = cert.server_score || Math.round(cert.score * 0.85);
    
    return [
      { label: "SSL Certificate Valid", status: ssl >= 80, icon: Lock },
      { label: "DNS Configuration Secure", status: dns >= 80, icon: Globe },
      { label: "Server Security Passed", status: server >= 80, icon: Server },
      { label: "No Backdoor Detected", status: cert.score >= 60, icon: Shield },
      { label: "Malware Scan Clear", status: cert.score >= 50, icon: CheckCircle },
    ];
  };

  const handleExportPDF = () => {
    if (!certificate) return;
    exportCertificatePDF({
      certificate_id: certificate.certificate_id,
      website_name: certificate.websiteName,
      owner_name: certificate.ownerName,
      score: certificate.score,
      risk_level: certificate.riskLevel,
      status: certificate.status,
      issue_date: certificate.issueDate,
      expiry_date: certificate.expiryDate,
      auditor_name: certificate.auditorName,
      auditor_title: certificate.auditorTitle,
      auditor_initials: certificate.auditorInitials,
    });
    toast.success("Certificate exported as PDF");
  };

  const isValidCertificate = certificate && certificate.status === "valid";
  const isInvalidOrExpired = hasSearched && (!certificate || certificate.status !== "valid");

  // Dynamic meta tags for social sharing
  const metaData = useMemo(() => {
    if (!certificate) {
      return {
        title: "SecureAudit - Certificate Verification",
        description: "Verify the authenticity of security certificates. SecureAudit is your trusted cyber security verification authority.",
      };
    }

    const level = certificate.score >= 85 ? "Platinum" : certificate.score >= 70 ? "Gold" : certificate.score >= 50 ? "Silver" : "Bronze";
    const statusEmoji = certificate.status === "valid" ? "✅" : certificate.status === "expired" ? "⚠️" : "❌";
    const statusText = certificate.status === "valid" ? "Verified" : certificate.status === "expired" ? "Expired" : "Revoked";

    return {
      title: `${statusEmoji} ${certificate.websiteName} - Security Certificate ${statusText}`,
      description: `${level} Level Certificate | Score: ${certificate.score}/100 | Risk: ${certificate.riskLevel.charAt(0).toUpperCase() + certificate.riskLevel.slice(1)} | ID: ${certificate.certificate_id} | Verified by SecureAudit`,
    };
  }, [certificate]);

  useDynamicMeta(metaData);

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Header */}
      <header className="sticky top-0 z-50 bg-secondary/95 backdrop-blur-md border-b border-border">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
              <Shield className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-lg font-bold text-foreground tracking-tight">SECUREAUDIT</h1>
                <p className="text-xs text-muted-foreground">Cyber Security Authority</p>
              </div>
            </Link>
            
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="sm"
                className="gap-2 border-border hover:bg-muted hidden sm:flex"
                onClick={() => document.getElementById('verify-input')?.focus()}
              >
                <Search className="w-4 h-4" />
                Verify Certificate
              </Button>
              <Link to="/">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="gap-2 text-muted-foreground hover:text-foreground"
                >
                  <HelpCircle className="w-4 h-4" />
                  <span className="hidden sm:inline">Support</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl mx-auto px-4 py-10">
        {/* Verification Search Section */}
        <Card className="mb-8 bg-card border-border shadow-card">
          <CardContent className="pt-8 pb-8">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <Shield className="w-8 h-8 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                CERTIFICATE VERIFICATION
              </h2>
              <p className="text-muted-foreground">
                Verify the authenticity of your security certificate
              </p>
            </div>

            <form onSubmit={handleVerify} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Certificate ID
                </label>
                <Input
                  id="verify-input"
                  type="text"
                  placeholder="SEC-XXXX-2025"
                  value={certificateId}
                  onChange={(e) => setCertificateId(e.target.value)}
                  className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground h-12 text-lg font-mono text-center"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Website / App Name <span className="text-muted-foreground font-normal">(Optional)</span>
                </label>
                <Input
                  type="text"
                  placeholder="example.com"
                  value={websiteName}
                  onChange={(e) => setWebsiteName(e.target.value)}
                  className="bg-muted/50 border-border text-foreground placeholder:text-muted-foreground h-12"
                />
              </div>

              <Button 
                type="submit" 
                disabled={isLoading || !certificateId.trim()}
                className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold gap-2"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Search className="w-5 h-5" />
                )}
                VERIFY CERTIFICATE
              </Button>
            </form>

            {/* QR Divider */}
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-4 text-muted-foreground">or</span>
              </div>
            </div>

            {/* QR Scan Box */}
            <button 
              onClick={() => setScannerOpen(true)}
              className="w-full border-2 border-dashed border-border rounded-xl p-6 text-center bg-muted/30 hover:bg-muted/50 hover:border-primary/50 transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-center gap-2 mb-3">
                <Camera className="w-6 h-6 text-muted-foreground group-hover:text-primary transition-colors" />
                <QrCode className="w-10 h-10 text-muted-foreground group-hover:text-primary transition-colors" />
              </div>
              <p className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">
                Tap to Scan QR Code
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                Use your device camera to verify certificate
              </p>
            </button>

            {/* QR Scanner Modal */}
            <QRCodeScanner
              isOpen={scannerOpen}
              onClose={() => setScannerOpen(false)}
              onScan={handleQRScan}
            />
          </CardContent>
        </Card>

        {/* Results Section */}
        {isLoading && (
          <Card className="bg-card border-border">
            <CardContent className="py-12 text-center">
              <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
              <p className="text-muted-foreground">Verifying certificate...</p>
            </CardContent>
          </Card>
        )}

        {/* Valid Certificate Result */}
        {!isLoading && isValidCertificate && certificate && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Success Header Card */}
            <Card className={`bg-card border-2 ${getStatusConfig(certificate.status).border}`}>
              <CardContent className="pt-8 pb-8">
                <div className="text-center mb-6">
                  <div className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${getStatusConfig(certificate.status).bg} mb-4`}>
                    <CheckCircle className={`w-10 h-10 ${getStatusConfig(certificate.status).color}`} />
                  </div>
                  <h3 className={`text-2xl font-bold ${getStatusConfig(certificate.status).color}`}>
                    {getStatusConfig(certificate.status).label}
                  </h3>
                </div>

                {/* Details Grid */}
                <div className="grid md:grid-cols-2 gap-6 mb-6">
                  {/* Left Column */}
                  <div className="space-y-4">
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Website / App Name</p>
                      <p className="text-lg font-semibold text-foreground">{certificate.websiteName}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Owner Name</p>
                      <p className="text-lg font-semibold text-foreground">{certificate.ownerName}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Certificate Level</p>
                      <div className="flex items-center gap-2">
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold text-white ${getCertificateLevel(certificate.score).color}`}>
                          {getCertificateLevel(certificate.score).level}
                        </span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted/50 rounded-lg p-4">
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Security Score</p>
                        <p className="text-2xl font-bold text-primary">{certificate.score}/100</p>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-4">
                        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Risk Level</p>
                        <div className="mt-1">{getRiskBadge(certificate.riskLevel)}</div>
                      </div>
                    </div>
                  </div>

                  {/* Right Column */}
                  <div className="space-y-4">
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Certificate ID</p>
                      <p className="text-lg font-mono font-semibold text-foreground">{certificate.certificate_id}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Issue Date</p>
                      <p className="text-lg font-semibold text-foreground">{formatDate(certificate.issueDate)}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Expiry Date</p>
                      <p className="text-lg font-semibold text-foreground">{formatDate(certificate.expiryDate)}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Status</p>
                      <Badge className="bg-success/20 text-success border-success/30 text-sm">
                        ACTIVE
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Certified Badge */}
                <div className="flex justify-center mb-6">
                  <div className="inline-flex items-center gap-2 px-6 py-3 bg-primary/10 rounded-full border border-primary/30">
                    <Shield className="w-5 h-5 text-primary" />
                    <span className="font-bold text-primary uppercase tracking-wide">Certified & Verified</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 justify-center flex-wrap">
                  <Button 
                    variant="outline"
                    className="gap-2 border-border"
                    onClick={() => setSecurityDetailsOpen(!securityDetailsOpen)}
                  >
                    <FileText className="w-4 h-4" />
                    View Certificate
                  </Button>
                  <Button 
                    onClick={handleExportPDF}
                    className="gap-2 bg-primary hover:bg-primary/90"
                  >
                    <Download className="w-4 h-4" />
                    Download PDF
                  </Button>
                  <ShareCertificate
                    certificateId={certificate.certificate_id}
                    websiteName={certificate.websiteName}
                    score={certificate.score}
                    status={certificate.status}
                  />
                  <Button 
                    variant="outline"
                    className="gap-2 border-border"
                  >
                    <FileText className="w-4 h-4" />
                    View Audit Report
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Certificate Preview */}
            <Card className="bg-card border-border">
              <CardContent className="pt-6 pb-6">
                <div className="flex flex-col md:flex-row gap-6 items-center">
                  {/* Certificate Thumbnail */}
                  <div className="w-full md:w-48 h-64 bg-gradient-to-br from-secondary to-muted rounded-lg border border-border flex items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center opacity-10">
                      <Shield className="w-32 h-32 text-primary" />
                    </div>
                    <div className="text-center z-10">
                      <Shield className="w-12 h-12 text-primary mx-auto mb-2" />
                      <p className="text-xs font-bold text-foreground">SECURITY</p>
                      <p className="text-xs font-bold text-foreground">CERTIFICATE</p>
                      <p className="text-xs text-muted-foreground mt-2">{certificate.certificate_id}</p>
                    </div>
                  </div>

                  {/* Issuer Info */}
                  <div className="flex-1 text-center md:text-left">
                    <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Issued By</p>
                    <p className="text-xl font-bold text-foreground mb-1">SECUREAUDIT</p>
                    <p className="text-sm text-muted-foreground mb-6">Official Cyber Security Verification Authority</p>

                    <div className="border-t border-border pt-4">
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Signature Preview</p>
                      <div className="flex items-center gap-4 justify-center md:justify-start">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                          <span className="font-signature text-xl text-primary">{certificate.auditorInitials}</span>
                        </div>
                        <div>
                          <p className="font-semibold text-foreground">{certificate.auditorName}</p>
                          <p className="text-sm text-muted-foreground">{certificate.auditorTitle}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Security Details Accordion */}
            <Collapsible open={securityDetailsOpen} onOpenChange={setSecurityDetailsOpen}>
              <Card className="bg-card border-border">
                <CollapsibleTrigger asChild>
                  <CardContent className="pt-4 pb-4 cursor-pointer hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Shield className="w-5 h-5 text-primary" />
                        <span className="font-semibold text-foreground">Security Details Summary</span>
                      </div>
                      {securityDetailsOpen ? (
                        <ChevronUp className="w-5 h-5 text-muted-foreground" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-muted-foreground" />
                      )}
                    </div>
                  </CardContent>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <div className="px-6 pb-6 space-y-3">
                    {getSecurityChecks(certificate).map((check, index) => (
                      <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                        <div className="flex items-center gap-3">
                          <check.icon className="w-4 h-4 text-muted-foreground" />
                          <span className="text-foreground">{check.label}</span>
                        </div>
                        {check.status ? (
                          <div className="flex items-center gap-2 text-success">
                            <CheckCircle className="w-4 h-4" />
                            <span className="text-sm font-medium">Passed</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 text-warning">
                            <AlertCircle className="w-4 h-4" />
                            <span className="text-sm font-medium">Warning</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CollapsibleContent>
              </Card>
            </Collapsible>

            {/* AI Analysis */}
            <Card className="bg-card border-border">
              <CardContent className="pt-6 pb-6">
                <div className="flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-primary" />
                  <h3 className="font-semibold text-foreground">AI Security Analysis</h3>
                </div>
                <AISecurityAnalysis
                  certificate={{
                    website_name: certificate.websiteName,
                    score: certificate.score,
                    risk_level: certificate.riskLevel,
                    ssl_score: certificate.ssl_score || Math.round(certificate.score * 0.9),
                    dns_score: certificate.dns_score || Math.round(certificate.score * 0.95),
                    server_score: certificate.server_score || Math.round(certificate.score * 0.85),
                  }}
                />
              </CardContent>
            </Card>

            {/* Embeddable Trust Badge */}
            <EmbedBadge certificateId={certificate.certificate_id} />
          </div>
        )}

        {/* Invalid/Expired Result */}
        {!isLoading && isInvalidOrExpired && (
          <Card className="bg-card border-2 border-destructive/30 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <CardContent className="py-12 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-destructive/10 mb-6">
                <AlertCircle className="w-10 h-10 text-destructive" />
              </div>
              <h3 className="text-2xl font-bold text-destructive mb-3">
                CERTIFICATE NOT VALID
              </h3>
              <p className="text-muted-foreground max-w-md mx-auto mb-6">
                {certificate ? (
                  `This certificate has ${certificate.status === "expired" ? "expired" : "been revoked"} and is no longer valid.`
                ) : (
                  `The certificate ID "${searchedId}" was not found in our database.`
                )}
              </p>
              <Button 
                variant="outline"
                className="gap-2 border-border"
              >
                <HelpCircle className="w-4 h-4" />
                Contact Support
              </Button>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12 bg-secondary/50">
        <div className="max-w-5xl mx-auto px-4">
          <div className="flex flex-col items-center text-center">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-6 h-6 text-primary" />
              <span className="text-lg font-bold text-foreground">SECUREAUDIT</span>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Cyber Security Verification Authority
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <Link to="/" className="hover:text-foreground transition-colors">Support</Link>
              <span>•</span>
              <Link to="/" className="hover:text-foreground transition-colors">Privacy Policy</Link>
              <span>•</span>
              <Link to="/" className="hover:text-foreground transition-colors">Terms</Link>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              © {new Date().getFullYear()} SECUREAUDIT. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Verify;
