import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Shield, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Users, 
  DollarSign,
  TrendingUp,
  Activity,
  Clock,
  FileText,
  Loader2,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import ExpiringSoonWidget from "@/components/ExpiringSoonWidget";
import CertificateAnalytics from "@/components/CertificateAnalytics";
import ActivityFeed from "@/components/ActivityFeed";
import DashboardLayout from "@/components/layout/DashboardLayout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
  created_at: string;
  auditor_name: string;
  auditor_title: string;
  auditor_initials: string;
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    
    const fetchCertificates = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        toast.error("Failed to load certificates");
        console.error(error);
      } else {
        setCertificates(data || []);
      }
      setIsLoading(false);
    };

    fetchCertificates();
  }, [user]);

  const handleRenew = (cert: Certificate) => {
    navigate(`/certificates?renew=${cert.id}`);
  };

  const stats = {
    total: certificates.length,
    valid: certificates.filter((c) => c.status === "valid").length,
    expired: certificates.filter((c) => c.status === "expired").length,
    highRisk: certificates.filter((c) => c.risk_level === "high").length,
  };

  const recentScans = certificates.slice(0, 5);
  const threatAlerts = certificates.filter(c => c.risk_level === "high" || c.status === "expired").slice(0, 5);

  const getRiskBadge = (risk: string) => {
    switch (risk) {
      case "low":
        return <Badge className="bg-success/10 text-success border-success/20">Low</Badge>;
      case "medium":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Medium</Badge>;
      case "high":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">High</Badge>;
      default:
        return <Badge variant="secondary">{risk}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "valid":
        return <Badge className="bg-success/10 text-success border-success/20">Valid</Badge>;
      case "expired":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Expired</Badge>;
      case "revoked":
        return <Badge className="bg-muted text-muted-foreground border-muted">Revoked</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-[80vh]">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-6 space-y-6">
        {/* Top Stats Row - 4 Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Total Customers</p>
                  <p className="text-2xl font-bold text-foreground">{stats.total}</p>
                  <div className="flex items-center gap-1 text-xs text-success">
                    <ArrowUpRight className="h-3 w-3" />
                    <span>+12% this month</span>
                  </div>
                </div>
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Active Certificates</p>
                  <p className="text-2xl font-bold text-success">{stats.valid}</p>
                  <div className="flex items-center gap-1 text-xs text-success">
                    <ArrowUpRight className="h-3 w-3" />
                    <span>+8% this month</span>
                  </div>
                </div>
                <div className="h-12 w-12 rounded-full bg-success/10 flex items-center justify-center">
                  <CheckCircle className="h-6 w-6 text-success" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">High Risk Alerts</p>
                  <p className="text-2xl font-bold text-destructive">{stats.highRisk}</p>
                  <div className="flex items-center gap-1 text-xs text-destructive">
                    <ArrowDownRight className="h-3 w-3" />
                    <span>-3% this month</span>
                  </div>
                </div>
                <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-muted-foreground">Monthly Revenue</p>
                  <p className="text-2xl font-bold text-foreground">$12,450</p>
                  <div className="flex items-center gap-1 text-xs text-success">
                    <ArrowUpRight className="h-3 w-3" />
                    <span>+18% this month</span>
                  </div>
                </div>
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Second Row: Analytics Charts */}
        <CertificateAnalytics certificates={certificates} />

        {/* Third Row: Recent Scans & Threat Alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Scans Table */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Recent Scans</CardTitle>
                  <CardDescription>Latest security scans performed</CardDescription>
                </div>
                <Badge variant="outline" className="gap-1">
                  <Activity className="h-3 w-3" />
                  Live
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-6">Website</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Risk</TableHead>
                    <TableHead className="pr-6">Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentScans.map((scan) => (
                    <TableRow key={scan.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell className="pl-6 font-medium">{scan.website_name}</TableCell>
                      <TableCell>
                        <span className={scan.score >= 80 ? "text-success" : scan.score >= 50 ? "text-warning" : "text-destructive"}>
                          {scan.score}%
                        </span>
                      </TableCell>
                      <TableCell>{getRiskBadge(scan.risk_level)}</TableCell>
                      <TableCell className="pr-6 text-muted-foreground text-sm">
                        {new Date(scan.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                  {recentScans.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        No scans found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Latest Threat Alerts */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg font-semibold">Latest Threat Alerts</CardTitle>
                  <CardDescription>Critical security issues requiring attention</CardDescription>
                </div>
                <Badge variant="destructive" className="gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  {threatAlerts.length}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="pl-6">Website</TableHead>
                    <TableHead>Issue</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="pr-6">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {threatAlerts.map((alert) => (
                    <TableRow key={alert.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell className="pl-6 font-medium">{alert.website_name}</TableCell>
                      <TableCell>
                        {alert.status === "expired" ? (
                          <span className="text-destructive">Certificate Expired</span>
                        ) : (
                          <span className="text-warning">High Risk Score</span>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(alert.status)}</TableCell>
                      <TableCell className="pr-6">
                        <button
                          onClick={() => handleRenew(alert)}
                          className="text-sm text-primary hover:underline"
                        >
                          {alert.status === "expired" ? "Renew" : "Review"}
                        </button>
                      </TableCell>
                    </TableRow>
                  ))}
                  {threatAlerts.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                        No active threats
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Expiring Soon Widget */}
        <ExpiringSoonWidget 
          certificates={certificates} 
          onRenew={handleRenew}
        />

        {/* Activity Feed */}
        <ActivityFeed />
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;
