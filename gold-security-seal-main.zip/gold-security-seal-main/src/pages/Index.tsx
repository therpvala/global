import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import CertificateFront from "@/components/pages/CertificateFront";
import TechnicalReport from "@/components/pages/TechnicalReport";
import SafetyActionPlan from "@/components/pages/SafetyActionPlan";
import CertificateGeneratorForm, { CertificateFormData } from "@/components/pages/CertificateGeneratorForm";
import { FileText, ClipboardList, Shield, Download, Plus, ArrowLeft, LogOut, Loader2, LayoutDashboard } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface CertificateData {
  websiteName: string;
  ownerName: string;
  score: number;
  riskLevel: "low" | "medium" | "high";
  certificateId: string;
  issueDate: string;
  expiryDate: string;
  auditorInitials: string;
  auditorName: string;
  auditorTitle: string;
  sslScore: number;
  dnsScore: number;
  serverScore: number;
}

const Index = () => {
  const navigate = useNavigate();
  const { user, profile, loading, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState("certificate");
  const [showGenerator, setShowGenerator] = useState(false);
  const [certificateData, setCertificateData] = useState<CertificateData>({
    websiteName: "TechSecure Solutions",
    ownerName: "John Anderson",
    score: 85,
    riskLevel: "low",
    certificateId: "SEC-4872-2025",
    issueDate: "23/12/2024",
    expiryDate: "23/12/2025",
    auditorInitials: "MK",
    auditorName: "Manoj Kumar",
    auditorTitle: "Chief Security Auditor",
    sslScore: 80,
    dnsScore: 60,
    serverScore: 75,
  });

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  // Load the latest certificate from database on mount
  useEffect(() => {
    if (!user) return;
    
    const loadLatestCertificate = async () => {
      const { data, error } = await supabase
        .from("certificates")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (data && !error) {
        const formatDate = (dateStr: string) => {
          const date = new Date(dateStr);
          const day = String(date.getDate()).padStart(2, "0");
          const month = String(date.getMonth() + 1).padStart(2, "0");
          const year = date.getFullYear();
          return `${day}/${month}/${year}`;
        };

        setCertificateData({
          websiteName: data.website_name,
          ownerName: data.owner_name,
          score: data.score,
          riskLevel: data.risk_level as "low" | "medium" | "high",
          certificateId: data.certificate_id,
          issueDate: formatDate(data.issue_date),
          expiryDate: formatDate(data.expiry_date),
          auditorInitials: data.auditor_initials,
          auditorName: data.auditor_name,
          auditorTitle: data.auditor_title,
          sslScore: data.ssl_score,
          dnsScore: data.dns_score,
          serverScore: data.server_score,
        });
      }
    };

    loadLatestCertificate();
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    toast.success("Signed out successfully");
    navigate('/auth');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const generateCertificateId = () => {
    const randomNum = Math.floor(1000 + Math.random() * 9000);
    const year = new Date().getFullYear();
    return `SEC-${randomNum}-${year}`;
  };

  const formatDate = (date: Date) => {
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const formatDateForDb = (date: Date) => {
    return date.toISOString().split("T")[0];
  };

  const getRiskLevel = (score: number): "low" | "medium" | "high" => {
    if (score >= 70) return "low";
    if (score >= 40) return "medium";
    return "high";
  };

  const handleGenerate = async (data: CertificateFormData) => {
    const issueDate = new Date();
    const expiryDate = new Date();
    expiryDate.setMonth(expiryDate.getMonth() + parseInt(data.validityPeriod));

    const newCertificateId = generateCertificateId();
    const riskLevel = getRiskLevel(data.securityScore);

    // Save to database
    const { error } = await supabase.from("certificates").insert({
      certificate_id: newCertificateId,
      website_name: data.websiteName,
      owner_name: data.ownerName,
      score: data.securityScore,
      risk_level: riskLevel,
      issue_date: formatDateForDb(issueDate),
      expiry_date: formatDateForDb(expiryDate),
      auditor_initials: data.auditorInitials,
      auditor_name: data.auditorName,
      auditor_title: data.auditorTitle,
      ssl_score: data.sslScore,
      dns_score: data.dnsScore,
      server_score: data.serverScore,
      status: "valid",
    });

    if (error) {
      console.error("Error saving certificate:", error);
      toast.error("Failed to save certificate", {
        description: error.message,
      });
      return;
    }

    setCertificateData({
      websiteName: data.websiteName,
      ownerName: data.ownerName,
      score: data.securityScore,
      riskLevel: riskLevel,
      certificateId: newCertificateId,
      issueDate: formatDate(issueDate),
      expiryDate: formatDate(expiryDate),
      auditorInitials: data.auditorInitials,
      auditorName: data.auditorName,
      auditorTitle: data.auditorTitle,
      sslScore: data.sslScore,
      dnsScore: data.dnsScore,
      serverScore: data.serverScore,
    });

    setShowGenerator(false);
    setActiveTab("certificate");
    toast.success("Certificate generated and saved!", {
      description: `Certificate ID: ${newCertificateId}`,
    });
  };

  if (showGenerator) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-secondary/80 backdrop-blur-md border-b border-border">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="w-8 h-8 text-primary" />
                <div>
                  <h1 className="text-lg font-bold text-foreground">SECUREAUDIT</h1>
                  <p className="text-xs text-muted-foreground">Cyber Security Verification</p>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                onClick={() => setShowGenerator(false)}
                className="gap-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Certificate
              </Button>
            </div>
          </div>
        </header>

        <CertificateGeneratorForm onGenerate={handleGenerate} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-secondary/80 backdrop-blur-md border-b border-border">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-lg font-bold text-foreground">SECUREAUDIT</h1>
                <p className="text-xs text-muted-foreground">Cyber Security Verification</p>
              </div>
            </div>
            
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full md:w-auto">
              <TabsList className="grid grid-cols-3 bg-muted/50 p-1">
                <TabsTrigger 
                  value="certificate" 
                  className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <Shield className="w-4 h-4" />
                  <span className="hidden sm:inline">Certificate</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="report"
                  className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <FileText className="w-4 h-4" />
                  <span className="hidden sm:inline">Report</span>
                </TabsTrigger>
                <TabsTrigger 
                  value="action"
                  className="flex items-center gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
                >
                  <ClipboardList className="w-4 h-4" />
                  <span className="hidden sm:inline">Action Plan</span>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="flex gap-2 items-center">
              {profile && (
                <span className="text-sm text-muted-foreground hidden md:inline">
                  {profile.full_name}
                </span>
              )}
              <Button 
                variant="outline" 
                onClick={() => navigate("/dashboard")}
                className="gap-2 border-muted-foreground/50 text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowGenerator(true)}
                className="gap-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              >
                <Plus className="w-4 h-4" />
                <span className="hidden sm:inline">New Certificate</span>
              </Button>
              <Button variant="outline" className="gap-2 border-muted-foreground/50 text-muted-foreground hover:bg-muted hover:text-foreground">
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Download PDF</span>
              </Button>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={handleSignOut}
                className="text-muted-foreground hover:text-destructive"
                title="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsContent value="certificate" className="mt-0">
            <CertificateFront 
              websiteName={certificateData.websiteName}
              ownerName={certificateData.ownerName}
              score={certificateData.score}
              riskLevel={certificateData.riskLevel}
              certificateId={certificateData.certificateId}
              issueDate={certificateData.issueDate}
              expiryDate={certificateData.expiryDate}
              auditorInitials={certificateData.auditorInitials}
              auditorName={certificateData.auditorName}
              auditorTitle={certificateData.auditorTitle}
            />
          </TabsContent>
          <TabsContent value="report" className="mt-0">
            <TechnicalReport 
              sslScore={certificateData.sslScore}
              dnsScore={certificateData.dnsScore}
              serverScore={certificateData.serverScore}
              auditorInitials={certificateData.auditorInitials}
              auditorName={certificateData.auditorName}
              auditorTitle={certificateData.auditorTitle}
            />
          </TabsContent>
          <TabsContent value="action" className="mt-0">
            <SafetyActionPlan 
              auditorInitials={certificateData.auditorInitials}
              auditorName={certificateData.auditorName}
              auditorTitle={certificateData.auditorTitle}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Index;
