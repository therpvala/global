import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./hooks/useAuth";
import Index from "./pages/Index";
import Verify from "./pages/Verify";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Certificates from "./pages/Certificates";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";
import ApiKeys from "./pages/ApiKeys";
import ApiDocsPage from "./pages/ApiDocsPage";
import Users from "./pages/Users";
import AuditLogsPage from "./pages/AuditLogsPage";
import NotificationsPage from "./pages/NotificationsPage";
import NotFound from "./pages/NotFound";
// Customer Pages
import CustomerDashboard from "./pages/customer/CustomerDashboard";
import RunScan from "./pages/customer/RunScan";
import CustomerCertificates from "./pages/customer/CustomerCertificates";
import AuditReports from "./pages/customer/AuditReports";
import AlertsMonitoring from "./pages/customer/AlertsMonitoring";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            {/* Admin Routes */}
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/certificates" element={<Certificates />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/api-keys" element={<ApiKeys />} />
            <Route path="/api-docs" element={<ApiDocsPage />} />
            <Route path="/users" element={<Users />} />
            <Route path="/audit-logs" element={<AuditLogsPage />} />
            <Route path="/notifications" element={<NotificationsPage />} />
            <Route path="/verify" element={<Verify />} />
            {/* Customer Routes */}
            <Route path="/customer/dashboard" element={<CustomerDashboard />} />
            <Route path="/customer/scan" element={<RunScan />} />
            <Route path="/customer/certificates" element={<CustomerCertificates />} />
            <Route path="/customer/reports" element={<AuditReports />} />
            <Route path="/customer/alerts" element={<AlertsMonitoring />} />
            <Route path="/customer/billing" element={<Settings />} />
            <Route path="/customer/marketplace" element={<Settings />} />
            <Route path="/customer/support" element={<Settings />} />
            <Route path="/customer/settings" element={<Settings />} />
            <Route path="/customer/backdoor-status" element={<AuditLogsPage />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
