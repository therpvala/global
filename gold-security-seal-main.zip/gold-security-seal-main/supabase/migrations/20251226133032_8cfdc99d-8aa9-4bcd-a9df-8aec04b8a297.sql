-- Allow authenticated users to delete certificates
CREATE POLICY "Authenticated users can delete certificates" 
ON public.certificates 
FOR DELETE 
USING (true);