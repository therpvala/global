-- Create certificates table for storing security audit certificates
CREATE TABLE public.certificates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  certificate_id TEXT NOT NULL UNIQUE,
  website_name TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  score INTEGER NOT NULL CHECK (score >= 0 AND score <= 100),
  risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  issue_date DATE NOT NULL DEFAULT CURRENT_DATE,
  expiry_date DATE NOT NULL,
  auditor_initials TEXT NOT NULL,
  auditor_name TEXT NOT NULL,
  auditor_title TEXT NOT NULL,
  ssl_score INTEGER NOT NULL DEFAULT 0 CHECK (ssl_score >= 0 AND ssl_score <= 100),
  dns_score INTEGER NOT NULL DEFAULT 0 CHECK (dns_score >= 0 AND dns_score <= 100),
  server_score INTEGER NOT NULL DEFAULT 0 CHECK (server_score >= 0 AND server_score <= 100),
  status TEXT NOT NULL DEFAULT 'valid' CHECK (status IN ('valid', 'expired', 'revoked')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security (public read, authenticated write)
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read certificates (for verification)
CREATE POLICY "Certificates are publicly readable" 
ON public.certificates 
FOR SELECT 
USING (true);

-- Allow authenticated users to insert certificates
CREATE POLICY "Authenticated users can create certificates" 
ON public.certificates 
FOR INSERT 
TO authenticated
WITH CHECK (true);

-- Allow authenticated users to update certificates
CREATE POLICY "Authenticated users can update certificates" 
ON public.certificates 
FOR UPDATE 
TO authenticated
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_certificates_updated_at
BEFORE UPDATE ON public.certificates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample certificate for testing verification
INSERT INTO public.certificates (
  certificate_id, website_name, owner_name, score, risk_level,
  issue_date, expiry_date, auditor_initials, auditor_name, auditor_title,
  ssl_score, dns_score, server_score, status
) VALUES (
  'SEC-4872-2025', 'TechSecure Solutions', 'John Anderson', 85, 'low',
  '2024-12-23', '2025-12-23', 'MK', 'Manoj Kumar', 'Chief Security Auditor',
  80, 60, 75, 'valid'
);