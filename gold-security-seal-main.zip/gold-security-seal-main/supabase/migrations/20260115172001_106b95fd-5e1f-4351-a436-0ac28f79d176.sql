-- Add resolution_notes column to alerts table
ALTER TABLE public.alerts 
  ADD COLUMN IF NOT EXISTS resolution_notes TEXT;

-- Create alert_history table to track all changes
CREATE TABLE public.alert_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  alert_id UUID NOT NULL REFERENCES public.alerts(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  previous_value JSONB,
  new_value JSONB,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.alert_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies for alert_history
CREATE POLICY "Users can view history of their alerts"
  ON public.alert_history
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.alerts 
      WHERE alerts.id = alert_history.alert_id 
      AND alerts.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can view all alert history"
  ON public.alert_history
  FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can create history for their alerts"
  ON public.alert_history
  FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.alerts 
      WHERE alerts.id = alert_history.alert_id 
      AND alerts.user_id = auth.uid()
    )
  );

-- Enable realtime for alert_history
ALTER PUBLICATION supabase_realtime ADD TABLE public.alert_history;

-- Create function to automatically log alert changes
CREATE OR REPLACE FUNCTION public.log_alert_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  action_type TEXT;
  prev_val JSONB;
  new_val JSONB;
BEGIN
  IF TG_OP = 'UPDATE' THEN
    -- Determine action type based on what changed
    IF OLD.status != NEW.status THEN
      action_type := 'status_changed';
      prev_val := jsonb_build_object('status', OLD.status);
      new_val := jsonb_build_object('status', NEW.status);
    ELSIF OLD.severity != NEW.severity THEN
      action_type := 'escalated';
      prev_val := jsonb_build_object('severity', OLD.severity);
      new_val := jsonb_build_object('severity', NEW.severity, 'escalation_count', NEW.escalation_count);
    ELSIF OLD.resolution_notes IS DISTINCT FROM NEW.resolution_notes THEN
      action_type := 'notes_updated';
      prev_val := jsonb_build_object('resolution_notes', OLD.resolution_notes);
      new_val := jsonb_build_object('resolution_notes', NEW.resolution_notes);
    ELSE
      action_type := 'updated';
      prev_val := to_jsonb(OLD);
      new_val := to_jsonb(NEW);
    END IF;

    INSERT INTO public.alert_history (alert_id, user_id, action, previous_value, new_value)
    VALUES (NEW.id, auth.uid(), action_type, prev_val, new_val);
    
    RETURN NEW;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger to log alert changes
CREATE TRIGGER log_alert_changes_trigger
  AFTER UPDATE ON public.alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.log_alert_changes();