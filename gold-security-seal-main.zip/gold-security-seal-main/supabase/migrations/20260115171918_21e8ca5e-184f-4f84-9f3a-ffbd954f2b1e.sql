-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule the escalation check to run every 5 minutes
SELECT cron.schedule(
  'check-alert-escalations',
  '*/5 * * * *',
  $$SELECT public.check_and_escalate_alerts();$$
);