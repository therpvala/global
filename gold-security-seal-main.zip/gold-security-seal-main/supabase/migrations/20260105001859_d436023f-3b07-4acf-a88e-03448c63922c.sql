-- Create table for storing AI analyses
CREATE TABLE public.certificate_analyses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  certificate_id UUID NOT NULL REFERENCES public.certificates(id) ON DELETE CASCADE,
  analysis JSONB NOT NULL,
  raw_text TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  created_by UUID REFERENCES auth.users(id)
);

-- Create index for faster lookups
CREATE INDEX idx_certificate_analyses_certificate_id ON public.certificate_analyses(certificate_id);
CREATE INDEX idx_certificate_analyses_created_at ON public.certificate_analyses(created_at DESC);

-- Enable RLS
ALTER TABLE public.certificate_analyses ENABLE ROW LEVEL SECURITY;

-- Policies: authenticated users can create, everyone can read (like certificates)
CREATE POLICY "Authenticated users can create analyses"
ON public.certificate_analyses
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Analyses are publicly readable"
ON public.certificate_analyses
FOR SELECT
USING (true);

CREATE POLICY "Authenticated users can delete their own analyses"
ON public.certificate_analyses
FOR DELETE
USING (auth.uid() = created_by);