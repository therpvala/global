-- Create audit_logs table
CREATE TABLE public.audit_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    user_name text,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    entity_name text,
    details jsonb DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY "Admins can view audit logs"
ON public.audit_logs
FOR SELECT
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Authenticated users can create logs (for their own actions)
CREATE POLICY "Authenticated users can create logs"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Create index for faster queries
CREATE INDEX idx_audit_logs_created_at ON public.audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_entity_type ON public.audit_logs(entity_type);
CREATE INDEX idx_audit_logs_user_id ON public.audit_logs(user_id);

-- Function to log certificate actions (can be called from triggers)
CREATE OR REPLACE FUNCTION public.log_certificate_action()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    action_type text;
    user_name_val text;
BEGIN
    -- Determine action type
    IF TG_OP = 'INSERT' THEN
        action_type := 'created';
    ELSIF TG_OP = 'UPDATE' THEN
        IF NEW.status != OLD.status THEN
            action_type := 'status_changed';
        ELSE
            action_type := 'updated';
        END IF;
    ELSIF TG_OP = 'DELETE' THEN
        action_type := 'deleted';
    END IF;

    -- Get user name from profiles
    SELECT full_name INTO user_name_val FROM public.profiles WHERE user_id = auth.uid();

    -- Insert audit log
    IF TG_OP = 'DELETE' THEN
        INSERT INTO public.audit_logs (user_id, user_name, action, entity_type, entity_id, entity_name, details)
        VALUES (
            auth.uid(),
            COALESCE(user_name_val, 'System'),
            action_type,
            'certificate',
            OLD.id::text,
            OLD.website_name,
            jsonb_build_object('certificate_id', OLD.certificate_id, 'status', OLD.status)
        );
        RETURN OLD;
    ELSE
        INSERT INTO public.audit_logs (user_id, user_name, action, entity_type, entity_id, entity_name, details)
        VALUES (
            auth.uid(),
            COALESCE(user_name_val, 'System'),
            action_type,
            'certificate',
            NEW.id::text,
            NEW.website_name,
            jsonb_build_object(
                'certificate_id', NEW.certificate_id,
                'status', NEW.status,
                'old_status', CASE WHEN TG_OP = 'UPDATE' THEN OLD.status ELSE NULL END
            )
        );
        RETURN NEW;
    END IF;
END;
$$;

-- Create triggers for certificate actions
CREATE TRIGGER audit_certificate_insert
    AFTER INSERT ON public.certificates
    FOR EACH ROW
    EXECUTE FUNCTION public.log_certificate_action();

CREATE TRIGGER audit_certificate_update
    AFTER UPDATE ON public.certificates
    FOR EACH ROW
    EXECUTE FUNCTION public.log_certificate_action();

CREATE TRIGGER audit_certificate_delete
    AFTER DELETE ON public.certificates
    FOR EACH ROW
    EXECUTE FUNCTION public.log_certificate_action();

-- Function to log role changes
CREATE OR REPLACE FUNCTION public.log_role_change()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    action_type text;
    user_name_val text;
    target_user_name text;
BEGIN
    -- Determine action type
    IF TG_OP = 'INSERT' THEN
        action_type := 'role_assigned';
    ELSIF TG_OP = 'UPDATE' THEN
        action_type := 'role_changed';
    ELSIF TG_OP = 'DELETE' THEN
        action_type := 'role_removed';
    END IF;

    -- Get current user name
    SELECT full_name INTO user_name_val FROM public.profiles WHERE user_id = auth.uid();
    
    -- Get target user name
    IF TG_OP = 'DELETE' THEN
        SELECT full_name INTO target_user_name FROM public.profiles WHERE user_id = OLD.user_id;
    ELSE
        SELECT full_name INTO target_user_name FROM public.profiles WHERE user_id = NEW.user_id;
    END IF;

    -- Insert audit log
    IF TG_OP = 'DELETE' THEN
        INSERT INTO public.audit_logs (user_id, user_name, action, entity_type, entity_id, entity_name, details)
        VALUES (
            auth.uid(),
            COALESCE(user_name_val, 'System'),
            action_type,
            'user_role',
            OLD.user_id::text,
            COALESCE(target_user_name, 'Unknown User'),
            jsonb_build_object('old_role', OLD.role::text)
        );
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO public.audit_logs (user_id, user_name, action, entity_type, entity_id, entity_name, details)
        VALUES (
            auth.uid(),
            COALESCE(user_name_val, 'System'),
            action_type,
            'user_role',
            NEW.user_id::text,
            COALESCE(target_user_name, 'Unknown User'),
            jsonb_build_object('old_role', OLD.role::text, 'new_role', NEW.role::text)
        );
        RETURN NEW;
    ELSE
        INSERT INTO public.audit_logs (user_id, user_name, action, entity_type, entity_id, entity_name, details)
        VALUES (
            auth.uid(),
            COALESCE(user_name_val, 'System'),
            action_type,
            'user_role',
            NEW.user_id::text,
            COALESCE(target_user_name, 'Unknown User'),
            jsonb_build_object('new_role', NEW.role::text)
        );
        RETURN NEW;
    END IF;
END;
$$;

-- Create triggers for role changes
CREATE TRIGGER audit_role_insert
    AFTER INSERT ON public.user_roles
    FOR EACH ROW
    EXECUTE FUNCTION public.log_role_change();

CREATE TRIGGER audit_role_update
    AFTER UPDATE ON public.user_roles
    FOR EACH ROW
    EXECUTE FUNCTION public.log_role_change();

CREATE TRIGGER audit_role_delete
    AFTER DELETE ON public.user_roles
    FOR EACH ROW
    EXECUTE FUNCTION public.log_role_change();