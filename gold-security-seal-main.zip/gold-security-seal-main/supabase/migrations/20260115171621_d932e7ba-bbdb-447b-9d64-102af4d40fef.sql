-- Create alert escalation rules table
CREATE TABLE public.alert_escalation_rules (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  severity TEXT NOT NULL CHECK (severity IN ('critical', 'high', 'medium', 'low')),
  alert_type TEXT CHECK (alert_type IN ('malware', 'backdoor', 'uptime', 'all')),
  threshold_minutes INTEGER NOT NULL DEFAULT 30,
  escalate_to_severity TEXT NOT NULL CHECK (escalate_to_severity IN ('critical', 'high', 'medium')),
  notify_email BOOLEAN NOT NULL DEFAULT true,
  notify_slack BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.alert_escalation_rules ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view their own escalation rules"
  ON public.alert_escalation_rules
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own escalation rules"
  ON public.alert_escalation_rules
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own escalation rules"
  ON public.alert_escalation_rules
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own escalation rules"
  ON public.alert_escalation_rules
  FOR DELETE
  USING (auth.uid() = user_id);

-- Add escalation tracking columns to alerts table
ALTER TABLE public.alerts 
  ADD COLUMN IF NOT EXISTS escalated_at TIMESTAMP WITH TIME ZONE,
  ADD COLUMN IF NOT EXISTS original_severity TEXT,
  ADD COLUMN IF NOT EXISTS escalation_count INTEGER DEFAULT 0;

-- Create function to auto-escalate alerts
CREATE OR REPLACE FUNCTION public.check_and_escalate_alerts()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  rule RECORD;
  alert_record RECORD;
BEGIN
  -- Loop through active escalation rules
  FOR rule IN 
    SELECT * FROM public.alert_escalation_rules 
    WHERE is_active = true
  LOOP
    -- Find alerts matching the rule that need escalation
    FOR alert_record IN
      SELECT * FROM public.alerts
      WHERE status = 'active'
        AND severity = rule.severity
        AND (rule.alert_type = 'all' OR alert_type = rule.alert_type)
        AND user_id = rule.user_id
        AND created_at < now() - (rule.threshold_minutes || ' minutes')::interval
        AND (escalated_at IS NULL OR escalated_at < now() - (rule.threshold_minutes || ' minutes')::interval)
    LOOP
      -- Escalate the alert
      UPDATE public.alerts
      SET 
        original_severity = COALESCE(original_severity, severity),
        severity = rule.escalate_to_severity,
        escalated_at = now(),
        escalation_count = COALESCE(escalation_count, 0) + 1,
        updated_at = now()
      WHERE id = alert_record.id;
    END LOOP;
  END LOOP;
END;
$$;

-- Enable realtime for escalation rules
ALTER PUBLICATION supabase_realtime ADD TABLE public.alert_escalation_rules;

-- Create trigger for updated_at
CREATE TRIGGER update_alert_escalation_rules_updated_at
  BEFORE UPDATE ON public.alert_escalation_rules
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();