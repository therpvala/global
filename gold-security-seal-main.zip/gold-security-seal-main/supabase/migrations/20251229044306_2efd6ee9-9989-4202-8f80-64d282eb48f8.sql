-- Create app_settings table for system configuration
CREATE TABLE public.app_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  key text NOT NULL UNIQUE,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  description text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Settings are readable by authenticated users
CREATE POLICY "Authenticated users can view settings"
ON public.app_settings
FOR SELECT
TO authenticated
USING (true);

-- Only authenticated users can update settings
CREATE POLICY "Authenticated users can update settings"
ON public.app_settings
FOR UPDATE
TO authenticated
USING (true);

-- Only authenticated users can insert settings
CREATE POLICY "Authenticated users can insert settings"
ON public.app_settings
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Add trigger for updated_at
CREATE TRIGGER update_app_settings_updated_at
BEFORE UPDATE ON public.app_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default settings
INSERT INTO public.app_settings (key, value, description) VALUES
  ('company', '{"name": "SecureAudit", "tagline": "Professional Security Certification", "logo_url": ""}', 'Company branding settings'),
  ('certificate', '{"default_validity_days": 365, "auto_expire_warning_days": 30, "require_signature": true}', 'Certificate generation settings'),
  ('notifications', '{"email_enabled": false, "expiry_reminder_days": [30, 14, 7], "admin_email": ""}', 'Notification settings');