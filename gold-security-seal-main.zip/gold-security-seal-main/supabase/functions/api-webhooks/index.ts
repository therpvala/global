import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function hashApiKey(key: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(key);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

interface ApiKeyRecord {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  key_prefix: string;
  permissions: string[];
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
}

interface ApiKeyValidation {
  valid: boolean;
  userId?: string;
  permissions?: string[];
  error?: string;
}

async function validateApiKey(
  supabase: SupabaseClient,
  authHeader: string | null,
  requiredPermission: string
): Promise<ApiKeyValidation> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { valid: false, error: "Authorization header required (Bearer token)" };
  }

  const token = authHeader.replace("Bearer ", "");
  
  // Check if it's an API key (starts with sck_)
  if (token.startsWith("sck_")) {
    const keyHash = await hashApiKey(token);
    const keyPrefix = token.substring(0, 12);

    const { data, error } = await supabase
      .from("api_keys")
      .select("*")
      .eq("key_hash", keyHash)
      .eq("key_prefix", keyPrefix)
      .eq("is_active", true)
      .single();

    if (error || !data) {
      return { valid: false, error: "Invalid API key" };
    }

    const apiKey = data as ApiKeyRecord;

    // Check expiration
    if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) {
      return { valid: false, error: "API key has expired" };
    }

    // Check permission
    if (!apiKey.permissions.includes(requiredPermission)) {
      return { valid: false, error: `API key lacks '${requiredPermission}' permission` };
    }

    // Update last_used_at
    await supabase
      .from("api_keys")
      .update({ last_used_at: new Date().toISOString() })
      .eq("id", apiKey.id);

    return { valid: true, userId: apiKey.user_id, permissions: apiKey.permissions };
  }

  // Fall back to JWT token auth
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return { valid: false, error: "Invalid or expired token" };
  }

  return { valid: true, userId: user.id, permissions: ["read", "write", "delete", "verify", "analytics", "webhooks"] };
}

interface WebhookPayload {
  event: string;
  certificate_id: string;
  website_name: string;
  timestamp: string;
  data: Record<string, unknown>;
}

async function sendWebhook(url: string, payload: WebhookPayload): Promise<boolean> {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    return response.ok;
  } catch (err) {
    console.error("Webhook delivery failed:", err);
    return false;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Validate API key with 'webhooks' permission
    const authHeader = req.headers.get("Authorization");
    const validation = await validateApiKey(supabase, authHeader, "webhooks");
    
    if (!validation.valid) {
      return new Response(
        JSON.stringify({ success: false, error: validation.error }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // POST - Register webhook or trigger test
    if (req.method === "POST") {
      const body = await req.json();
      
      // Test webhook
      if (body.action === "test") {
        if (!body.webhook_url) {
          return new Response(
            JSON.stringify({ success: false, error: "webhook_url required for test" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const testPayload: WebhookPayload = {
          event: "test",
          certificate_id: "TEST-001",
          website_name: "test.example.com",
          timestamp: new Date().toISOString(),
          data: { message: "This is a test webhook from SecureAudit" },
        };

        const success = await sendWebhook(body.webhook_url, testPayload);

        return new Response(
          JSON.stringify({ 
            success, 
            message: success ? "Test webhook sent successfully" : "Failed to deliver webhook"
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Trigger webhook for certificate event
      if (body.event && body.certificate_id && body.webhook_url) {
        const { data: cert, error } = await supabase
          .from("certificates")
          .select("*")
          .eq("id", body.certificate_id)
          .single();

        if (error || !cert) {
          return new Response(
            JSON.stringify({ success: false, error: "Certificate not found" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        const payload: WebhookPayload = {
          event: body.event,
          certificate_id: cert.certificate_id,
          website_name: cert.website_name,
          timestamp: new Date().toISOString(),
          data: {
            owner: cert.owner_name,
            score: cert.score,
            risk_level: cert.risk_level,
            status: cert.status,
            expiry_date: cert.expiry_date,
          },
        };

        const success = await sendWebhook(body.webhook_url, payload);

        return new Response(
          JSON.stringify({ 
            success, 
            message: success ? "Webhook delivered" : "Webhook delivery failed"
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: false, 
          error: "Invalid request. Required: action=test with webhook_url, or event+certificate_id+webhook_url" 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // GET - List available webhook events
    if (req.method === "GET") {
      return new Response(
        JSON.stringify({
          success: true,
          available_events: [
            { event: "certificate.created", description: "Triggered when a new certificate is issued" },
            { event: "certificate.updated", description: "Triggered when a certificate is modified" },
            { event: "certificate.renewed", description: "Triggered when a certificate is renewed" },
            { event: "certificate.revoked", description: "Triggered when a certificate is revoked" },
            { event: "certificate.expired", description: "Triggered when a certificate expires" },
            { event: "certificate.expiring_soon", description: "Triggered 7/14/30 days before expiry" },
          ],
          usage: {
            test: "POST with { action: 'test', webhook_url: 'https://...' }",
            trigger: "POST with { event: 'certificate.created', certificate_id: 'uuid', webhook_url: 'https://...' }",
          },
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Webhook API error:", err);
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
