import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function hashApiKey(key: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(key);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

interface ApiKeyRecord {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  key_prefix: string;
  permissions: string[];
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
}

interface ApiKeyValidation {
  valid: boolean;
  userId?: string;
  permissions?: string[];
  error?: string;
}

async function validateApiKey(
  supabase: SupabaseClient,
  authHeader: string | null,
  requiredPermission: string
): Promise<ApiKeyValidation> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { valid: false, error: "Authorization header required (Bearer token)" };
  }

  const token = authHeader.replace("Bearer ", "");
  
  // Check if it's an API key (starts with sck_)
  if (token.startsWith("sck_")) {
    const keyHash = await hashApiKey(token);
    const keyPrefix = token.substring(0, 12);

    const { data, error } = await supabase
      .from("api_keys")
      .select("*")
      .eq("key_hash", keyHash)
      .eq("key_prefix", keyPrefix)
      .eq("is_active", true)
      .single();

    if (error || !data) {
      return { valid: false, error: "Invalid API key" };
    }

    const apiKey = data as ApiKeyRecord;

    // Check expiration
    if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) {
      return { valid: false, error: "API key has expired" };
    }

    // Check permission
    if (!apiKey.permissions.includes(requiredPermission)) {
      return { valid: false, error: `API key lacks '${requiredPermission}' permission` };
    }

    // Update last_used_at
    await supabase
      .from("api_keys")
      .update({ last_used_at: new Date().toISOString() })
      .eq("id", apiKey.id);

    return { valid: true, userId: apiKey.user_id, permissions: apiKey.permissions };
  }

  // Fall back to JWT token auth
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return { valid: false, error: "Invalid or expired token" };
  }

  return { valid: true, userId: user.id, permissions: ["read", "write", "delete", "verify", "analytics", "webhooks"] };
}

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  issue_date: string;
  expiry_date: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "GET") {
    return new Response(
      JSON.stringify({ success: false, error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Validate API key with 'analytics' permission
    const authHeader = req.headers.get("Authorization");
    const validation = await validateApiKey(supabase, authHeader, "analytics");
    
    if (!validation.valid) {
      return new Response(
        JSON.stringify({ success: false, error: validation.error }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch all certificates
    const { data: certificates, error } = await supabase
      .from("certificates")
      .select("*");

    if (error) {
      return new Response(
        JSON.stringify({ success: false, error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const certs = (certificates || []) as Certificate[];
    const now = new Date();
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    // Calculate stats
    const stats = {
      total: certs.length,
      by_status: {
        valid: 0,
        expired: 0,
        revoked: 0,
      } as Record<string, number>,
      by_risk: {
        low: 0,
        medium: 0,
        high: 0,
      } as Record<string, number>,
      expiring_soon: 0,
      average_score: 0,
      score_distribution: {
        excellent: 0, // 85+
        good: 0,      // 70-84
        fair: 0,      // 50-69
        poor: 0,      // <50
      },
    };

    let totalScore = 0;
    
    for (const cert of certs) {
      // Status
      const isExpired = new Date(cert.expiry_date) < now;
      if (isExpired) {
        stats.by_status.expired++;
      } else if (cert.status === "revoked") {
        stats.by_status.revoked++;
      } else {
        stats.by_status.valid++;
      }

      // Risk
      if (cert.risk_level in stats.by_risk) {
        stats.by_risk[cert.risk_level]++;
      }

      // Expiring soon
      const expiryDate = new Date(cert.expiry_date);
      if (expiryDate > now && expiryDate <= thirtyDaysFromNow) {
        stats.expiring_soon++;
      }

      // Score
      totalScore += cert.score;
      if (cert.score >= 85) stats.score_distribution.excellent++;
      else if (cert.score >= 70) stats.score_distribution.good++;
      else if (cert.score >= 50) stats.score_distribution.fair++;
      else stats.score_distribution.poor++;
    }

    stats.average_score = stats.total > 0 ? Math.round(totalScore / stats.total) : 0;

    // Monthly trends (last 6 months)
    const monthlyTrends = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
      const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);
      
      const monthCerts = certs.filter((c) => {
        const issueDate = new Date(c.issue_date);
        return issueDate >= monthStart && issueDate <= monthEnd;
      });

      monthlyTrends.push({
        month: monthStart.toLocaleDateString("en-US", { month: "short", year: "numeric" }),
        issued: monthCerts.length,
        average_score: monthCerts.length > 0 
          ? Math.round(monthCerts.reduce((sum, c) => sum + c.score, 0) / monthCerts.length)
          : 0,
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        analytics: {
          summary: stats,
          monthly_trends: monthlyTrends,
          generated_at: new Date().toISOString(),
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Analytics error:", err);
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
