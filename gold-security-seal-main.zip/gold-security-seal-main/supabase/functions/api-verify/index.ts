import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function hashApiKey(key: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(key);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

interface ApiKeyRecord {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  key_prefix: string;
  permissions: string[];
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
}

interface ApiKeyValidation {
  valid: boolean;
  userId?: string;
  permissions?: string[];
  error?: string;
}

async function validateApiKey(
  supabase: SupabaseClient,
  authHeader: string | null,
  requiredPermission: string
): Promise<ApiKeyValidation> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { valid: false, error: "Authorization header required (Bearer token)" };
  }

  const token = authHeader.replace("Bearer ", "");
  
  // Check if it's an API key (starts with sck_)
  if (token.startsWith("sck_")) {
    const keyHash = await hashApiKey(token);
    const keyPrefix = token.substring(0, 12);

    const { data, error } = await supabase
      .from("api_keys")
      .select("*")
      .eq("key_hash", keyHash)
      .eq("key_prefix", keyPrefix)
      .eq("is_active", true)
      .single();

    if (error || !data) {
      return { valid: false, error: "Invalid API key" };
    }

    const apiKey = data as ApiKeyRecord;

    // Check expiration
    if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) {
      return { valid: false, error: "API key has expired" };
    }

    // Check permission
    if (!apiKey.permissions.includes(requiredPermission)) {
      return { valid: false, error: `API key lacks '${requiredPermission}' permission` };
    }

    // Update last_used_at
    await supabase
      .from("api_keys")
      .update({ last_used_at: new Date().toISOString() })
      .eq("id", apiKey.id);

    return { valid: true, userId: apiKey.user_id, permissions: apiKey.permissions };
  }

  // Fall back to JWT token auth
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return { valid: false, error: "Invalid or expired token" };
  }

  return { valid: true, userId: user.id, permissions: ["read", "write", "delete", "verify", "analytics", "webhooks"] };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Validate API key with 'verify' permission
    const authHeader = req.headers.get("Authorization");
    const validation = await validateApiKey(supabase, authHeader, "verify");
    
    if (!validation.valid) {
      return new Response(
        JSON.stringify({ success: false, error: validation.error }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const url = new URL(req.url);
    const certificateId = url.searchParams.get("id");

    if (!certificateId) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: "Certificate ID required. Use ?id=CERT-XXXX" 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { data, error } = await supabase
      .from("certificates")
      .select("certificate_id, website_name, owner_name, score, risk_level, status, issue_date, expiry_date")
      .eq("certificate_id", certificateId)
      .single();

    if (error || !data) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          verified: false,
          error: "Certificate not found" 
        }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const isExpired = new Date(data.expiry_date) < new Date();
    const daysUntilExpiry = Math.ceil((new Date(data.expiry_date).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    const isValid = data.status === "Active" && !isExpired;

    return new Response(
      JSON.stringify({
        success: true,
        verified: isValid,
        certificate: {
          id: data.certificate_id,
          website: data.website_name,
          owner: data.owner_name,
          score: data.score,
          risk_level: data.risk_level,
          status: isExpired ? "expired" : data.status.toLowerCase(),
          issue_date: data.issue_date,
          expiry_date: data.expiry_date,
          is_expired: isExpired,
          days_until_expiry: daysUntilExpiry,
        },
        verified_at: new Date().toISOString(),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Verification error:", err);
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
