import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const certificateId = url.searchParams.get("id");

    if (!certificateId) {
      return new Response(
        JSON.stringify({ error: "Certificate ID is required" }),
        { 
          status: 400, 
          headers: { ...corsHeaders, "Content-Type": "application/json" } 
        }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: certificate, error } = await supabase
      .from("certificates")
      .select("*")
      .eq("certificate_id", certificateId.toUpperCase())
      .maybeSingle();

    if (error) {
      console.error("Database error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to fetch certificate" }),
        { 
          status: 500, 
          headers: { ...corsHeaders, "Content-Type": "application/json" } 
        }
      );
    }

    if (!certificate) {
      // Return default OG meta for invalid certificate
      return new Response(
        JSON.stringify({
          title: "Certificate Not Found - SecureAudit",
          description: "This security certificate could not be verified. Please check the certificate ID and try again.",
          image: null,
          status: "not_found",
        }),
        { 
          headers: { ...corsHeaders, "Content-Type": "application/json" } 
        }
      );
    }

    // Determine certificate level
    let level = "Bronze";
    if (certificate.score >= 85) level = "Platinum";
    else if (certificate.score >= 70) level = "Gold";
    else if (certificate.score >= 50) level = "Silver";

    // Determine status emoji and text
    let statusEmoji = "✅";
    let statusText = "Verified";
    if (certificate.status === "expired") {
      statusEmoji = "⚠️";
      statusText = "Expired";
    } else if (certificate.status === "revoked") {
      statusEmoji = "❌";
      statusText = "Revoked";
    }

    const title = `${statusEmoji} ${certificate.website_name} - Security Certificate ${statusText}`;
    const description = `${level} Level Certificate | Score: ${certificate.score}/100 | Risk: ${certificate.risk_level.charAt(0).toUpperCase() + certificate.risk_level.slice(1)} | ID: ${certificate.certificate_id} | Verified by SecureAudit`;

    // Generate SVG for OG image
    const bgColor = certificate.status === "valid" ? "#10b981" : certificate.status === "expired" ? "#f59e0b" : "#ef4444";
    const levelColor = level === "Platinum" ? "#94a3b8" : level === "Gold" ? "#eab308" : level === "Silver" ? "#9ca3af" : "#d97706";
    
    const svg = `
      <svg width="1200" height="630" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#1a1a2e"/>
            <stop offset="100%" style="stop-color:#16213e"/>
          </linearGradient>
          <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" style="stop-color:${bgColor}"/>
            <stop offset="100%" style="stop-color:${bgColor}88"/>
          </linearGradient>
        </defs>
        
        <!-- Background -->
        <rect width="1200" height="630" fill="url(#bg)"/>
        
        <!-- Left accent bar -->
        <rect x="0" y="0" width="8" height="630" fill="url(#accent)"/>
        
        <!-- Shield icon -->
        <g transform="translate(80, 180)">
          <path d="M50 0 L100 20 L100 60 C100 100 50 130 50 130 C50 130 0 100 0 60 L0 20 Z" 
                fill="${bgColor}" opacity="0.2"/>
          <path d="M50 10 L90 27 L90 57 C90 90 50 115 50 115 C50 115 10 90 10 57 L10 27 Z" 
                fill="${bgColor}"/>
          <text x="50" y="75" text-anchor="middle" fill="white" font-size="40" font-weight="bold">✓</text>
        </g>
        
        <!-- Title -->
        <text x="200" y="220" fill="white" font-size="42" font-weight="bold" font-family="system-ui, -apple-system, sans-serif">
          ${certificate.website_name}
        </text>
        
        <!-- Subtitle -->
        <text x="200" y="270" fill="${bgColor}" font-size="24" font-weight="600" font-family="system-ui, sans-serif">
          Security Certificate ${statusText}
        </text>
        
        <!-- Stats row -->
        <g transform="translate(200, 320)">
          <!-- Score -->
          <rect x="0" y="0" width="180" height="80" rx="8" fill="white" opacity="0.1"/>
          <text x="90" y="35" text-anchor="middle" fill="#9ca3af" font-size="14" font-family="system-ui, sans-serif">SCORE</text>
          <text x="90" y="65" text-anchor="middle" fill="white" font-size="28" font-weight="bold" font-family="system-ui, sans-serif">${certificate.score}/100</text>
          
          <!-- Level -->
          <rect x="200" y="0" width="180" height="80" rx="8" fill="${levelColor}" opacity="0.2"/>
          <text x="290" y="35" text-anchor="middle" fill="#9ca3af" font-size="14" font-family="system-ui, sans-serif">LEVEL</text>
          <text x="290" y="65" text-anchor="middle" fill="${levelColor}" font-size="28" font-weight="bold" font-family="system-ui, sans-serif">${level}</text>
          
          <!-- Risk -->
          <rect x="400" y="0" width="180" height="80" rx="8" fill="white" opacity="0.1"/>
          <text x="490" y="35" text-anchor="middle" fill="#9ca3af" font-size="14" font-family="system-ui, sans-serif">RISK</text>
          <text x="490" y="65" text-anchor="middle" fill="white" font-size="28" font-weight="bold" font-family="system-ui, sans-serif">${certificate.risk_level.charAt(0).toUpperCase() + certificate.risk_level.slice(1)}</text>
        </g>
        
        <!-- Certificate ID -->
        <text x="200" y="460" fill="#6b7280" font-size="18" font-family="monospace">
          Certificate ID: ${certificate.certificate_id}
        </text>
        
        <!-- Brand -->
        <g transform="translate(80, 540)">
          <text x="0" y="30" fill="white" font-size="24" font-weight="bold" font-family="system-ui, sans-serif">SECUREAUDIT</text>
          <text x="220" y="30" fill="#6b7280" font-size="18" font-family="system-ui, sans-serif">Cyber Security Verification Authority</text>
        </g>
        
        <!-- Bottom accent -->
        <rect x="0" y="620" width="1200" height="10" fill="url(#accent)"/>
      </svg>
    `;

    // Convert SVG to base64 data URI for embedding
    const svgBase64 = btoa(svg);
    const imageDataUri = `data:image/svg+xml;base64,${svgBase64}`;

    console.log(`Generated OG data for certificate: ${certificateId}`);

    return new Response(
      JSON.stringify({
        title,
        description,
        image: imageDataUri,
        status: certificate.status,
        certificate: {
          id: certificate.certificate_id,
          website_name: certificate.website_name,
          owner_name: certificate.owner_name,
          score: certificate.score,
          risk_level: certificate.risk_level,
          level,
          issue_date: certificate.issue_date,
          expiry_date: certificate.expiry_date,
        },
      }),
      { 
        headers: { 
          ...corsHeaders, 
          "Content-Type": "application/json",
          "Cache-Control": "public, max-age=3600"
        } 
      }
    );
  } catch (error) {
    console.error("Error generating OG data:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { 
        status: 500, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      }
    );
  }
});
