import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  expiry_date: string;
  status: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ error: "RESEND_API_KEY not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get notification settings
    const { data: settings } = await supabase
      .from("app_settings")
      .select("value")
      .eq("key", "notifications")
      .single();

    const notificationSettings = settings?.value as {
      expiryWarningDays?: number;
      emailRecipients?: string;
      enableEmailNotifications?: boolean;
    } | null;

    if (!notificationSettings?.enableEmailNotifications) {
      return new Response(
        JSON.stringify({ message: "Email notifications disabled" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const warningDays = notificationSettings.expiryWarningDays || 30;
    const recipients = notificationSettings.emailRecipients?.split(",").map(e => e.trim()).filter(Boolean) || [];

    if (recipients.length === 0) {
      return new Response(
        JSON.stringify({ message: "No email recipients configured" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Find certificates expiring within warning period
    const warningDate = new Date();
    warningDate.setDate(warningDate.getDate() + warningDays);

    const { data: expiringCerts, error } = await supabase
      .from("certificates")
      .select("*")
      .eq("status", "active")
      .lte("expiry_date", warningDate.toISOString().split("T")[0])
      .gte("expiry_date", new Date().toISOString().split("T")[0]);

    if (error) throw error;

    if (!expiringCerts || expiringCerts.length === 0) {
      return new Response(
        JSON.stringify({ message: "No certificates expiring soon" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Build email content
    const certList = expiringCerts.map((cert: Certificate) => {
      const daysUntilExpiry = Math.ceil(
        (new Date(cert.expiry_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
      );
      return `• ${cert.website_name} (${cert.certificate_id}) - Expires in ${daysUntilExpiry} days (${cert.expiry_date})`;
    }).join("\n");

    const emailHtml = `
      <h2>Certificate Expiry Warning</h2>
      <p>The following certificates are expiring within ${warningDays} days:</p>
      <ul>
        ${expiringCerts.map((cert: Certificate) => {
          const daysUntilExpiry = Math.ceil(
            (new Date(cert.expiry_date).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
          );
          return `<li><strong>${cert.website_name}</strong> (${cert.certificate_id}) - Expires in ${daysUntilExpiry} days (${cert.expiry_date})</li>`;
        }).join("")}
      </ul>
      <p>Please take action to renew these certificates before they expire.</p>
    `;

    // Send email via Resend
    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${resendApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Certificate Manager <onboarding@resend.dev>",
        to: recipients,
        subject: `⚠️ ${expiringCerts.length} Certificate(s) Expiring Soon`,
        html: emailHtml,
        text: `Certificate Expiry Warning\n\nThe following certificates are expiring within ${warningDays} days:\n\n${certList}\n\nPlease take action to renew these certificates before they expire.`,
      }),
    });

    if (!emailResponse.ok) {
      const errorText = await emailResponse.text();
      throw new Error(`Resend API error: ${errorText}`);
    }

    const result = await emailResponse.json();

    // Log the notification
    await supabase.from("audit_logs").insert({
      action: "expiry_notification_sent",
      entity_type: "notification",
      entity_name: `${expiringCerts.length} certificates`,
      details: {
        certificates: expiringCerts.map((c: Certificate) => c.certificate_id),
        recipients,
        resend_id: result.id,
      },
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Sent expiry warning for ${expiringCerts.length} certificate(s)`,
        emailId: result.id 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    console.error("Error sending notifications:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
