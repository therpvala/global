import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CertificateData {
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  ssl_score: number;
  dns_score: number;
  server_score: number;
  status: string;
  expiry_date: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { certificate } = await req.json() as { certificate: CertificateData };
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");

    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const systemPrompt = `You are a cybersecurity expert analyzing website security certificates. Based on the provided certificate data, generate actionable security recommendations.

Your response MUST be a valid JSON object with this exact structure:
{
  "summary": "Brief 1-2 sentence overview of the security posture",
  "risk_assessment": "low" | "medium" | "high" | "critical",
  "recommendations": [
    {
      "priority": "high" | "medium" | "low",
      "category": "SSL" | "DNS" | "Server" | "General",
      "title": "Short recommendation title",
      "description": "Detailed actionable recommendation"
    }
  ],
  "immediate_actions": ["Action 1", "Action 2"],
  "long_term_improvements": ["Improvement 1", "Improvement 2"]
}

Focus on:
- SSL/TLS configuration issues
- DNS security (DNSSEC, SPF, DKIM, DMARC)
- Server hardening recommendations
- Certificate renewal and validity
- Specific vulnerabilities based on scores`;

    const userPrompt = `Analyze this security certificate and provide recommendations:

Website: ${certificate.website_name}
Owner: ${certificate.owner_name}
Overall Score: ${certificate.score}/100
Risk Level: ${certificate.risk_level}
Status: ${certificate.status}
Expiry Date: ${certificate.expiry_date}

Component Scores:
- SSL/TLS Score: ${certificate.ssl_score}/100
- DNS Security Score: ${certificate.dns_score}/100
- Server Security Score: ${certificate.server_score}/100

Generate specific, actionable security recommendations based on these scores.`;

    console.log("Calling Lovable AI Gateway for certificate analysis...");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Please add credits to continue." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      throw new Error(`AI Gateway error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No response from AI");
    }

    // Parse the JSON response from AI
    let analysis;
    try {
      // Remove markdown code blocks if present
      const cleanedContent = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      analysis = JSON.parse(cleanedContent);
    } catch (parseError) {
      console.error("Failed to parse AI response:", content);
      // Fallback response if JSON parsing fails
      analysis = {
        summary: content.substring(0, 200),
        risk_assessment: certificate.risk_level,
        recommendations: [
          {
            priority: "medium",
            category: "General",
            title: "Review Security Configuration",
            description: "Please review your security configuration based on the scores provided.",
          },
        ],
        immediate_actions: ["Review SSL configuration", "Check DNS settings"],
        long_term_improvements: ["Implement regular security audits"],
      };
    }

    console.log("Analysis completed successfully");

    return new Response(JSON.stringify({ analysis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in analyze-certificate:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
