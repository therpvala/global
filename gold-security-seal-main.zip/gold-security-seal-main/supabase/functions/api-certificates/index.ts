import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

async function hashApiKey(key: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(key);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

interface ApiKeyRecord {
  id: string;
  user_id: string;
  name: string;
  key_hash: string;
  key_prefix: string;
  permissions: string[];
  last_used_at: string | null;
  expires_at: string | null;
  created_at: string;
  is_active: boolean;
}

interface ApiKeyValidation {
  valid: boolean;
  userId?: string;
  permissions?: string[];
  error?: string;
}

async function validateApiKey(
  supabase: SupabaseClient,
  authHeader: string | null,
  requiredPermission: string
): Promise<ApiKeyValidation> {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return { valid: false, error: "Authorization header required (Bearer token)" };
  }

  const token = authHeader.replace("Bearer ", "");
  
  // Check if it's an API key (starts with sck_)
  if (token.startsWith("sck_")) {
    const keyHash = await hashApiKey(token);
    const keyPrefix = token.substring(0, 12);

    const { data, error } = await supabase
      .from("api_keys")
      .select("*")
      .eq("key_hash", keyHash)
      .eq("key_prefix", keyPrefix)
      .eq("is_active", true)
      .single();

    if (error || !data) {
      return { valid: false, error: "Invalid API key" };
    }

    const apiKey = data as ApiKeyRecord;

    // Check expiration
    if (apiKey.expires_at && new Date(apiKey.expires_at) < new Date()) {
      return { valid: false, error: "API key has expired" };
    }

    // Check permission
    if (!apiKey.permissions.includes(requiredPermission)) {
      return { valid: false, error: `API key lacks '${requiredPermission}' permission` };
    }

    // Update last_used_at
    await supabase
      .from("api_keys")
      .update({ last_used_at: new Date().toISOString() })
      .eq("id", apiKey.id);

    return { valid: true, userId: apiKey.user_id, permissions: apiKey.permissions };
  }

  // Fall back to JWT token auth
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) {
    return { valid: false, error: "Invalid or expired token" };
  }

  return { valid: true, userId: user.id, permissions: ["read", "write", "delete", "verify", "analytics", "webhooks"] };
}

function getRequiredPermission(method: string): string {
  switch (method) {
    case "POST": return "write";
    case "PUT": return "write";
    case "DELETE": return "delete";
    default: return "read";
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Validate API key with appropriate permission
    const authHeader = req.headers.get("Authorization");
    const requiredPermission = getRequiredPermission(req.method);
    const validation = await validateApiKey(supabase, authHeader, requiredPermission);
    
    if (!validation.valid) {
      return new Response(
        JSON.stringify({ success: false, error: validation.error }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const url = new URL(req.url);
    const id = url.searchParams.get("id");

    // GET - List certificates or get single certificate
    if (req.method === "GET") {
      if (id) {
        const { data, error } = await supabase
          .from("certificates")
          .select("*")
          .eq("id", id)
          .single();

        if (error) {
          return new Response(
            JSON.stringify({ success: false, error: "Certificate not found" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }

        return new Response(
          JSON.stringify({ success: true, certificate: data }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const limit = parseInt(url.searchParams.get("limit") || "50");
      const offset = parseInt(url.searchParams.get("offset") || "0");
      const status = url.searchParams.get("status");
      const risk = url.searchParams.get("risk");

      let query = supabase
        .from("certificates")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(offset, offset + limit - 1);

      if (status) query = query.eq("status", status);
      if (risk) query = query.eq("risk_level", risk);

      const { data, error, count } = await query;

      if (error) {
        return new Response(
          JSON.stringify({ success: false, error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          certificates: data,
          pagination: { total: count, limit, offset }
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // POST - Create certificate
    if (req.method === "POST") {
      const body = await req.json();
      
      const required = ["website_name", "owner_name", "score", "risk_level", "expiry_date"];
      for (const field of required) {
        if (!body[field]) {
          return new Response(
            JSON.stringify({ success: false, error: `Missing required field: ${field}` }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }

      // Get user profile for auditor info
      const { data: profile } = await supabase
        .from("profiles")
        .select("full_name, title, initials")
        .eq("user_id", validation.userId)
        .single();

      const certificateId = `CERT-${Date.now().toString(36).toUpperCase()}`;
      
      const { data, error } = await supabase
        .from("certificates")
        .insert({
          certificate_id: certificateId,
          website_name: body.website_name,
          owner_name: body.owner_name,
          score: body.score,
          risk_level: body.risk_level,
          status: body.status || "valid",
          expiry_date: body.expiry_date,
          ssl_score: body.ssl_score || 0,
          dns_score: body.dns_score || 0,
          server_score: body.server_score || 0,
          auditor_name: profile?.full_name || "API User",
          auditor_title: profile?.title || "Security Auditor",
          auditor_initials: profile?.initials || "API",
        })
        .select()
        .single();

      if (error) {
        return new Response(
          JSON.stringify({ success: false, error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, certificate: data }),
        { status: 201, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // PUT - Update certificate
    if (req.method === "PUT") {
      if (!id) {
        return new Response(
          JSON.stringify({ success: false, error: "Certificate ID required in query" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const body = await req.json();
      const allowedFields = ["website_name", "owner_name", "score", "risk_level", "status", "expiry_date", "ssl_score", "dns_score", "server_score"];
      const updates: Record<string, unknown> = {};
      
      for (const field of allowedFields) {
        if (body[field] !== undefined) {
          updates[field] = body[field];
        }
      }

      const { data, error } = await supabase
        .from("certificates")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) {
        return new Response(
          JSON.stringify({ success: false, error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, certificate: data }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // DELETE - Delete certificate
    if (req.method === "DELETE") {
      if (!id) {
        return new Response(
          JSON.stringify({ success: false, error: "Certificate ID required in query" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      const { error } = await supabase
        .from("certificates")
        .delete()
        .eq("id", id);

      if (error) {
        return new Response(
          JSON.stringify({ success: false, error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      return new Response(
        JSON.stringify({ success: true, message: "Certificate deleted" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: false, error: "Method not allowed" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("API error:", err);
    return new Response(
      JSON.stringify({ success: false, error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
