import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

interface Certificate {
  id: string;
  certificate_id: string;
  website_name: string;
  owner_name: string;
  score: number;
  risk_level: string;
  status: string;
  expiry_date: string;
  issue_date: string;
}

function getCertificateLevel(score: number): string {
  if (score >= 90) return "Platinum";
  if (score >= 75) return "Gold";
  return "Silver";
}

function getStatusColor(status: string, isExpired: boolean): { bg: string; text: string; border: string } {
  if (isExpired || status === "expired" || status === "revoked") {
    return { bg: "#fef2f2", text: "#dc2626", border: "#fecaca" };
  }
  return { bg: "#f0fdf4", text: "#16a34a", border: "#bbf7d0" };
}

function getLevelColor(level: string): string {
  switch (level) {
    case "Platinum": return "#a855f7";
    case "Gold": return "#f59e0b";
    default: return "#94a3b8";
  }
}

function generateBadgeSVG(cert: Certificate, size: "small" | "medium" | "large", theme: "light" | "dark"): string {
  const isExpired = new Date(cert.expiry_date) < new Date();
  const isValid = !isExpired && cert.status !== "expired" && cert.status !== "revoked";
  const level = getCertificateLevel(cert.score);
  const statusColors = getStatusColor(cert.status, isExpired);
  const levelColor = getLevelColor(level);
  
  const sizes = {
    small: { width: 180, height: 60, fontSize: 10, iconSize: 20, padding: 8 },
    medium: { width: 240, height: 80, fontSize: 12, iconSize: 28, padding: 12 },
    large: { width: 320, height: 100, fontSize: 14, iconSize: 36, padding: 16 },
  };
  
  const s = sizes[size];
  const bgColor = theme === "dark" ? "#1e293b" : "#ffffff";
  const textColor = theme === "dark" ? "#f8fafc" : "#1e293b";
  const subtextColor = theme === "dark" ? "#94a3b8" : "#64748b";
  const borderColor = theme === "dark" ? "#334155" : "#e2e8f0";
  
  const shieldIcon = isValid
    ? `<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="${statusColors.text}" opacity="0.2"/>
       <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="${statusColors.text}" stroke-width="2" fill="none"/>
       <path d="M9 12l2 2 4-4" stroke="${statusColors.text}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`
    : `<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="${statusColors.text}" opacity="0.2"/>
       <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" stroke="${statusColors.text}" stroke-width="2" fill="none"/>
       <path d="M15 9l-6 6M9 9l6 6" stroke="${statusColors.text}" stroke-width="2" fill="none" stroke-linecap="round"/>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${s.width}" height="${s.height}" viewBox="0 0 ${s.width} ${s.height}">
    <defs>
      <linearGradient id="shimmer" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" style="stop-color:${levelColor};stop-opacity:0.1"/>
        <stop offset="50%" style="stop-color:${levelColor};stop-opacity:0.3"/>
        <stop offset="100%" style="stop-color:${levelColor};stop-opacity:0.1"/>
      </linearGradient>
      <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
        <feDropShadow dx="0" dy="2" stdDeviation="4" flood-opacity="0.1"/>
      </filter>
    </defs>
    
    <!-- Background -->
    <rect x="0" y="0" width="${s.width}" height="${s.height}" rx="8" ry="8" fill="${bgColor}" stroke="${borderColor}" stroke-width="1" filter="url(#shadow)"/>
    
    <!-- Level accent bar -->
    <rect x="0" y="0" width="4" height="${s.height}" rx="8" ry="0" fill="${levelColor}"/>
    <rect x="0" y="0" width="8" height="${s.height}" fill="${levelColor}" clip-path="inset(0 round 8px 0 0 8px)"/>
    
    <!-- Shield icon -->
    <g transform="translate(${s.padding + 8}, ${(s.height - s.iconSize) / 2})">
      <svg width="${s.iconSize}" height="${s.iconSize}" viewBox="0 0 24 24">
        ${shieldIcon}
      </svg>
    </g>
    
    <!-- Text content -->
    <text x="${s.padding + s.iconSize + 20}" y="${s.height / 2 - s.fontSize * 0.6}" font-family="system-ui, -apple-system, sans-serif" font-size="${s.fontSize}" font-weight="600" fill="${textColor}">
      ${isValid ? "Verified Secure" : "Not Verified"}
    </text>
    <text x="${s.padding + s.iconSize + 20}" y="${s.height / 2 + s.fontSize * 0.8}" font-family="system-ui, -apple-system, sans-serif" font-size="${s.fontSize * 0.85}" fill="${subtextColor}">
      ${level} • Score: ${cert.score}/100
    </text>
    
    <!-- CyberSec brand -->
    <text x="${s.width - s.padding}" y="${s.height - s.padding}" font-family="system-ui, -apple-system, sans-serif" font-size="${s.fontSize * 0.7}" fill="${subtextColor}" text-anchor="end">
      CyberSec Verified
    </text>
  </svg>`;
}

function generateWidgetHTML(cert: Certificate, size: "small" | "medium" | "large", theme: "light" | "dark", baseUrl: string): string {
  const svg = generateBadgeSVG(cert, size, theme);
  const verifyUrl = `${baseUrl}/verify?id=${cert.certificate_id}`;
  
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: transparent; }
    .cybersec-badge {
      display: inline-block;
      text-decoration: none;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      border-radius: 8px;
    }
    .cybersec-badge:hover {
      transform: translateY(-2px);
    }
    .cybersec-badge svg {
      display: block;
    }
  </style>
</head>
<body>
  <a href="${verifyUrl}" target="_blank" rel="noopener noreferrer" class="cybersec-badge" title="Verify Certificate">
    ${svg}
  </a>
</body>
</html>`;
}

function generateEmbedCode(certificateId: string, size: "small" | "medium" | "large", theme: "light" | "dark", baseUrl: string): string {
  const sizes = {
    small: { width: 180, height: 60 },
    medium: { width: 240, height: 80 },
    large: { width: 320, height: 100 },
  };
  const s = sizes[size];
  
  return `<iframe src="${baseUrl}/functions/v1/embed-badge?id=${certificateId}&size=${size}&theme=${theme}" width="${s.width}" height="${s.height}" frameborder="0" scrolling="no" style="border:none;overflow:hidden;" title="CyberSec Verified Badge"></iframe>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const certificateId = url.searchParams.get("id");
    const size = (url.searchParams.get("size") || "medium") as "small" | "medium" | "large";
    const theme = (url.searchParams.get("theme") || "light") as "light" | "dark";
    const format = url.searchParams.get("format") || "html"; // html, svg, or code
    
    if (!certificateId) {
      return new Response(
        JSON.stringify({ error: "Certificate ID is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data: cert, error } = await supabase
      .from("certificates")
      .select("*")
      .eq("certificate_id", certificateId)
      .single();

    if (error || !cert) {
      // Return a "not found" badge
      const notFoundSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="80" viewBox="0 0 240 80">
        <rect x="0" y="0" width="240" height="80" rx="8" ry="8" fill="#fef2f2" stroke="#fecaca" stroke-width="1"/>
        <text x="120" y="45" font-family="system-ui, sans-serif" font-size="14" fill="#dc2626" text-anchor="middle">Certificate Not Found</text>
      </svg>`;
      
      if (format === "svg") {
        return new Response(notFoundSvg, {
          headers: { ...corsHeaders, "Content-Type": "image/svg+xml", "Cache-Control": "public, max-age=300" },
        });
      }
      
      return new Response(
        `<!DOCTYPE html><html><body style="margin:0">${notFoundSvg}</body></html>`,
        { headers: { ...corsHeaders, "Content-Type": "text/html", "Cache-Control": "public, max-age=300" } }
      );
    }

    // Determine base URL for verification links
    const origin = req.headers.get("origin") || url.origin.replace("/functions/v1", "");
    const baseUrl = origin.includes("localhost") ? origin : origin.replace(/:\d+/, "");
    const cleanBaseUrl = baseUrl.replace("/functions/v1/embed-badge", "").replace(/\/+$/, "");

    if (format === "svg") {
      const svg = generateBadgeSVG(cert, size, theme);
      return new Response(svg, {
        headers: { 
          ...corsHeaders, 
          "Content-Type": "image/svg+xml",
          "Cache-Control": "public, max-age=3600",
        },
      });
    }

    if (format === "code") {
      const embedCode = generateEmbedCode(certificateId, size, theme, supabaseUrl);
      return new Response(
        JSON.stringify({ embedCode, certificateId, size, theme }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Default: return HTML widget
    const html = generateWidgetHTML(cert, size, theme, cleanBaseUrl);
    return new Response(html, {
      headers: { 
        ...corsHeaders, 
        "Content-Type": "text/html",
        "Cache-Control": "public, max-age=3600",
        "X-Frame-Options": "ALLOWALL",
      },
    });

  } catch (error) {
    console.error("Error generating badge:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
