

# MLM Vala – Premium Dark Landing Page

## Overview
A high-end, dark-themed SaaS landing page for MLM Vala with a premium 3D animated hero, 20 MLM plan cards, and smooth interactions throughout.

---

## 1. Dark Premium Theme Setup
- Deep navy/black background across the entire site
- Neon blue (`#00D4FF`) and electric green (`#39FF14`) as accent colors
- No light theme — forced dark mode only
- Professional typography with clean hierarchy

## 2. Top Navigation Bar
- **Logo**: "MLM Vala" with neon accent styling
- **Nav links**: Login, Register, Super Admin
- Sticky/transparent nav with subtle blur backdrop
- Each link routes to a placeholder page

## 3. Hero Section
- **Heading**: "MLM Vala – Multi Plan MLM SaaS Engine"
- **Subheading**: Compelling tagline about global MLM solutions
- **Two CTA buttons**: Login (outlined) & Register (filled neon gradient)
- **Animated background**: Canvas-based 3D neural network tree with:
  - Neon blue pulsing nodes
  - Electric green connection lines with flowing light
  - Binary-style branching structure
  - Subtle parallax depth and particle dust
  - Smooth, professional performance
- **Live animated counters**: Members, Total Payout ($), Active Networks — numbers count up on scroll

## 4. MLM Plans Grid (4×5 Layout)
20 cards displaying exactly these plans:
1. Binary Plan, 2. Unilevel Plan, 3. Matrix Plan, 4. Stairstep Breakaway Plan, 5. Generation Plan, 6. Monoline Plan, 7. Board / Cycler Plan, 8. Australian (2-Up) Plan, 9. Party Plan, 10. Single Leg Plan, 11. Hybrid Plan, 12. Multi-Tier Affiliate Plan, 13. Dual Team Plan, 14. Fixed ROI Plan, 15. Variable ROI Plan, 16. Revenue Sharing Plan, 17. Smart Contract MLM, 18. Staking Referral Plan, 19. DeFi Reward Plan, 20. Tokenized Reward Plan

Each card includes:
- Plan name
- Animated icon (unique per plan category)
- Pricing badges: $5/Monthly · $9/White Label · $249/Lifetime
- "Start Now" button with neon hover glow
- Smooth hover lift + glow border effect

## 5. Footer
- Four-column layout: About, Pricing, Contact, Terms
- Subtle separator with neon accent line
- "MLM Vala" branding with copyright

## 6. Placeholder Pages
- **/login** – Simple dark-themed login form placeholder
- **/register** – Simple dark-themed register form placeholder
- **/super-admin** – Placeholder admin dashboard page
- All pages maintain the dark premium aesthetic

## 7. Animations & Polish
- Scroll-triggered fade-in animations for sections
- Smooth counter animations in the hero
- Hover glow effects on all interactive elements
- Canvas neural network animation (no heavy 3D libraries — pure canvas for performance)
- Responsive design: grid collapses to 2 columns on tablet, 1 on mobile

