import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { planName, planCategory, planStructure } = await req.json();

    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Map plan name to plan_type enum
    const planTypeMap: Record<string, string> = {
      "Binary Plan": "binary",
      "Unilevel Plan": "unilevel",
      "Matrix Plan": "matrix",
      "Stairstep Breakaway": "stairstep_breakaway",
      "Generation Plan": "generation",
      "Monoline Plan": "monoline",
      "Board / Cycler Plan": "board_cycler",
      "Australian (2-Up) Plan": "australian_2up",
      "Single Leg Plan": "single_leg",
      "Party Plan": "party",
      "Hybrid Plan": "hybrid",
      "Multi-Tier Affiliate": "multi_tier_affiliate",
      "Dual Team / Tri-Binary": "dual_team",
      "ROI Plan": "fixed_roi",
      "Revenue Sharing Plan": "revenue_sharing",
      "Profit Sharing Plan": "revenue_sharing",
      "Smart Contract MLM": "smart_contract_mlm",
      "Staking Referral Plan": "staking_referral",
      "Token Reward / Reflection": "tokenized_reward",
      "Subscription Residual": "unilevel",
      "SaaS Affiliate Model": "multi_tier_affiliate",
      "Compression-Based": "hybrid",
      "E-Commerce MLM": "unilevel",
      "Franchise MLM Plan": "hybrid",
      "Insurance / Finance MLM": "unilevel",
      "Real Estate MLM": "hybrid",
    };

    const planType = planTypeMap[planName] || "binary";

    // Create a temporary demo user
    const demoEmail = `demo-${Date.now()}@mlmvala-demo.local`;
    const demoPassword = crypto.randomUUID();

    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email: demoEmail,
      password: demoPassword,
      email_confirm: true,
      user_metadata: { full_name: "Demo User", is_demo: true },
    });

    if (authError) throw authError;
    const userId = authUser.user.id;

    // Create demo tenant
    const expiryDate = new Date(Date.now() + 30 * 60 * 1000).toISOString(); // 30 min
    const { data: tenant, error: tenantError } = await supabaseAdmin
      .from("tenants")
      .insert({
        business_name: `Demo - ${planName}`,
        owner_name: "Demo User",
        email: demoEmail,
        plan_type: planType,
        status: "active",
        owner_user_id: userId,
        expiry_date: expiryDate,
      })
      .select()
      .single();

    if (tenantError) throw tenantError;

    // Assign admin role
    await supabaseAdmin.from("user_roles").insert({ user_id: userId, role: "admin" });

    // Create demo member
    await supabaseAdmin.from("members").insert({
      tenant_id: tenant.id,
      username: "demo_admin",
      user_id: userId,
      status: "active",
    });

    // Sign in as demo user to get session
    const { data: signInData, error: signInError } = await supabaseAdmin.auth.admin.generateLink({
      type: "magiclink",
      email: demoEmail,
    });

    // Use signInWithPassword for the demo user
    // We'll return credentials for client-side sign in
    return new Response(
      JSON.stringify({
        status: "success",
        data: {
          email: demoEmail,
          password: demoPassword,
          tenantId: tenant.id,
          expiresAt: expiryDate,
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ status: "error", message: error.message }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
