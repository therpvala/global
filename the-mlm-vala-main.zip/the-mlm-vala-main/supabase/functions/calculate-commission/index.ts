import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CommissionRequest {
  tenantId: string;
  memberId: string;
  amount: number;
  packagePv?: number;
  packageBv?: number;
}

// Plan-specific commission calculators
const calculators: Record<string, (ctx: CalcContext) => CommissionEntry[]> = {
  binary: calcBinary,
  unilevel: calcUnilevel,
  matrix: calcMatrix,
  stairstep_breakaway: calcStairstep,
  generation: calcGeneration,
  monoline: calcMonoline,
  board_cycler: calcBoardCycler,
  australian_2up: calcAustralian,
  single_leg: calcSingleLeg,
  party: calcParty,
  hybrid: calcHybrid,
  multi_tier_affiliate: calcMultiTier,
  dual_team: calcDualTeam,
  fixed_roi: calcROI,
  variable_roi: calcROI,
  revenue_sharing: calcRevenueShare,
  smart_contract_mlm: calcSmartContract,
  staking_referral: calcStaking,
  defi_reward: calcDefiReward,
  tokenized_reward: calcTokenReward,
};

interface CalcContext {
  memberId: string;
  tenantId: string;
  amount: number;
  pv: number;
  bv: number;
  sponsors: SponsorChain[];
}

interface SponsorChain {
  id: string;
  level: number;
  status: string;
}

interface CommissionEntry {
  member_id: string;
  tenant_id: string;
  amount: number;
  commission_type: string;
  level: number | null;
  source_member_id: string;
}

// ─── Calculator implementations ───

function calcBinary(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  // Direct referral 10%
  if (ctx.sponsors[0]) {
    entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.10, "binary_pair", 1));
  }
  // Matching bonus 5% up to 3 levels
  ctx.sponsors.slice(1, 4).forEach((s, i) => {
    if (s.status === "active") {
      entries.push(makeEntry(ctx, s.id, ctx.amount * 0.05, "matching_bonus", i + 2));
    }
  });
  return entries;
}

function calcUnilevel(ctx: CalcContext): CommissionEntry[] {
  const rates = [0.10, 0.05, 0.03, 0.02, 0.01, 0.01, 0.005, 0.005, 0.005, 0.005];
  return ctx.sponsors.slice(0, 10).map((s, i) =>
    s.status === "active" ? makeEntry(ctx, s.id, ctx.amount * rates[i], "level_override", i + 1) : null
  ).filter(Boolean) as CommissionEntry[];
}

function calcMatrix(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.10, "matrix_fill", 1));
  ctx.sponsors.slice(1, 7).forEach((s, i) => {
    if (s.status === "active") entries.push(makeEntry(ctx, s.id, ctx.amount * 0.03, "matrix_fill", i + 2));
  });
  return entries;
}

function calcStairstep(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.12, "level_override", 1));
  ctx.sponsors.slice(1, 5).forEach((s, i) => {
    if (s.status === "active") entries.push(makeEntry(ctx, s.id, ctx.amount * 0.03, "level_override", i + 2));
  });
  return entries;
}

function calcGeneration(ctx: CalcContext): CommissionEntry[] {
  const rates = [0.08, 0.05, 0.03, 0.02, 0.01];
  return ctx.sponsors.slice(0, 5).map((s, i) =>
    s.status === "active" ? makeEntry(ctx, s.id, ctx.amount * rates[i], "generation_bonus", i + 1) : null
  ).filter(Boolean) as CommissionEntry[];
}

function calcMonoline(ctx: CalcContext): CommissionEntry[] {
  return ctx.sponsors.slice(0, 5).map((s, i) =>
    s.status === "active" ? makeEntry(ctx, s.id, ctx.amount * 0.02, "pool_share", i + 1) : null
  ).filter(Boolean) as CommissionEntry[];
}

function calcBoardCycler(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.15, "board_cycle", 1));
  return entries;
}

function calcAustralian(ctx: CalcContext): CommissionEntry[] {
  // Pass-up: first 2 sales go to sponsor
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.10, "direct_referral", 1));
  return entries;
}

function calcSingleLeg(ctx: CalcContext): CommissionEntry[] {
  return ctx.sponsors.slice(0, 8).map((s, i) =>
    s.status === "active" ? makeEntry(ctx, s.id, ctx.amount * 0.02, "level_override", i + 1) : null
  ).filter(Boolean) as CommissionEntry[];
}

function calcParty(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.12, "rank_bonus", 1));
  return entries;
}

function calcHybrid(ctx: CalcContext): CommissionEntry[] {
  // Combine binary + unilevel logic
  const entries = calcBinary(ctx);
  ctx.sponsors.slice(0, 5).forEach((s, i) => {
    if (s.status === "active") entries.push(makeEntry(ctx, s.id, ctx.amount * 0.02, "level_override", i + 1));
  });
  return entries;
}

function calcMultiTier(ctx: CalcContext): CommissionEntry[] {
  const rates = [0.15, 0.05, 0.03];
  return ctx.sponsors.slice(0, 3).map((s, i) =>
    s.status === "active" ? makeEntry(ctx, s.id, ctx.amount * rates[i], "direct_referral", i + 1) : null
  ).filter(Boolean) as CommissionEntry[];
}

function calcDualTeam(ctx: CalcContext): CommissionEntry[] {
  return calcBinary(ctx); // Similar to binary with dual matching
}

function calcROI(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  // Direct referral 5% + ROI credit logged separately
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.05, "direct_referral", 1));
  entries.push(makeEntry(ctx, ctx.memberId, ctx.amount * 0.01, "roi_credit", null));
  return entries;
}

function calcRevenueShare(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.08, "revenue_share", 1));
  entries.push(makeEntry(ctx, ctx.memberId, ctx.amount * 0.02, "pool_share", null));
  return entries;
}

function calcSmartContract(ctx: CalcContext): CommissionEntry[] {
  return calcUnilevel(ctx); // On-chain equivalent uses level logic
}

function calcStaking(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.05, "staking_reward", 1));
  entries.push(makeEntry(ctx, ctx.memberId, ctx.amount * 0.008, "staking_reward", null));
  return entries;
}

function calcDefiReward(ctx: CalcContext): CommissionEntry[] {
  return calcStaking(ctx);
}

function calcTokenReward(ctx: CalcContext): CommissionEntry[] {
  const entries: CommissionEntry[] = [];
  if (ctx.sponsors[0]) entries.push(makeEntry(ctx, ctx.sponsors[0].id, ctx.amount * 0.05, "token_reward", 1));
  entries.push(makeEntry(ctx, ctx.memberId, ctx.amount * 0.01, "token_reward", null));
  return entries;
}

function makeEntry(ctx: CalcContext, memberId: string, amount: number, type: string, level: number | null): CommissionEntry {
  return {
    member_id: memberId,
    tenant_id: ctx.tenantId,
    amount: Math.round(amount * 100) / 100,
    commission_type: type,
    level,
    source_member_id: ctx.memberId,
  };
}

// ─── Main handler ───

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { tenantId, memberId, amount, packagePv, packageBv } = (await req.json()) as CommissionRequest;

    if (!tenantId || !memberId || !amount) {
      throw new Error("Missing required fields: tenantId, memberId, amount");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    // Get tenant plan type
    const { data: tenant, error: tErr } = await supabase
      .from("tenants")
      .select("plan_type, status")
      .eq("id", tenantId)
      .single();
    if (tErr || !tenant) throw new Error("Tenant not found");
    if (tenant.status !== "active") throw new Error("Tenant is not active");

    // Build sponsor chain (upline path)
    const sponsors: SponsorChain[] = [];
    let currentId = memberId;
    for (let depth = 0; depth < 15; depth++) {
      const { data: member } = await supabase
        .from("members")
        .select("sponsor_id, status")
        .eq("id", currentId)
        .eq("tenant_id", tenantId)
        .single();
      if (!member?.sponsor_id) break;
      sponsors.push({ id: member.sponsor_id, level: depth + 1, status: member.status });
      currentId = member.sponsor_id;
    }

    const calcFn = calculators[tenant.plan_type] || calcUnilevel;
    const ctx: CalcContext = {
      memberId,
      tenantId,
      amount,
      pv: packagePv || 0,
      bv: packageBv || 0,
      sponsors,
    };

    const entries = calcFn(ctx).filter(e => e.amount > 0);

    if (entries.length > 0) {
      // Insert commissions
      const { error: cErr } = await supabase.from("commissions").insert(entries);
      if (cErr) throw new Error(`Commission insert failed: ${cErr.message}`);

      // Credit wallets
      for (const entry of entries) {
        const { data: wallet } = await supabase
          .from("wallets")
          .select("id, income_wallet")
          .eq("member_id", entry.member_id)
          .eq("tenant_id", tenantId)
          .single();

        if (wallet) {
          await supabase
            .from("wallets")
            .update({ income_wallet: wallet.income_wallet + entry.amount })
            .eq("id", wallet.id);
        } else {
          await supabase.from("wallets").insert({
            member_id: entry.member_id,
            tenant_id: tenantId,
            income_wallet: entry.amount,
          });
        }
      }
    }

    return new Response(
      JSON.stringify({
        status: "success",
        data: {
          planType: tenant.plan_type,
          commissionsCreated: entries.length,
          totalDistributed: entries.reduce((s, e) => s + e.amount, 0),
        },
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ status: "error", message: error.message }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
