
-- =============================================
-- ENUMS
-- =============================================
CREATE TYPE public.app_role AS ENUM ('super_admin', 'admin', 'moderator', 'user');

CREATE TYPE public.plan_type AS ENUM (
  'binary', 'unilevel', 'matrix', 'stairstep_breakaway', 'generation',
  'monoline', 'board_cycler', 'australian_2up', 'party', 'single_leg',
  'hybrid', 'multi_tier_affiliate', 'dual_team', 'fixed_roi', 'variable_roi',
  'revenue_sharing', 'smart_contract_mlm', 'staking_referral', 'defi_reward', 'tokenized_reward'
);

CREATE TYPE public.pricing_type AS ENUM ('monthly_5', 'white_label_9', 'lifetime_249');
CREATE TYPE public.tenant_status AS ENUM ('active', 'suspended', 'expired', 'pending');
CREATE TYPE public.member_status AS ENUM ('active', 'inactive', 'blocked');
CREATE TYPE public.payout_status AS ENUM ('pending', 'approved', 'rejected', 'processed');
CREATE TYPE public.payment_status AS ENUM ('success', 'failed', 'pending', 'refunded');
CREATE TYPE public.commission_type AS ENUM (
  'direct_referral', 'level_override', 'matching_bonus', 'binary_pair',
  'matrix_fill', 'pool_share', 'roi_credit', 'rank_bonus', 'generation_bonus',
  'board_cycle', 'revenue_share', 'staking_reward', 'defi_yield', 'token_reward'
);

-- =============================================
-- USER ROLES TABLE (security-first)
-- =============================================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'user',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function for role checks
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can read own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Super admins can manage roles" ON public.user_roles
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));

-- =============================================
-- PROFILES TABLE
-- =============================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT,
  avatar_url TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile" ON public.profiles
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON public.profiles
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON public.profiles
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Super admins can read all profiles" ON public.profiles
  FOR SELECT USING (public.has_role(auth.uid(), 'super_admin'));

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, full_name)
  VALUES (NEW.id, NEW.raw_user_meta_data ->> 'full_name');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =============================================
-- MASTER PLATFORM TABLES
-- =============================================

-- TENANTS
CREATE TABLE public.tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  business_name TEXT NOT NULL,
  owner_name TEXT NOT NULL,
  email TEXT NOT NULL,
  plan_type public.plan_type NOT NULL DEFAULT 'binary',
  pricing_type public.pricing_type NOT NULL DEFAULT 'monthly_5',
  license_key TEXT UNIQUE,
  expiry_date TIMESTAMPTZ,
  white_label_enabled BOOLEAN NOT NULL DEFAULT false,
  status public.tenant_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage tenants" ON public.tenants
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Tenant owners can read own tenant" ON public.tenants
  FOR SELECT USING (auth.uid() = owner_user_id);

-- SUBSCRIPTIONS
CREATE TABLE public.subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  billing_cycle TEXT NOT NULL DEFAULT 'monthly',
  amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  next_due_date TIMESTAMPTZ,
  payment_status public.payment_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage subscriptions" ON public.subscriptions
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Tenant owners can read own subscriptions" ON public.subscriptions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
  );

-- PAYMENTS (platform-level)
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  transaction_id TEXT,
  gateway TEXT NOT NULL DEFAULT 'stripe',
  amount NUMERIC(10,2) NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status public.payment_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage payments" ON public.payments
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Tenant owners can read own payments" ON public.payments
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
  );

-- SYSTEM LOGS
CREATE TABLE public.system_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action_type TEXT NOT NULL,
  admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE SET NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.system_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage system logs" ON public.system_logs
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));

-- BRANDING (white label)
CREATE TABLE public.branding (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL UNIQUE,
  logo_url TEXT,
  brand_name TEXT,
  primary_color TEXT DEFAULT '#00bcd4',
  custom_domain TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.branding ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage branding" ON public.branding
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Tenant owners can manage own branding" ON public.branding
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
  );

-- =============================================
-- TENANT-SCOPED TABLES (isolated by tenant_id + RLS)
-- =============================================

-- MEMBERS
CREATE TABLE public.members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  username TEXT NOT NULL,
  sponsor_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
  parent_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
  position TEXT,
  rank_id UUID,
  status public.member_status NOT NULL DEFAULT 'active',
  join_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage members" ON public.members
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read own record" ON public.members
  FOR SELECT USING (auth.uid() = user_id);

CREATE INDEX idx_members_tenant ON public.members(tenant_id);
CREATE INDEX idx_members_sponsor ON public.members(sponsor_id);
CREATE INDEX idx_members_parent ON public.members(parent_id);

-- WALLETS
CREATE TABLE public.wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL UNIQUE,
  income_wallet NUMERIC(12,2) NOT NULL DEFAULT 0,
  roi_wallet NUMERIC(12,2) NOT NULL DEFAULT 0,
  repurchase_wallet NUMERIC(12,2) NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage wallets" ON public.wallets
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read own wallet" ON public.wallets
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.members m WHERE m.id = member_id AND m.user_id = auth.uid())
  );

CREATE INDEX idx_wallets_tenant ON public.wallets(tenant_id);

-- COMMISSIONS
CREATE TABLE public.commissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL,
  commission_type public.commission_type NOT NULL,
  amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  source_member_id UUID REFERENCES public.members(id) ON DELETE SET NULL,
  level INTEGER,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.commissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage commissions" ON public.commissions
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read own commissions" ON public.commissions
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.members m WHERE m.id = member_id AND m.user_id = auth.uid())
  );

CREATE INDEX idx_commissions_tenant ON public.commissions(tenant_id);
CREATE INDEX idx_commissions_member ON public.commissions(member_id);

-- PAYOUTS
CREATE TABLE public.payouts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  member_id UUID REFERENCES public.members(id) ON DELETE CASCADE NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  request_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  status public.payout_status NOT NULL DEFAULT 'pending',
  transaction_reference TEXT,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage payouts" ON public.payouts
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read own payouts" ON public.payouts
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.members m WHERE m.id = member_id AND m.user_id = auth.uid())
  );

CREATE INDEX idx_payouts_tenant ON public.payouts(tenant_id);

-- PACKAGES
CREATE TABLE public.packages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  bv NUMERIC(10,2) NOT NULL DEFAULT 0,
  pv NUMERIC(10,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.packages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage packages" ON public.packages
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read packages" ON public.packages
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.members m WHERE m.tenant_id = packages.tenant_id AND m.user_id = auth.uid())
  );

-- RANKS
CREATE TABLE public.ranks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  required_pv NUMERIC(10,2) NOT NULL DEFAULT 0,
  required_team_volume NUMERIC(10,2) NOT NULL DEFAULT 0,
  bonus_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ranks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage ranks" ON public.ranks
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );
CREATE POLICY "Members can read ranks" ON public.ranks
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.members m WHERE m.tenant_id = ranks.tenant_id AND m.user_id = auth.uid())
  );

-- Add FK from members.rank_id to ranks
ALTER TABLE public.members ADD CONSTRAINT fk_members_rank FOREIGN KEY (rank_id) REFERENCES public.ranks(id) ON DELETE SET NULL;

-- POOLS
CREATE TABLE public.pools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  qualification_rule TEXT,
  distribution_type TEXT NOT NULL DEFAULT 'equal',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.pools ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can manage pools" ON public.pools
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );

-- AUDIT LOGS (tenant-scoped)
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  module TEXT,
  details JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tenant admins can read audit logs" ON public.audit_logs
  FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants t WHERE t.id = tenant_id AND t.owner_user_id = auth.uid())
    OR public.has_role(auth.uid(), 'super_admin')
  );

CREATE INDEX idx_audit_logs_tenant ON public.audit_logs(tenant_id);
CREATE INDEX idx_audit_logs_created ON public.audit_logs(created_at DESC);

-- =============================================
-- PLAN CONFIGURATION TABLE
-- =============================================
CREATE TABLE public.plan_configurations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_type public.plan_type NOT NULL,
  config_key TEXT NOT NULL,
  config_value JSONB NOT NULL DEFAULT '{}',
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(plan_type, config_key)
);
ALTER TABLE public.plan_configurations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Super admins can manage plan configs" ON public.plan_configurations
  FOR ALL USING (public.has_role(auth.uid(), 'super_admin'));
CREATE POLICY "Authenticated can read plan configs" ON public.plan_configurations
  FOR SELECT USING (auth.role() = 'authenticated');

-- =============================================
-- UPDATED_AT TRIGGER FUNCTION
-- =============================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_branding_updated_at BEFORE UPDATE ON public.branding FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_plan_configs_updated_at BEFORE UPDATE ON public.plan_configurations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
