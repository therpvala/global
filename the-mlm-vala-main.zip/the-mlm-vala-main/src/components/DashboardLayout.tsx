import { useState } from "react";
import { Link, useLocation, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Users, GitBranch, DollarSign, Wallet,
  CreditCard, Award, Package, Layers, BarChart3,
  Plug, Settings, Palette, HeadphonesIcon, FileText,
  ChevronLeft, ChevronRight, LogOut, Menu, X
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import TopNavbar from "@/components/TopNavbar";
import DemoRoleSwitcher from "@/components/DemoRoleSwitcher";

const modules = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/dashboard" },
  { name: "Members", icon: Users, path: "/dashboard/members" },
  { name: "Network Tree", icon: GitBranch, path: "/dashboard/network-tree" },
  { name: "Commissions", icon: DollarSign, path: "/dashboard/commissions" },
  { name: "Payout", icon: CreditCard, path: "/dashboard/payout" },
  { name: "Wallet", icon: Wallet, path: "/dashboard/wallet" },
  { name: "Rank & Rewards", icon: Award, path: "/dashboard/rank-rewards" },
  { name: "Packages / Products", icon: Package, path: "/dashboard/packages" },
  { name: "Pools / Boards", icon: Layers, path: "/dashboard/pools" },
  { name: "Reports", icon: BarChart3, path: "/dashboard/reports" },
  { name: "Integrations", icon: Plug, path: "/dashboard/integrations" },
  { name: "Settings", icon: Settings, path: "/dashboard/settings" },
  { name: "White Label", icon: Palette, path: "/dashboard/white-label" },
  { name: "Support", icon: HeadphonesIcon, path: "/dashboard/support" },
  { name: "Audit Logs", icon: FileText, path: "/dashboard/audit-logs" },
  { name: "Analytics", icon: BarChart3, path: "/dashboard/analytics" },
];

const DashboardLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { signOut } = useAuth();

  const handleLogout = async () => {
    sessionStorage.removeItem("demo_plan");
    await signOut();
    navigate("/");
  };

  const isActive = (path: string) => {
    if (path === "/dashboard") return location.pathname === "/dashboard";
    return location.pathname.startsWith(path);
  };

  const SidebarContent = () => (
    <>
      {/* Logo */}
      <div className="flex items-center justify-between h-14 px-3 border-b border-border">
        {!collapsed && (
          <Link to="/" className="text-lg font-bold">
            <span className="text-primary text-glow-blue">MLM</span>
            <span className="text-accent text-glow-green ml-1">Vala</span>
          </Link>
        )}
        <button
          onClick={() => { setCollapsed(!collapsed); setMobileOpen(false); }}
          className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground hidden lg:block"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
        <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground lg:hidden">
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
        {modules.map((mod) => (
          <Link
            key={mod.path}
            to={mod.path}
            onClick={() => setMobileOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
              isActive(mod.path)
                ? "bg-primary/10 text-primary glow-blue"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground"
            )}
            title={collapsed ? mod.name : undefined}
          >
            <mod.icon className="h-4 w-4 shrink-0" />
            {!collapsed && <span className="truncate">{mod.name}</span>}
          </Link>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-border p-2">
        <button
          onClick={handleLogout}
          className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          title={collapsed ? "Logout" : undefined}
        >
          <LogOut className="h-4 w-4 shrink-0" />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </>
  );

  return (
    <div className="flex min-h-screen bg-background">
      {/* Mobile Overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Mobile Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 h-screen z-50 flex flex-col border-r border-border bg-card w-60 transition-transform duration-300 lg:hidden",
        mobileOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <SidebarContent />
      </aside>

      {/* Desktop Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 h-screen z-40 flex-col border-r border-border bg-card transition-all duration-300 hidden lg:flex",
        collapsed ? "w-16" : "w-60"
      )}>
        <SidebarContent />
      </aside>

      {/* Main Content */}
      <div className={cn("flex-1 flex flex-col transition-all duration-300", collapsed ? "lg:ml-16" : "lg:ml-60")}>
        {/* Mobile Header */}
        <div className="flex items-center h-14 px-3 border-b border-border bg-card lg:hidden">
          <button onClick={() => setMobileOpen(true)} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground mr-3">
            <Menu className="h-5 w-5" />
          </button>
          <Link to="/" className="text-lg font-bold">
            <span className="text-primary text-glow-blue">MLM</span>
            <span className="text-accent text-glow-green ml-1">Vala</span>
          </Link>
        </div>

        <DemoRoleSwitcher />
        <TopNavbar />
        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
