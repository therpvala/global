import { cn } from "@/lib/utils";

type StatusType = "active" | "inactive" | "pending" | "suspended" | "expired" | "blocked" | "success" | "failed" | "approved" | "rejected" | "processed";

const statusStyles: Record<StatusType, string> = {
  active: "bg-accent/10 text-accent",
  success: "bg-accent/10 text-accent",
  approved: "bg-accent/10 text-accent",
  processed: "bg-primary/10 text-primary",
  pending: "bg-yellow-500/10 text-yellow-400",
  inactive: "bg-muted text-muted-foreground",
  suspended: "bg-destructive/10 text-destructive",
  expired: "bg-destructive/10 text-destructive",
  blocked: "bg-destructive/10 text-destructive",
  failed: "bg-destructive/10 text-destructive",
  rejected: "bg-destructive/10 text-destructive",
};

interface StatusBadgeProps {
  status: string;
  className?: string;
}

const StatusBadge = ({ status, className }: StatusBadgeProps) => {
  const key = status.toLowerCase() as StatusType;
  const style = statusStyles[key] || "bg-muted text-muted-foreground";
  return (
    <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium capitalize", style, className)}>
      {status}
    </span>
  );
};

export default StatusBadge;
