import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Shield, Users, DollarSign, UserCog, X, AlertTriangle } from "lucide-react";

type DemoRole = "admin" | "sub_admin" | "member" | "finance";

interface DemoPlan {
  name: string;
  category: string;
  structure: string;
  isDemo: boolean;
  startedAt: number;
}

const roles: { id: DemoRole; label: string; icon: React.ElementType; color: string }[] = [
  { id: "admin", label: "Admin View", icon: Shield, color: "text-primary" },
  { id: "sub_admin", label: "Sub Admin", icon: UserCog, color: "text-violet-400" },
  { id: "member", label: "Member View", icon: Users, color: "text-emerald-400" },
  { id: "finance", label: "Finance Manager", icon: DollarSign, color: "text-amber-400" },
];

const DemoRoleSwitcher = () => {
  const [demoPlan, setDemoPlan] = useState<DemoPlan | null>(null);
  const [activeRole, setActiveRole] = useState<DemoRole>("admin");
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const raw = sessionStorage.getItem("demo_plan");
    if (raw) {
      try { setDemoPlan(JSON.parse(raw)); } catch { /* ignore */ }
    }
  }, []);

  if (!demoPlan || dismissed) return null;

  return (
    <div className="border-b border-border bg-card/80 backdrop-blur-sm">
      {/* Demo watermark banner */}
      <div className="flex items-center justify-between px-4 py-1.5 bg-amber-500/10 border-b border-amber-500/20">
        <div className="flex items-center gap-2 text-[11px] text-amber-400">
          <AlertTriangle className="h-3 w-3" />
          <span className="font-semibold">DEMO MODE</span>
          <span className="text-muted-foreground">— {demoPlan.name} ({demoPlan.category} · {demoPlan.structure})</span>
          <span className="text-muted-foreground">• No payouts • Auto-expires • Isolated data</span>
        </div>
        <button onClick={() => { setDismissed(true); sessionStorage.removeItem("demo_plan"); }} className="text-muted-foreground hover:text-foreground">
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Role switcher */}
      <div className="flex items-center gap-1 px-4 py-2">
        <span className="text-[10px] text-muted-foreground mr-2 uppercase tracking-wider font-semibold">Role Preview:</span>
        {roles.map((role) => (
          <button
            key={role.id}
            onClick={() => setActiveRole(role.id)}
            className={cn(
              "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[11px] font-medium transition-all",
              activeRole === role.id
                ? "bg-primary/15 text-primary border border-primary/30"
                : "text-muted-foreground hover:bg-secondary/80 hover:text-foreground border border-transparent"
            )}
          >
            <role.icon className={cn("h-3 w-3", activeRole === role.id ? role.color : "")} />
            {role.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default DemoRoleSwitcher;
