import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";
import { TrendingUp, TrendingDown } from "lucide-react";

interface KPICardProps {
  title: string;
  value: string;
  change?: string;
  trend?: "up" | "down" | "neutral";
  icon: LucideIcon;
  className?: string;
}

const KPICard = ({ title, value, change, trend = "neutral", icon: Icon, className }: KPICardProps) => (
  <div className={cn(
    "rounded-lg border border-border bg-card p-4 transition-all duration-200 hover:border-primary/30 hover:shadow-[0_0_20px_hsl(var(--primary)/0.1)]",
    className
  )}>
    <div className="flex items-start justify-between">
      <div className="space-y-1">
        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
        <p className="text-2xl font-bold text-foreground">{value}</p>
        {change && (
          <div className="flex items-center gap-1 text-xs">
            {trend === "up" && <TrendingUp className="h-3 w-3 text-accent" />}
            {trend === "down" && <TrendingDown className="h-3 w-3 text-destructive" />}
            <span className={cn(
              trend === "up" && "text-accent",
              trend === "down" && "text-destructive",
              trend === "neutral" && "text-muted-foreground"
            )}>
              {change}
            </span>
          </div>
        )}
      </div>
      <div className="rounded-lg bg-primary/10 p-2.5">
        <Icon className="h-5 w-5 text-primary" />
      </div>
    </div>
  </div>
);

export default KPICard;
