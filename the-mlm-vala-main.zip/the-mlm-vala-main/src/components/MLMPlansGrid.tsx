import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  GitBranch, Layers, Grid3X3, TrendingUp, Users, Minus,
  RotateCcw, ArrowUpRight, PartyPopper, Route, Combine,
  Award, Swords, RefreshCw, Lock, PieChart, Share2,
  Unlock, FileCode, Coins, Gem, ShoppingCart, Building2,
  Shield, Home,
} from "lucide-react";

type PlanCategory = "Core" | "Hybrid" | "Financial" | "Digital" | "Crypto" | "Industry";

interface PlanFeatures {
  commissionType: string;
  depthWidth: string;
  roi: boolean;
  pool: boolean;
  rankSystem: boolean;
}

interface Plan {
  name: string;
  icon: React.ElementType;
  category: PlanCategory;
  description: string;
  structure: string;
  features: PlanFeatures;
}

const plans: Plan[] = [
  { name: "Binary Plan", icon: GitBranch, category: "Core", description: "Two-leg structure with volume balancing and pair commissions.", structure: "Binary Tree", features: { commissionType: "Pair Match", depthWidth: "2 Legs × Unlimited", roi: false, pool: true, rankSystem: true } },
  { name: "Unilevel Plan", icon: Layers, category: "Core", description: "Unlimited width with level-based commissions up to N depth.", structure: "Unilevel Tree", features: { commissionType: "Level Override", depthWidth: "Unlimited × 10 Levels", roi: false, pool: false, rankSystem: true } },
  { name: "Matrix Plan", icon: Grid3X3, category: "Core", description: "Fixed width × depth grid with forced spillover placement.", structure: "Forced Matrix", features: { commissionType: "Matrix Fill", depthWidth: "3×9 / 4×7 / Custom", roi: false, pool: true, rankSystem: true } },
  { name: "Stairstep Breakaway", icon: TrendingUp, category: "Core", description: "Volume-based advancement with breakaway group overrides.", structure: "Stairstep", features: { commissionType: "Override Bonus", depthWidth: "Group Volume", roi: false, pool: false, rankSystem: true } },
  { name: "Generation Plan", icon: Users, category: "Core", description: "Generational depth commissions triggered by rank qualification.", structure: "Generation Tree", features: { commissionType: "Generation Bonus", depthWidth: "5–7 Generations", roi: false, pool: false, rankSystem: true } },
  { name: "Monoline Plan", icon: Minus, category: "Core", description: "Single line placement — everyone benefits from every new join.", structure: "Single Queue", features: { commissionType: "Queue Bonus", depthWidth: "1 Line × All", roi: false, pool: true, rankSystem: false } },
  { name: "Board / Cycler Plan", icon: RotateCcw, category: "Core", description: "Board-based cycling with re-entry and escalation logic.", structure: "Board Cycle", features: { commissionType: "Cycle Bonus", depthWidth: "2×2 / 3×3 Board", roi: false, pool: true, rankSystem: false } },
  { name: "Australian (2-Up) Plan", icon: ArrowUpRight, category: "Core", description: "Pass-up model where first two sales go to the upline sponsor.", structure: "Pass-Up", features: { commissionType: "Pass-Up Earn", depthWidth: "2-Up × Unlimited", roi: false, pool: false, rankSystem: false } },
  { name: "Single Leg Plan", icon: Route, category: "Core", description: "All members placed in a single vertical leg structure.", structure: "Single Leg", features: { commissionType: "Team Volume", depthWidth: "1 Leg × Unlimited", roi: true, pool: false, rankSystem: true } },
  { name: "Party Plan", icon: PartyPopper, category: "Core", description: "Event-driven sales model with host rewards and bonuses.", structure: "Event Based", features: { commissionType: "Host Bonus", depthWidth: "Event Groups", roi: false, pool: false, rankSystem: true } },
  { name: "Hybrid Plan", icon: Combine, category: "Hybrid", description: "Combine multiple plan logics into one custom structure.", structure: "Multi-Structure", features: { commissionType: "Multi Commission", depthWidth: "Custom Config", roi: true, pool: true, rankSystem: true } },
  { name: "Multi-Tier Affiliate", icon: Award, category: "Hybrid", description: "Affiliate-style referral tiers with multi-level tracking.", structure: "Affiliate Tiers", features: { commissionType: "Tier Commission", depthWidth: "3–5 Tiers", roi: false, pool: false, rankSystem: true } },
  { name: "Dual Team / Tri-Binary", icon: Swords, category: "Hybrid", description: "Extended binary with dual or triple team matching logic.", structure: "Dual/Tri Team", features: { commissionType: "Team Match", depthWidth: "2–3 Teams", roi: false, pool: true, rankSystem: true } },
  { name: "Compression-Based", icon: RefreshCw, category: "Hybrid", description: "Skips inactive members and compresses levels for active earners.", structure: "Dynamic Compression", features: { commissionType: "Compressed Level", depthWidth: "Dynamic Depth", roi: false, pool: false, rankSystem: true } },
  { name: "ROI Plan", icon: Lock, category: "Financial", description: "Fixed or variable daily returns on investment packages.", structure: "ROI Model", features: { commissionType: "Daily ROI", depthWidth: "Package Based", roi: true, pool: false, rankSystem: true } },
  { name: "Revenue Sharing Plan", icon: PieChart, category: "Financial", description: "Company revenue distributed among qualified members.", structure: "Revenue Pool", features: { commissionType: "Revenue Split", depthWidth: "Global Pool", roi: false, pool: true, rankSystem: true } },
  { name: "Profit Sharing Plan", icon: Share2, category: "Financial", description: "Net profit distribution based on member contribution and rank.", structure: "Profit Pool", features: { commissionType: "Profit Share", depthWidth: "Quarterly Pool", roi: false, pool: true, rankSystem: true } },
  { name: "Subscription Residual", icon: RefreshCw, category: "Digital", description: "Recurring commissions from ongoing subscription renewals.", structure: "Residual", features: { commissionType: "Recurring Earn", depthWidth: "5 Levels Deep", roi: false, pool: false, rankSystem: true } },
  { name: "SaaS Affiliate Model", icon: Unlock, category: "Digital", description: "SaaS product referral with tiered affiliate commissions.", structure: "SaaS Affiliate", features: { commissionType: "MRR Share", depthWidth: "3 Tiers", roi: false, pool: false, rankSystem: false } },
  { name: "Smart Contract MLM", icon: FileCode, category: "Crypto", description: "Blockchain-powered MLM with automated smart contract payouts.", structure: "Smart Contract", features: { commissionType: "On-Chain Payout", depthWidth: "Contract Logic", roi: false, pool: true, rankSystem: false } },
  { name: "Staking Referral Plan", icon: Coins, category: "Crypto", description: "Referral rewards from staking pools with tiered yield bonuses.", structure: "Staking Pool", features: { commissionType: "Stake Yield", depthWidth: "Pool Tiers", roi: true, pool: true, rankSystem: false } },
  { name: "Token Reward / Reflection", icon: Gem, category: "Crypto", description: "Token-based rewards with reflection mechanics and burn logic.", structure: "Tokenomics", features: { commissionType: "Token Reflect", depthWidth: "Holder Based", roi: true, pool: false, rankSystem: false } },
  { name: "E-Commerce MLM", icon: ShoppingCart, category: "Industry", description: "Product-based MLM with shopping cart and order commissions.", structure: "E-Commerce", features: { commissionType: "Order Comm", depthWidth: "5–10 Levels", roi: false, pool: false, rankSystem: true } },
  { name: "Franchise MLM Plan", icon: Building2, category: "Industry", description: "Franchise model with territory-based network and overrides.", structure: "Franchise", features: { commissionType: "Territory Earn", depthWidth: "Region Based", roi: false, pool: false, rankSystem: true } },
  { name: "Insurance / Finance MLM", icon: Shield, category: "Industry", description: "Policy-based MLM for insurance and financial product distribution.", structure: "Policy Based", features: { commissionType: "Renewal Comm", depthWidth: "Agent Tree", roi: false, pool: false, rankSystem: true } },
  { name: "Real Estate MLM", icon: Home, category: "Industry", description: "Property referral MLM with deal-based commission structure.", structure: "Deal Based", features: { commissionType: "Deal Closing", depthWidth: "Agent Network", roi: false, pool: false, rankSystem: true } },
];

const categoryColors: Record<PlanCategory, string> = {
  Core: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  Hybrid: "bg-violet-500/20 text-violet-400 border-violet-500/30",
  Financial: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  Digital: "bg-sky-500/20 text-sky-400 border-sky-500/30",
  Crypto: "bg-orange-500/20 text-orange-400 border-orange-500/30",
  Industry: "bg-rose-500/20 text-rose-400 border-rose-500/30",
};

const PlanCard = ({ plan, index }: { plan: Plan; index: number }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const handleDemo = async () => {
    setLoading(true);
    toast.info(`Launching ${plan.name} demo...`);
    try {
      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-demo-tenant`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
          },
          body: JSON.stringify({
            planName: plan.name,
            planCategory: plan.category,
            planStructure: plan.structure,
          }),
        }
      );
      const result = await res.json();
      if (result.status === "success") {
        // Auto sign-in with demo credentials
        const { createClient } = await import("@supabase/supabase-js");
        const tempClient = createClient(
          import.meta.env.VITE_SUPABASE_URL,
          import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY
        );
        await tempClient.auth.signInWithPassword({
          email: result.data.email,
          password: result.data.password,
        });
        // Store demo context
        sessionStorage.setItem("demo_plan", JSON.stringify({
          name: plan.name,
          category: plan.category,
          structure: plan.structure,
          isDemo: true,
          startedAt: Date.now(),
          tenantId: result.data.tenantId,
          expiresAt: result.data.expiresAt,
        }));
        // Reload to pick up new session
        window.location.href = "/dashboard";
      } else {
        throw new Error(result.message || "Failed to create demo");
      }
    } catch (err: any) {
      toast.error(err.message || "Demo launch failed");
      setLoading(false);
    }
  };

  const Icon = plan.icon;
  const { features } = plan;

  return (
    <div
      ref={ref}
      className={`group relative flex flex-col rounded-xl border border-border/40 bg-card overflow-hidden transition-all duration-500 hover:-translate-y-1 hover:border-primary/50 hover:shadow-[0_0_30px_-5px_hsl(var(--primary)/0.3)] ${visible ? "animate-fade-in" : "opacity-0"}`}
      style={{ animationDelay: `${index * 40}ms` }}
    >
      {/* Header row */}
      <div className="flex items-start justify-between p-5 pb-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 text-primary transition-colors group-hover:bg-primary/20">
          <Icon size={24} />
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-2.5 py-1 text-[9px] font-bold uppercase tracking-wider text-emerald-400 border border-emerald-500/30">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live Demo
          </span>
          <span className="text-[10px] text-muted-foreground">#{index + 1}</span>
        </div>
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col px-5 pb-5">
        <h3 className="text-sm font-bold text-foreground mb-1">{plan.name}</h3>
        <span className={`inline-block w-fit rounded-full border px-2 py-0.5 text-[9px] font-semibold mb-2 ${categoryColors[plan.category]}`}>
          {plan.category} · {plan.structure}
        </span>
        <p className="text-[11px] text-muted-foreground mb-3 line-clamp-2 leading-relaxed">{plan.description}</p>

        {/* Feature grid */}
        <div className="grid grid-cols-2 gap-x-3 gap-y-1.5 mb-3 text-[10px]">
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Commission:</span>
          </div>
          <span className="text-foreground font-medium truncate">{features.commissionType}</span>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Depth/Width:</span>
          </div>
          <span className="text-foreground font-medium truncate">{features.depthWidth}</span>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">ROI:</span>
          </div>
          <span className={features.roi ? "text-emerald-400 font-medium" : "text-muted-foreground"}>
            {features.roi ? "✓ Yes" : "✗ No"}
          </span>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Pool:</span>
          </div>
          <span className={features.pool ? "text-emerald-400 font-medium" : "text-muted-foreground"}>
            {features.pool ? "✓ Yes" : "✗ No"}
          </span>
          <div className="flex items-center gap-1">
            <span className="text-muted-foreground">Rank System:</span>
          </div>
          <span className={features.rankSystem ? "text-emerald-400 font-medium" : "text-muted-foreground"}>
            {features.rankSystem ? "✓ Yes" : "✗ No"}
          </span>
        </div>

        {/* Pricing */}
        <div className="flex flex-wrap items-center gap-1.5 mb-4">
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-semibold text-primary">$5/Monthly</span>
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-semibold text-accent">$9/White Label</span>
          <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-semibold text-foreground">$249/Lifetime</span>
        </div>

        {/* Buttons */}
        <div className="mt-auto flex items-center gap-2">
          <button
            onClick={handleDemo}
            disabled={loading}
            className="flex-1 rounded-lg bg-primary py-2.5 text-xs font-bold text-primary-foreground transition-all hover:shadow-[0_0_20px_-3px_hsl(var(--primary)/0.5)] disabled:opacity-50"
          >
            {loading ? "Loading..." : "▶ Live Demo"}
          </button>
          <button className="flex-1 rounded-lg border border-border/60 py-2.5 text-xs font-semibold text-muted-foreground transition-all hover:border-primary/50 hover:text-primary">
            Buy Now
          </button>
        </div>
      </div>
    </div>
  );
};

const MLMPlansGrid = () => {
  const [filter, setFilter] = useState<PlanCategory | "All">("All");
  const categories: (PlanCategory | "All")[] = ["All", "Core", "Hybrid", "Financial", "Digital", "Crypto", "Industry"];
  const filtered = filter === "All" ? plans : plans.filter(p => p.category === filter);

  return (
    <section className="relative py-24">
      <div className="container">
        <h2 className="mb-4 text-center text-3xl font-black text-foreground md:text-4xl">
          <span className="text-primary text-glow-blue">{plans.length}</span> Universal MLM Plans
        </h2>
        <p className="mx-auto mb-8 max-w-xl text-center text-muted-foreground">
          Every plan includes a fully working live demo. One click — instant access. No login required.
        </p>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-all border ${
                filter === cat
                  ? "bg-primary/20 text-primary border-primary/50"
                  : "bg-secondary/50 text-muted-foreground border-border/40 hover:border-primary/30 hover:text-foreground"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {filtered.map((plan, i) => (
            <PlanCard key={plan.name} plan={plan} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default MLMPlansGrid;
