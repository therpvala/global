import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const { user, signOut, hasRole } = useAuth();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/70 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="text-2xl font-black tracking-tight">
          <span className="text-primary text-glow-blue">MLM</span>{" "}
          <span className="text-accent text-glow-green">Vala</span>
        </Link>

        {/* Desktop */}
        <div className="hidden items-center gap-6 md:flex">
          {user ? (
            <>
              <Link to="/dashboard" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">Dashboard</Link>
              {hasRole("super_admin") && (
                <Link to="/super-admin" className="rounded-md border border-primary/40 px-4 py-2 text-sm font-medium text-primary transition-all hover:bg-primary/10 hover:glow-blue">Super Admin</Link>
              )}
              <button onClick={() => signOut()} className="text-sm font-medium text-muted-foreground transition-colors hover:text-destructive">Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">Login</Link>
              <Link to="/register" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">Register</Link>
            </>
          )}
        </div>

        {/* Mobile toggle */}
        <button onClick={() => setOpen(!open)} className="text-foreground md:hidden">
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="border-t border-border/50 bg-background/95 backdrop-blur-xl md:hidden">
          <div className="container flex flex-col gap-4 py-4">
            {user ? (
              <>
                <Link to="/dashboard" onClick={() => setOpen(false)} className="text-sm font-medium text-muted-foreground">Dashboard</Link>
                {hasRole("super_admin") && (
                  <Link to="/super-admin" onClick={() => setOpen(false)} className="text-sm font-medium text-primary">Super Admin</Link>
                )}
                <button onClick={() => { signOut(); setOpen(false); }} className="text-left text-sm font-medium text-muted-foreground">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setOpen(false)} className="text-sm font-medium text-muted-foreground">Login</Link>
                <Link to="/register" onClick={() => setOpen(false)} className="text-sm font-medium text-muted-foreground">Register</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
