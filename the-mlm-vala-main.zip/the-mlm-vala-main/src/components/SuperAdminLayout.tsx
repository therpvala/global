import { useState } from "react";
import { Link, useLocation, Outlet } from "react-router-dom";
import {
  LayoutDashboard, Users, Key, Cpu, CreditCard,
  Plug, Globe, Settings, Clock, Shield,
  FileText, HeadphonesIcon, BarChart3, Database,
  ChevronLeft, ChevronRight, LogOut, DollarSign
} from "lucide-react";
import { cn } from "@/lib/utils";

const modules = [
  { name: "Dashboard", icon: LayoutDashboard, path: "/super-admin" },
  { name: "Tenants / Clients", icon: Users, path: "/super-admin/tenants" },
  { name: "License Management", icon: Key, path: "/super-admin/licenses" },
  { name: "Plan Engine Control", icon: Cpu, path: "/super-admin/plan-engine" },
  { name: "Billing & Subscriptions", icon: CreditCard, path: "/super-admin/billing" },
  { name: "Payment Gateways", icon: Plug, path: "/super-admin/payment-gateways" },
  { name: "Global Commission", icon: DollarSign, path: "/super-admin/commissions" },
  { name: "White Label Control", icon: Globe, path: "/super-admin/white-label" },
  { name: "System Configuration", icon: Settings, path: "/super-admin/system-config" },
  { name: "Cron & Scheduler", icon: Clock, path: "/super-admin/cron" },
  { name: "Security & Roles", icon: Shield, path: "/super-admin/security" },
  { name: "Audit & Logs", icon: FileText, path: "/super-admin/audit-logs" },
  { name: "Support Monitoring", icon: HeadphonesIcon, path: "/super-admin/support" },
  { name: "Revenue Analytics", icon: BarChart3, path: "/super-admin/revenue" },
  { name: "Backup & Maintenance", icon: Database, path: "/super-admin/backup" },
  { name: "Global Analytics", icon: BarChart3, path: "/super-admin/analytics" },
];

const SuperAdminLayout = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => {
    if (path === "/super-admin") return location.pathname === "/super-admin";
    return location.pathname.startsWith(path);
  };

  return (
    <div className="flex min-h-screen bg-background">
      <aside
        className={cn(
          "fixed top-0 left-0 h-screen z-40 flex flex-col border-r border-border bg-card transition-all duration-300",
          collapsed ? "w-16" : "w-60"
        )}
      >
        <div className="flex items-center justify-between h-14 px-3 border-b border-border">
          {!collapsed && (
            <Link to="/super-admin" className="text-lg font-bold">
              <span className="text-destructive">⚡</span>
              <span className="text-primary text-glow-blue ml-1">Super</span>
              <span className="text-accent text-glow-green ml-1">Admin</span>
            </Link>
          )}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
          {modules.map((mod) => (
            <Link
              key={mod.path}
              to={mod.path}
              className={cn(
                "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors",
                isActive(mod.path)
                  ? "bg-primary/10 text-primary glow-blue"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
              title={collapsed ? mod.name : undefined}
            >
              <mod.icon className="h-4 w-4 shrink-0" />
              {!collapsed && <span className="truncate">{mod.name}</span>}
            </Link>
          ))}
        </nav>

        <div className="border-t border-border p-2">
          <Link
            to="/"
            className="flex items-center gap-3 rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
            title={collapsed ? "Back to Home" : undefined}
          >
            <LogOut className="h-4 w-4 shrink-0" />
            {!collapsed && <span>Back to Home</span>}
          </Link>
        </div>
      </aside>

      <main className={cn("flex-1 transition-all duration-300", collapsed ? "ml-16" : "ml-60")}>
        <Outlet />
      </main>
    </div>
  );
};

export default SuperAdminLayout;
