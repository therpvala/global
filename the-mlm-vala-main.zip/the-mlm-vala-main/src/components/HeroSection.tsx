import { Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import NetworkCanvas from "./NetworkCanvas";

const counters = [
  { label: "Members", target: 14520, prefix: "" },
  { label: "Total Payout", target: 2340000, prefix: "$" },
  { label: "Active Networks", target: 870, prefix: "" },
];

const AnimatedCounter = ({ target, prefix, label }: { target: number; prefix: string; label: string }) => {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          const duration = 2000;
          const start = performance.now();
          const animate = (now: number) => {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setValue(Math.floor(eased * target));
            if (progress < 1) requestAnimationFrame(animate);
          };
          requestAnimationFrame(animate);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  const formatted = target >= 1000000
    ? `${prefix}${(value / 1000000).toFixed(value >= target ? 1 : 1)}M`
    : target >= 1000
    ? `${prefix}${(value / 1000).toFixed(value >= target ? 1 : 0)}K`
    : `${prefix}${value.toLocaleString()}`;

  return (
    <div ref={ref} className="text-center">
      <div className="text-3xl font-black text-primary text-glow-blue md:text-4xl">{formatted}</div>
      <div className="mt-1 text-xs font-medium uppercase tracking-widest text-muted-foreground">{label}</div>
    </div>
  );
};

const HeroSection = () => (
  <section className="relative flex min-h-screen items-center justify-center overflow-hidden pt-16">
    <NetworkCanvas />
    <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />

    <div className="relative z-10 container flex flex-col items-center gap-8 py-20 text-center">
      <h1 className="max-w-4xl text-4xl font-black leading-tight tracking-tight md:text-6xl lg:text-7xl">
        <span className="text-primary text-glow-blue">MLM Vala</span>
        <br />
        <span className="text-foreground">Multi Plan MLM SaaS Engine</span>
      </h1>

      <p className="max-w-2xl text-lg text-muted-foreground md:text-xl">
        The world's most advanced multi-plan MLM platform. Launch, manage, and scale your network marketing business with enterprise-grade technology.
      </p>

      <div className="flex flex-wrap items-center justify-center gap-4">
        <Link
          to="/login"
          className="rounded-lg border border-primary/50 px-8 py-3 text-sm font-semibold text-primary transition-all hover:bg-primary/10 hover:glow-blue"
        >
          Login
        </Link>
        <Link
          to="/register"
          className="rounded-lg bg-gradient-to-r from-primary to-accent px-8 py-3 text-sm font-semibold text-primary-foreground transition-all hover:opacity-90 hover:glow-green"
        >
          Register Now
        </Link>
      </div>

      <div className="mt-8 flex flex-wrap items-center justify-center gap-12 md:gap-16">
        {counters.map((c) => (
          <AnimatedCounter key={c.label} {...c} />
        ))}
      </div>
    </div>
  </section>
);

export default HeroSection;
