import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="border-t border-border/50 bg-card/50">
    <div className="container py-12">
      <div className="mb-8 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
      <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">About</h4>
          <p className="text-xs leading-relaxed text-muted-foreground">
            MLM Vala is a global SaaS platform powering multi-plan network marketing businesses worldwide.
          </p>
        </div>
        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">Pricing</h4>
          <ul className="space-y-2 text-xs text-muted-foreground">
            <li>$5/month – Standard</li>
            <li>$9/month – White Label</li>
            <li>$249 – Lifetime Access</li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">Contact</h4>
          <ul className="space-y-2 text-xs text-muted-foreground">
            <li>support@mlmvala.com</li>
            <li>+1 (800) 555-0199</li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-sm font-bold text-foreground">Legal</h4>
          <ul className="space-y-2 text-xs text-muted-foreground">
            <li><Link to="/" className="hover:text-primary">Terms of Service</Link></li>
            <li><Link to="/" className="hover:text-primary">Privacy Policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="mt-10 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()}{" "}
        <span className="font-bold text-primary">MLM</span>{" "}
        <span className="font-bold text-accent">Vala</span>. All rights reserved.
      </div>
    </div>
  </footer>
);

export default Footer;
