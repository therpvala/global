import { useEffect, useRef } from "react";

interface Node {
  x: number;
  y: number;
  z: number;
  radius: number;
  pulsePhase: number;
  children: number[];
}

const NetworkCanvas = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let width = 0;
    let height = 0;
    let nodes: Node[] = [];
    let particles: { x: number; y: number; vx: number; vy: number; life: number; maxLife: number }[] = [];

    const resize = () => {
      width = canvas.width = canvas.offsetWidth * window.devicePixelRatio;
      height = canvas.height = canvas.offsetHeight * window.devicePixelRatio;
      ctx.scale(1, 1);
      buildTree();
    };

    const buildTree = () => {
      nodes = [];
      const cx = width / 2;
      const startY = height * 0.15;
      const levelHeight = height * 0.12;
      const maxDepth = 5;

      const addNode = (x: number, y: number, depth: number, parentIdx: number) => {
        const idx = nodes.length;
        const z = Math.random() * 0.4 + 0.8;
        nodes.push({ x, y, z, radius: (4 - depth * 0.4) * z, pulsePhase: Math.random() * Math.PI * 2, children: [] });
        if (parentIdx >= 0) nodes[parentIdx].children.push(idx);

        if (depth < maxDepth) {
          const spread = (width * 0.35) / Math.pow(2, depth);
          addNode(x - spread, y + levelHeight, depth + 1, idx);
          addNode(x + spread, y + levelHeight, depth + 1, idx);
        }
      };

      addNode(cx, startY, 0, -1);

      // Background particles
      particles = [];
      for (let i = 0; i < 60; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.3,
          vy: (Math.random() - 0.5) * 0.3,
          life: Math.random() * 200,
          maxLife: 200 + Math.random() * 200,
        });
      }
    };

    const draw = (time: number) => {
      ctx.clearRect(0, 0, width, height);
      const t = time * 0.001;

      // Particles
      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.life++;
        if (p.life > p.maxLife || p.x < 0 || p.x > width || p.y < 0 || p.y > height) {
          p.x = Math.random() * width;
          p.y = Math.random() * height;
          p.life = 0;
        }
        const alpha = Math.sin((p.life / p.maxLife) * Math.PI) * 0.3;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(190, 100%, 50%, ${alpha})`;
        ctx.fill();
      }

      // Edges with flowing light
      for (const node of nodes) {
        for (const ci of node.children) {
          const child = nodes[ci];
          const grad = ctx.createLinearGradient(node.x, node.y, child.x, child.y);
          const flowPos = ((t * 0.5 + ci * 0.1) % 1);
          grad.addColorStop(0, "hsla(120, 100%, 56%, 0.05)");
          grad.addColorStop(Math.max(0, flowPos - 0.15), "hsla(120, 100%, 56%, 0.05)");
          grad.addColorStop(flowPos, "hsla(120, 100%, 56%, 0.6)");
          grad.addColorStop(Math.min(1, flowPos + 0.15), "hsla(120, 100%, 56%, 0.05)");
          grad.addColorStop(1, "hsla(120, 100%, 56%, 0.05)");

          ctx.beginPath();
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(child.x, child.y);
          ctx.strokeStyle = grad;
          ctx.lineWidth = 1.5 * node.z;
          ctx.stroke();
        }
      }

      // Nodes
      for (const node of nodes) {
        const pulse = Math.sin(t * 2 + node.pulsePhase) * 0.3 + 0.7;
        const r = node.radius * (1 + pulse * 0.3);

        // Glow
        const glow = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, r * 4);
        glow.addColorStop(0, `hsla(190, 100%, 50%, ${0.25 * pulse})`);
        glow.addColorStop(1, "hsla(190, 100%, 50%, 0)");
        ctx.beginPath();
        ctx.arc(node.x, node.y, r * 4, 0, Math.PI * 2);
        ctx.fillStyle = glow;
        ctx.fill();

        // Core
        ctx.beginPath();
        ctx.arc(node.x, node.y, r, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(190, 100%, 60%, ${0.7 + pulse * 0.3})`;
        ctx.fill();
      }

      animId = requestAnimationFrame(draw);
    };

    resize();
    animId = requestAnimationFrame(draw);
    window.addEventListener("resize", resize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />;
};

export default NetworkCanvas;
