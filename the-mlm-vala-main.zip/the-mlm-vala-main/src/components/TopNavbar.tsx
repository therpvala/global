import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { Search, Bell, ChevronRight, LogOut, User, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const routeLabels: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/dashboard/members": "Members",
  "/dashboard/network-tree": "Network Tree",
  "/dashboard/commissions": "Commissions",
  "/dashboard/payout": "Payout",
  "/dashboard/wallet": "Wallet",
  "/dashboard/rank-rewards": "Rank & Rewards",
  "/dashboard/packages": "Packages / Products",
  "/dashboard/pools": "Pools / Boards",
  "/dashboard/reports": "Reports",
  "/dashboard/integrations": "Integrations",
  "/dashboard/settings": "Settings",
  "/dashboard/white-label": "White Label",
  "/dashboard/support": "Support",
  "/dashboard/audit-logs": "Audit Logs",
};

interface TopNavbarProps {
  planName?: string;
}

const TopNavbar = ({ planName = "Binary Plan" }: TopNavbarProps) => {
  const location = useLocation();
  const [searchOpen, setSearchOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const currentLabel = routeLabels[location.pathname] || "Dashboard";
  const breadcrumbs = location.pathname === "/dashboard"
    ? [{ label: "Dashboard", path: "/dashboard" }]
    : [
        { label: "Dashboard", path: "/dashboard" },
        { label: currentLabel, path: location.pathname },
      ];

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-border bg-card/80 backdrop-blur-md px-4 lg:px-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-1.5 text-sm">
        {breadcrumbs.map((crumb, i) => (
          <span key={crumb.path} className="flex items-center gap-1.5">
            {i > 0 && <ChevronRight className="h-3 w-3 text-muted-foreground" />}
            <Link
              to={crumb.path}
              className={cn(
                "transition-colors",
                i === breadcrumbs.length - 1
                  ? "text-foreground font-medium"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {crumb.label}
            </Link>
          </span>
        ))}
        <span className="ml-3 rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-medium text-primary">
          {planName}
        </span>
      </div>

      {/* Right Section */}
      <div className="flex items-center gap-2">
        {/* Search */}
        <div className={cn("relative transition-all duration-200", searchOpen ? "w-56" : "w-8")}>
          {searchOpen ? (
            <input
              autoFocus
              type="text"
              placeholder="Search modules..."
              className="w-full rounded-md border border-border bg-secondary/50 px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              onBlur={() => setSearchOpen(false)}
            />
          ) : (
            <button onClick={() => setSearchOpen(true)} className="p-1.5 rounded-md hover:bg-secondary text-muted-foreground">
              <Search className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Notifications */}
        <button className="relative p-1.5 rounded-md hover:bg-secondary text-muted-foreground">
          <Bell className="h-4 w-4" />
          <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-accent" />
        </button>

        {/* Profile Dropdown */}
        <div className="relative">
          <button
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 rounded-md px-2 py-1.5 hover:bg-secondary transition-colors"
          >
            <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center">
              <User className="h-3.5 w-3.5 text-primary" />
            </div>
            <span className="text-sm text-foreground hidden sm:inline">Admin</span>
          </button>

          {profileOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} />
              <div className="absolute right-0 top-full mt-1 z-50 w-44 rounded-lg border border-border bg-card shadow-lg animate-fade-in-up">
                <Link to="/dashboard/settings" className="flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors rounded-t-lg" onClick={() => setProfileOpen(false)}>
                  <Settings className="h-3.5 w-3.5" /> Settings
                </Link>
                <Link to="/" className="flex items-center gap-2 px-3 py-2 text-sm text-destructive hover:bg-secondary transition-colors rounded-b-lg" onClick={() => setProfileOpen(false)}>
                  <LogOut className="h-3.5 w-3.5" /> Logout
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default TopNavbar;
