import { useState } from "react";
import { cn } from "@/lib/utils";
import { ChevronRight, ChevronDown } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface MicroCategory {
  name: string;
  action?: string;
}

export interface NanoCategory {
  name: string;
  micros: MicroCategory[];
}

export interface SubCategory {
  name: string;
  nanos: NanoCategory[];
}

export interface Category {
  name: string;
  icon: LucideIcon;
  subs: SubCategory[];
}

interface ModuleShellProps {
  title: string;
  description: string;
  categories: Category[];
}

const ModuleShell = ({ title, description, categories }: ModuleShellProps) => {
  const [activeCat, setActiveCat] = useState(0);
  const [activeSub, setActiveSub] = useState(0);
  const [expandedNanos, setExpandedNanos] = useState<Record<string, boolean>>({});

  const toggleNano = (key: string) => {
    setExpandedNanos((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const currentCat = categories[activeCat];
  const currentSub = currentCat?.subs[activeSub];

  return (
    <div className="flex min-h-screen">
      {/* Internal Sidebar */}
      <div className="w-56 shrink-0 border-r border-border bg-card/50 p-3">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
          Categories
        </h3>
        <div className="space-y-0.5">
          {categories.map((cat, ci) => (
            <button
              key={cat.name}
              onClick={() => { setActiveCat(ci); setActiveSub(0); }}
              className={cn(
                "flex items-center gap-2 w-full rounded-md px-2 py-1.5 text-sm transition-colors text-left",
                activeCat === ci
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-secondary hover:text-foreground"
              )}
            >
              <cat.icon className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{cat.name}</span>
            </button>
          ))}
        </div>

        {/* Sub Categories */}
        {currentCat && (
          <>
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mt-6 mb-2 px-2">
              Sub Categories
            </h3>
            <div className="space-y-0.5">
              {currentCat.subs.map((sub, si) => (
                <button
                  key={sub.name}
                  onClick={() => setActiveSub(si)}
                  className={cn(
                    "flex items-center gap-2 w-full rounded-md px-2 py-1.5 text-xs transition-colors text-left",
                    activeSub === si
                      ? "bg-accent/10 text-accent"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <ChevronRight className="h-3 w-3 shrink-0" />
                  <span className="truncate">{sub.name}</span>
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Content Area */}
      <div className="flex-1 p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">{title}</h1>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        </div>

        {currentSub && (
          <div className="space-y-3">
            <h2 className="text-lg font-semibold text-foreground">
              {currentCat.name} → {currentSub.name}
            </h2>

            {currentSub.nanos.map((nano, ni) => {
              const nanoKey = `${activeCat}-${activeSub}-${ni}`;
              const isOpen = expandedNanos[nanoKey] ?? true;
              return (
                <div key={nano.name} className="rounded-lg border border-border bg-card p-4">
                  <button
                    onClick={() => toggleNano(nanoKey)}
                    className="flex items-center gap-2 w-full text-left"
                  >
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4 text-primary" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    )}
                    <span className="text-sm font-medium text-foreground">{nano.name}</span>
                  </button>
                  {isOpen && (
                    <div className="mt-3 ml-6 space-y-2">
                      {nano.micros.map((micro) => (
                        <div
                          key={micro.name}
                          className="flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2"
                        >
                          <span className="text-sm text-foreground">{micro.name}</span>
                          {micro.action && (
                            <button className="text-xs px-3 py-1 rounded-md bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
                              {micro.action}
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default ModuleShell;
