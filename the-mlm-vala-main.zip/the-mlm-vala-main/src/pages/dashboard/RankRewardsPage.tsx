import ModuleShell, { Category } from "@/components/ModuleShell";
import { Award, Trophy } from "lucide-react";

const categories: Category[] = [
  {
    name: "Rank Settings",
    icon: Award,
    subs: [
      {
        name: "Create Rank",
        nanos: [
          { name: "Volume Requirement", micros: [{ name: "Save Rank", action: "Save" }] },
        ],
      },
      {
        name: "Qualification Rules",
        nanos: [
          { name: "Active Status Check", micros: [{ name: "Update Rule", action: "Update" }] },
        ],
      },
    ],
  },
  {
    name: "Achievers",
    icon: Trophy,
    subs: [
      {
        name: "Rank Achieved List",
        nanos: [
          { name: "Filter By Date", micros: [{ name: "View Details", action: "View" }] },
        ],
      },
    ],
  },
];

const RankRewardsPage = () => (
  <ModuleShell title="Rank & Rewards" description="Configure rank qualifications, rewards, and view achievers." categories={categories} />
);

export default RankRewardsPage;
