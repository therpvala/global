import ModuleShell, { Category } from "@/components/ModuleShell";
import { Palette, Globe } from "lucide-react";

const categories: Category[] = [
  {
    name: "Branding",
    icon: Palette,
    subs: [
      {
        name: "Upload Logo",
        nanos: [
          { name: "Logo File", micros: [{ name: "Save", action: "Save" }] },
        ],
      },
      {
        name: "Change Site Name",
        nanos: [
          { name: "Site Name", micros: [{ name: "Apply", action: "Apply" }] },
        ],
      },
    ],
  },
  {
    name: "Domain",
    icon: Globe,
    subs: [
      {
        name: "Custom Domain",
        nanos: [
          { name: "Verify DNS", micros: [{ name: "Activate", action: "Activate" }] },
        ],
      },
    ],
  },
];

const WhiteLabelPage = () => (
  <ModuleShell title="White Label" description="Customize branding, logo, site name, and connect custom domains." categories={categories} />
);

export default WhiteLabelPage;
