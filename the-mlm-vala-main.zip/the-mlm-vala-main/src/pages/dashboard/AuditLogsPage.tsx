import ModuleShell, { Category } from "@/components/ModuleShell";
import { FileText, Search } from "lucide-react";

const categories: Category[] = [
  {
    name: "Activity Logs",
    icon: FileText,
    subs: [
      {
        name: "Admin Logs",
        nanos: [
          { name: "Filter", micros: [{ name: "Export", action: "Export" }] },
        ],
      },
      {
        name: "Member Logs",
        nanos: [
          { name: "Search", micros: [{ name: "View Action", action: "View" }] },
        ],
      },
    ],
  },
];

const AuditLogsPage = () => (
  <ModuleShell title="Audit Logs" description="View admin and member activity logs with search and export capabilities." categories={categories} />
);

export default AuditLogsPage;
