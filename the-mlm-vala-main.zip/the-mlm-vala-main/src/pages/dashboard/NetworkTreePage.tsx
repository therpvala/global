import ModuleShell, { Category } from "@/components/ModuleShell";
import { GitBranch, Search } from "lucide-react";

const categories: Category[] = [
  {
    name: "Tree View",
    icon: GitBranch,
    subs: [
      {
        name: "Binary / Matrix / Unilevel View",
        nanos: [
          { name: "Expand Levels", micros: [{ name: "View Member Detail", action: "View" }] },
        ],
      },
      {
        name: "Search Member",
        nanos: [
          { name: "Jump to Position", micros: [{ name: "Highlight Path", action: "Highlight" }] },
        ],
      },
    ],
  },
];

const NetworkTreePage = () => (
  <ModuleShell title="Network Tree" description="Visualize network structure across Binary, Matrix, and Unilevel views." categories={categories} />
);

export default NetworkTreePage;
