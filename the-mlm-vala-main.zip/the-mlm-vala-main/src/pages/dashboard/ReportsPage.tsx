import ModuleShell, { Category } from "@/components/ModuleShell";
import { BarChart3, GitBranch } from "lucide-react";

const categories: Category[] = [
  {
    name: "Financial Reports",
    icon: BarChart3,
    subs: [
      {
        name: "Income Report",
        nanos: [
          { name: "Date Filter", micros: [{ name: "Export PDF", action: "Export" }] },
        ],
      },
      {
        name: "Payout Report",
        nanos: [
          { name: "Member Filter", micros: [{ name: "Download CSV", action: "Download" }] },
        ],
      },
    ],
  },
  {
    name: "Network Reports",
    icon: GitBranch,
    subs: [
      {
        name: "Growth Report",
        nanos: [
          { name: "Plan Filter", micros: [{ name: "Export", action: "Export" }] },
        ],
      },
    ],
  },
];

const ReportsPage = () => (
  <ModuleShell title="Reports" description="Generate and export financial and network growth reports." categories={categories} />
);

export default ReportsPage;
