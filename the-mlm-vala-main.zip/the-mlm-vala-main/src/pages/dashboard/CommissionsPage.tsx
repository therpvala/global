import ModuleShell, { Category } from "@/components/ModuleShell";
import { DollarSign, History } from "lucide-react";

const categories: Category[] = [
  {
    name: "Commission Engine",
    icon: DollarSign,
    subs: [
      {
        name: "Direct Bonus",
        nanos: [
          { name: "Calculation Logic", micros: [{ name: "View Log", action: "View" }] },
        ],
      },
      {
        name: "Binary / Structure Bonus",
        nanos: [
          { name: "Volume Calculation", micros: [{ name: "Adjust Entry", action: "Adjust" }] },
        ],
      },
      {
        name: "Matching Bonus",
        nanos: [
          { name: "Percentage Settings", micros: [{ name: "Save Rule", action: "Save" }] },
        ],
      },
    ],
  },
  {
    name: "History",
    icon: History,
    subs: [
      {
        name: "Daily Commission",
        nanos: [
          { name: "Member Filter", micros: [{ name: "Export CSV", action: "Export" }] },
        ],
      },
      {
        name: "Adjustment",
        nanos: [
          { name: "Manual Edit", micros: [{ name: "Confirm Update", action: "Confirm" }] },
        ],
      },
    ],
  },
];

const CommissionsPage = () => (
  <ModuleShell title="Commissions" description="Configure commission engine, bonuses, and view commission history." categories={categories} />
);

export default CommissionsPage;
