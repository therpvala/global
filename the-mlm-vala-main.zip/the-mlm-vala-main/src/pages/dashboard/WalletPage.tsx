import ModuleShell, { Category } from "@/components/ModuleShell";
import { Wallet, TrendingUp, RefreshCw } from "lucide-react";

const categories: Category[] = [
  {
    name: "Wallet Types",
    icon: Wallet,
    subs: [
      {
        name: "Income Wallet",
        nanos: [
          { name: "Transactions", micros: [{ name: "Export", action: "Export" }] },
        ],
      },
      {
        name: "ROI Wallet",
        nanos: [
          { name: "Daily Credit", micros: [{ name: "View Source", action: "View" }] },
        ],
      },
      {
        name: "Repurchase Wallet",
        nanos: [
          { name: "Balance Transfer", micros: [{ name: "Confirm Transfer", action: "Confirm" }] },
        ],
      },
    ],
  },
];

const WalletPage = () => (
  <ModuleShell title="Wallet" description="Manage income, ROI, and repurchase wallets with full transaction history." categories={categories} />
);

export default WalletPage;
