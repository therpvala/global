import ModuleShell, { Category } from "@/components/ModuleShell";
import { Settings, DollarSign } from "lucide-react";

const categories: Category[] = [
  {
    name: "System Settings",
    icon: Settings,
    subs: [
      {
        name: "General Settings",
        nanos: [
          { name: "Timezone", micros: [{ name: "Save", action: "Save" }] },
        ],
      },
      {
        name: "Commission Settings",
        nanos: [
          { name: "Global Cap", micros: [{ name: "Update", action: "Update" }] },
        ],
      },
    ],
  },
];

const SettingsPage = () => (
  <ModuleShell title="Settings" description="Configure system-wide settings, timezone, and commission caps." categories={categories} />
);

export default SettingsPage;
