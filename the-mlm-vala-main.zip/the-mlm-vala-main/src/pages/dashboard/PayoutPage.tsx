import ModuleShell, { Category } from "@/components/ModuleShell";
import { CreditCard, Clock } from "lucide-react";

const categories: Category[] = [
  {
    name: "Requests",
    icon: CreditCard,
    subs: [
      {
        name: "Pending Withdrawals",
        nanos: [
          { name: "Approve / Reject", micros: [{ name: "Transaction ID Entry", action: "Enter" }] },
        ],
      },
      {
        name: "Processed",
        nanos: [
          { name: "Status Filter", micros: [{ name: "View Receipt", action: "View" }] },
        ],
      },
    ],
  },
  {
    name: "Auto Payout",
    icon: Clock,
    subs: [
      {
        name: "Schedule",
        nanos: [
          { name: "Cron Settings", micros: [{ name: "Run Now", action: "Run" }] },
        ],
      },
    ],
  },
];

const PayoutPage = () => (
  <ModuleShell title="Payout" description="Manage withdrawal requests, process payouts, and configure auto-payout schedules." categories={categories} />
);

export default PayoutPage;
