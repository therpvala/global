import ModuleShell, { Category } from "@/components/ModuleShell";
import { Package, ShoppingCart } from "lucide-react";

const categories: Category[] = [
  {
    name: "Package Setup",
    icon: Package,
    subs: [
      {
        name: "Create Package",
        nanos: [
          { name: "BV / PV Setup", micros: [{ name: "Activate", action: "Activate" }] },
        ],
      },
      {
        name: "Package List",
        nanos: [
          { name: "Edit / Disable", micros: [{ name: "Save Update", action: "Save" }] },
        ],
      },
    ],
  },
  {
    name: "Orders",
    icon: ShoppingCart,
    subs: [
      {
        name: "New Orders",
        nanos: [
          { name: "Payment Status", micros: [{ name: "Confirm Order", action: "Confirm" }] },
        ],
      },
    ],
  },
];

const PackagesPage = () => (
  <ModuleShell title="Packages / Products" description="Set up packages with BV/PV, manage product listings, and process orders." categories={categories} />
);

export default PackagesPage;
