import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import KPICard from "@/components/KPICard";
import DataTable from "@/components/DataTable";
import StatusBadge from "@/components/StatusBadge";
import {
  DollarSign, Users, TrendingUp, Award, BarChart3, PieChart as PieChartIcon,
  Activity, AlertTriangle, Download, Calendar, Filter
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Legend
} from "recharts";
import { cn } from "@/lib/utils";

const chartTooltipStyle = {
  contentStyle: { background: "hsl(222, 47%, 8%)", border: "1px solid hsl(222, 30%, 16%)", borderRadius: "8px", fontSize: "12px", color: "hsl(210, 40%, 96%)" },
  itemStyle: { color: "hsl(210, 40%, 96%)" },
};

type TabId = "revenue" | "members" | "commissions" | "network" | "risk";

const tabs: { id: TabId; label: string; icon: typeof DollarSign }[] = [
  { id: "revenue", label: "Revenue", icon: DollarSign },
  { id: "members", label: "Member Growth", icon: Users },
  { id: "commissions", label: "Commissions", icon: TrendingUp },
  { id: "network", label: "Network Health", icon: Activity },
  { id: "risk", label: "Financial Risk", icon: AlertTriangle },
];

const dateRanges = ["7d", "30d", "90d", "1y", "All"] as const;

const COLORS = [
  "hsl(190, 100%, 50%)", "hsl(120, 100%, 56%)", "hsl(45, 100%, 50%)",
  "hsl(280, 80%, 60%)", "hsl(0, 84%, 60%)", "hsl(210, 80%, 60%)",
  "hsl(160, 80%, 50%)", "hsl(30, 90%, 55%)",
];

const AnalyticsPage = () => {
  const [activeTab, setActiveTab] = useState<TabId>("revenue");
  const [dateRange, setDateRange] = useState<typeof dateRanges[number]>("30d");

  const dateFilter = useMemo(() => {
    const now = new Date();
    if (dateRange === "7d") return new Date(now.getTime() - 7 * 86400000).toISOString();
    if (dateRange === "30d") return new Date(now.getTime() - 30 * 86400000).toISOString();
    if (dateRange === "90d") return new Date(now.getTime() - 90 * 86400000).toISOString();
    if (dateRange === "1y") return new Date(now.getTime() - 365 * 86400000).toISOString();
    return "2020-01-01T00:00:00.000Z";
  }, [dateRange]);

  // Queries
  const { data: members = [] } = useQuery({
    queryKey: ["analytics-members", dateFilter],
    queryFn: async () => {
      const { data } = await supabase.from("members").select("id, username, status, join_date, rank_id, sponsor_id, tenant_id").gte("join_date", dateFilter).order("join_date", { ascending: false });
      return data || [];
    },
  });

  const { data: commissions = [] } = useQuery({
    queryKey: ["analytics-commissions", dateFilter],
    queryFn: async () => {
      const { data } = await supabase.from("commissions").select("id, amount, commission_type, created_at, level, member_id").gte("created_at", dateFilter).order("created_at", { ascending: false });
      return data || [];
    },
  });

  const { data: payouts = [] } = useQuery({
    queryKey: ["analytics-payouts", dateFilter],
    queryFn: async () => {
      const { data } = await supabase.from("payouts").select("id, amount, status, request_date, processed_at").gte("request_date", dateFilter);
      return data || [];
    },
  });

  const { data: wallets = [] } = useQuery({
    queryKey: ["analytics-wallets"],
    queryFn: async () => {
      const { data } = await supabase.from("wallets").select("id, income_wallet, roi_wallet, repurchase_wallet, member_id");
      return data || [];
    },
  });

  const { data: packages = [] } = useQuery({
    queryKey: ["analytics-packages"],
    queryFn: async () => {
      const { data } = await supabase.from("packages").select("id, name, price, bv, pv, status");
      return data || [];
    },
  });

  // Derived analytics
  const totalRevenue = commissions.reduce((s, c) => s + Number(c.amount), 0);
  const totalPayouts = payouts.reduce((s, p) => s + Number(p.amount), 0);
  const activeMembers = members.filter(m => m.status === "active").length;
  const inactiveMembers = members.filter(m => m.status === "inactive").length;
  const totalWalletBalance = wallets.reduce((s, w) => s + Number(w.income_wallet) + Number(w.roi_wallet) + Number(w.repurchase_wallet), 0);

  // Group commissions by type for pie chart
  const commissionByType = useMemo(() => {
    const map: Record<string, number> = {};
    commissions.forEach(c => { map[c.commission_type] = (map[c.commission_type] || 0) + Number(c.amount); });
    return Object.entries(map).map(([name, value], i) => ({ name: name.replace(/_/g, " "), value, color: COLORS[i % COLORS.length] }));
  }, [commissions]);

  // Group members by day for trend chart
  const memberTrend = useMemo(() => {
    const map: Record<string, number> = {};
    members.forEach(m => {
      const day = m.join_date?.slice(0, 10) || "";
      if (day) map[day] = (map[day] || 0) + 1;
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).map(([date, count]) => ({ date, count }));
  }, [members]);

  // Commission trend by day
  const commissionTrend = useMemo(() => {
    const map: Record<string, number> = {};
    commissions.forEach(c => {
      const day = c.created_at?.slice(0, 10) || "";
      if (day) map[day] = (map[day] || 0) + Number(c.amount);
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).map(([date, amount]) => ({ date, amount }));
  }, [commissions]);

  // Top earners
  const topEarners = useMemo(() => {
    const map: Record<string, { total: number; count: number }> = {};
    commissions.forEach(c => {
      if (!map[c.member_id]) map[c.member_id] = { total: 0, count: 0 };
      map[c.member_id].total += Number(c.amount);
      map[c.member_id].count += 1;
    });
    return Object.entries(map).map(([id, data]) => ({ id, ...data })).sort((a, b) => b.total - a.total).slice(0, 10);
  }, [commissions]);

  // Member status distribution
  const statusDistribution = useMemo(() => {
    const map: Record<string, number> = {};
    members.forEach(m => { map[m.status] = (map[m.status] || 0) + 1; });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }));
  }, [members]);

  // Payout status distribution
  const payoutStatusDist = useMemo(() => {
    const map: Record<string, number> = {};
    payouts.forEach(p => { map[p.status] = (map[p.status] || 0) + Number(p.amount); });
    return Object.entries(map).map(([name, value], i) => ({ name, value: Math.round(value * 100) / 100, color: COLORS[i % COLORS.length] }));
  }, [payouts]);

  // ROI liability (sum of roi_wallet)
  const roiLiability = wallets.reduce((s, w) => s + Number(w.roi_wallet), 0);
  const pendingPayouts = payouts.filter(p => p.status === "pending").reduce((s, p) => s + Number(p.amount), 0);

  // Network depth stats
  const networkDepth = useMemo(() => {
    const depths: Record<string, number> = {};
    const parentMap: Record<string, string | null> = {};
    members.forEach(m => { parentMap[m.id] = m.sponsor_id; });
    const getDepth = (id: string, visited = new Set<string>()): number => {
      if (visited.has(id)) return 0;
      visited.add(id);
      const parent = parentMap[id];
      if (!parent) return 1;
      return 1 + getDepth(parent, visited);
    };
    members.forEach(m => { depths[m.id] = getDepth(m.id); });
    const depthDist: Record<number, number> = {};
    Object.values(depths).forEach(d => { depthDist[d] = (depthDist[d] || 0) + 1; });
    return Object.entries(depthDist).map(([depth, count]) => ({ depth: `Level ${depth}`, count })).sort((a, b) => parseInt(a.depth.split(" ")[1]) - parseInt(b.depth.split(" ")[1]));
  }, [members]);

  const topEarnerColumns = [
    { key: "id", label: "Member ID", sortable: true, render: (row: any) => <span className="text-xs font-mono text-muted-foreground">{row.id.slice(0, 8)}...</span> },
    { key: "total", label: "Total Earned", sortable: true, render: (row: any) => <span className="text-accent font-semibold">${row.total.toFixed(2)}</span> },
    { key: "count", label: "Transactions", sortable: true },
  ];

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Analytics & BI</h1>
          <p className="text-sm text-muted-foreground">Real-time insights across all dimensions</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-border bg-card overflow-hidden">
            {dateRanges.map(r => (
              <button key={r} onClick={() => setDateRange(r)} className={cn(
                "px-3 py-1.5 text-xs font-medium transition-colors",
                dateRange === r ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
              )}>{r}</button>
            ))}
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-xs text-muted-foreground hover:bg-secondary transition-colors">
            <Download className="h-3.5 w-3.5" /> Export
          </button>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex gap-1 overflow-x-auto rounded-lg border border-border bg-card p-1">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={cn(
            "flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap",
            activeTab === tab.id ? "bg-primary/10 text-primary shadow-sm" : "text-muted-foreground hover:bg-secondary hover:text-foreground"
          )}>
            <tab.icon className="h-4 w-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Revenue Tab */}
      {activeTab === "revenue" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <KPICard title="Total Revenue" value={`$${totalRevenue.toFixed(2)}`} trend="up" change="Commission based" icon={DollarSign} />
            <KPICard title="Total Payouts" value={`$${totalPayouts.toFixed(2)}`} trend="down" change="All payouts" icon={TrendingUp} />
            <KPICard title="Net Revenue" value={`$${(totalRevenue - totalPayouts).toFixed(2)}`} trend={totalRevenue > totalPayouts ? "up" : "down"} change="Revenue - Payouts" icon={BarChart3} />
            <KPICard title="Wallet Holdings" value={`$${totalWalletBalance.toFixed(2)}`} trend="neutral" change="All wallets" icon={Activity} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Commission Revenue Trend</h3>
              <ResponsiveContainer width="100%" height={280}>
                <AreaChart data={commissionTrend}>
                  <defs>
                    <linearGradient id="revAnalGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
                  <XAxis dataKey="date" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip {...chartTooltipStyle} />
                  <Area type="monotone" dataKey="amount" stroke="hsl(190, 100%, 50%)" fill="url(#revAnalGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Payout Distribution</h3>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={payoutStatusDist} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} strokeWidth={0}>
                    {payoutStatusDist.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip {...chartTooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
                {payoutStatusDist.map(item => (
                  <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
                    {item.name} (${item.value})
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Member Growth Tab */}
      {activeTab === "members" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <KPICard title="Total Members" value={String(members.length)} trend="up" change={`${activeMembers} active`} icon={Users} />
            <KPICard title="Active" value={String(activeMembers)} trend="up" change={`${members.length > 0 ? ((activeMembers / members.length) * 100).toFixed(1) : 0}% rate`} icon={Users} />
            <KPICard title="Inactive" value={String(inactiveMembers)} trend="down" change={`${members.length > 0 ? ((inactiveMembers / members.length) * 100).toFixed(1) : 0}% rate`} icon={Users} />
            <KPICard title="Retention" value={`${members.length > 0 ? ((activeMembers / members.length) * 100).toFixed(1) : 0}%`} trend={activeMembers > inactiveMembers ? "up" : "down"} change="Active / Total" icon={Award} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Daily Joining Trend</h3>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={memberTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
                  <XAxis dataKey="date" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip {...chartTooltipStyle} />
                  <Bar dataKey="count" fill="hsl(120, 100%, 56%)" radius={[4, 4, 0, 0]} opacity={0.8} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Status Distribution</h3>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} strokeWidth={0}>
                    {statusDistribution.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip {...chartTooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
                {statusDistribution.map(item => (
                  <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
                    {item.name} ({item.value})
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Commissions Tab */}
      {activeTab === "commissions" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <KPICard title="Total Commissions" value={`$${totalRevenue.toFixed(2)}`} trend="up" change={`${commissions.length} txns`} icon={DollarSign} />
            <KPICard title="Commission Types" value={String(commissionByType.length)} trend="neutral" change="Active types" icon={PieChartIcon} />
            <KPICard title="Avg Per Member" value={`$${members.length > 0 ? (totalRevenue / members.length).toFixed(2) : "0.00"}`} trend="neutral" change="Per member" icon={TrendingUp} />
            <KPICard title="Top Earner" value={topEarners[0] ? `$${topEarners[0].total.toFixed(2)}` : "$0.00"} trend="up" change="Highest single" icon={Award} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Commission Type Breakdown</h3>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={commissionByType} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
                  <XAxis type="number" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis type="category" dataKey="name" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} width={120} />
                  <Tooltip {...chartTooltipStyle} />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {commissionByType.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Distribution</h3>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={commissionByType} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={70} strokeWidth={0}>
                    {commissionByType.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip {...chartTooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
                {commissionByType.map(item => (
                  <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground capitalize">
                    <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
                    {item.name}
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DataTable title="Top Earners" columns={topEarnerColumns} data={topEarners} pageSize={10} />
        </div>
      )}

      {/* Network Health Tab */}
      {activeTab === "network" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <KPICard title="Network Size" value={String(members.length)} trend="up" change="Total nodes" icon={Users} />
            <KPICard title="Max Depth" value={String(networkDepth.length)} trend="neutral" change="Levels deep" icon={Activity} />
            <KPICard title="Avg Team Size" value={members.length > 0 ? (members.filter(m => m.sponsor_id).length / Math.max(members.filter(m => !m.sponsor_id).length, 1)).toFixed(1) : "0"} trend="neutral" change="Per sponsor" icon={Users} />
            <KPICard title="Orphan Nodes" value={String(members.filter(m => !m.sponsor_id).length)} trend="neutral" change="No sponsor" icon={AlertTriangle} />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Depth Distribution</h3>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={networkDepth}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
                  <XAxis dataKey="depth" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip {...chartTooltipStyle} />
                  <Bar dataKey="count" fill="hsl(280, 80%, 60%)" radius={[4, 4, 0, 0]} opacity={0.8} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Member Status Health</h3>
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={statusDistribution} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={90} strokeWidth={0} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                    {statusDistribution.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie>
                  <Tooltip {...chartTooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Financial Risk Tab */}
      {activeTab === "risk" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <KPICard title="ROI Liability" value={`$${roiLiability.toFixed(2)}`} trend={roiLiability > totalRevenue * 0.5 ? "down" : "up"} change="Outstanding ROI" icon={AlertTriangle} />
            <KPICard title="Pending Payouts" value={`$${pendingPayouts.toFixed(2)}`} trend={pendingPayouts > 0 ? "down" : "up"} change="Awaiting processing" icon={DollarSign} />
            <KPICard title="Payout Ratio" value={`${totalRevenue > 0 ? ((totalPayouts / totalRevenue) * 100).toFixed(1) : 0}%`} trend={totalPayouts / Math.max(totalRevenue, 1) > 0.7 ? "down" : "up"} change="Payouts / Revenue" icon={TrendingUp} />
            <KPICard title="Active Packages" value={String(packages.filter(p => p.status === "active").length)} trend="neutral" change={`of ${packages.length} total`} icon={Award} />
          </div>

          {/* Risk Indicators */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border bg-card p-4 space-y-4">
              <h3 className="text-sm font-semibold text-foreground">Risk Indicators</h3>
              {[
                { label: "Payout-to-Revenue Ratio", value: totalRevenue > 0 ? (totalPayouts / totalRevenue) * 100 : 0, threshold: 70, unit: "%" },
                { label: "ROI Liability Coverage", value: totalRevenue > 0 ? (roiLiability / totalRevenue) * 100 : 0, threshold: 50, unit: "%" },
                { label: "Pending Payout Pressure", value: totalPayouts > 0 ? (pendingPayouts / Math.max(totalPayouts, 1)) * 100 : 0, threshold: 30, unit: "%" },
                { label: "Active Member Ratio", value: members.length > 0 ? (activeMembers / members.length) * 100 : 0, threshold: 60, unit: "%", inverted: true },
              ].map(indicator => (
                <div key={indicator.label} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">{indicator.label}</span>
                    <span className={cn(
                      "font-semibold",
                      indicator.inverted
                        ? indicator.value >= indicator.threshold ? "text-accent" : "text-destructive"
                        : indicator.value <= indicator.threshold ? "text-accent" : "text-destructive"
                    )}>
                      {indicator.value.toFixed(1)}{indicator.unit}
                    </span>
                  </div>
                  <div className="h-2 rounded-full bg-secondary overflow-hidden">
                    <div
                      className={cn("h-full rounded-full transition-all",
                        indicator.inverted
                          ? indicator.value >= indicator.threshold ? "bg-accent" : "bg-destructive"
                          : indicator.value <= indicator.threshold ? "bg-accent" : "bg-destructive"
                      )}
                      style={{ width: `${Math.min(indicator.value, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="rounded-lg border border-border bg-card p-4">
              <h3 className="text-sm font-semibold text-foreground mb-4">Payout vs Revenue</h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={[
                  { name: "Revenue", value: totalRevenue },
                  { name: "Payouts", value: totalPayouts },
                  { name: "Pending", value: pendingPayouts },
                  { name: "ROI Liability", value: roiLiability },
                ]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
                  <XAxis dataKey="name" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip {...chartTooltipStyle} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    <Cell fill="hsl(190, 100%, 50%)" />
                    <Cell fill="hsl(120, 100%, 56%)" />
                    <Cell fill="hsl(45, 100%, 50%)" />
                    <Cell fill="hsl(0, 84%, 60%)" />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {members.length === 0 && commissions.length === 0 && (
        <div className="rounded-lg border border-border bg-card p-12 text-center">
          <BarChart3 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Data Yet</h3>
          <p className="text-sm text-muted-foreground">Analytics will populate once members, commissions, and transactions are recorded.</p>
        </div>
      )}
    </div>
  );
};

export default AnalyticsPage;
