import ModuleShell, { Category } from "@/components/ModuleShell";
import { Layers, Share2 } from "lucide-react";

const categories: Category[] = [
  {
    name: "Pool Setup",
    icon: Layers,
    subs: [
      {
        name: "Create Pool",
        nanos: [
          { name: "Entry Condition", micros: [{ name: "Save Rule", action: "Save" }] },
        ],
      },
      {
        name: "Distribution",
        nanos: [
          { name: "Trigger Distribution", micros: [{ name: "View Report", action: "View" }] },
        ],
      },
    ],
  },
];

const PoolsPage = () => (
  <ModuleShell title="Pools / Boards" description="Create and manage pool entries, conditions, and distribution triggers." categories={categories} />
);

export default PoolsPage;
