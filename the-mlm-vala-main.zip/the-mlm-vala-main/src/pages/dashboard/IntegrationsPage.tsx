import ModuleShell, { Category } from "@/components/ModuleShell";
import { Plug, Mail } from "lucide-react";

const categories: Category[] = [
  {
    name: "Payment Gateway",
    icon: Plug,
    subs: [
      {
        name: "Add Gateway",
        nanos: [
          { name: "API Key Setup", micros: [{ name: "Test Connection", action: "Test" }] },
        ],
      },
      {
        name: "Active Gateway",
        nanos: [
          { name: "Enable / Disable", micros: [{ name: "Save", action: "Save" }] },
        ],
      },
    ],
  },
  {
    name: "SMS / Email",
    icon: Mail,
    subs: [
      {
        name: "SMTP Setup",
        nanos: [
          { name: "Test Email", micros: [{ name: "Confirm", action: "Confirm" }] },
        ],
      },
    ],
  },
];

const IntegrationsPage = () => (
  <ModuleShell title="Integrations" description="Configure payment gateways, SMTP, SMS, and third-party integrations." categories={categories} />
);

export default IntegrationsPage;
