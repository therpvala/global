import ModuleShell, { Category } from "@/components/ModuleShell";
import { Users, UserPlus, Shield, User, Wallet, GitBranch } from "lucide-react";

const categories: Category[] = [
  {
    name: "Member Management",
    icon: Users,
    subs: [
      {
        name: "All Members",
        nanos: [
          { name: "Filter (Active / Inactive / Rank)", micros: [
            { name: "Edit Member", action: "Edit" },
            { name: "Suspend Member", action: "Suspend" },
            { name: "Delete Member", action: "Delete" },
          ]},
        ],
      },
      {
        name: "Add Member",
        nanos: [
          { name: "Sponsor Selection", micros: [{ name: "Auto Placement", action: "Place" }] },
        ],
      },
      {
        name: "KYC",
        nanos: [
          { name: "Pending Verification", micros: [
            { name: "Approve", action: "Approve" },
            { name: "Reject", action: "Reject" },
          ]},
        ],
      },
    ],
  },
  {
    name: "Member Profile",
    icon: User,
    subs: [
      {
        name: "Personal Info",
        nanos: [
          { name: "Edit Info", micros: [{ name: "Save Changes", action: "Save" }] },
        ],
      },
      {
        name: "Financial Info",
        nanos: [
          { name: "Wallet View", micros: [{ name: "Transaction Details", action: "View" }] },
        ],
      },
      {
        name: "Network Info",
        nanos: [
          { name: "Upline / Downline", micros: [{ name: "Jump to Tree", action: "Go" }] },
        ],
      },
    ],
  },
];

const MembersPage = () => (
  <ModuleShell title="Members" description="Manage all members, KYC verification, and member profiles." categories={categories} />
);

export default MembersPage;
