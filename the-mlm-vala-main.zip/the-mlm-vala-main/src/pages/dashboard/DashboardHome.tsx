import { Users, DollarSign, TrendingUp, CreditCard, UserPlus, Award } from "lucide-react";
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import KPICard from "@/components/KPICard";
import DataTable from "@/components/DataTable";
import StatusBadge from "@/components/StatusBadge";
import { Link } from "react-router-dom";

// Mock data
const revenueData = [
  { month: "Jan", revenue: 4200 }, { month: "Feb", revenue: 5800 },
  { month: "Mar", revenue: 7200 }, { month: "Apr", revenue: 6100 },
  { month: "May", revenue: 8400 }, { month: "Jun", revenue: 9200 },
  { month: "Jul", revenue: 11000 },
];

const joiningData = [
  { week: "W1", members: 12 }, { week: "W2", members: 18 },
  { week: "W3", members: 25 }, { week: "W4", members: 22 },
  { week: "W5", members: 30 }, { week: "W6", members: 35 },
  { week: "W7", members: 28 },
];

const commissionBreakdown = [
  { name: "Direct", value: 35, color: "hsl(190, 100%, 50%)" },
  { name: "Level", value: 25, color: "hsl(120, 100%, 56%)" },
  { name: "Binary", value: 20, color: "hsl(45, 100%, 50%)" },
  { name: "Pool", value: 12, color: "hsl(280, 80%, 60%)" },
  { name: "ROI", value: 8, color: "hsl(0, 84%, 60%)" },
];

const recentMembers = [
  { id: "1", username: "john_doe", sponsor: "admin", rank: "Silver", status: "Active", joined: "2026-02-14" },
  { id: "2", username: "jane_smith", sponsor: "john_doe", rank: "Bronze", status: "Active", joined: "2026-02-13" },
  { id: "3", username: "mike_w", sponsor: "jane_smith", rank: "Bronze", status: "Pending", joined: "2026-02-12" },
  { id: "4", username: "sarah_k", sponsor: "admin", rank: "Gold", status: "Active", joined: "2026-02-11" },
  { id: "5", username: "alex_p", sponsor: "sarah_k", rank: "Bronze", status: "Inactive", joined: "2026-02-10" },
];

const quickActions = [
  { label: "Add Member", icon: UserPlus, path: "/dashboard/members", color: "text-primary" },
  { label: "Run Commission", icon: DollarSign, path: "/dashboard/commissions", color: "text-accent" },
  { label: "Generate Payout", icon: CreditCard, path: "/dashboard/payout", color: "text-yellow-400" },
  { label: "View Network", icon: TrendingUp, path: "/dashboard/network-tree", color: "text-purple-400" },
];

const memberColumns = [
  { key: "username", label: "Username", sortable: true },
  { key: "sponsor", label: "Sponsor", sortable: true },
  { key: "rank", label: "Rank", sortable: true },
  {
    key: "status", label: "Status", sortable: true,
    render: (row: any) => <StatusBadge status={row.status} />,
  },
  { key: "joined", label: "Joined", sortable: true },
];

const chartTooltipStyle = {
  contentStyle: { background: "hsl(222, 47%, 8%)", border: "1px solid hsl(222, 30%, 16%)", borderRadius: "8px", fontSize: "12px", color: "hsl(210, 40%, 96%)" },
  itemStyle: { color: "hsl(210, 40%, 96%)" },
};

const DashboardHome = () => (
  <div className="p-4 lg:p-6 space-y-6">
    {/* KPI Grid */}
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
      <KPICard title="Total Members" value="2,847" change="+12.5% this month" trend="up" icon={Users} />
      <KPICard title="Revenue" value="$52,400" change="+8.2% this month" trend="up" icon={DollarSign} />
      <KPICard title="Commissions" value="$18,200" change="+15.3% this month" trend="up" icon={TrendingUp} />
      <KPICard title="Payouts" value="$12,800" change="-2.1% this month" trend="down" icon={CreditCard} />
      <KPICard title="New Joins" value="142" change="+22% this week" trend="up" icon={UserPlus} />
      <KPICard title="Top Rank" value="Diamond" change="3 achievers" trend="neutral" icon={Award} />
    </div>

    {/* Charts Row */}
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Revenue Chart */}
      <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">Revenue Trend</h3>
        <ResponsiveContainer width="100%" height={220}>
          <AreaChart data={revenueData}>
            <defs>
              <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
            <XAxis dataKey="month" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip {...chartTooltipStyle} />
            <Area type="monotone" dataKey="revenue" stroke="hsl(190, 100%, 50%)" fill="url(#revGrad)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Commission Breakdown */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">Commission Breakdown</h3>
        <ResponsiveContainer width="100%" height={160}>
          <PieChart>
            <Pie data={commissionBreakdown} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={65} strokeWidth={0}>
              {commissionBreakdown.map((entry, i) => (
                <Cell key={i} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip {...chartTooltipStyle} />
          </PieChart>
        </ResponsiveContainer>
        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
          {commissionBreakdown.map((item) => (
            <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
              {item.name} ({item.value}%)
            </div>
          ))}
        </div>
      </div>
    </div>

    {/* Joining Trend + Quick Actions */}
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Joining Trend */}
      <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">Joining Trend</h3>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={joiningData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
            <XAxis dataKey="week" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <Tooltip {...chartTooltipStyle} />
            <Bar dataKey="members" fill="hsl(120, 100%, 56%)" radius={[4, 4, 0, 0]} opacity={0.8} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Quick Actions */}
      <div className="rounded-lg border border-border bg-card p-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 gap-2">
          {quickActions.map((action) => (
            <Link
              key={action.label}
              to={action.path}
              className="flex flex-col items-center gap-2 rounded-lg border border-border p-3 hover:bg-secondary/50 hover:border-primary/30 transition-all duration-200"
            >
              <action.icon className={`h-5 w-5 ${action.color}`} />
              <span className="text-xs text-muted-foreground text-center">{action.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>

    {/* Recent Members Table */}
    <DataTable
      title="Recent Members"
      columns={memberColumns}
      data={recentMembers}
      pageSize={5}
    />
  </div>
);

export default DashboardHome;
