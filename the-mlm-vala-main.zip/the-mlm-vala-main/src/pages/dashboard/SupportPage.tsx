import ModuleShell, { Category } from "@/components/ModuleShell";
import { HeadphonesIcon } from "lucide-react";

const categories: Category[] = [
  {
    name: "Tickets",
    icon: HeadphonesIcon,
    subs: [
      {
        name: "Open Tickets",
        nanos: [
          { name: "Reply", micros: [{ name: "Close Ticket", action: "Close" }] },
        ],
      },
    ],
  },
];

const SupportPage = () => (
  <ModuleShell title="Support" description="Manage support tickets, reply to inquiries, and close resolved tickets." categories={categories} />
);

export default SupportPage;
