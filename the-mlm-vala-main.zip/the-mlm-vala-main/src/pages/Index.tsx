import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import MLMPlansGrid from "@/components/MLMPlansGrid";
import Footer from "@/components/Footer";

const Index = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <HeroSection />
    <MLMPlansGrid />
    <Footer />
  </div>
);

export default Index;
