import ModuleShell, { Category } from "@/components/ModuleShell";
import { HeadphonesIcon, MessageSquare } from "lucide-react";

const categories: Category[] = [
  {
    name: "Ticket Monitoring",
    icon: HeadphonesIcon,
    subs: [
      { name: "Open Tickets", nanos: [{ name: "Filter By Tenant", micros: [{ name: "View", action: "View" }] }] },
      { name: "Resolved Tickets", nanos: [{ name: "History", micros: [{ name: "View", action: "View" }] }] },
    ],
  },
  {
    name: "Live Chat",
    icon: MessageSquare,
    subs: [
      { name: "Active Sessions", nanos: [{ name: "Monitor", micros: [{ name: "Join", action: "Join" }] }] },
    ],
  },
];

const SASupportPage = () => (
  <ModuleShell title="Support Monitoring" description="Monitor support tickets and live chat sessions across all tenants." categories={categories} />
);

export default SASupportPage;
