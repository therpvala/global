import ModuleShell, { Category } from "@/components/ModuleShell";
import { LayoutDashboard, Activity } from "lucide-react";

const categories: Category[] = [
  {
    name: "Global Overview",
    icon: LayoutDashboard,
    subs: [
      {
        name: "Total Tenants",
        nanos: [
          { name: "Active / Suspended", micros: [{ name: "View Details", action: "View" }] },
        ],
      },
      {
        name: "Total Revenue",
        nanos: [
          { name: "Monthly / Lifetime Split", micros: [{ name: "Export Report", action: "Export" }] },
        ],
      },
      {
        name: "Active Plans Distribution",
        nanos: [
          { name: "Plan Usage Stats", micros: [{ name: "Drill Down", action: "View" }] },
        ],
      },
    ],
  },
  {
    name: "System Health",
    icon: Activity,
    subs: [
      {
        name: "Server Status",
        nanos: [
          { name: "CPU / Memory", micros: [{ name: "View Logs", action: "View" }] },
        ],
      },
      {
        name: "Cron Status",
        nanos: [
          { name: "Last Run", micros: [{ name: "Run Now", action: "Run" }] },
        ],
      },
    ],
  },
];

const SADashboard = () => (
  <ModuleShell title="Super Admin Dashboard" description="Global overview of tenants, revenue, plans, and system health." categories={categories} />
);

export default SADashboard;
