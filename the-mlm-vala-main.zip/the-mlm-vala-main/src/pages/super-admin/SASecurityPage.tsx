import ModuleShell, { Category } from "@/components/ModuleShell";
import { Shield, Lock } from "lucide-react";

const categories: Category[] = [
  {
    name: "Admin Roles",
    icon: Shield,
    subs: [
      {
        name: "Create Sub Admin",
        nanos: [{ name: "Assign Permissions", micros: [{ name: "Save", action: "Save" }] }],
      },
    ],
  },
  {
    name: "Access Control",
    icon: Lock,
    subs: [
      { name: "Module Permissions", nanos: [{ name: "Configure", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Read / Write / Delete Rights", nanos: [{ name: "Set Permissions", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
];

const SASecurityPage = () => (
  <ModuleShell title="Security & Roles" description="Manage admin roles, sub-admins, and fine-grained access control." categories={categories} />
);

export default SASecurityPage;
