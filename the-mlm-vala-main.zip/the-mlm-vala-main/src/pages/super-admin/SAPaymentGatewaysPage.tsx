import ModuleShell, { Category } from "@/components/ModuleShell";
import { Plug, FileText } from "lucide-react";

const categories: Category[] = [
  {
    name: "Global Gateway Setup",
    icon: Plug,
    subs: [
      { name: "Stripe", nanos: [{ name: "API Keys", micros: [{ name: "Configure", action: "Configure" }] }] },
      { name: "Razorpay", nanos: [{ name: "API Keys", micros: [{ name: "Configure", action: "Configure" }] }] },
      { name: "PayPal", nanos: [{ name: "API Keys", micros: [{ name: "Configure", action: "Configure" }] }] },
      { name: "Crypto Payment", nanos: [{ name: "Wallet Config", micros: [{ name: "Configure", action: "Configure" }] }] },
    ],
  },
  {
    name: "Gateway Logs",
    icon: FileText,
    subs: [
      { name: "Success", nanos: [{ name: "View Transactions", micros: [{ name: "View", action: "View" }] }] },
      { name: "Failed", nanos: [{ name: "View Failures", micros: [{ name: "View", action: "View" }] }] },
      { name: "Refunds", nanos: [{ name: "Process Refunds", micros: [{ name: "Process", action: "Process" }] }] },
    ],
  },
];

const SAPaymentGatewaysPage = () => (
  <ModuleShell title="Payment Gateways" description="Configure global payment gateways and monitor transaction logs." categories={categories} />
);

export default SAPaymentGatewaysPage;
