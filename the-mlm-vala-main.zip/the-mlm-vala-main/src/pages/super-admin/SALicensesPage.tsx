import ModuleShell, { Category } from "@/components/ModuleShell";
import { Key, KeyRound } from "lucide-react";

const categories: Category[] = [
  {
    name: "License Generator",
    icon: Key,
    subs: [
      {
        name: "Select Plan",
        nanos: [
          { name: "Select Pricing ($5 / $9 / $249)", micros: [{ name: "Set Expiry", action: "Set" }] },
          { name: "Generate Key", micros: [{ name: "Generate", action: "Generate" }] },
        ],
      },
    ],
  },
  {
    name: "License Control",
    icon: KeyRound,
    subs: [
      {
        name: "Active Keys",
        nanos: [
          { name: "Extend", micros: [{ name: "Disable", action: "Disable" }] },
        ],
      },
      {
        name: "Expired Keys",
        nanos: [
          { name: "Renew", micros: [{ name: "Delete", action: "Delete" }] },
        ],
      },
    ],
  },
];

const SALicensesPage = () => (
  <ModuleShell title="License Management" description="Generate, extend, renew, and control license keys for all plans." categories={categories} />
);

export default SALicensesPage;
