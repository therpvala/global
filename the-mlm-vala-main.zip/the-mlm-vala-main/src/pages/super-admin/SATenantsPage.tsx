import ModuleShell, { Category } from "@/components/ModuleShell";
import { Users, UserCog } from "lucide-react";

const categories: Category[] = [
  {
    name: "Tenant Management",
    icon: Users,
    subs: [
      {
        name: "All Clients",
        nanos: [
          { name: "Search / Filter", micros: [{ name: "Edit / Suspend", action: "Edit" }] },
        ],
      },
      {
        name: "Create Tenant",
        nanos: [
          { name: "Assign Plan", micros: [{ name: "Generate License", action: "Generate" }] },
        ],
      },
    ],
  },
  {
    name: "Tenant Profile",
    icon: UserCog,
    subs: [
      {
        name: "Business Info",
        nanos: [
          { name: "Plan Details", micros: [{ name: "View", action: "View" }] },
          { name: "Expiry Date", micros: [{ name: "View", action: "View" }] },
          { name: "Database ID", micros: [{ name: "View", action: "View" }] },
          { name: "White Label Status", micros: [{ name: "View", action: "View" }] },
        ],
      },
      {
        name: "Upgrade / Downgrade",
        nanos: [
          { name: "Change Plan", micros: [{ name: "Apply", action: "Apply" }] },
        ],
      },
    ],
  },
];

const SATenantsPage = () => (
  <ModuleShell title="Tenants / Clients" description="Manage all tenants, profiles, plans, and lifecycle operations." categories={categories} />
);

export default SATenantsPage;
