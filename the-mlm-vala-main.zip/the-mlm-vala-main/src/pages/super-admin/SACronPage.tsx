import ModuleShell, { Category } from "@/components/ModuleShell";
import { Clock, RefreshCw, Layers } from "lucide-react";

const categories: Category[] = [
  {
    name: "Commission Cron",
    icon: Clock,
    subs: [
      { name: "Run Now", nanos: [{ name: "Manual Trigger", micros: [{ name: "Run", action: "Run" }] }] },
      { name: "View Log", nanos: [{ name: "Execution History", micros: [{ name: "View", action: "View" }] }] },
    ],
  },
  {
    name: "ROI Cron",
    icon: RefreshCw,
    subs: [
      { name: "Run Now", nanos: [{ name: "Manual Trigger", micros: [{ name: "Run", action: "Run" }] }] },
      { name: "View Log", nanos: [{ name: "Execution History", micros: [{ name: "View", action: "View" }] }] },
    ],
  },
  {
    name: "Pool Distribution Cron",
    icon: Layers,
    subs: [
      { name: "Schedule", nanos: [{ name: "Cron Expression", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Manual Trigger", nanos: [{ name: "Run Distribution", micros: [{ name: "Run", action: "Run" }] }] },
    ],
  },
];

const SACronPage = () => (
  <ModuleShell title="Cron & Scheduler" description="Manage commission, ROI, and pool distribution cron jobs." categories={categories} />
);

export default SACronPage;
