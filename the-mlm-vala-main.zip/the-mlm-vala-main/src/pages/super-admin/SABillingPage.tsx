import ModuleShell, { Category } from "@/components/ModuleShell";
import { CreditCard, BarChart3 } from "lucide-react";

const categories: Category[] = [
  {
    name: "Active Subscriptions",
    icon: CreditCard,
    subs: [
      {
        name: "Monthly Plans",
        nanos: [{ name: "Renewal Status", micros: [{ name: "View", action: "View" }] }],
      },
      {
        name: "Lifetime Plans",
        nanos: [{ name: "View List", micros: [{ name: "View", action: "View" }] }],
      },
    ],
  },
  {
    name: "Revenue Reports",
    icon: BarChart3,
    subs: [
      {
        name: "Monthly Income",
        nanos: [{ name: "Export", micros: [{ name: "Export", action: "Export" }] }],
      },
      {
        name: "Plan-wise Revenue",
        nanos: [{ name: "Filter", micros: [{ name: "View", action: "View" }] }],
      },
      {
        name: "White Label Revenue",
        nanos: [{ name: "Filter", micros: [{ name: "View", action: "View" }] }],
      },
    ],
  },
];

const SABillingPage = () => (
  <ModuleShell title="Billing & Subscriptions" description="Manage active subscriptions and view revenue reports across all plans." categories={categories} />
);

export default SABillingPage;
