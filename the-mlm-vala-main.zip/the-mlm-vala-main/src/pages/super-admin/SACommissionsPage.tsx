import ModuleShell, { Category } from "@/components/ModuleShell";
import { DollarSign, Settings } from "lucide-react";

const categories: Category[] = [
  {
    name: "Global Commission Rules",
    icon: DollarSign,
    subs: [
      { name: "Direct Referral", nanos: [{ name: "Percentage Config", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Level Override", nanos: [{ name: "Depth Settings", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Matching Bonus", nanos: [{ name: "Pair Rules", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
  {
    name: "Plan-Specific Overrides",
    icon: Settings,
    subs: [
      { name: "Override By Plan", nanos: [{ name: "Select Plan", micros: [{ name: "Apply Override", action: "Apply" }] }] },
    ],
  },
];

const SACommissionsPage = () => (
  <ModuleShell title="Global Commission Settings" description="Configure global commission rules and plan-specific overrides." categories={categories} />
);

export default SACommissionsPage;
