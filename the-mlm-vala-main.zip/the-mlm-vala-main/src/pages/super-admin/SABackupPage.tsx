import ModuleShell, { Category } from "@/components/ModuleShell";
import { Database, Wrench } from "lucide-react";

const categories: Category[] = [
  {
    name: "Database Backup",
    icon: Database,
    subs: [
      { name: "Manual Backup", nanos: [{ name: "Trigger Backup", micros: [{ name: "Run", action: "Run" }] }] },
      { name: "Auto Daily Backup", nanos: [{ name: "Schedule Config", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
  {
    name: "System Maintenance",
    icon: Wrench,
    subs: [
      { name: "Enable Maintenance Mode", nanos: [{ name: "Toggle", micros: [{ name: "Apply", action: "Apply" }] }] },
      { name: "Clear Cache", nanos: [{ name: "Purge All", micros: [{ name: "Clear", action: "Clear" }] }] },
      { name: "Rebuild Index", nanos: [{ name: "Re-index DB", micros: [{ name: "Run", action: "Run" }] }] },
    ],
  },
];

const SABackupPage = () => (
  <ModuleShell title="Backup & Maintenance" description="Database backups, cache management, and system maintenance controls." categories={categories} />
);

export default SABackupPage;
