import ModuleShell, { Category } from "@/components/ModuleShell";
import { Settings, Shield } from "lucide-react";

const categories: Category[] = [
  {
    name: "Global Settings",
    icon: Settings,
    subs: [
      { name: "Default Currency", nanos: [{ name: "Select Currency", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Timezone", nanos: [{ name: "Select Timezone", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Tax Settings", nanos: [{ name: "Configure Tax", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
  {
    name: "Security",
    icon: Shield,
    subs: [
      { name: "Password Policy", nanos: [{ name: "Min Length / Complexity", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "2FA Enable", nanos: [{ name: "Toggle 2FA", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "IP Restriction", nanos: [{ name: "Whitelist IPs", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
];

const SASystemConfigPage = () => (
  <ModuleShell title="System Configuration" description="Global settings for currency, timezone, tax, and security policies." categories={categories} />
);

export default SASystemConfigPage;
