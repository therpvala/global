import ModuleShell, { Category } from "@/components/ModuleShell";
import { FileText, Users } from "lucide-react";

const categories: Category[] = [
  {
    name: "Admin Actions",
    icon: FileText,
    subs: [
      { name: "Filter By Date", nanos: [{ name: "Date Range", micros: [{ name: "Export", action: "Export" }] }] },
    ],
  },
  {
    name: "Tenant Activity",
    icon: Users,
    subs: [
      { name: "View Changes", nanos: [{ name: "Activity Log", micros: [{ name: "Download Log", action: "Download" }] }] },
    ],
  },
];

const SAAuditLogsPage = () => (
  <ModuleShell title="Audit & Logs" description="Track admin actions and tenant activity with full export support." categories={categories} />
);

export default SAAuditLogsPage;
