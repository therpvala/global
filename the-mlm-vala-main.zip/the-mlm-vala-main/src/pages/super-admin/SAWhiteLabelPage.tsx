import ModuleShell, { Category } from "@/components/ModuleShell";
import { Globe, Users } from "lucide-react";

const categories: Category[] = [
  {
    name: "Branding Policy",
    icon: Globe,
    subs: [
      { name: "Allow Custom Logo", nanos: [{ name: "Toggle", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Allow Custom Domain", nanos: [{ name: "Toggle", micros: [{ name: "Save", action: "Save" }] }] },
      { name: "Remove MLM Vala Branding", nanos: [{ name: "Toggle", micros: [{ name: "Save", action: "Save" }] }] },
    ],
  },
  {
    name: "White Label Tenants",
    icon: Users,
    subs: [
      { name: "View List", nanos: [{ name: "Tenant List", micros: [{ name: "View", action: "View" }] }] },
      { name: "Disable / Enable", nanos: [{ name: "Toggle Access", micros: [{ name: "Apply", action: "Apply" }] }] },
    ],
  },
];

const SAWhiteLabelPage = () => (
  <ModuleShell title="White Label Control" description="Manage branding policies and white label tenant access." categories={categories} />
);

export default SAWhiteLabelPage;
