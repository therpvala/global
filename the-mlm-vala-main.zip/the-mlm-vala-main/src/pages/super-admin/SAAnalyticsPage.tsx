import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import KPICard from "@/components/KPICard";
import DataTable from "@/components/DataTable";
import StatusBadge from "@/components/StatusBadge";
import {
  DollarSign, Users, TrendingUp, Globe, BarChart3,
  Activity, Building2, Key, Download
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid
} from "recharts";
import { cn } from "@/lib/utils";

const chartTooltipStyle = {
  contentStyle: { background: "hsl(222, 47%, 8%)", border: "1px solid hsl(222, 30%, 16%)", borderRadius: "8px", fontSize: "12px", color: "hsl(210, 40%, 96%)" },
  itemStyle: { color: "hsl(210, 40%, 96%)" },
};

const COLORS = [
  "hsl(190, 100%, 50%)", "hsl(120, 100%, 56%)", "hsl(45, 100%, 50%)",
  "hsl(280, 80%, 60%)", "hsl(0, 84%, 60%)", "hsl(210, 80%, 60%)",
  "hsl(160, 80%, 50%)", "hsl(30, 90%, 55%)",
];

const dateRanges = ["7d", "30d", "90d", "1y", "All"] as const;

const SAAnalyticsPage = () => {
  const [dateRange, setDateRange] = useState<typeof dateRanges[number]>("30d");

  const dateFilter = useMemo(() => {
    const now = new Date();
    if (dateRange === "7d") return new Date(now.getTime() - 7 * 86400000).toISOString();
    if (dateRange === "30d") return new Date(now.getTime() - 30 * 86400000).toISOString();
    if (dateRange === "90d") return new Date(now.getTime() - 90 * 86400000).toISOString();
    if (dateRange === "1y") return new Date(now.getTime() - 365 * 86400000).toISOString();
    return "2020-01-01T00:00:00.000Z";
  }, [dateRange]);

  const { data: tenants = [] } = useQuery({
    queryKey: ["sa-tenants"],
    queryFn: async () => {
      const { data } = await supabase.from("tenants").select("*");
      return data || [];
    },
  });

  const { data: subscriptions = [] } = useQuery({
    queryKey: ["sa-subscriptions"],
    queryFn: async () => {
      const { data } = await supabase.from("subscriptions").select("*");
      return data || [];
    },
  });

  const { data: payments = [] } = useQuery({
    queryKey: ["sa-payments", dateFilter],
    queryFn: async () => {
      const { data } = await supabase.from("payments").select("*").gte("created_at", dateFilter);
      return data || [];
    },
  });

  const { data: systemLogs = [] } = useQuery({
    queryKey: ["sa-system-logs", dateFilter],
    queryFn: async () => {
      const { data } = await supabase.from("system_logs").select("*").gte("created_at", dateFilter).order("created_at", { ascending: false }).limit(100);
      return data || [];
    },
  });

  // Derived metrics
  const activeTenants = tenants.filter(t => t.status === "active").length;
  const suspendedTenants = tenants.filter(t => t.status === "suspended").length;
  const whileLabelTenants = tenants.filter(t => t.white_label_enabled).length;
  const totalPaymentRevenue = payments.filter(p => p.status === "success").reduce((s, p) => s + Number(p.amount), 0);
  const mrr = subscriptions.filter(s => s.payment_status === "success").reduce((s, sub) => s + Number(sub.amount), 0);

  // Tenant by plan type
  const tenantsByPlan = useMemo(() => {
    const map: Record<string, number> = {};
    tenants.forEach(t => { map[t.plan_type] = (map[t.plan_type] || 0) + 1; });
    return Object.entries(map).map(([name, value], i) => ({ name: name.replace(/_/g, " "), value, color: COLORS[i % COLORS.length] }));
  }, [tenants]);

  // Tenant by pricing type
  const tenantsByPricing = useMemo(() => {
    const map: Record<string, number> = {};
    tenants.forEach(t => {
      const label = t.pricing_type === "monthly_5" ? "$5/mo" : t.pricing_type === "white_label_9" ? "$9 WL" : "$249 LT";
      map[label] = (map[label] || 0) + 1;
    });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }));
  }, [tenants]);

  // Tenant creation trend
  const tenantTrend = useMemo(() => {
    const map: Record<string, number> = {};
    tenants.forEach(t => {
      const day = t.created_at?.slice(0, 10) || "";
      if (day) map[day] = (map[day] || 0) + 1;
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).map(([date, count]) => ({ date, count }));
  }, [tenants]);

  // Status distribution
  const statusDist = useMemo(() => {
    const map: Record<string, number> = {};
    tenants.forEach(t => { map[t.status] = (map[t.status] || 0) + 1; });
    return Object.entries(map).map(([name, value], i) => ({ name, value, color: COLORS[i % COLORS.length] }));
  }, [tenants]);

  // Payment trend
  const paymentTrend = useMemo(() => {
    const map: Record<string, number> = {};
    payments.filter(p => p.status === "success").forEach(p => {
      const day = p.created_at?.slice(0, 10) || "";
      if (day) map[day] = (map[day] || 0) + Number(p.amount);
    });
    return Object.entries(map).sort(([a], [b]) => a.localeCompare(b)).map(([date, amount]) => ({ date, amount }));
  }, [payments]);

  const tenantColumns = [
    { key: "business_name", label: "Business", sortable: true },
    { key: "owner_name", label: "Owner", sortable: true },
    { key: "plan_type", label: "Plan", sortable: true, render: (row: any) => <span className="text-xs capitalize">{row.plan_type.replace(/_/g, " ")}</span> },
    { key: "pricing_type", label: "Pricing", sortable: true, render: (row: any) => <span className="text-xs">{row.pricing_type === "monthly_5" ? "$5/mo" : row.pricing_type === "white_label_9" ? "$9 WL" : "$249 LT"}</span> },
    { key: "status", label: "Status", sortable: true, render: (row: any) => <StatusBadge status={row.status} /> },
    { key: "white_label_enabled", label: "WL", sortable: true, render: (row: any) => <span className={cn("text-xs font-medium", row.white_label_enabled ? "text-accent" : "text-muted-foreground")}>{row.white_label_enabled ? "Yes" : "No"}</span> },
  ];

  return (
    <div className="p-4 lg:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Global Analytics</h1>
          <p className="text-sm text-muted-foreground">Cross-tenant platform intelligence</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border border-border bg-card overflow-hidden">
            {dateRanges.map(r => (
              <button key={r} onClick={() => setDateRange(r)} className={cn(
                "px-3 py-1.5 text-xs font-medium transition-colors",
                dateRange === r ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary"
              )}>{r}</button>
            ))}
          </div>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-card text-xs text-muted-foreground hover:bg-secondary transition-colors">
            <Download className="h-3.5 w-3.5" /> Export
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        <KPICard title="Total Tenants" value={String(tenants.length)} trend="up" change={`${activeTenants} active`} icon={Building2} />
        <KPICard title="Active Tenants" value={String(activeTenants)} trend="up" change={`${suspendedTenants} suspended`} icon={Users} />
        <KPICard title="MRR" value={`$${mrr.toFixed(2)}`} trend="up" change="Monthly recurring" icon={DollarSign} />
        <KPICard title="Total Revenue" value={`$${totalPaymentRevenue.toFixed(2)}`} trend="up" change="Successful payments" icon={TrendingUp} />
        <KPICard title="White Label" value={String(whileLabelTenants)} trend="neutral" change={`of ${tenants.length} tenants`} icon={Globe} />
        <KPICard title="System Events" value={String(systemLogs.length)} trend="neutral" change="Recent logs" icon={Activity} />
      </div>

      {/* Charts Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-lg border border-border bg-card p-4">
          <h3 className="text-sm font-semibold text-foreground mb-4">Payment Revenue Trend</h3>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={paymentTrend}>
              <defs>
                <linearGradient id="saRevGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(190, 100%, 50%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
              <XAxis dataKey="date" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip {...chartTooltipStyle} />
              <Area type="monotone" dataKey="amount" stroke="hsl(190, 100%, 50%)" fill="url(#saRevGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <h3 className="text-sm font-semibold text-foreground mb-4">Tenant Status</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={statusDist} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={40} outerRadius={65} strokeWidth={0}>
                {statusDist.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip {...chartTooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
            {statusDist.map(item => (
              <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground capitalize">
                <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
                {item.name} ({item.value})
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Charts Row 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-lg border border-border bg-card p-4">
          <h3 className="text-sm font-semibold text-foreground mb-4">Plan Type Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={tenantsByPlan} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(222, 30%, 16%)" />
              <XAxis type="number" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="name" tick={{ fill: "hsl(215, 20%, 55%)", fontSize: 9 }} axisLine={false} tickLine={false} width={120} />
              <Tooltip {...chartTooltipStyle} />
              <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                {tenantsByPlan.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-lg border border-border bg-card p-4">
          <h3 className="text-sm font-semibold text-foreground mb-4">Pricing Tier Split</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={tenantsByPricing} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} strokeWidth={0} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {tenantsByPricing.map((e, i) => <Cell key={i} fill={e.color} />)}
              </Pie>
              <Tooltip {...chartTooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 justify-center">
            {tenantsByPricing.map(item => (
              <div key={item.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="h-2 w-2 rounded-full" style={{ background: item.color }} />
                {item.name} ({item.value})
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tenant Table */}
      <DataTable title="All Tenants" columns={tenantColumns} data={tenants} pageSize={10} />

      {/* Empty state */}
      {tenants.length === 0 && (
        <div className="rounded-lg border border-border bg-card p-12 text-center">
          <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">No Tenants Yet</h3>
          <p className="text-sm text-muted-foreground">Global analytics will populate once tenants are created.</p>
        </div>
      )}
    </div>
  );
};

export default SAAnalyticsPage;
