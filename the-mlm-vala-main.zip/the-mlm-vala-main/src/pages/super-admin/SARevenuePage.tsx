import ModuleShell, { Category } from "@/components/ModuleShell";
import { BarChart3, TrendingUp } from "lucide-react";

const categories: Category[] = [
  {
    name: "Revenue Overview",
    icon: BarChart3,
    subs: [
      { name: "Total Revenue", nanos: [{ name: "Monthly / Yearly", micros: [{ name: "Export", action: "Export" }] }] },
      { name: "Plan-wise Revenue", nanos: [{ name: "Breakdown", micros: [{ name: "View", action: "View" }] }] },
    ],
  },
  {
    name: "Growth Metrics",
    icon: TrendingUp,
    subs: [
      { name: "Tenant Growth", nanos: [{ name: "Month-over-Month", micros: [{ name: "View", action: "View" }] }] },
      { name: "Churn Rate", nanos: [{ name: "Attrition Stats", micros: [{ name: "View", action: "View" }] }] },
    ],
  },
];

const SARevenuePage = () => (
  <ModuleShell title="Revenue Analytics" description="Real-time revenue monitoring, plan breakdowns, and growth metrics." categories={categories} />
);

export default SARevenuePage;
