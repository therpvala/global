import ModuleShell, { Category } from "@/components/ModuleShell";
import { Cpu, Wrench } from "lucide-react";

const categories: Category[] = [
  {
    name: "22 Plan Presets",
    icon: Cpu,
    subs: [
      {
        name: "Binary Configuration",
        nanos: [{ name: "Commission Rules", micros: [{ name: "Edit", action: "Edit" }] }],
      },
      {
        name: "Unilevel Configuration",
        nanos: [{ name: "Level Settings", micros: [{ name: "Edit", action: "Edit" }] }],
      },
      {
        name: "Matrix Configuration",
        nanos: [{ name: "Width × Depth", micros: [{ name: "Edit", action: "Edit" }] }],
      },
      {
        name: "ROI Configuration",
        nanos: [{ name: "Fixed / Variable", micros: [{ name: "Edit", action: "Edit" }] }],
      },
      {
        name: "Crypto Configuration",
        nanos: [{ name: "Staking / DeFi / Token", micros: [{ name: "Edit", action: "Edit" }] }],
      },
    ],
  },
  {
    name: "Rule Builder",
    icon: Wrench,
    subs: [
      {
        name: "Add Commission Rule",
        nanos: [
          { name: "Save Preset", micros: [{ name: "Assign To Plan", action: "Assign" }] },
        ],
      },
    ],
  },
];

const SAPlanEnginePage = () => (
  <ModuleShell title="Plan Engine Control" description="Configure all 22 MLM plan presets and build custom commission rules." categories={categories} />
);

export default SAPlanEnginePage;
