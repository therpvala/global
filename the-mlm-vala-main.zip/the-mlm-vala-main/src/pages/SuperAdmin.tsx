import Navbar from "@/components/Navbar";
import { Shield } from "lucide-react";

const SuperAdmin = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="flex min-h-screen items-center justify-center pt-16">
      <div className="text-center">
        <Shield size={64} className="mx-auto mb-4 text-primary animate-pulse-glow" />
        <h1 className="text-3xl font-black text-foreground">
          <span className="text-primary text-glow-blue">Super Admin</span> Panel
        </h1>
        <p className="mt-2 text-muted-foreground">Admin dashboard coming soon.</p>
      </div>
    </div>
  </div>
);

export default SuperAdmin;
