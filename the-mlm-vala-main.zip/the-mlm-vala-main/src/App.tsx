import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";
import SuperAdminLayout from "./components/SuperAdminLayout";
import SADashboard from "./pages/super-admin/SADashboard";
import SATenantsPage from "./pages/super-admin/SATenantsPage";
import SALicensesPage from "./pages/super-admin/SALicensesPage";
import SAPlanEnginePage from "./pages/super-admin/SAPlanEnginePage";
import SABillingPage from "./pages/super-admin/SABillingPage";
import SAPaymentGatewaysPage from "./pages/super-admin/SAPaymentGatewaysPage";
import SACommissionsPage from "./pages/super-admin/SACommissionsPage";
import SAWhiteLabelPage from "./pages/super-admin/SAWhiteLabelPage";
import SASystemConfigPage from "./pages/super-admin/SASystemConfigPage";
import SACronPage from "./pages/super-admin/SACronPage";
import SASecurityPage from "./pages/super-admin/SASecurityPage";
import SAAuditLogsPage from "./pages/super-admin/SAAuditLogsPage";
import SASupportPage from "./pages/super-admin/SASupportPage";
import SARevenuePage from "./pages/super-admin/SARevenuePage";
import SABackupPage from "./pages/super-admin/SABackupPage";
import DashboardLayout from "./components/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import MembersPage from "./pages/dashboard/MembersPage";
import NetworkTreePage from "./pages/dashboard/NetworkTreePage";
import CommissionsPage from "./pages/dashboard/CommissionsPage";
import PayoutPage from "./pages/dashboard/PayoutPage";
import WalletPage from "./pages/dashboard/WalletPage";
import RankRewardsPage from "./pages/dashboard/RankRewardsPage";
import PackagesPage from "./pages/dashboard/PackagesPage";
import PoolsPage from "./pages/dashboard/PoolsPage";
import ReportsPage from "./pages/dashboard/ReportsPage";
import IntegrationsPage from "./pages/dashboard/IntegrationsPage";
import SettingsPage from "./pages/dashboard/SettingsPage";
import WhiteLabelPage from "./pages/dashboard/WhiteLabelPage";
import SupportPage from "./pages/dashboard/SupportPage";
import AuditLogsPage from "./pages/dashboard/AuditLogsPage";
import AnalyticsPage from "./pages/dashboard/AnalyticsPage";
import SAAnalyticsPage from "./pages/super-admin/SAAnalyticsPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/super-admin" element={
              <ProtectedRoute requiredRole="super_admin">
                <SuperAdminLayout />
              </ProtectedRoute>
            }>
              <Route index element={<SADashboard />} />
              <Route path="tenants" element={<SATenantsPage />} />
              <Route path="licenses" element={<SALicensesPage />} />
              <Route path="plan-engine" element={<SAPlanEnginePage />} />
              <Route path="billing" element={<SABillingPage />} />
              <Route path="payment-gateways" element={<SAPaymentGatewaysPage />} />
              <Route path="commissions" element={<SACommissionsPage />} />
              <Route path="white-label" element={<SAWhiteLabelPage />} />
              <Route path="system-config" element={<SASystemConfigPage />} />
              <Route path="cron" element={<SACronPage />} />
              <Route path="security" element={<SASecurityPage />} />
              <Route path="audit-logs" element={<SAAuditLogsPage />} />
              <Route path="support" element={<SASupportPage />} />
              <Route path="revenue" element={<SARevenuePage />} />
              <Route path="backup" element={<SABackupPage />} />
              <Route path="analytics" element={<SAAnalyticsPage />} />
            </Route>
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <DashboardLayout />
              </ProtectedRoute>
            }>
              <Route index element={<DashboardHome />} />
              <Route path="members" element={<MembersPage />} />
              <Route path="network-tree" element={<NetworkTreePage />} />
              <Route path="commissions" element={<CommissionsPage />} />
              <Route path="payout" element={<PayoutPage />} />
              <Route path="wallet" element={<WalletPage />} />
              <Route path="rank-rewards" element={<RankRewardsPage />} />
              <Route path="packages" element={<PackagesPage />} />
              <Route path="pools" element={<PoolsPage />} />
              <Route path="reports" element={<ReportsPage />} />
              <Route path="integrations" element={<IntegrationsPage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="white-label" element={<WhiteLabelPage />} />
              <Route path="support" element={<SupportPage />} />
              <Route path="audit-logs" element={<AuditLogsPage />} />
              <Route path="analytics" element={<AnalyticsPage />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
