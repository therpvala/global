export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: string
          module: string | null
          tenant_id: string
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: string
          module?: string | null
          tenant_id: string
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: string
          module?: string | null
          tenant_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "audit_logs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      branding: {
        Row: {
          brand_name: string | null
          created_at: string
          custom_domain: string | null
          id: string
          logo_url: string | null
          primary_color: string | null
          tenant_id: string
          updated_at: string
        }
        Insert: {
          brand_name?: string | null
          created_at?: string
          custom_domain?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          tenant_id: string
          updated_at?: string
        }
        Update: {
          brand_name?: string | null
          created_at?: string
          custom_domain?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "branding_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: true
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      commissions: {
        Row: {
          amount: number
          commission_type: Database["public"]["Enums"]["commission_type"]
          created_at: string
          id: string
          level: number | null
          member_id: string
          source_member_id: string | null
          tenant_id: string
        }
        Insert: {
          amount?: number
          commission_type: Database["public"]["Enums"]["commission_type"]
          created_at?: string
          id?: string
          level?: number | null
          member_id: string
          source_member_id?: string | null
          tenant_id: string
        }
        Update: {
          amount?: number
          commission_type?: Database["public"]["Enums"]["commission_type"]
          created_at?: string
          id?: string
          level?: number | null
          member_id?: string
          source_member_id?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "commissions_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commissions_source_member_id_fkey"
            columns: ["source_member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "commissions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      members: {
        Row: {
          created_at: string
          id: string
          join_date: string
          parent_id: string | null
          position: string | null
          rank_id: string | null
          sponsor_id: string | null
          status: Database["public"]["Enums"]["member_status"]
          tenant_id: string
          user_id: string | null
          username: string
        }
        Insert: {
          created_at?: string
          id?: string
          join_date?: string
          parent_id?: string | null
          position?: string | null
          rank_id?: string | null
          sponsor_id?: string | null
          status?: Database["public"]["Enums"]["member_status"]
          tenant_id: string
          user_id?: string | null
          username: string
        }
        Update: {
          created_at?: string
          id?: string
          join_date?: string
          parent_id?: string | null
          position?: string | null
          rank_id?: string | null
          sponsor_id?: string | null
          status?: Database["public"]["Enums"]["member_status"]
          tenant_id?: string
          user_id?: string | null
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_members_rank"
            columns: ["rank_id"]
            isOneToOne: false
            referencedRelation: "ranks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "members_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "members_sponsor_id_fkey"
            columns: ["sponsor_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "members_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      packages: {
        Row: {
          bv: number
          created_at: string
          id: string
          name: string
          price: number
          pv: number
          status: string
          tenant_id: string
        }
        Insert: {
          bv?: number
          created_at?: string
          id?: string
          name: string
          price?: number
          pv?: number
          status?: string
          tenant_id: string
        }
        Update: {
          bv?: number
          created_at?: string
          id?: string
          name?: string
          price?: number
          pv?: number
          status?: string
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "packages_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          created_at: string
          currency: string
          gateway: string
          id: string
          status: Database["public"]["Enums"]["payment_status"]
          tenant_id: string
          transaction_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          gateway?: string
          id?: string
          status?: Database["public"]["Enums"]["payment_status"]
          tenant_id: string
          transaction_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          gateway?: string
          id?: string
          status?: Database["public"]["Enums"]["payment_status"]
          tenant_id?: string
          transaction_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payments_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      payouts: {
        Row: {
          amount: number
          created_at: string
          id: string
          member_id: string
          processed_at: string | null
          request_date: string
          status: Database["public"]["Enums"]["payout_status"]
          tenant_id: string
          transaction_reference: string | null
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          member_id: string
          processed_at?: string | null
          request_date?: string
          status?: Database["public"]["Enums"]["payout_status"]
          tenant_id: string
          transaction_reference?: string | null
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          member_id?: string
          processed_at?: string | null
          request_date?: string
          status?: Database["public"]["Enums"]["payout_status"]
          tenant_id?: string
          transaction_reference?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payouts_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: false
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payouts_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      plan_configurations: {
        Row: {
          config_key: string
          config_value: Json
          created_at: string
          description: string | null
          id: string
          plan_type: Database["public"]["Enums"]["plan_type"]
          updated_at: string
        }
        Insert: {
          config_key: string
          config_value?: Json
          created_at?: string
          description?: string | null
          id?: string
          plan_type: Database["public"]["Enums"]["plan_type"]
          updated_at?: string
        }
        Update: {
          config_key?: string
          config_value?: Json
          created_at?: string
          description?: string | null
          id?: string
          plan_type?: Database["public"]["Enums"]["plan_type"]
          updated_at?: string
        }
        Relationships: []
      }
      pools: {
        Row: {
          created_at: string
          distribution_type: string
          id: string
          name: string
          qualification_rule: string | null
          tenant_id: string
        }
        Insert: {
          created_at?: string
          distribution_type?: string
          id?: string
          name: string
          qualification_rule?: string | null
          tenant_id: string
        }
        Update: {
          created_at?: string
          distribution_type?: string
          id?: string
          name?: string
          qualification_rule?: string | null
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "pools_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      ranks: {
        Row: {
          bonus_amount: number
          created_at: string
          id: string
          name: string
          required_pv: number
          required_team_volume: number
          sort_order: number
          tenant_id: string
        }
        Insert: {
          bonus_amount?: number
          created_at?: string
          id?: string
          name: string
          required_pv?: number
          required_team_volume?: number
          sort_order?: number
          tenant_id: string
        }
        Update: {
          bonus_amount?: number
          created_at?: string
          id?: string
          name?: string
          required_pv?: number
          required_team_volume?: number
          sort_order?: number
          tenant_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ranks_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      subscriptions: {
        Row: {
          amount: number
          billing_cycle: string
          created_at: string
          id: string
          next_due_date: string | null
          payment_status: Database["public"]["Enums"]["payment_status"]
          tenant_id: string
          updated_at: string
        }
        Insert: {
          amount?: number
          billing_cycle?: string
          created_at?: string
          id?: string
          next_due_date?: string | null
          payment_status?: Database["public"]["Enums"]["payment_status"]
          tenant_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          billing_cycle?: string
          created_at?: string
          id?: string
          next_due_date?: string | null
          payment_status?: Database["public"]["Enums"]["payment_status"]
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      system_logs: {
        Row: {
          action_type: string
          admin_id: string | null
          created_at: string
          description: string | null
          id: string
          tenant_id: string | null
        }
        Insert: {
          action_type: string
          admin_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          tenant_id?: string | null
        }
        Update: {
          action_type?: string
          admin_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          tenant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "system_logs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          business_name: string
          created_at: string
          email: string
          expiry_date: string | null
          id: string
          license_key: string | null
          owner_name: string
          owner_user_id: string | null
          plan_type: Database["public"]["Enums"]["plan_type"]
          pricing_type: Database["public"]["Enums"]["pricing_type"]
          status: Database["public"]["Enums"]["tenant_status"]
          updated_at: string
          white_label_enabled: boolean
        }
        Insert: {
          business_name: string
          created_at?: string
          email: string
          expiry_date?: string | null
          id?: string
          license_key?: string | null
          owner_name: string
          owner_user_id?: string | null
          plan_type?: Database["public"]["Enums"]["plan_type"]
          pricing_type?: Database["public"]["Enums"]["pricing_type"]
          status?: Database["public"]["Enums"]["tenant_status"]
          updated_at?: string
          white_label_enabled?: boolean
        }
        Update: {
          business_name?: string
          created_at?: string
          email?: string
          expiry_date?: string | null
          id?: string
          license_key?: string | null
          owner_name?: string
          owner_user_id?: string | null
          plan_type?: Database["public"]["Enums"]["plan_type"]
          pricing_type?: Database["public"]["Enums"]["pricing_type"]
          status?: Database["public"]["Enums"]["tenant_status"]
          updated_at?: string
          white_label_enabled?: boolean
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          id: string
          income_wallet: number
          member_id: string
          repurchase_wallet: number
          roi_wallet: number
          tenant_id: string
          updated_at: string
        }
        Insert: {
          id?: string
          income_wallet?: number
          member_id: string
          repurchase_wallet?: number
          roi_wallet?: number
          tenant_id: string
          updated_at?: string
        }
        Update: {
          id?: string
          income_wallet?: number
          member_id?: string
          repurchase_wallet?: number
          roi_wallet?: number
          tenant_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallets_member_id_fkey"
            columns: ["member_id"]
            isOneToOne: true
            referencedRelation: "members"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wallets_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "super_admin" | "admin" | "moderator" | "user"
      commission_type:
        | "direct_referral"
        | "level_override"
        | "matching_bonus"
        | "binary_pair"
        | "matrix_fill"
        | "pool_share"
        | "roi_credit"
        | "rank_bonus"
        | "generation_bonus"
        | "board_cycle"
        | "revenue_share"
        | "staking_reward"
        | "defi_yield"
        | "token_reward"
      member_status: "active" | "inactive" | "blocked"
      payment_status: "success" | "failed" | "pending" | "refunded"
      payout_status: "pending" | "approved" | "rejected" | "processed"
      plan_type:
        | "binary"
        | "unilevel"
        | "matrix"
        | "stairstep_breakaway"
        | "generation"
        | "monoline"
        | "board_cycler"
        | "australian_2up"
        | "party"
        | "single_leg"
        | "hybrid"
        | "multi_tier_affiliate"
        | "dual_team"
        | "fixed_roi"
        | "variable_roi"
        | "revenue_sharing"
        | "smart_contract_mlm"
        | "staking_referral"
        | "defi_reward"
        | "tokenized_reward"
      pricing_type: "monthly_5" | "white_label_9" | "lifetime_249"
      tenant_status: "active" | "suspended" | "expired" | "pending"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["super_admin", "admin", "moderator", "user"],
      commission_type: [
        "direct_referral",
        "level_override",
        "matching_bonus",
        "binary_pair",
        "matrix_fill",
        "pool_share",
        "roi_credit",
        "rank_bonus",
        "generation_bonus",
        "board_cycle",
        "revenue_share",
        "staking_reward",
        "defi_yield",
        "token_reward",
      ],
      member_status: ["active", "inactive", "blocked"],
      payment_status: ["success", "failed", "pending", "refunded"],
      payout_status: ["pending", "approved", "rejected", "processed"],
      plan_type: [
        "binary",
        "unilevel",
        "matrix",
        "stairstep_breakaway",
        "generation",
        "monoline",
        "board_cycler",
        "australian_2up",
        "party",
        "single_leg",
        "hybrid",
        "multi_tier_affiliate",
        "dual_team",
        "fixed_roi",
        "variable_roi",
        "revenue_sharing",
        "smart_contract_mlm",
        "staking_referral",
        "defi_reward",
        "tokenized_reward",
      ],
      pricing_type: ["monthly_5", "white_label_9", "lifetime_249"],
      tenant_status: ["active", "suspended", "expired", "pending"],
    },
  },
} as const
