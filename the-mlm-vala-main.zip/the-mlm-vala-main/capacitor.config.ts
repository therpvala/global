import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.df9368c2a70a4e6db0ed61ee8d3c56e4',
  appName: 'MLM Vala',
  webDir: 'dist',
  server: {
    url: 'https://df9368c2-a70a-4e6d-b0ed-61ee8d3c56e4.lovableproject.com?forceHideBadge=true',
    cleartext: true
  }
};

export default config;
