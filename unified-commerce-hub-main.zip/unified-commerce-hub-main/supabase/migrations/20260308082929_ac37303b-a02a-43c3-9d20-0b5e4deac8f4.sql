
-- Fix the existing super admin demo account role
UPDATE public.user_roles 
SET role = 'super_admin' 
WHERE user_id = 'd4981431-ad55-4122-b131-82a20e1152a6';
