
CREATE OR REPLACE FUNCTION public.get_user_role(_user_id uuid)
 RETURNS app_role
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $$
  SELECT role
  FROM public.user_roles
  WHERE user_id = _user_id
  ORDER BY 
    CASE role 
      WHEN 'super_admin' THEN 0
      WHEN 'admin' THEN 1 
      WHEN 'owner' THEN 2 
      WHEN 'manager' THEN 3
      WHEN 'inventory_manager' THEN 4
      WHEN 'accountant' THEN 5
      WHEN 'cashier' THEN 6 
    END
  LIMIT 1
$$;
