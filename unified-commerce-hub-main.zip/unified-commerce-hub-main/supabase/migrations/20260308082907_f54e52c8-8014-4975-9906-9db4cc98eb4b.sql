
-- Update the trigger function to read role from user metadata
CREATE OR REPLACE FUNCTION public.handle_new_user_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _role public.app_role;
BEGIN
  -- Read the selected role from user metadata, default to 'cashier'
  _role := COALESCE(
    (NEW.raw_user_meta_data->>'selected_role')::public.app_role,
    'cashier'
  );
  
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, _role);
  
  RETURN NEW;
END;
$$;
