
ALTER TYPE public.app_role ADD VALUE 'inventory_manager';
ALTER TYPE public.app_role ADD VALUE 'accountant';
