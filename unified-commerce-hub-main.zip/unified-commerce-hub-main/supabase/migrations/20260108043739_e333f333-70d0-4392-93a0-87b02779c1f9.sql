-- Fix the permissive audit logs insert policy
DROP POLICY IF EXISTS "System can insert audit logs" ON public.audit_logs;

-- Create a more restrictive policy - only allow inserts via the log_audit_event function
-- The function uses SECURITY DEFINER so it can insert without RLS
-- We'll restrict direct inserts to authenticated users only
CREATE POLICY "Authenticated can insert audit logs"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Also add policy for service role / triggers (anon role shouldn't insert)
CREATE POLICY "Service role can insert audit logs"
ON public.audit_logs
FOR INSERT
TO service_role
WITH CHECK (true);