import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { 
  Search, 
  RefreshCw, 
  Shield, 
  UserCheck, 
  UserX, 
  Key, 
  LogIn, 
  LogOut,
  AlertTriangle,
  Clock,
  User,
  Loader2
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { Json } from '@/integrations/supabase/types';

interface AuditLog {
  id: string;
  event_type: string;
  event_category: string;
  actor_id: string | null;
  target_id: string | null;
  details: Json;
  created_at: string;
  actor_name?: string;
  target_name?: string;
}

const eventTypeConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  role_assigned: { icon: Shield, color: 'text-accent', label: 'Role Assigned' },
  role_changed: { icon: Key, color: 'text-warning', label: 'Role Changed' },
  role_removed: { icon: AlertTriangle, color: 'text-destructive', label: 'Role Removed' },
  user_activated: { icon: UserCheck, color: 'text-success', label: 'User Activated' },
  user_deactivated: { icon: UserX, color: 'text-destructive', label: 'User Deactivated' },
  login_success: { icon: LogIn, color: 'text-success', label: 'Login Success' },
  login_failed: { icon: AlertTriangle, color: 'text-destructive', label: 'Login Failed' },
  logout: { icon: LogOut, color: 'text-muted-foreground', label: 'Logout' },
};

export function AuditLogViewer() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [profiles, setProfiles] = useState<Record<string, string>>({});

  const fetchLogs = async () => {
    setLoading(true);
    
    const { data: logsData, error: logsError } = await supabase
      .from('audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);
    
    if (logsError) {
      toast.error('Failed to fetch audit logs');
      setLoading(false);
      return;
    }

    // Fetch all related profiles for actor and target names
    const userIds = new Set<string>();
    logsData?.forEach(log => {
      if (log.actor_id) userIds.add(log.actor_id);
      if (log.target_id) userIds.add(log.target_id);
    });

    if (userIds.size > 0) {
      const { data: profilesData } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', Array.from(userIds));
      
      const profileMap: Record<string, string> = {};
      profilesData?.forEach(p => {
        profileMap[p.id] = p.full_name || p.email || 'Unknown';
      });
      setProfiles(profileMap);
    }

    setLogs(logsData || []);
    setLoading(false);
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const filteredLogs = logs.filter(log => {
    const matchesSearch = !searchQuery || 
      log.event_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profiles[log.actor_id || '']?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      profiles[log.target_id || '']?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || log.event_category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const getEventConfig = (eventType: string) => {
    return eventTypeConfig[eventType] || { 
      icon: Clock, 
      color: 'text-muted-foreground', 
      label: eventType.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) 
    };
  };

  const formatDetails = (details: Json) => {
    if (!details || typeof details !== 'object' || Array.isArray(details)) return null;
    
    const entries = Object.entries(details as Record<string, unknown>);
    if (entries.length === 0) return null;
    
    return entries.map(([key, value]) => (
      <span key={key} className="inline-flex items-center gap-1 text-xs">
        <span className="text-muted-foreground">{key.replace(/_/g, ' ')}:</span>
        <Badge variant="outline" className="text-xs font-mono">
          {String(value).toUpperCase().replace('_', ' ')}
        </Badge>
      </span>
    ));
  };

  return (
    <Card className="card-3d border-amber-500/30">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="font-display text-xl tracking-wider flex items-center gap-2">
            <Clock className="h-5 w-5 text-amber-400" />
            Audit Log
          </CardTitle>
          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-48 bg-secondary/50"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40 bg-secondary/50">
                <SelectValue placeholder="Filter category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="user_management">User Management</SelectItem>
                <SelectItem value="authentication">Authentication</SelectItem>
                <SelectItem value="security">Security</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={fetchLogs} variant="outline" size="icon" className="border-amber-500/30 hover:bg-amber-500/10">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
          </div>
        ) : filteredLogs.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No audit logs found</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {filteredLogs.map((log) => {
                const config = getEventConfig(log.event_type);
                const Icon = config.icon;
                
                return (
                  <div
                    key={log.id}
                    className="flex items-start gap-4 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                  >
                    <div className={`mt-1 p-2 rounded-lg bg-secondary ${config.color}`}>
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{config.label}</span>
                        <Badge variant="outline" className="text-xs">
                          {log.event_category.replace(/_/g, ' ')}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground mt-1">
                        {log.actor_id && (
                          <span className="inline-flex items-center gap-1">
                            <User className="h-3 w-3" />
                            <span className="font-medium text-foreground">
                              {profiles[log.actor_id] || 'System'}
                            </span>
                          </span>
                        )}
                        {log.target_id && log.actor_id !== log.target_id && (
                          <span>
                            {' → '}
                            <span className="font-medium text-foreground">
                              {profiles[log.target_id] || 'Unknown'}
                            </span>
                          </span>
                        )}
                      </div>
                      {log.details && typeof log.details === 'object' && !Array.isArray(log.details) && Object.keys(log.details).length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {formatDetails(log.details)}
                        </div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDistanceToNow(new Date(log.created_at), { addSuffix: true })}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
