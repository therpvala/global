import { useAuth } from '@/contexts/AuthContext';
import Dashboard from '@/pages/Dashboard';
import SuperAdminDashboard from '@/pages/SuperAdminDashboard';
import AdminDashboard from '@/pages/AdminDashboard';
import OwnerDashboard from '@/pages/OwnerDashboard';
import ManagerDashboard from '@/pages/ManagerDashboard';
import InventoryManagerDashboard from '@/pages/InventoryManagerDashboard';
import AccountantDashboard from '@/pages/AccountantDashboard';
import CashierDashboard from '@/pages/CashierDashboard';
import { Loader2 } from 'lucide-react';

export function RoleBasedDashboard() {
  const { user, role, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Dashboard />;
  }

  switch (role) {
    case 'super_admin':
      return <SuperAdminDashboard />;
    case 'admin':
      return <AdminDashboard />;
    case 'owner':
      return <OwnerDashboard />;
    case 'manager':
      return <ManagerDashboard />;
    case 'inventory_manager':
      return <InventoryManagerDashboard />;
    case 'accountant':
      return <AccountantDashboard />;
    case 'cashier':
      return <CashierDashboard />;
    default:
      return <Dashboard />;
  }
}
