import { Button } from "@/components/ui/button";
import { Receipt, Menu, X } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function LandingNavbar({ onSignIn, onPrimary }: { onSignIn: () => void; onPrimary: () => void }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const links = [
    { href: "#features", label: "Features" },
    { href: "#why-us", label: "Why Us" },
    { href: "#roles", label: "Roles" },
    { href: "#pricing", label: "Pricing" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-white/10 bg-[#050831]/90 backdrop-blur-xl">
      <div className="container-wide">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl border border-[#F946AB]/40 bg-gradient-to-br from-[#F946AB]/20 to-[#415BA7]/20 flex items-center justify-center">
              <Receipt className="h-5 w-5 text-[#F946AB]" />
            </div>
            <span className="font-display text-xl font-black text-white">
              Smart<span className="text-[#F946AB]">POS</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <a key={link.href} href={link.href} className="text-sm font-semibold text-white/80 hover:text-[#F946AB] transition-colors">
                {link.label}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={onSignIn}
              className="hidden sm:inline-flex border border-white/30 text-white hover:bg-white/10 hover:border-[#F946AB] bg-transparent">
              Login
            </Button>
            <Button size="sm" onClick={onPrimary}
              className="bg-gradient-to-r from-[#F946AB] to-[#E1035A] text-white font-bold hover:opacity-90 border-0">
              Get Started Free
            </Button>
            <Button variant="ghost" size="icon" className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        <div className={cn("md:hidden overflow-hidden transition-all duration-300", mobileMenuOpen ? "max-h-48 pb-4" : "max-h-0")}>
          <div className="flex flex-col gap-3">
            {links.map((link) => (
              <a key={link.href} href={link.href} className="text-sm font-semibold text-white/80 hover:text-[#F946AB] py-2">
                {link.label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
