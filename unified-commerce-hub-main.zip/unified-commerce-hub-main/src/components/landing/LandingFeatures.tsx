import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Icon3D } from "@/components/ui/Icon3D";
import {
  Receipt, CreditCard, Package, BarChart3, Users, ShieldCheck,
  Zap, Globe, Smartphone, Cloud, Bell, Lock, Rocket, ScanBarcode,
  Heart, UserCog
} from "lucide-react";

const features = [
  { icon: Zap, title: "Smart Billing", description: "Lightning-fast billing with auto tax calculation and instant receipt generation.", color: "pink" as const },
  { icon: ScanBarcode, title: "Barcode Scanning", description: "Scan products instantly with barcode support for faster checkout.", color: "medium" as const },
  { icon: Package, title: "Inventory Management", description: "Real-time stock tracking with low-stock alerts and automated reorder suggestions.", color: "dark" as const },
  { icon: CreditCard, title: "Multi Payment Support", description: "Accept cash, cards, UPI, wallets, and split payments seamlessly.", color: "pink" as const },
  { icon: Receipt, title: "GST Ready Billing", description: "Generate compliant invoices with automatic tax calculations.", color: "medium" as const },
  { icon: BarChart3, title: "Sales Reports", description: "Comprehensive dashboards with sales trends, profit margins, and insights.", color: "dark" as const },
  { icon: Users, title: "Customer Management", description: "Customer profiles, purchase history, and loyalty points tracking.", color: "pink" as const },
  { icon: UserCog, title: "Staff Management", description: "Manage employees, shifts, and performance tracking.", color: "medium" as const },
  { icon: BarChart3, title: "Analytics Dashboard", description: "Real-time analytics with interactive charts and business intelligence.", color: "dark" as const },
  { icon: Cloud, title: "Cloud Backup", description: "Automatic cloud sync ensures your data is always safe and accessible.", color: "pink" as const },
];

const additionalFeatures = [
  { icon: Globe, label: "Multi-Store", desc: "Manage all branches" },
  { icon: Smartphone, label: "Mobile Ready", desc: "Works on any device" },
  { icon: Bell, label: "Smart Alerts", desc: "Instant notifications" },
  { icon: Lock, label: "Data Privacy", desc: "Your data, your control" },
  { icon: Heart, label: "Loyalty System", desc: "Reward customers" },
  { icon: ShieldCheck, label: "Secure Access", desc: "Role-based permissions" },
];

export function LandingFeatures() {
  return (
    <section id="features" className="py-24 bg-gradient-to-b from-[#050831] to-[#133072]">
      <div className="container-wide">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#F946AB]/30 bg-[#F946AB]/10 px-4 py-2 mb-6">
            <Zap className="h-4 w-4 text-[#F946AB]" />
            <span className="text-sm font-bold text-[#F946AB]">Powerful Features</span>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-black text-white">
            Everything You Need to
            <span className="block mt-2 bg-gradient-to-r from-[#F946AB] to-[#5AA5E4] bg-clip-text text-transparent">
              Run Your Business
            </span>
          </h2>
          <p className="mt-6 max-w-2xl mx-auto text-lg text-white/70">
            From quick billing to detailed analytics, our POS suite covers every aspect of modern retail operations.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {features.map((feature, index) => (
            <Card
              key={feature.title}
              className="group rounded-2xl border border-white/10 bg-white/5 backdrop-blur-md transition-all duration-300 hover:border-[#F946AB]/50 hover:shadow-[0_0_40px_rgba(249,70,171,0.1)] animate-fade-in"
              style={{ animationDelay: `${index * 80}ms` }}
            >
              <CardHeader className="pb-3">
                <Icon3D icon={feature.icon} color={feature.color} size="lg" animated className="group-hover:scale-110 transition-transform" />
                <CardTitle className="font-display text-base font-bold text-white mt-3">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-white/65 text-sm leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Features Strip */}
        <div className="mt-20 rounded-3xl border border-white/10 bg-white/3 p-8 backdrop-blur-md">
          <h3 className="text-center font-display text-2xl font-bold text-white mb-8">And Much More...</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {additionalFeatures.map((item) => (
              <div key={item.label} className="text-center group cursor-pointer">
                <div className="mx-auto h-14 w-14 rounded-2xl border border-white/15 bg-white/5 flex items-center justify-center mb-3 transition-all group-hover:border-[#F946AB]/50 group-hover:bg-[#F946AB]/10">
                  <item.icon className="h-6 w-6 text-[#F946AB]" />
                </div>
                <p className="font-bold text-sm text-white">{item.label}</p>
                <p className="text-xs text-white/60 mt-1">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Banner */}
        <div className="mt-16 rounded-3xl border border-[#F946AB]/30 bg-gradient-to-r from-[#133072]/50 to-[#F946AB]/10 p-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <Icon3D icon={Rocket} color="rose" size="lg" animated />
            <div>
              <p className="font-display text-xl font-bold text-white">Ready to modernize your counter?</p>
              <p className="text-sm text-white/70">Start with sign-in, add products, and bill instantly.</p>
            </div>
          </div>
          <div className="text-sm font-bold text-[#F946AB]">No clutter. Just speed.</div>
        </div>
      </div>
    </section>
  );
}
