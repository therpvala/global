import { Button } from "@/components/ui/button";
import { Icon3D } from "@/components/ui/Icon3D";
import { ChevronRight, Play, Store, Receipt, Timer, BarChart3, ShieldCheck, Zap, TrendingUp, Package } from "lucide-react";
import heroPOSBg from "@/assets/hero-pos-bg.jpg";

export function LandingHero({ onPrimaryCta, onSecondaryCta }: { onPrimaryCta: () => void; onSecondaryCta: () => void }) {
  return (
    <section className="pt-24 pb-16 bg-[#050831]">
      <div className="container-wide">
        {/* Compact Split Layout */}
        <div className="grid lg:grid-cols-2 gap-8 items-stretch">
          {/* Left Card - Content */}
          <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#133072]/60 to-[#050831] p-8 md:p-10 backdrop-blur-md flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#F946AB]/40 bg-[#F946AB]/10 px-4 py-2 w-fit mb-6">
              <Zap className="h-4 w-4 text-[#F946AB]" />
              <span className="text-xs font-bold tracking-wide text-white">AI-Powered POS Software</span>
            </div>

            <h1 className="font-display text-4xl md:text-5xl font-black leading-[1.1] text-white">
              Smart POS
              <span className="block mt-2 bg-gradient-to-r from-[#F946AB] to-[#E1035A] bg-clip-text text-transparent">
                Billing System
              </span>
            </h1>

            <p className="mt-5 text-base text-white/80 leading-relaxed max-w-lg">
              Fast, Secure and Intelligent Billing System for Retail Stores, Shops and Businesses.
              GST-ready invoices, inventory sync, and real-time analytics.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button size="lg" onClick={onPrimaryCta}
                className="gap-2 bg-gradient-to-r from-[#F946AB] to-[#E1035A] hover:from-[#E1035A] hover:to-[#F946AB] text-white font-bold shadow-[0_0_25px_rgba(249,70,171,0.3)] border border-[#F946AB]/50">
                Get Started Free <ChevronRight className="h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={onSecondaryCta}
                className="gap-2 border border-white/30 text-white hover:bg-white/10 hover:border-[#F946AB] font-bold bg-transparent">
                <Play className="h-4 w-4" /> Watch Demo
              </Button>
            </div>

            {/* Compact Stats Row */}
            <div className="mt-8 grid grid-cols-3 gap-3">
              {[
                { icon: Store, label: "Active Stores", value: "500+" },
                { icon: Receipt, label: "Daily Transactions", value: "50K+" },
                { icon: Timer, label: "Avg Checkout", value: "< 8s" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-xl border border-white/15 bg-white/5 p-3 backdrop-blur-md text-center">
                  <Icon3D icon={stat.icon} color="rose" size="sm" animated className="mx-auto mb-1.5" />
                  <p className="font-display text-lg font-black text-white">{stat.value}</p>
                  <p className="text-[10px] text-white/60 mt-0.5">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Card - Image + Dashboard Preview */}
          <div className="rounded-3xl border border-white/10 overflow-hidden relative min-h-[480px]">
            <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroPOSBg})` }} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#050831]/95 via-[#050831]/40 to-transparent" />

            {/* Floating Dashboard Card */}
            <div className="absolute bottom-6 left-6 right-6 z-10">
              <div className="rounded-2xl border border-[#F946AB]/30 bg-[#050831]/85 p-5 backdrop-blur-xl">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-[10px] font-bold tracking-widest text-[#F946AB] uppercase">Live Dashboard</p>
                    <p className="font-display text-lg font-black text-white">Today's Snapshot</p>
                  </div>
                  <div className="h-10 w-10 rounded-xl border border-[#F946AB]/40 bg-[#F946AB]/15 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5 text-[#F946AB]" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { icon: Receipt, label: "Bills", value: "128" },
                    { icon: BarChart3, label: "Revenue", value: "₹3.9L" },
                    { icon: Package, label: "Low Stock", value: "7" },
                  ].map((s) => (
                    <div key={s.label} className="rounded-xl border border-white/10 bg-white/5 p-3 text-center">
                      <s.icon className="h-4 w-4 text-[#F946AB] mx-auto mb-1" />
                      <p className="font-display text-base font-black text-white">{s.value}</p>
                      <p className="text-[10px] text-white/60">{s.label}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-xl border border-[#415BA7]/30 bg-[#415BA7]/10 p-3 flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-[#5AA5E4]" />
                  <p className="text-xs font-semibold text-white">Enterprise Security — Role-based access with audit trails</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
