import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useCreateInventoryMovement } from "@/hooks/useInventory";
import { useProducts } from "@/hooks/useProducts";
import { toast } from "sonner";
import { Plus } from "lucide-react";

export function StockMovementModal() {
  const [open, setOpen] = useState(false);
  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [movementType, setMovementType] = useState<"in" | "out" | "adjustment" | "transfer">("in");
  const [reason, setReason] = useState("");

  const { data: products } = useProducts();
  const createMovement = useCreateInventoryMovement();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productId || !quantity) {
      toast.error("Please select a product and enter a quantity.");
      return;
    }

    const qty = parseInt(quantity, 10);
    if (isNaN(qty) || qty === 0) {
      toast.error("Quantity must be a non-zero number.");
      return;
    }

    // For 'out' type, make quantity negative
    const finalQty = movementType === "out" ? -Math.abs(qty) : Math.abs(qty);

    try {
      await createMovement.mutateAsync({
        productId,
        quantity: finalQty,
        movementType,
        reason: reason.trim() || undefined,
      });
      toast.success("Stock movement recorded successfully!");
      setOpen(false);
      setProductId("");
      setQuantity("");
      setMovementType("in");
      setReason("");
    } catch (err: any) {
      toast.error(err.message || "Failed to create stock movement.");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-[hsl(var(--emerald))] hover:bg-[hsl(var(--emerald)/0.9)] text-white font-bold gap-2">
          <Plus className="h-4 w-4" /> Add Movement
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display font-black text-xl">Record Stock Movement</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div className="space-y-2">
            <Label htmlFor="product">Product</Label>
            <Select value={productId} onValueChange={setProductId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a product" />
              </SelectTrigger>
              <SelectContent>
                {(products || []).map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name} (Stock: {p.stock})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="type">Movement Type</Label>
            <Select value={movementType} onValueChange={(v) => setMovementType(v as any)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="in">Stock In</SelectItem>
                <SelectItem value="out">Stock Out</SelectItem>
                <SelectItem value="adjustment">Adjustment</SelectItem>
                <SelectItem value="transfer">Transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">Quantity</Label>
            <Input
              id="quantity"
              type="number"
              min="1"
              placeholder="Enter quantity"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason (optional)</Label>
            <Textarea
              id="reason"
              placeholder="e.g. New shipment received, Damaged goods..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="resize-none"
              maxLength={500}
            />
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button
              type="submit"
              disabled={createMovement.isPending}
              className="bg-[hsl(var(--emerald))] hover:bg-[hsl(var(--emerald)/0.9)] text-white font-bold"
            >
              {createMovement.isPending ? "Saving..." : "Record Movement"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
