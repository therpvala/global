import { Bell, Crown, Search, User, Wifi, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { ThemeToggleButton } from "@/components/theme/ThemeToggleButton";
import { MobileSidebar } from "./MobileSidebar";
import { cn } from "@/lib/utils";

export function Header() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [currentTime, setCurrentTime] = useState(new Date());
  const { profile, role, signOut } = useAuth();
  const navigate = useNavigate();
  const isSuperAdmin = role === "super_admin";

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      clearInterval(timer);
    };
  }, []);

  const handleSignOut = async () => {
    await signOut();
    navigate("/auth");
  };

  return (
    <header className="sticky top-0 z-30 h-16 border-b border-border bg-card/90 backdrop-blur-xl">
      <div className="flex h-full items-center justify-between px-4 lg:px-6">
        <div className="flex items-center gap-3">
          <MobileSidebar />
          <div>
            <h1 className="font-display text-lg font-bold flex items-center gap-2 text-foreground">
              {isSuperAdmin && <Crown className="h-5 w-5 text-primary" />}
              Dashboard
              <span className="text-muted-foreground">•</span>
              <span className="text-primary font-black">
                {role === "super_admin" ? "Super Admin" : role?.replace("_", " ").replace(/\b\w/g, (l) => l.toUpperCase())}
              </span>
            </h1>
            <p className="text-xs font-medium text-muted-foreground">{currentTime.toLocaleTimeString()}</p>
          </div>
        </div>

        <div className="relative w-80 hidden lg:block">
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search products, orders…"
            className="pl-11 rounded-xl h-10 font-medium border bg-background"
          />
        </div>

        <div className="flex items-center gap-4">
          <ThemeToggleButton />
          <div className="flex items-center gap-2">
            {isOnline ? (
              <Badge variant="outline" className="gap-1.5 rounded-full font-bold border-[hsl(var(--success)/0.3)] bg-[hsl(var(--success)/0.1)] text-[hsl(var(--success))]">
                <Wifi className="h-3 w-3" /><span className="hidden sm:inline text-xs">Online</span>
              </Badge>
            ) : (
              <Badge variant="outline" className="gap-1.5 rounded-full border-destructive/30 bg-destructive/10 text-destructive font-bold">
                <WifiOff className="h-3 w-3" /><span className="hidden sm:inline text-xs">Offline</span>
              </Badge>
            )}
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative rounded-xl hover:bg-muted">
                <Bell className="h-5 w-5 text-muted-foreground" />
                <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">3</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 rounded-2xl border bg-popover p-2">
              <DropdownMenuLabel className="font-bold px-3 py-2">Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="flex flex-col items-start gap-1 py-3 px-3 cursor-pointer rounded-xl">
                <span className="font-bold text-primary">Low Stock Alert</span>
                <span className="text-xs text-muted-foreground">Chocolate Croissant is running low (12 left)</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="flex flex-col items-start gap-1 py-3 px-3 cursor-pointer rounded-xl">
                <span className="font-bold text-secondary">New Order</span>
                <span className="text-xs text-muted-foreground">Order #1235 received - $45.99</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="gap-3 px-2 rounded-xl hover:bg-muted">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl border overflow-hidden border-primary/30 bg-primary/10">
                  {profile?.avatar_url ? (
                    <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
                  ) : (
                    <User className="h-4 w-4 text-primary" />
                  )}
                </div>
                <div className="hidden text-left lg:block">
                  <p className="text-sm font-bold text-foreground">{profile?.full_name || "User"}</p>
                  <p className="text-[11px] capitalize font-medium text-primary">
                    {role?.replace("_", " ") || "Guest"}
                  </p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 rounded-2xl border bg-popover p-2">
              <DropdownMenuLabel className="font-bold px-3 py-2">My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-2 font-medium" onClick={() => navigate("/settings")}>Profile</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-2 font-medium" onClick={() => navigate("/settings")}>Settings</DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-2 font-medium">Help & Support</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="cursor-pointer rounded-xl px-3 py-2 font-bold text-primary" onClick={handleSignOut}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
