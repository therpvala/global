import { useState } from "react";
import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { SidebarContent } from "./Sidebar";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

export function MobileSidebar() {
  const [open, setOpen] = useState(false);
  const { role } = useAuth();
  const isSuperAdmin = role === "super_admin";

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden rounded-xl hover:bg-muted"
        >
          <Menu className="h-5 w-5 text-muted-foreground" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent
        side="left"
        className={cn(
          "w-72 p-0 flex flex-col border-r",
          isSuperAdmin
            ? "bg-gradient-to-b from-[hsl(var(--slate))] to-[hsl(215,30%,18%)] border-[hsl(var(--rose)/0.3)]"
            : "bg-[hsl(var(--sidebar-background))] border-[hsl(var(--sidebar-border))]"
        )}
      >
        <SidebarContent collapsed={false} onNavClick={() => setOpen(false)} />
      </SheetContent>
    </Sheet>
  );
}
