import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/AuthContext";
import {
  BarChart3, Boxes, ChevronLeft, ChevronRight, Crown, History,
  LayoutDashboard, LogOut, Package, Receipt, Settings, ShoppingCart,
  Truck, User, Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: ShoppingCart, label: "Sales", path: "/pos" },
  { icon: Package, label: "Products", path: "/products" },
  { icon: Boxes, label: "Inventory", path: "/inventory" },
  { icon: Truck, label: "Suppliers", path: "/suppliers" },
  { icon: History, label: "Transactions", path: "/transactions" },
  { icon: Users, label: "Customers", path: "/customers" },
  { icon: User, label: "Employees", path: "/employees" },
  { icon: BarChart3, label: "Reports", path: "/reports" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

const roleAccess: Record<string, string[]> = {
  "/dashboard": ["super_admin", "admin", "owner", "manager", "inventory_manager", "accountant", "cashier"],
  "/pos": ["super_admin", "admin", "owner", "manager", "cashier"],
  "/products": ["super_admin", "admin", "owner", "manager", "inventory_manager"],
  "/inventory": ["super_admin", "admin", "owner", "manager", "inventory_manager"],
  "/suppliers": ["super_admin", "admin", "owner", "manager", "inventory_manager"],
  "/transactions": ["super_admin", "admin", "owner", "manager", "accountant", "cashier"],
  "/customers": ["super_admin", "admin", "owner", "manager", "cashier"],
  "/employees": ["super_admin", "admin", "owner", "manager"],
  "/reports": ["super_admin", "admin", "owner", "manager", "accountant"],
  "/settings": ["super_admin", "admin", "owner"],
};

interface SidebarContentProps {
  collapsed: boolean;
  onNavClick?: () => void;
}

export function SidebarContent({ collapsed, onNavClick }: SidebarContentProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, role, signOut } = useAuth();

  const filteredNav = navItems.filter((item) => !role || roleAccess[item.path]?.includes(role));
  const isSuperAdmin = role === "super_admin";

  const handleSignOut = async () => {
    await signOut();
    toast.success("Signed out successfully");
    navigate("/auth");
  };

  const roleBadge = (role ?? "").replace("_", " ");

  return (
    <>
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 px-4 border-b border-[hsl(var(--brand-dark))]">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl border-2 flex-shrink-0 border-[hsl(var(--brand-pink)/0.5)] bg-gradient-to-br from-[hsl(var(--brand-pink)/0.2)] to-[hsl(var(--brand-dark)/0.3)]">
          {isSuperAdmin ? <Crown className="h-6 w-6 text-[hsl(var(--brand-pink))]" /> : <Receipt className="h-6 w-6 text-[hsl(var(--brand-pink))]" />}
        </div>
        {!collapsed && (
          <div>
            <h1 className="font-display text-lg font-black text-white">
              Smart<span className="text-[hsl(var(--brand-pink))]">POS</span>
            </h1>
            <span className="text-[10px] uppercase tracking-wider font-bold text-[hsl(var(--brand-pink)/0.6)]">
              {isSuperAdmin ? "Super Admin" : "Billing Suite"}
            </span>
          </div>
        )}
      </div>

      {/* User Info */}
      {user && !collapsed && (
        <div className="p-4 border-b border-[hsl(var(--brand-dark))]">
          <div className="flex items-center gap-3 p-3 rounded-xl border border-[hsl(var(--brand-dark))] bg-[hsl(var(--brand-dark)/0.5)]">
            <div className="h-10 w-10 rounded-xl border flex items-center justify-center overflow-hidden flex-shrink-0 border-[hsl(var(--brand-pink)/0.3)] bg-[hsl(var(--brand-pink)/0.1)]">
              {profile?.avatar_url ? (
                <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
              ) : (
                <User className="h-5 w-5 text-[hsl(var(--brand-pink))]" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate text-white">
                {profile?.full_name || "User"}
              </p>
              <Badge variant="outline" className="text-[10px] mt-1 uppercase tracking-wider font-bold border-[hsl(var(--brand-pink)/0.3)] text-[hsl(var(--brand-pink))] bg-[hsl(var(--brand-pink)/0.1)]">
                {roleBadge || "No Role"}
              </Badge>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 space-y-1 p-3 overflow-y-auto sidebar-no-scroll">
        {filteredNav.map((item) => {
          const isActive = location.pathname === item.path;
          const Icon = item.icon;
          return (
            <Tooltip key={item.path} delayDuration={0}>
              <TooltipTrigger asChild>
                <Link
                  to={item.path}
                  onClick={onNavClick}
                  className={cn(
                    "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-bold transition-all duration-200 border",
                    isActive
                      ? "bg-[hsl(var(--brand-pink)/0.15)] text-[hsl(var(--brand-pink))] border-[hsl(var(--brand-pink)/0.3)]"
                      : "text-white/70 hover:bg-[hsl(var(--brand-dark))] hover:text-white border-transparent"
                  )}
                >
                  <Icon className={cn(
                    "h-5 w-5 flex-shrink-0 transition-colors",
                    isActive
                      ? "text-[hsl(var(--brand-pink))]"
                      : "text-white/50 group-hover:text-white"
                  )} />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              </TooltipTrigger>
              {collapsed && (
                <TooltipContent side="right" className="bg-popover border-border font-bold">{item.label}</TooltipContent>
              )}
            </Tooltip>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-[hsl(var(--brand-dark))] space-y-1">
        {user && (
          <Tooltip delayDuration={0}>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                onClick={handleSignOut}
                className={cn(
                  "w-full justify-start rounded-xl font-bold text-white/70 hover:bg-[hsl(var(--brand-dark))] hover:text-white",
                  collapsed && "justify-center"
                )}
              >
                <LogOut className="h-5 w-5" />
                {!collapsed && <span className="ml-3">Sign Out</span>}
              </Button>
            </TooltipTrigger>
            {collapsed && <TooltipContent side="right" className="bg-popover border-border font-bold">Sign Out</TooltipContent>}
          </Tooltip>
        )}
      </div>
    </>
  );
}

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 z-40 h-screen transition-all duration-300 flex-col sidebar-no-scroll border-r hidden lg:flex",
        "bg-gradient-to-b from-[hsl(var(--brand-deepest))] to-[hsl(var(--brand-dark))] border-[hsl(var(--brand-dark))]",
        collapsed ? "w-20" : "w-64"
      )}
    >
      <SidebarContent collapsed={collapsed} />
      <div className="p-3 border-t border-[hsl(var(--brand-dark))]">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
          className="w-full justify-center rounded-xl text-white/50 hover:bg-[hsl(var(--brand-dark))] hover:text-white"
        >
          {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>
    </aside>
  );
}
