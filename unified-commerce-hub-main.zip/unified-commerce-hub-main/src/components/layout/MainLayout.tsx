import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { Footer } from './Footer';
import { cn } from '@/lib/utils';

interface MainLayoutProps {
  children: React.ReactNode;
  fullWidth?: boolean;
}

export function MainLayout({ children, fullWidth = false }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-background font-body flex flex-col">
      <Sidebar />
      <div className="lg:pl-64 transition-all duration-300 flex flex-col flex-1">
        <Header />
        <main className={cn('p-6 flex-1', fullWidth && 'p-0')}>
          {children}
        </main>
        <Footer variant="minimal" />
      </div>
    </div>
  );
}
