import { cn } from "@/lib/utils";

interface FooterProps {
  className?: string;
  variant?: "default" | "glass" | "minimal";
}

export function Footer({ className, variant = "default" }: FooterProps) {
  return (
    <footer
      className={cn(
        "w-full py-4 text-center",
        variant === "glass" && "glass-card border-t border-border",
        variant === "minimal" && "bg-transparent",
        variant === "default" && "bg-card border-t border-border",
        className
      )}
    >
      <p className="text-sm font-medium text-muted-foreground">
        Powered by{" "}
        <span className="font-bold text-primary">
          Softwarewala
        </span>
        <span className="text-foreground">™</span>
      </p>
    </footer>
  );
}
