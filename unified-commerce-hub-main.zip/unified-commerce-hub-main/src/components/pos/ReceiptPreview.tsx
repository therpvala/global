import { CartItem, Customer, PaymentMethod } from '@/types/pos';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Printer, 
  Mail, 
  Download, 
  Receipt, 
  Store, 
  Phone, 
  MapPin,
  Calendar,
  CreditCard,
  Banknote,
  Smartphone,
  Wallet,
  Gift,
  CheckCircle2
} from 'lucide-react';
import { format } from 'date-fns';

interface ReceiptPreviewProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  paymentMethod: PaymentMethod;
  customer?: Customer | null;
  receiptNumber?: string;
  onPrint: () => void;
  onEmail?: () => void;
  onDownload?: () => void;
}

const paymentMethodIcons: Record<PaymentMethod, React.ReactNode> = {
  cash: <Banknote className="h-4 w-4" />,
  card: <CreditCard className="h-4 w-4" />,
  upi: <Smartphone className="h-4 w-4" />,
  wallet: <Wallet className="h-4 w-4" />,
  split: <CreditCard className="h-4 w-4" />,
};

const paymentMethodLabels: Record<PaymentMethod, string> = {
  cash: 'Cash',
  card: 'Credit/Debit Card',
  upi: 'UPI',
  wallet: 'Digital Wallet',
  split: 'Split Payment',
};

export function ReceiptPreview({
  isOpen,
  onClose,
  items,
  subtotal,
  discount,
  tax,
  total,
  paymentMethod,
  customer,
  receiptNumber,
  onPrint,
  onEmail,
  onDownload,
}: ReceiptPreviewProps) {
  const currentDate = new Date();
  const generatedReceiptNumber = receiptNumber || `RCP-${Date.now().toString(36).toUpperCase()}`;
  const pointsEarned = customer ? Math.floor(total / 10) : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md glass-card p-0 overflow-hidden max-h-[90vh]">
        <DialogHeader className="p-4 border-b border-border bg-secondary/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Receipt className="h-6 w-6 text-primary" />
              <DialogTitle className="font-display text-gradient-ocean">Receipt Preview</DialogTitle>
            </div>
          </div>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[60vh] p-6">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl icon-box-primary mb-3">
              <Store className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-xl font-bold font-display text-gradient-ocean">POS Store</h2>
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mt-1">
              <MapPin className="h-3 w-3" />
              <span>123 Business Street, City</span>
            </div>
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
              <Phone className="h-3 w-3" />
              <span>+1 234-567-8900</span>
            </div>
          </div>

          <div className="glass-card p-3 mb-4 text-center">
            <div className="flex items-center justify-center gap-2 text-sm font-semibold text-foreground">
              <span className="text-muted-foreground">Receipt #:</span>
              <span className="text-gradient-ocean font-mono">{generatedReceiptNumber}</span>
            </div>
            <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground mt-1">
              <Calendar className="h-3 w-3" />
              <span>{format(currentDate, 'MMM dd, yyyy • hh:mm a')}</span>
            </div>
          </div>

          {customer && (
            <div className="glass-card p-3 mb-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Customer</p>
                  <p className="font-medium text-foreground">{customer.name}</p>
                  {customer.phone && (
                    <p className="text-xs text-muted-foreground">{customer.phone}</p>
                  )}
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-warning">
                    <Gift className="h-4 w-4" />
                    <span className="text-sm font-semibold">+{pointsEarned} pts</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Loyalty Points Earned</p>
                </div>
              </div>
            </div>
          )}

          <div className="mb-4">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Items</h3>
            <div className="space-y-2">
              {items.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-start justify-between py-2 border-b border-border/30 last:border-0"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground text-sm truncate">{item.product.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {item.quantity} × ${item.product.price.toFixed(2)}
                    </p>
                  </div>
                  <div className="text-right ml-4">
                    <p className="font-semibold text-foreground text-sm">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </p>
                    {item.discount > 0 && (
                      <p className="text-xs text-success">-${item.discount.toFixed(2)}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator className="my-4 bg-border" />

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-medium text-foreground">${subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-success">Discount</span>
                <span className="font-medium text-success">-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Tax (5%)</span>
              <span className="font-medium text-foreground">${tax.toFixed(2)}</span>
            </div>
            <Separator className="my-2 bg-border" />
            <div className="flex justify-between items-center">
              <span className="text-lg font-semibold text-foreground">Total</span>
              <span className="text-2xl font-bold text-gradient-ocean">${total.toFixed(2)}</span>
            </div>
          </div>

          <Separator className="my-4 bg-border" />

          <div className="glass-card p-3 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {paymentMethodIcons[paymentMethod]}
                <span className="text-sm text-muted-foreground">Payment Method</span>
              </div>
              <span className="font-medium text-foreground">{paymentMethodLabels[paymentMethod]}</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-success/10 border border-success/30">
            <CheckCircle2 className="h-5 w-5 text-success" />
            <span className="font-semibold text-success">Payment Successful</span>
          </div>

          <div className="text-center mt-4">
            <p className="text-sm text-muted-foreground">Thank you for your purchase!</p>
            <p className="text-xs text-muted-foreground mt-1">Visit us again soon</p>
          </div>
        </div>

        <div className="p-4 border-t border-border bg-card/50">
          <div className="grid grid-cols-3 gap-2 mb-3">
            <Button
              variant="outline"
              size="sm"
              onClick={onPrint}
              className="flex items-center gap-1"
            >
              <Printer className="h-4 w-4" />
              <span className="hidden sm:inline">Print</span>
            </Button>
            {onEmail && (
              <Button
                variant="outline"
                size="sm"
                onClick={onEmail}
                className="flex items-center gap-1"
              >
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">Email</span>
              </Button>
            )}
            {onDownload && (
              <Button
                variant="outline"
                size="sm"
                onClick={onDownload}
                className="flex items-center gap-1"
              >
                <Download className="h-4 w-4" />
                <span className="hidden sm:inline">Save</span>
              </Button>
            )}
          </div>
          <Button className="w-full" onClick={onClose}>
            Done
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
