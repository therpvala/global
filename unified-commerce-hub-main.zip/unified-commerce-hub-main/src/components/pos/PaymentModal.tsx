import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import {
  Banknote,
  CreditCard,
  Smartphone,
  Wallet,
  SplitSquareVertical,
  CheckCircle2,
  Printer,
  Send,
} from 'lucide-react';
import { PaymentMethod } from '@/types/pos';

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  total: number;
  onComplete: (method: PaymentMethod, amountPaid: number) => void;
}

const paymentMethods = [
  { id: 'cash' as PaymentMethod, label: 'Cash', icon: Banknote, color: 'bg-success/10 text-success border-success/30' },
  { id: 'card' as PaymentMethod, label: 'Card', icon: CreditCard, color: 'bg-primary/10 text-primary border-primary/30' },
  { id: 'upi' as PaymentMethod, label: 'UPI', icon: Smartphone, color: 'bg-accent/10 text-accent border-accent/30' },
  { id: 'wallet' as PaymentMethod, label: 'Wallet', icon: Wallet, color: 'bg-warning/10 text-warning border-warning/30' },
  { id: 'split' as PaymentMethod, label: 'Split', icon: SplitSquareVertical, color: 'bg-secondary/50 text-secondary-foreground border-secondary' },
];

const quickAmounts = [10, 20, 50, 100];

export function PaymentModal({ open, onClose, total, onComplete }: PaymentModalProps) {
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('cash');
  const [amountPaid, setAmountPaid] = useState(total.toString());
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const numericAmount = parseFloat(amountPaid) || 0;
  const change = numericAmount - total;

  const handlePayment = async () => {
    setIsProcessing(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsProcessing(false);
    setIsComplete(true);
  };

  const handleClose = () => {
    if (isComplete) {
      onComplete(selectedMethod, numericAmount);
    }
    setIsComplete(false);
    setIsProcessing(false);
    setAmountPaid(total.toString());
    onClose();
  };

  if (isComplete) {
    return (
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-md glass-card">
          <div className="flex flex-col items-center py-8">
            <div className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-success/20 border border-success/50 glow-accent">
              <CheckCircle2 className="h-10 w-10 text-success" />
            </div>
            <h2 className="mb-2 text-2xl font-bold font-display text-gradient-ocean">Payment Successful!</h2>
            <p className="text-muted-foreground mb-6">Transaction completed</p>

            <div className="w-full rounded-xl glass-card p-4 mb-6">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Total</span>
                <span className="font-semibold">${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Paid</span>
                <span className="font-semibold">${numericAmount.toFixed(2)}</span>
              </div>
              {change > 0 && (
                <div className="flex justify-between pt-2 border-t border-success/30">
                  <span className="font-medium text-success">Change</span>
                  <span className="font-bold text-success">${change.toFixed(2)}</span>
                </div>
              )}
            </div>

            <div className="flex gap-3 w-full">
              <Button variant="outline" className="flex-1 gap-2" onClick={handleClose}>
                <Printer className="h-4 w-4" />
                Print Receipt
              </Button>
              <Button variant="outline" className="flex-1 gap-2">
                <Send className="h-4 w-4" />
                Send Receipt
              </Button>
            </div>
            <Button className="w-full mt-3" onClick={handleClose}>
              New Sale
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg glass-card">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold font-display text-gradient-ocean">Complete Payment</DialogTitle>
        </DialogHeader>

        {/* Payment Methods */}
        <div className="grid grid-cols-5 gap-2 py-4">
          {paymentMethods.map((method) => {
            const Icon = method.icon;
            return (
              <button
                key={method.id}
                onClick={() => setSelectedMethod(method.id)}
                className={cn(
                  'flex flex-col items-center gap-2 rounded-xl border-2 p-3 transition-all duration-300',
                  selectedMethod === method.id
                    ? cn(method.color, 'shadow-lg')
                    : 'border-border bg-card hover:border-primary/40 hover:bg-primary/5'
                )}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{method.label}</span>
              </button>
            );
          })}
        </div>

        <Separator className="bg-border" />

        {/* Amount Section */}
        <div className="py-4 space-y-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-1">Amount Due</p>
            <p className="text-4xl font-bold text-gradient-ocean">${total.toFixed(2)}</p>
          </div>

          {selectedMethod === 'cash' && (
            <>
              <div className="space-y-2">
                <Label className="text-primary">Amount Received</Label>
                <Input
                  type="number"
                  value={amountPaid}
                  onChange={(e) => setAmountPaid(e.target.value)}
                  className="text-center text-2xl font-bold h-14 border-border focus:border-primary bg-card"
                  min={0}
                  step={0.01}
                />
              </div>

              <div className="grid grid-cols-4 gap-2">
                {quickAmounts.map((amount) => (
                  <Button
                    key={amount}
                    variant="outline"
                    onClick={() => setAmountPaid((total + amount).toString())}
                    className="font-semibold"
                  >
                    +${amount}
                  </Button>
                ))}
              </div>

              <Button
                variant="secondary"
                className="w-full"
                onClick={() => setAmountPaid(total.toFixed(2))}
              >
                Exact Amount
              </Button>

              {change > 0 && (
                <div className="rounded-xl glass-card p-4 text-center border-success/30">
                  <p className="text-sm text-success/80">Change to return</p>
                  <p className="text-2xl font-bold text-success">${change.toFixed(2)}</p>
                </div>
              )}
            </>
          )}

          {selectedMethod === 'card' && (
            <div className="rounded-xl glass-card p-6 text-center">
              <CreditCard className="h-12 w-12 mx-auto mb-3 text-primary animate-float" />
              <p className="text-primary font-medium">Insert or tap card on terminal</p>
              <p className="text-sm text-muted-foreground mt-1">Waiting for payment...</p>
            </div>
          )}

          {selectedMethod === 'upi' && (
            <div className="rounded-xl glass-card p-6 text-center">
              <Smartphone className="h-12 w-12 mx-auto mb-3 text-accent animate-float" />
              <p className="text-accent font-medium">Scan QR code to pay</p>
              <div className="mt-4 mx-auto w-32 h-32 glass-card rounded-xl flex items-center justify-center border-2 border-dashed border-accent/30">
                <span className="text-xs text-muted-foreground">QR Code</span>
              </div>
            </div>
          )}
        </div>

        <Separator className="bg-border" />

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4">
          <Button variant="outline" onClick={handleClose} className="flex-1">
            Cancel
          </Button>
          <Button
            onClick={handlePayment}
            disabled={isProcessing || (selectedMethod === 'cash' && numericAmount < total)}
            className="flex-1"
          >
            {isProcessing ? (
              <span className="flex items-center gap-2">
                <span className="h-4 w-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" />
                Processing...
              </span>
            ) : (
              `Pay $${total.toFixed(2)}`
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
