import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Percent, DollarSign, Tag } from 'lucide-react';

interface DiscountModalProps {
  open: boolean;
  onClose: () => void;
  subtotal: number;
  onApplyDiscount: (discount: number, type: 'percentage' | 'fixed') => void;
}

const quickDiscounts = [5, 10, 15, 20, 25];

export function DiscountModal({
  open,
  onClose,
  subtotal,
  onApplyDiscount,
}: DiscountModalProps) {
  const [discountType, setDiscountType] = useState<'percentage' | 'fixed'>('percentage');
  const [discountValue, setDiscountValue] = useState('');
  const [couponCode, setCouponCode] = useState('');

  const handleApply = () => {
    const value = parseFloat(discountValue);
    if (isNaN(value) || value <= 0) return;
    
    onApplyDiscount(value, discountType);
    setDiscountValue('');
    onClose();
  };

  const handleQuickDiscount = (percent: number) => {
    onApplyDiscount(percent, 'percentage');
    onClose();
  };

  const handleCouponApply = () => {
    // Mock coupon codes
    const coupons: Record<string, { discount: number; type: 'percentage' | 'fixed' }> = {
      'SAVE10': { discount: 10, type: 'percentage' },
      'FLAT5': { discount: 5, type: 'fixed' },
      'VIP20': { discount: 20, type: 'percentage' },
    };

    const coupon = coupons[couponCode.toUpperCase()];
    if (coupon) {
      onApplyDiscount(coupon.discount, coupon.type);
      setCouponCode('');
      onClose();
    }
  };

  const previewDiscount = discountType === 'percentage' 
    ? (subtotal * (parseFloat(discountValue) || 0)) / 100
    : parseFloat(discountValue) || 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md glass-card-3d">
        <DialogHeader>
          <DialogTitle className="text-xl font-display ocean-text flex items-center gap-2">
            <Percent className="h-5 w-5" />
            Apply Discount
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="quick" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-secondary/50">
            <TabsTrigger value="quick">Quick</TabsTrigger>
            <TabsTrigger value="custom">Custom</TabsTrigger>
            <TabsTrigger value="coupon">Coupon</TabsTrigger>
          </TabsList>

          <TabsContent value="quick" className="space-y-4 mt-4">
            <p className="text-sm text-muted-foreground">Select a quick discount percentage</p>
            <div className="grid grid-cols-5 gap-2">
              {quickDiscounts.map((percent) => (
                <Button
                  key={percent}
                  variant="outline"
                  className="h-16 border-primary/30 hover:bg-primary/20 hover:border-primary"
                  onClick={() => handleQuickDiscount(percent)}
                >
                  <span className="text-lg font-bold">{percent}%</span>
                </Button>
              ))}
            </div>
            <div className="text-center text-sm text-muted-foreground">
              Subtotal: ${subtotal.toFixed(2)}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-4 mt-4">
            <div className="flex gap-2">
              <Button
                variant={discountType === 'percentage' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setDiscountType('percentage')}
                className="flex-1 gap-2"
              >
                <Percent className="h-4 w-4" />
                Percentage
              </Button>
              <Button
                variant={discountType === 'fixed' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setDiscountType('fixed')}
                className="flex-1 gap-2"
              >
                <DollarSign className="h-4 w-4" />
                Fixed Amount
              </Button>
            </div>

            <div className="space-y-2">
              <Label>Discount Value</Label>
              <div className="relative">
                {discountType === 'fixed' && (
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                )}
                <Input
                  type="number"
                  placeholder={discountType === 'percentage' ? 'Enter percentage' : 'Enter amount'}
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  className={discountType === 'fixed' ? 'pl-10' : ''}
                />
                {discountType === 'percentage' && (
                  <Percent className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                )}
              </div>
            </div>

            {discountValue && (
              <div className="p-3 rounded-lg bg-success/10 border border-success/30">
                <p className="text-sm text-success">
                  Discount: ${previewDiscount.toFixed(2)} 
                  {discountType === 'percentage' && ` (${discountValue}%)`}
                </p>
              </div>
            )}

            <Button
              className="w-full bg-primary hover:bg-primary/90"
              onClick={handleApply}
              disabled={!discountValue || parseFloat(discountValue) <= 0}
            >
              Apply Discount
            </Button>
          </TabsContent>

          <TabsContent value="coupon" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Coupon Code</Label>
              <div className="relative">
                <Tag className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Enter coupon code"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="pl-10 uppercase"
                />
              </div>
            </div>

            <Button
              className="w-full bg-primary hover:bg-primary/90"
              onClick={handleCouponApply}
              disabled={!couponCode}
            >
              Apply Coupon
            </Button>

            <div className="text-xs text-muted-foreground">
              <p className="font-medium mb-1">Available coupons (demo):</p>
              <p>SAVE10 - 10% off</p>
              <p>FLAT5 - $5 off</p>
              <p>VIP20 - 20% off</p>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
