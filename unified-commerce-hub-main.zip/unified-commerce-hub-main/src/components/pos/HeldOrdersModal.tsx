import { HeldOrder, CartItem } from '@/types/pos';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, User, FileText, Trash2, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface HeldOrdersModalProps {
  open: boolean;
  onClose: () => void;
  heldOrders: HeldOrder[];
  onRecallOrder: (order: HeldOrder) => void;
  onDeleteOrder: (orderId: string) => void;
}

export function HeldOrdersModal({
  open,
  onClose,
  heldOrders,
  onRecallOrder,
  onDeleteOrder,
}: HeldOrdersModalProps) {
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl glass-card-3d">
        <DialogHeader>
          <DialogTitle className="text-xl font-display ocean-text">
            Held Orders ({heldOrders.length})
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 max-h-[60vh] overflow-y-auto">
          {heldOrders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Clock className="h-12 w-12 mx-auto mb-3 text-primary/30" />
              <p>No held orders</p>
            </div>
          ) : (
            heldOrders.map((order) => (
              <div
                key={order.id}
                className="rounded-xl glass ocean-border p-4 hover:border-primary/40 transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {order.customerName && (
                      <Badge variant="outline" className="gap-1 border-primary/30">
                        <User className="h-3 w-3" />
                        {order.customerName}
                      </Badge>
                    )}
                    <Badge variant="outline" className="gap-1 border-muted-foreground/30">
                      <Clock className="h-3 w-3" />
                      {formatDistanceToNow(order.createdAt, { addSuffix: true })}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:bg-destructive/10"
                    onClick={() => onDeleteOrder(order.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>

                {order.note && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                    <FileText className="h-3 w-3" />
                    {order.note}
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex flex-wrap gap-2">
                    {order.items.slice(0, 3).map((item, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {item.quantity}x {item.product.name}
                      </Badge>
                    ))}
                    {order.items.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{order.items.length - 3} more
                      </Badge>
                    )}
                  </div>
                  <Button
                    size="sm"
                    className="gap-2 bg-primary/20 text-primary hover:bg-primary/30"
                    onClick={() => {
                      onRecallOrder(order);
                      onClose();
                    }}
                  >
                    Recall
                    <ArrowRight className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
