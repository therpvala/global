import { CartItem, Customer } from '@/types/pos';
import { Minus, Plus, Trash2, ShoppingBag, Percent, User, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';

interface CartProps {
  items: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
  onClearCart: () => void;
  cartDiscount?: number;
  selectedCustomer?: Customer | null;
}

export function Cart({ items, onUpdateQuantity, onRemoveItem, onCheckout, onClearCart, cartDiscount = 0, selectedCustomer }: CartProps) {
  const subtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const itemDiscounts = items.reduce((sum, item) => sum + item.discount, 0);
  const totalDiscount = cartDiscount + itemDiscounts;
  const tax = (subtotal - totalDiscount) * 0.05;
  const total = subtotal - totalDiscount + tax;

  return (
    <div className="flex h-full flex-col bg-card">
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <ShoppingBag className="h-5 w-5 text-primary" />
          <h2 className="font-semibold font-display text-foreground">Current Order</h2>
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-white">{items.length}</span>
        </div>
        {items.length > 0 && (
          <Button variant="ghost" size="sm" onClick={onClearCart} className="text-destructive hover:text-destructive">Clear</Button>
        )}
      </div>

      {selectedCustomer && (
        <div className="px-4 py-2 border-b border-border bg-muted/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 min-w-0">
              <User className="h-4 w-4 text-primary shrink-0" />
              <span className="text-sm font-medium truncate">{selectedCustomer.name}</span>
            </div>
            <div className="flex items-center gap-1 text-primary shrink-0">
              <Gift className="h-3 w-3" />
              <span className="text-xs font-medium">+{Math.floor(total / 10)} pts</span>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4">
        {items.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-muted-foreground">
            <ShoppingBag className="h-12 w-12 mb-3 opacity-30" />
            <p className="text-sm">No items in cart</p>
            <p className="text-xs">Tap products to add them</p>
          </div>
        ) : (
          <div className="space-y-3">
            {items.map((item) => (
              <div key={item.product.id} className="group rounded-xl border border-border p-3 transition-all hover:border-primary/30">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <span className="text-sm font-bold text-primary">{item.product.name.charAt(0)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-foreground text-sm truncate">{item.product.name}</h4>
                    <p className="text-xs text-muted-foreground">${item.product.price.toFixed(2)} each</p>
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7 opacity-0 group-hover:opacity-100 text-destructive shrink-0" onClick={() => onRemoveItem(item.product.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}><Minus className="h-3 w-3" /></Button>
                    <span className="w-6 text-center font-semibold text-sm">{item.quantity}</span>
                    <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}><Plus className="h-3 w-3" /></Button>
                  </div>
                  <span className="font-semibold text-primary">${(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {cartDiscount > 0 && (
        <div className="px-4 py-2 border-t border-border">
          <Badge variant="outline" className="w-full justify-center gap-1 border-[hsl(var(--success)/0.5)] bg-[hsl(var(--success)/0.1)] text-[hsl(var(--success))] py-2">
            <Percent className="h-3 w-3" />Discount: -${cartDiscount.toFixed(2)}
          </Badge>
        </div>
      )}

      <div className="p-4 border-t border-border">
        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span className="font-medium">${subtotal.toFixed(2)}</span></div>
          {totalDiscount > 0 && <div className="flex justify-between text-sm"><span className="text-[hsl(var(--success))]">Discount</span><span className="text-[hsl(var(--success))]">-${totalDiscount.toFixed(2)}</span></div>}
          <div className="flex justify-between text-sm"><span className="text-muted-foreground">Tax (5%)</span><span>${tax.toFixed(2)}</span></div>
          <Separator />
          <div className="flex justify-between"><span className="text-lg font-semibold">Total</span><span className="text-2xl font-bold text-primary">${total.toFixed(2)}</span></div>
        </div>
        <Button onClick={onCheckout} disabled={items.length === 0} className="w-full h-12 text-base font-bold gradient-primary">
          Proceed to Payment
        </Button>
      </div>
    </div>
  );
}
