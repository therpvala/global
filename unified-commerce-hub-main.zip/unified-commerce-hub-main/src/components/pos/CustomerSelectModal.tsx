import { useState } from 'react';
import { Customer } from '@/types/pos';
import { customers } from '@/data/mockData';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, User, Gift, Star, Phone, Mail } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CustomerSelectModalProps {
  open: boolean;
  onClose: () => void;
  onSelectCustomer: (customer: Customer | null) => void;
  selectedCustomer: Customer | null;
}

export function CustomerSelectModal({
  open,
  onClose,
  onSelectCustomer,
  selectedCustomer,
}: CustomerSelectModalProps) {
  const [search, setSearch] = useState('');

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      c.email?.toLowerCase().includes(search.toLowerCase())
  );

  const getSegmentColor = (segment?: string) => {
    switch (segment) {
      case 'vip': return 'border-warning/50 bg-warning/10 text-warning';
      case 'new': return 'border-success/50 bg-success/10 text-success';
      case 'at-risk': return 'border-destructive/50 bg-destructive/10 text-destructive';
      default: return 'border-primary/50 bg-primary/10 text-primary';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl glass-card-3d">
        <DialogHeader>
          <DialogTitle className="text-xl font-display ocean-text flex items-center gap-2">
            <User className="h-5 w-5" />
            Select Customer
          </DialogTitle>
        </DialogHeader>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name, phone, or email..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="space-y-3 max-h-[50vh] overflow-y-auto">
          {filteredCustomers.map((customer) => (
            <div
              key={customer.id}
              className={cn(
                'rounded-xl p-4 cursor-pointer transition-all border',
                selectedCustomer?.id === customer.id
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50 hover:bg-primary/5'
              )}
              onClick={() => {
                onSelectCustomer(customer);
                onClose();
              }}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/10">
                    <span className="text-lg font-bold text-primary">
                      {customer.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{customer.name}</h3>
                      {customer.segment && (
                        <Badge variant="outline" className={cn('text-xs', getSegmentColor(customer.segment))}>
                          {customer.segment === 'vip' && <Star className="h-3 w-3 mr-1" />}
                          {customer.segment.toUpperCase()}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {customer.phone}
                      </span>
                      {customer.email && (
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {customer.email}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 text-warning">
                    <Gift className="h-4 w-4" />
                    <span className="font-semibold">{customer.loyaltyPoints.toLocaleString()}</span>
                    <span className="text-xs text-muted-foreground">pts</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    ${customer.totalSpent.toLocaleString()} spent
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {selectedCustomer && (
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              onSelectCustomer(null);
              onClose();
            }}
          >
            Remove Customer
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
