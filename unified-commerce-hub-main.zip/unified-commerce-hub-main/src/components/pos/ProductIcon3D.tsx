import { cn } from '@/lib/utils';

interface ProductIcon3DProps {
  category: string;
  productName: string;
  className?: string;
}

const categoryIcons: Record<string, { emoji: string; gradient: string }> = {
  Beverages: { emoji: '☕', gradient: 'from-amber-500/30 via-orange-400/20 to-amber-600/30' },
  Snacks: { emoji: '🍪', gradient: 'from-yellow-500/30 via-amber-400/20 to-orange-500/30' },
  Dairy: { emoji: '🥛', gradient: 'from-blue-200/30 via-sky-100/20 to-blue-300/30' },
  Bakery: { emoji: '🥐', gradient: 'from-orange-400/30 via-amber-300/20 to-yellow-500/30' },
  Frozen: { emoji: '🧊', gradient: 'from-cyan-400/30 via-blue-300/20 to-sky-500/30' },
  'Personal Care': { emoji: '🧴', gradient: 'from-pink-400/30 via-purple-300/20 to-fuchsia-500/30' },
};

const productEmojis: Record<string, string> = {
  'Espresso Coffee': '☕',
  'Cappuccino': '☕',
  'Iced Latte': '🧋',
  'Green Tea': '🍵',
  'Fresh Orange Juice': '🍊',
  'Chocolate Croissant': '🥐',
  'Blueberry Muffin': '🧁',
  'Cheese Danish': '🥮',
  'Greek Yogurt': '🥛',
  'Organic Milk': '🥛',
  'Almond Butter Cookies': '🍪',
  'Trail Mix': '🥜',
};

export function ProductIcon3D({ category, productName, className }: ProductIcon3DProps) {
  const categoryData = categoryIcons[category] || { emoji: '📦', gradient: 'from-gray-400/30 via-gray-300/20 to-gray-500/30' };
  const emoji = productEmojis[productName] || categoryData.emoji;

  return (
    <div
      className={cn(
        'relative flex items-center justify-center rounded-xl overflow-hidden',
        'bg-gradient-to-br',
        categoryData.gradient,
        className
      )}
      style={{
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
    >
      {/* 3D Floating Platform */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent rounded-xl" />
      
      {/* Glow Effect */}
      <div 
        className="absolute inset-0 opacity-50"
        style={{
          background: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.3) 0%, transparent 60%)',
        }}
      />
      
      {/* 3D Shadow */}
      <div 
        className="absolute bottom-2 left-1/2 -translate-x-1/2 w-2/3 h-2 rounded-full bg-black/20 blur-sm"
        style={{
          transform: 'translateX(-50%) rotateX(60deg)',
        }}
      />
      
      {/* Main Icon with 3D Transform */}
      <span 
        className="text-4xl drop-shadow-lg transition-transform duration-300 group-hover:scale-110 group-hover:-translate-y-1"
        style={{
          filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.2))',
          transform: 'translateZ(20px)',
        }}
      >
        {emoji}
      </span>
      
      {/* Subtle Reflection */}
      <div 
        className="absolute bottom-0 left-0 right-0 h-1/3 opacity-20"
        style={{
          background: 'linear-gradient(to top, rgba(255,255,255,0.3) 0%, transparent 100%)',
          transform: 'scaleY(-1) translateY(-100%)',
          filter: 'blur(2px)',
        }}
      />
      
      {/* Animated Shine */}
      <div 
        className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: 'linear-gradient(105deg, transparent 40%, rgba(255,255,255,0.2) 45%, transparent 50%)',
          animation: 'shine 2s ease-in-out infinite',
        }}
      />
    </div>
  );
}
