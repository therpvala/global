import { useState } from 'react';
import { products, categories } from '@/data/mockData';
import { Product } from '@/types/pos';
import { cn } from '@/lib/utils';
import { 
  Search, Plus, Filter, ChevronLeft, ChevronRight, LayoutGrid,
  Coffee, Cookie, Milk, Croissant, Snowflake, Sparkles, MilkOff,
  Carrot, Apple, Beef, Fish, Egg, Wheat, Bean, Droplets, Flame,
  CircleDot, Candy, SprayCan, ChefHat, Newspaper, UtensilsCrossed,
  Soup, Cherry, CakeSlice, HeartPulse, Baby, PawPrint, Pencil,
  Cpu, Gift, Cigarette, Leaf, LucideIcon
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ProductIcon3D } from './ProductIcon3D';
import { ScrollArea } from '@/components/ui/scroll-area';

const iconMap: Record<string, LucideIcon> = {
  Coffee, Cookie, Milk, Croissant, Snowflake, Sparkles, MilkOff,
  Carrot, Apple, Beef, Fish, Egg, Wheat, Bean, Droplets, Flame,
  CircleDot, Candy, SprayCan, ChefHat, Newspaper, UtensilsCrossed,
  Soup, Cherry, CakeSlice, HeartPulse, Baby, PawPrint, Pencil,
  Cpu, Gift, Cigarette, Leaf
};

interface ProductGridProps {
  onAddToCart: (product: Product) => void;
}

export function ProductGrid({ onAddToCart }: ProductGridProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.barcode?.includes(searchQuery);
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    return matchesSearch && matchesCategory && product.isActive;
  });

  const getCategoryColor = (categoryName: string): string => {
    const category = categories.find(c => c.name === categoryName);
    return category?.color || '#0077B6';
  };

  return (
    <div className="flex h-full">
      {/* Categories Sidebar */}
      <div 
        className={cn(
          "flex flex-col border-r border-border bg-card/50 transition-all duration-300 overflow-hidden",
          sidebarCollapsed ? "w-14" : "w-56"
        )}
      >
        <div className="flex items-center justify-between p-3 border-b border-border">
          {!sidebarCollapsed && (
            <span className="font-semibold text-sm text-gradient-ocean">Categories</span>
          )}
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="h-7 w-7"
          >
            {sidebarCollapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </Button>
        </div>

        <ScrollArea className="flex-1 sidebar-no-scroll">
          <div className={cn("p-2 space-y-1.5", sidebarCollapsed && "px-1")}>
            <button
              onClick={() => setSelectedCategory(null)}
              className={cn(
                "w-full flex items-center gap-2 px-3 py-2.5 rounded-lg transition-all duration-300",
                "border-2 font-medium text-sm",
                selectedCategory === null
                  ? "bg-primary/10 border-primary text-primary glow-primary"
                  : "border-border text-foreground/80 hover:border-primary/60 hover:bg-primary/5"
              )}
            >
              <LayoutGrid 
                className={cn(
                  "shrink-0 transition-transform duration-300",
                  sidebarCollapsed ? "w-5 h-5" : "w-4 h-4"
                )}
              />
              {!sidebarCollapsed && <span>All Products</span>}
            </button>

            {categories.map((category) => {
              const isSelected = selectedCategory === category.name;
              const IconComponent = category.icon ? iconMap[category.icon] : null;
              
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.name)}
                  className={cn(
                    "w-full flex items-center gap-2 px-3 py-2.5 rounded-lg transition-all duration-300",
                    "border-2 font-medium text-sm group",
                    isSelected
                      ? "bg-primary/10 border-primary text-primary"
                      : "border-transparent hover:border-primary/40"
                  )}
                >
                  {IconComponent ? (
                    <IconComponent 
                      className={cn(
                        "shrink-0 transition-all duration-300",
                        sidebarCollapsed ? "w-5 h-5" : "w-4 h-4",
                        "group-hover:scale-110"
                      )}
                      style={{ color: isSelected ? undefined : category.color }}
                    />
                  ) : (
                    <div 
                      className={cn(
                        "w-3 h-3 rounded-full shrink-0",
                        sidebarCollapsed && "w-4 h-4"
                      )}
                      style={{ backgroundColor: category.color }}
                    />
                  )}
                  {!sidebarCollapsed && (
                    <span className="truncate">{category.name}</span>
                  )}
                  {!sidebarCollapsed && (
                    <Badge variant="secondary" className="ml-auto text-[10px] px-1.5 py-0">
                      {category.productCount}
                    </Badge>
                  )}
                </button>
              );
            })}
          </div>
        </ScrollArea>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex gap-3 p-4 border-b border-border">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name, SKU, or barcode..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-card border-border focus:border-primary"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {selectedCategory && (
          <div className="px-4 py-2 border-b border-border flex items-center gap-2 bg-secondary/30">
            <div 
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: getCategoryColor(selectedCategory) }}
            />
            <span className="text-sm font-medium">{selectedCategory}</span>
            <Button 
              variant="ghost" 
              size="sm" 
              className="ml-auto h-6 text-xs hover:bg-destructive/10 hover:text-destructive"
              onClick={() => setSelectedCategory(null)}
            >
              Clear
            </Button>
          </div>
        )}

        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {filteredProducts.map((product, index) => (
              <button
                key={product.id}
                onClick={() => onAddToCart(product)}
                className={cn(
                  'group relative flex flex-col rounded-xl pro-card-hover p-4 text-left border border-[hsl(var(--ocean-primary)/0.2)]',
                  product.stock <= product.lowStockAlert && 'border-warning/50'
                )}
              >
                {product.stock <= product.lowStockAlert && (
                  <Badge
                    variant="outline"
                    className="absolute -right-2 -top-2 border-warning/50 bg-warning/20 text-warning text-[10px] animate-pulse"
                  >
                    Low Stock
                  </Badge>
                )}

                <div 
                  className="absolute top-2 left-2 w-2 h-2 rounded-full"
                  style={{ backgroundColor: getCategoryColor(product.category) }}
                />

                <ProductIcon3D 
                  category={product.category} 
                  productName={product.name}
                  className="mb-3 h-24 w-full"
                />

                <div className="flex-1">
                  <h4 className="font-medium text-foreground line-clamp-2 text-sm mb-1 group-hover:text-primary transition-colors">
                    {product.name}
                  </h4>
                  <p className="text-xs text-muted-foreground mb-2">{product.sku}</p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-border">
                  <span className="text-lg font-bold text-gradient-ocean">
                    ${product.price.toFixed(2)}
                  </span>
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground opacity-0 transition-all duration-300 group-hover:opacity-100">
                    <Plus className="h-4 w-4" />
                  </div>
                </div>
              </button>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground/30" />
                <p>No products found</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
