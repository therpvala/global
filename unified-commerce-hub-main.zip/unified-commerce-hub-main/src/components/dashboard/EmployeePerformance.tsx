import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, User, Star } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';

interface Employee {
  id: string;
  name: string;
  role: string;
  avatar?: string;
  sales: number;
  target: number;
  transactions: number;
  rating: number;
  trend: 'up' | 'down' | 'neutral';
}

const employees: Employee[] = [
  { 
    id: '1', 
    name: 'Sarah Johnson', 
    role: 'Senior Cashier',
    sales: 4250, 
    target: 4000,
    transactions: 86,
    rating: 4.9,
    trend: 'up'
  },
  { 
    id: '2', 
    name: 'Mike Chen', 
    role: 'Cashier',
    sales: 3180, 
    target: 3500,
    transactions: 62,
    rating: 4.7,
    trend: 'up'
  },
  { 
    id: '3', 
    name: 'Emily Davis', 
    role: 'Cashier',
    sales: 2890, 
    target: 3000,
    transactions: 54,
    rating: 4.5,
    trend: 'down'
  },
  { 
    id: '4', 
    name: 'James Wilson', 
    role: 'Part-time',
    sales: 1650, 
    target: 2000,
    transactions: 38,
    rating: 4.2,
    trend: 'neutral'
  },
];

export function EmployeePerformance() {
  return (
    <div className="pro-card p-5">
      <div className="mb-5 flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold text-foreground">Employee Performance</h3>
          <p className="text-sm text-muted-foreground">Today's sales by team member</p>
        </div>
        <button className="text-sm font-medium text-primary hover:text-primary/80 transition-colors">
          View All
        </button>
      </div>
      
      <div className="space-y-4">
        {employees.map((employee, index) => {
          const progress = Math.min((employee.sales / employee.target) * 100, 100);
          const isOverTarget = employee.sales >= employee.target;
          
          return (
            <div 
              key={employee.id} 
              className="group p-3 rounded-lg hover:bg-secondary/50 transition-all"
            >
              <div className="flex items-center gap-3 mb-2">
                <div className="relative">
                  <Avatar className="h-10 w-10 border-2 border-border">
                    <AvatarImage src={employee.avatar} alt={employee.name} />
                    <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
                      {employee.name.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  {index === 0 && (
                    <div className="absolute -top-1 -right-1 h-4 w-4 bg-primary rounded-full flex items-center justify-center">
                      <Star className="h-2.5 w-2.5 text-white fill-white" />
                    </div>
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground truncate">{employee.name}</p>
                    {employee.trend === 'up' && (
                      <TrendingUp className="h-3.5 w-3.5 text-success" />
                    )}
                    {employee.trend === 'down' && (
                      <TrendingDown className="h-3.5 w-3.5 text-destructive" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{employee.role}</p>
                </div>
                
                <div className="text-right">
                  <p className={cn(
                    'font-display font-bold',
                    isOverTarget ? 'text-success' : 'text-foreground'
                  )}>
                    ${employee.sales.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {employee.transactions} orders
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Progress 
                  value={progress} 
                  className="h-1.5 flex-1" 
                />
                <span className={cn(
                  'text-xs font-medium min-w-[48px] text-right',
                  isOverTarget ? 'text-success' : 'text-muted-foreground'
                )}>
                  {Math.round(progress)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
