import { MapPin, Store } from 'lucide-react';

const stores = [
  { id: 1, name: 'Downtown Store', lat: 40.7128, lng: -74.006, sales: '$12,450', status: 'active' },
  { id: 2, name: 'Mall Branch', lat: 40.7589, lng: -73.9851, sales: '$8,320', status: 'active' },
  { id: 3, name: 'Airport Outlet', lat: 40.6413, lng: -73.7781, sales: '$15,780', status: 'active' },
];

export function StoreMap() {
  return (
    <div className="pro-card p-5 h-full">
      <div className="mb-4">
        <h3 className="font-display text-lg font-semibold text-foreground">Store Locations</h3>
        <p className="text-sm text-muted-foreground">Active stores and performance</p>
      </div>
      
      {/* Map Placeholder */}
      <div className="relative h-48 rounded-lg bg-secondary/50 border border-border overflow-hidden mb-4">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="h-10 w-10 text-primary/40 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Interactive Map</p>
            <p className="text-xs text-muted-foreground/60">Coming Soon</p>
          </div>
        </div>
        
        {/* Decorative grid */}
        <div className="absolute inset-0 opacity-10">
          <div className="grid grid-cols-8 grid-rows-6 h-full">
            {Array.from({ length: 48 }).map((_, i) => (
              <div key={i} className="border border-primary/20" />
            ))}
          </div>
        </div>
        
        {/* Fake map pins */}
        <div className="absolute top-8 left-12">
          <div className="h-3 w-3 bg-success rounded-full animate-pulse" />
        </div>
        <div className="absolute top-16 right-16">
          <div className="h-3 w-3 bg-accent rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
        </div>
        <div className="absolute bottom-12 left-1/3">
          <div className="h-3 w-3 bg-primary rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
        </div>
      </div>
      
      {/* Store List */}
      <div className="space-y-2">
        {stores.map((store) => (
          <div key={store.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-secondary/50 transition-colors">
            <div className="icon-box icon-box-md rounded-lg bg-primary/10">
              <Store className="h-4 w-4 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{store.name}</p>
              <p className="text-xs text-muted-foreground">Today: {store.sales}</p>
            </div>
            <div className="h-2 w-2 rounded-full bg-success" />
          </div>
        ))}
      </div>
    </div>
  );
}
