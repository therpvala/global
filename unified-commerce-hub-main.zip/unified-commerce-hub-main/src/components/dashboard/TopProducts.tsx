import { dashboardStats } from '@/data/mockData';
import { TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export function TopProducts() {
  return (
    <div className="pro-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold text-foreground">Top Selling</h3>
          <p className="text-sm text-muted-foreground">Best performers today</p>
        </div>
        <div className="icon-box icon-box-lg rounded-lg bg-accent/15">
          <TrendingUp className="h-5 w-5 text-accent" />
        </div>
      </div>

      <div className="space-y-2">
        {dashboardStats.topProducts.map((item, index) => (
          <div
            key={item.product.id}
            className="group flex items-center gap-3 rounded-lg p-2.5 transition-all hover:bg-secondary/50"
          >
            <div className={cn(
              'flex h-8 w-8 items-center justify-center rounded-lg font-display text-sm font-bold',
              index === 0 ? 'bg-primary/15 text-primary' :
              index === 1 ? 'bg-secondary/50 text-secondary' :
              index === 2 ? 'bg-accent/15 text-accent' :
              'bg-secondary text-muted-foreground'
            )}>
              #{index + 1}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">{item.product.name}</p>
              <p className="text-xs text-muted-foreground">{item.product.category}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-foreground">{item.quantity} sold</p>
              <p className="text-xs text-accent">${(item.quantity * item.product.price).toFixed(2)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
