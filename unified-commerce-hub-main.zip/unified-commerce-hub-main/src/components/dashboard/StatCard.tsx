import { cn } from '@/lib/utils';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: LucideIcon;
  glowColor?: string;
  /** Use gradient variant for colorful filled cards */
  variant?: 'default' | 'gradient';
}

const gradientMap: Record<string, string> = {
  pink: 'stat-card-pink',
  blue: 'stat-card-blue',
  purple: 'stat-card-dark',
  dark: 'stat-card-dark',
  rose: 'stat-card-rose',
  mixed: 'stat-card-mixed',
  primary: 'stat-card-pink',
  accent: 'stat-card-blue',
};

export function StatCard({ title, value, change, changeType = 'neutral', icon: Icon, glowColor = 'pink', variant = 'gradient' }: StatCardProps) {
  const isGradient = variant === 'gradient';
  const gradientClass = gradientMap[glowColor] || 'stat-card-pink';

  if (isGradient) {
    return (
      <div className={cn(gradientClass, 'group transition-all duration-300 hover:-translate-y-1')}>
        <div className="flex items-start justify-between relative z-10">
          <div className="space-y-1.5 min-w-0 flex-1">
            <p className="text-xs font-bold uppercase tracking-wider text-white/70 truncate">{title}</p>
            <p className="font-display text-2xl font-black text-white truncate">{value}</p>
            {change && (
              <div className="flex items-center gap-1.5">
                {changeType === 'positive' && <TrendingUp className="h-3 w-3 text-white/80 shrink-0" />}
                {changeType === 'negative' && <TrendingDown className="h-3 w-3 text-white/80 shrink-0" />}
                <span className="text-xs font-bold text-white/80 truncate">{change}</span>
              </div>
            )}
          </div>
          <div className="h-12 w-12 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center shrink-0 ml-3 group-hover:scale-110 transition-transform duration-300">
            <Icon className="h-6 w-6 text-white" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="group pro-card p-5">
      <div className="flex items-start justify-between">
        <div className="space-y-1.5 min-w-0 flex-1">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider truncate">{title}</p>
          <p className="font-display text-2xl font-black text-foreground truncate">{value}</p>
          {change && (
            <div className="flex items-center gap-1.5">
              {changeType === 'positive' && <TrendingUp className="h-3 w-3 text-[hsl(var(--success))] shrink-0" />}
              {changeType === 'negative' && <TrendingDown className="h-3 w-3 text-destructive shrink-0" />}
              <span className={cn(
                'text-xs font-bold truncate',
                changeType === 'positive' && 'text-[hsl(var(--success))]',
                changeType === 'negative' && 'text-destructive',
                changeType === 'neutral' && 'text-muted-foreground'
              )}>{change}</span>
            </div>
          )}
        </div>
        <div className="h-11 w-11 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 ml-3 group-hover:scale-110 transition-transform duration-300">
          <Icon className="h-5 w-5 text-primary" />
        </div>
      </div>
    </div>
  );
}
