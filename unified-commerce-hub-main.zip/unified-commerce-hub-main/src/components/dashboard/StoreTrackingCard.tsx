import { cn } from '@/lib/utils';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { Icon3D, IconColor } from '@/components/ui/Icon3D';

interface StoreTrackingCardProps {
  title: string;
  value: string;
  subtitle?: string;
  icon: LucideIcon;
  trend?: { value: string; isPositive: boolean };
  color?: string;
}

const colorMap: Record<string, IconColor> = {
  primary: 'pink', accent: 'medium', soft: 'dark', dark: 'deepest',
  blue: 'medium', green: 'medium', amber: 'pink',
};

export function StoreTrackingCard({ title, value, subtitle, icon, trend, color = 'primary' }: StoreTrackingCardProps) {
  const mappedColor: IconColor = colorMap[color] || 'rose';

  return (
    <div className="group pro-card p-5">
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider">{title}</p>
          <p className="font-display text-2xl font-black text-foreground">{value}</p>
          {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
          {trend && (
            <div className="flex items-center gap-1.5 pt-1">
              {trend.isPositive ? <TrendingUp className="h-3.5 w-3.5 text-[hsl(var(--success))]" /> : <TrendingDown className="h-3.5 w-3.5 text-destructive" />}
              <span className={cn('text-xs font-bold', trend.isPositive ? 'text-[hsl(var(--success))]' : 'text-destructive')}>{trend.value}</span>
              <span className="text-xs text-muted-foreground">vs last week</span>
            </div>
          )}
        </div>
        <Icon3D icon={icon} color={mappedColor} size="lg" animated className="transition-transform duration-300 group-hover:scale-110" />
      </div>
    </div>
  );
}
