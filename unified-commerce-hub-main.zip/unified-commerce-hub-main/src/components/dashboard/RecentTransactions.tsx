import { recentTransactions } from '@/data/mockData';
import { CheckCircle2, Clock, CreditCard, Banknote, Smartphone } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const paymentIcons = {
  cash: Banknote,
  card: CreditCard,
  upi: Smartphone,
  wallet: Smartphone,
  split: CreditCard,
};

export function RecentTransactions() {
  return (
    <div className="pro-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold text-foreground">Recent Orders</h3>
          <p className="text-sm text-muted-foreground">Latest transactions processed</p>
        </div>
        <button className="text-sm font-medium text-primary hover:text-primary/80 transition-colors">
          View All
        </button>
      </div>

      <div className="space-y-1">
        {recentTransactions.map((transaction) => {
          const PaymentIcon = paymentIcons[transaction.paymentMethod];
          const timeAgo = Math.floor((Date.now() - transaction.createdAt.getTime()) / 60000);
          
          return (
            <div
              key={transaction.id}
              className="group flex items-center gap-3 rounded-lg p-2.5 transition-all hover:bg-secondary/50"
            >
              <div
                className={cn(
                  'icon-box icon-box-md rounded-lg',
                  transaction.status === 'completed' ? 'bg-success/15' : 'bg-warning/15'
                )}
              >
                {transaction.status === 'completed' ? (
                  <CheckCircle2 className="h-4 w-4 text-success" />
                ) : (
                  <Clock className="h-4 w-4 text-warning" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-medium text-foreground">{transaction.receiptNumber}</p>
                  <Badge variant="outline" className="text-[10px] border-border bg-secondary/50 text-muted-foreground">
                    <PaymentIcon className="mr-1 h-2.5 w-2.5" />
                    {transaction.paymentMethod.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {timeAgo < 60 ? `${timeAgo}m ago` : `${Math.floor(timeAgo / 60)}h ago`}
                </p>
              </div>

              <div className="text-right">
                <p className="text-sm font-medium text-foreground">${transaction.total.toFixed(2)}</p>
                {transaction.discount > 0 && (
                  <p className="text-xs text-success">-${transaction.discount.toFixed(2)} off</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
