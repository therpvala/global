import { Link } from 'react-router-dom';
import { ShoppingCart, Package, UserPlus, FileText, BarChart3, Settings } from 'lucide-react';
import { cn } from '@/lib/utils';

const actions = [
  { icon: ShoppingCart, label: 'New Sale', path: '/pos', color: 'pink' },
  { icon: Package, label: 'Add Product', path: '/products', color: 'medium' },
  { icon: UserPlus, label: 'New Customer', path: '/customers', color: 'rose' },
  { icon: FileText, label: 'View Reports', path: '/reports', color: 'dark' },
  { icon: BarChart3, label: 'Analytics', path: '/reports', color: 'medium' },
  { icon: Settings, label: 'Settings', path: '/settings', color: 'deepest' },
];

const colorClasses: Record<string, string> = {
  pink: 'bg-primary/15 text-primary group-hover:bg-primary/25',
  medium: 'bg-secondary/15 text-secondary group-hover:bg-secondary/25',
  rose: 'bg-destructive/15 text-destructive group-hover:bg-destructive/25',
  dark: 'bg-accent/15 text-accent-foreground group-hover:bg-accent/25',
  deepest: 'bg-muted text-muted-foreground group-hover:bg-muted/80',
};

export function QuickActions() {
  return (
    <div className="pro-card p-5">
      <div className="mb-4">
        <h3 className="font-display text-lg font-semibold text-foreground">Quick Actions</h3>
        <p className="text-sm text-muted-foreground">Frequently used operations</p>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {actions.map((action) => {
          const Icon = action.icon;
          const colorClass = colorClasses[action.color] || colorClasses.pink;
          return (
            <Link key={action.label} to={action.path} className="group flex flex-col items-center gap-2 rounded-lg p-3 transition-all hover:bg-muted/50">
              <div className={cn('flex h-10 w-10 items-center justify-center rounded-lg transition-all group-hover:scale-105', colorClass)}>
                <Icon className="h-5 w-5" />
              </div>
              <span className="text-xs font-medium text-muted-foreground text-center group-hover:text-foreground transition-colors">{action.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
