import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const data = [
  { hour: '9AM', orders: 12 },
  { hour: '10AM', orders: 19 },
  { hour: '11AM', orders: 24 },
  { hour: '12PM', orders: 35 },
  { hour: '1PM', orders: 42 },
  { hour: '2PM', orders: 28 },
  { hour: '3PM', orders: 22 },
  { hour: '4PM', orders: 18 },
  { hour: '5PM', orders: 31 },
  { hour: '6PM', orders: 38 },
];

export function OrdersChart() {
  const maxOrders = Math.max(...data.map(d => d.orders));
  
  return (
    <div className="pro-card p-5 h-full">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h3 className="font-display text-lg font-semibold text-foreground">Orders Today</h3>
          <p className="text-sm text-muted-foreground">Hourly distribution</p>
        </div>
        <div className="text-right">
          <p className="font-display text-2xl font-bold text-foreground">269</p>
          <p className="text-xs text-success">+12% vs yesterday</p>
        </div>
      </div>
      
      <div className="h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barSize={24}>
            <XAxis 
              dataKey="hour" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
            />
            <YAxis 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
              width={30}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
              }}
              labelStyle={{ color: 'hsl(var(--foreground))' }}
              formatter={(value: number) => [`${value} orders`, 'Orders']}
            />
            <Bar dataKey="orders" radius={[4, 4, 0, 0]}>
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.orders === maxOrders ? 'hsl(var(--primary))' : 'hsl(var(--primary) / 0.4)'}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
