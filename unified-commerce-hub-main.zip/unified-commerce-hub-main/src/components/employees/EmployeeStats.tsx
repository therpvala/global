import { Users, UserCheck, Clock, TrendingUp, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useEmployees } from '@/hooks/useEmployees';
import { useShifts } from '@/hooks/useShifts';
import { useMemo } from 'react';

const colorStyles: Record<string, { icon: string; bg: string }> = {
  blue: { icon: 'text-secondary', bg: 'bg-secondary/15' },
  green: { icon: 'text-success', bg: 'bg-success/15' },
  purple: { icon: 'text-primary', bg: 'bg-primary/15' },
  orange: { icon: 'text-accent', bg: 'bg-accent/15' },
};

export function EmployeeStats() {
  const { data: employees = [], isLoading: employeesLoading } = useEmployees();
  
  // Get current week dates for shift query
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  
  const { data: weekShifts = [] } = useShifts(
    startOfWeek.toISOString().split('T')[0],
    endOfWeek.toISOString().split('T')[0]
  );

  const stats = useMemo(() => {
    const activeEmployees = employees.filter(e => e.is_active);
    
    // Count unique employees with shifts today
    const todayStr = new Date().toISOString().split('T')[0];
    const todayShifts = weekShifts.filter(s => s.shift_date === todayStr);
    const onDutyCount = new Set(todayShifts.map(s => s.employee_id)).size;
    
    // Calculate average hours from shifts this week
    const totalHours = weekShifts.reduce((acc, shift) => {
      const start = shift.start_time.split(':').map(Number);
      const end = shift.end_time.split(':').map(Number);
      const hours = (end[0] + end[1]/60) - (start[0] + start[1]/60);
      return acc + Math.max(0, hours);
    }, 0);
    const avgHours = employees.length > 0 ? (totalHours / employees.length).toFixed(1) : '0';

    return [
      {
        title: 'Total Employees',
        value: employees.length.toString(),
        subtitle: `${activeEmployees.length} active`,
        icon: Users,
        color: 'blue',
      },
      {
        title: 'On Duty Now',
        value: onDutyCount.toString(),
        subtitle: `${todayShifts.length} shifts today`,
        icon: UserCheck,
        color: 'green',
      },
      {
        title: 'Avg Hours/Week',
        value: avgHours,
        subtitle: 'This week',
        icon: Clock,
        color: 'purple',
      },
      {
        title: 'Shifts Scheduled',
        value: weekShifts.length.toString(),
        subtitle: 'This week',
        icon: TrendingUp,
        color: 'orange',
      },
    ];
  }, [employees, weekShifts]);

  if (employeesLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="pro-card p-5 animate-pulse">
            <div className="flex items-start justify-between">
              <div className="space-y-2">
                <div className="h-3 w-20 bg-muted rounded" />
                <div className="h-6 w-12 bg-muted rounded" />
                <div className="h-3 w-16 bg-muted rounded" />
              </div>
              <div className="h-12 w-12 bg-muted rounded-xl" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const style = colorStyles[stat.color];
        const Icon = stat.icon;
        
        return (
          <div key={stat.title} className="pro-card p-5">
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{stat.title}</p>
                <p className="font-display text-2xl font-bold text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
              </div>
              <div className={cn('icon-box icon-box-xl rounded-xl', style.bg)}>
                <Icon className={cn('h-6 w-6', style.icon)} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
