import { useState, useMemo } from 'react';
import { ChevronLeft, ChevronRight, Clock, Plus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useShifts, useCreateShift, type ShiftInsert } from '@/hooks/useShifts';
import { useEmployees } from '@/hooks/useEmployees';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const getShiftType = (startTime: string): 'morning' | 'afternoon' | 'evening' | 'night' => {
  const hour = parseInt(startTime.split(':')[0]);
  if (hour >= 5 && hour < 12) return 'morning';
  if (hour >= 12 && hour < 17) return 'afternoon';
  if (hour >= 17 && hour < 21) return 'evening';
  return 'night';
};

const shiftTypeColors: Record<string, string> = {
  morning: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  afternoon: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  evening: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  night: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
};

export function ShiftScheduler() {
  const [currentWeek, setCurrentWeek] = useState(0);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newShift, setNewShift] = useState<Partial<ShiftInsert>>({
    start_time: '09:00',
    end_time: '17:00',
  });
  
  const getWeekDates = () => {
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay() + (currentWeek * 7));
    
    return weekDays.map((_, index) => {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + index);
      return date;
    });
  };
  
  const weekDates = getWeekDates();
  const startDate = weekDates[0].toISOString().split('T')[0];
  const endDate = weekDates[6].toISOString().split('T')[0];

  const { data: shifts = [], isLoading: shiftsLoading } = useShifts(startDate, endDate);
  const { data: employees = [] } = useEmployees();
  const createShift = useCreateShift();
  
  const getShiftsForDay = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    return shifts.filter(shift => shift.shift_date === dateStr);
  };

  const handleCreateShift = async () => {
    if (!newShift.employee_id || !newShift.shift_date || !newShift.start_time || !newShift.end_time) return;
    
    await createShift.mutateAsync(newShift as ShiftInsert);
    setIsAddDialogOpen(false);
    setNewShift({
      start_time: '09:00',
      end_time: '17:00',
    });
  };

  return (
    <div className="space-y-4">
      {/* Week Navigation */}
      <div className="pro-card p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" onClick={() => setCurrentWeek(currentWeek - 1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <div className="text-center">
              <h3 className="font-display text-lg font-semibold text-foreground">
                {weekDates[0].toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
              </h3>
              <p className="text-sm text-muted-foreground">
                {weekDates[0].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - {weekDates[6].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
              </p>
            </div>
            <Button variant="outline" size="icon" onClick={() => setCurrentWeek(currentWeek + 1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setCurrentWeek(0)}>Today</Button>
            
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
                  <Plus className="h-4 w-4" />
                  Add Shift
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle>Add New Shift</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Employee *</Label>
                    <Select
                      value={newShift.employee_id}
                      onValueChange={(value) => setNewShift({ ...newShift, employee_id: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.map((emp) => (
                          <SelectItem key={emp.id} value={emp.id}>
                            {emp.full_name} - {emp.position}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Date *</Label>
                    <Input
                      type="date"
                      value={newShift.shift_date || ''}
                      onChange={(e) => setNewShift({ ...newShift, shift_date: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Start Time *</Label>
                      <Input
                        type="time"
                        value={newShift.start_time || ''}
                        onChange={(e) => setNewShift({ ...newShift, start_time: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>End Time *</Label>
                      <Input
                        type="time"
                        value={newShift.end_time || ''}
                        onChange={(e) => setNewShift({ ...newShift, end_time: e.target.value })}
                      />
                    </div>
                  </div>
                  <Button 
                    onClick={handleCreateShift}
                    className="w-full"
                    disabled={createShift.isPending || !newShift.employee_id || !newShift.shift_date}
                  >
                    {createShift.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      'Create Shift'
                    )}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Schedule Grid */}
      <div className="pro-card overflow-hidden">
        <div className="grid grid-cols-7 border-b border-border">
          {weekDays.map((day, index) => {
            const date = weekDates[index];
            const isToday = date.toDateString() === new Date().toDateString();
            
            return (
              <div
                key={day}
                className={cn(
                  'p-3 text-center border-r border-border last:border-r-0',
                  isToday && 'bg-primary/10'
                )}
              >
                <p className={cn(
                  'text-xs font-medium uppercase tracking-wider',
                  isToday ? 'text-primary' : 'text-muted-foreground'
                )}>
                  {day}
                </p>
                <p className={cn(
                  'font-display text-lg font-bold',
                  isToday ? 'text-primary' : 'text-foreground'
                )}>
                  {date.getDate()}
                </p>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-7 min-h-[400px]">
          {shiftsLoading ? (
            <div className="col-span-7 flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            weekDays.map((_, dayIndex) => {
              const date = weekDates[dayIndex];
              const dayShifts = getShiftsForDay(date);
              const isToday = date.toDateString() === new Date().toDateString();
              
              return (
                <div
                  key={dayIndex}
                  className={cn(
                    'p-2 border-r border-border last:border-r-0 space-y-2',
                    isToday && 'bg-primary/5'
                  )}
                >
                  {dayShifts.map((shift) => {
                    const shiftType = getShiftType(shift.start_time);
                    const employeeName = shift.employees?.full_name?.split(' ').map(n => n[0] + '.').join(' ') || 'Unknown';
                    
                    return (
                      <div
                        key={shift.id}
                        className={cn(
                          'p-2 rounded-lg border text-xs cursor-pointer transition-all hover:scale-[1.02]',
                          shiftTypeColors[shiftType]
                        )}
                      >
                        <p className="font-medium truncate">{employeeName}</p>
                        <div className="flex items-center gap-1 mt-1 opacity-80">
                          <Clock className="h-3 w-3" />
                          <span>{shift.start_time.slice(0,5)} - {shift.end_time.slice(0,5)}</span>
                        </div>
                        <p className="text-[10px] mt-1 opacity-70 capitalize">{shift.status}</p>
                      </div>
                    );
                  })}
                  {dayShifts.length === 0 && (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-xs text-muted-foreground/50">No shifts</p>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 justify-center">
        {Object.entries(shiftTypeColors).map(([type, color]) => (
          <div key={type} className="flex items-center gap-2">
            <div className={cn('h-3 w-3 rounded', color.split(' ')[0])} />
            <span className="text-xs text-muted-foreground capitalize">{type}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
