import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Award, Target, Clock, DollarSign, Loader2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { useEmployeePerformances } from '@/hooks/useEmployeePerformance';
import { useEmployees } from '@/hooks/useEmployees';

// Fallback mock data when no performance records exist
const mockSalesData = [
  { name: 'Sarah J.', sales: 4250, target: 4000 },
  { name: 'Mike C.', sales: 3180, target: 3500 },
  { name: 'James W.', sales: 3890, target: 3500 },
  { name: 'Lisa A.', sales: 2450, target: 2500 },
  { name: 'Emily D.', sales: 2890, target: 3000 },
  { name: 'David B.', sales: 1650, target: 2000 },
];

const weeklyTrend = [
  { week: 'W1', performance: 82 },
  { week: 'W2', performance: 85 },
  { week: 'W3', performance: 78 },
  { week: 'W4', performance: 91 },
];

const attendanceData = [
  { name: 'Present', value: 88, color: 'hsl(var(--chart-1))' },
  { name: 'Late', value: 7, color: 'hsl(var(--chart-3))' },
  { name: 'Absent', value: 5, color: 'hsl(var(--chart-5))' },
];

export function PerformanceMetrics() {
  const { data: performances = [], isLoading: perfLoading } = useEmployeePerformances();
  const { data: employees = [], isLoading: empLoading } = useEmployees();

  const { salesData, topPerformers, totalSales, avgAttendance } = useMemo(() => {
    if (performances.length === 0) {
      // Use mock data when no performance records
      return {
        salesData: mockSalesData,
        topPerformers: mockSalesData.slice(0, 3).map((p, i) => ({
          id: String(i),
          name: p.name,
          role: 'Staff',
          sales: p.sales,
          rating: 4.5 + Math.random() * 0.4,
          trend: p.sales > p.target ? 'up' : 'down',
          avatar: null,
        })),
        totalSales: mockSalesData.reduce((a, b) => a + b.sales, 0),
        avgAttendance: 88,
      };
    }

    const sales = performances.map(p => ({
      name: p.employees?.full_name?.split(' ').map(n => n[0] + '.').join(' ') || 'Unknown',
      sales: Number(p.sales_amount) || 0,
      target: 3000, // Default target
    }));

    const top = performances
      .sort((a, b) => (Number(b.sales_amount) || 0) - (Number(a.sales_amount) || 0))
      .slice(0, 3)
      .map((p, i) => ({
        id: p.id,
        name: p.employees?.full_name || 'Unknown',
        role: p.employees?.position || 'Staff',
        sales: Number(p.sales_amount) || 0,
        rating: Number(p.rating) || 0,
        trend: i === 2 ? 'down' : 'up',
        avatar: p.employees?.avatar_url,
      }));

    const total = performances.reduce((a, b) => a + (Number(b.sales_amount) || 0), 0);
    const avgAtt = performances.reduce((a, b) => a + (Number(b.attendance_percentage) || 0), 0) / performances.length;

    return {
      salesData: sales,
      topPerformers: top,
      totalSales: total,
      avgAttendance: avgAtt,
    };
  }, [performances]);

  if (perfLoading || empLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Row - Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sales Performance Bar Chart */}
        <div className="lg:col-span-2 pro-card p-5">
          <div className="mb-4">
            <h3 className="font-display text-lg font-semibold text-foreground">Sales Performance</h3>
            <p className="text-sm text-muted-foreground">Individual sales vs targets this month</p>
          </div>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={salesData} layout="vertical" barGap={4}>
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} width={60} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                  formatter={(value: number, name: string) => [`$${value.toLocaleString()}`, name === 'sales' ? 'Sales' : 'Target']}
                />
                <Bar dataKey="target" fill="hsl(var(--muted))" radius={[0, 4, 4, 0]} barSize={16} />
                <Bar dataKey="sales" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attendance Pie Chart */}
        <div className="pro-card p-5">
          <div className="mb-4">
            <h3 className="font-display text-lg font-semibold text-foreground">Attendance</h3>
            <p className="text-sm text-muted-foreground">This month overview</p>
          </div>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {attendanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                  formatter={(value: number) => [`${value}%`, '']}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-2">
            {attendanceData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-muted-foreground">{item.name} ({item.value}%)</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performers */}
        <div className="pro-card p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-display text-lg font-semibold text-foreground">Top Performers</h3>
              <p className="text-sm text-muted-foreground">Based on sales this month</p>
            </div>
            <div className="icon-box icon-box-lg rounded-lg bg-yellow-500/15">
              <Award className="h-5 w-5 text-yellow-400" />
            </div>
          </div>
          
          <div className="space-y-4">
            {topPerformers.map((employee, index) => (
              <div key={employee.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30">
                <div className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-lg font-display text-sm font-bold',
                  index === 0 ? 'bg-yellow-500/20 text-yellow-400' :
                  index === 1 ? 'bg-gray-400/20 text-gray-400' :
                  'bg-orange-500/20 text-orange-400'
                )}>
                  #{index + 1}
                </div>
                <Avatar className="h-10 w-10 border border-border">
                  <AvatarImage src={employee.avatar || undefined} />
                  <AvatarFallback className="bg-primary/10 text-primary text-sm">
                    {employee.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground truncate">{employee.name}</p>
                    {employee.trend === 'up' ? (
                      <TrendingUp className="h-3.5 w-3.5 text-emerald-400" />
                    ) : (
                      <TrendingDown className="h-3.5 w-3.5 text-red-400" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{employee.role}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold text-foreground">${employee.sales.toLocaleString()}</p>
                  <p className="text-xs text-muted-foreground">⭐ {employee.rating.toFixed(1)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Trend */}
        <div className="pro-card p-5">
          <div className="mb-4">
            <h3 className="font-display text-lg font-semibold text-foreground">Team Performance Trend</h3>
            <p className="text-sm text-muted-foreground">Weekly average score</p>
          </div>
          <div className="h-[180px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weeklyTrend}>
                <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} />
                <YAxis domain={[70, 100]} axisLine={false} tickLine={false} tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} width={30} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                  formatter={(value: number) => [`${value}%`, 'Score']}
                />
                <Line type="monotone" dataKey="performance" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: 'hsl(var(--primary))', strokeWidth: 0, r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t border-border">
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Target className="h-4 w-4 text-blue-400" />
              </div>
              <p className="font-display text-lg font-bold text-foreground">
                {Math.round(avgAttendance)}%
              </p>
              <p className="text-xs text-muted-foreground">Attendance</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <Clock className="h-4 w-4 text-purple-400" />
              </div>
              <p className="font-display text-lg font-bold text-foreground">{employees.length}</p>
              <p className="text-xs text-muted-foreground">Employees</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <DollarSign className="h-4 w-4 text-emerald-400" />
              </div>
              <p className="font-display text-lg font-bold text-foreground">
                ${(totalSales / 1000).toFixed(1)}k
              </p>
              <p className="text-xs text-muted-foreground">Total Sales</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
