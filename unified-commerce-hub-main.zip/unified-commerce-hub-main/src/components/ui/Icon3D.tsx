import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

export type IconColor = 'pink' | 'rose' | 'medium' | 'dark' | 'deepest' | 'primary' | 'accent' | 'soft';
export type IconSize = 'sm' | 'md' | 'lg' | 'xl';

interface Icon3DProps {
  icon: LucideIcon;
  color?: IconColor;
  size?: IconSize;
  animated?: boolean;
  className?: string;
}

const colorStyles: Record<IconColor, string> = {
  pink: 'bg-gradient-to-br from-[hsl(var(--brand-pink))] to-[hsl(var(--brand-rose))] border-[hsl(var(--brand-pink)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-pink)/0.3)]',
  rose: 'bg-gradient-to-br from-[hsl(var(--brand-rose))] to-[hsl(var(--brand-pink))] border-[hsl(var(--brand-rose)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-rose)/0.3)]',
  medium: 'bg-gradient-to-br from-[hsl(var(--brand-medium))] to-[hsl(var(--brand-dark))] border-[hsl(var(--brand-medium)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-medium)/0.3)]',
  dark: 'bg-gradient-to-br from-[hsl(var(--brand-dark))] to-[hsl(var(--brand-deepest))] border-[hsl(var(--brand-dark)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-dark)/0.3)]',
  deepest: 'bg-gradient-to-br from-[hsl(var(--brand-deepest))] to-[hsl(var(--brand-dark))] border-[hsl(var(--brand-deepest)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-deepest)/0.4)]',
  primary: 'bg-gradient-to-br from-[hsl(var(--brand-pink))] to-[hsl(var(--brand-medium))] border-[hsl(var(--brand-pink)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-pink)/0.3)]',
  accent: 'bg-gradient-to-br from-[hsl(var(--brand-medium))] to-[hsl(var(--brand-dark))] border-[hsl(var(--brand-medium)/0.5)] shadow-[0_4px_20px_hsl(var(--brand-medium)/0.3)]',
  soft: 'bg-gradient-to-br from-[hsl(var(--primary-light))] to-[hsl(var(--brand-pink)/0.4)] border-[hsl(var(--brand-pink)/0.3)] shadow-[0_4px_20px_hsl(var(--primary-light)/0.3)]',
};

const sizeStyles: Record<IconSize, { box: string; icon: string }> = {
  sm: { box: 'h-10 w-10', icon: 'h-5 w-5' },
  md: { box: 'h-12 w-12', icon: 'h-6 w-6' },
  lg: { box: 'h-14 w-14', icon: 'h-7 w-7' },
  xl: { box: 'h-16 w-16', icon: 'h-8 w-8' },
};

export function Icon3D({ 
  icon: Icon, 
  color = 'pink', 
  size = 'md',
  animated = false,
  className 
}: Icon3DProps) {
  return (
    <div 
      className={cn(
        'rounded-2xl border-2 flex items-center justify-center',
        sizeStyles[size].box,
        colorStyles[color] || colorStyles.pink,
        animated && 'hover:scale-110 hover:-translate-y-1',
        'transition-all duration-300',
        className
      )}
    >
      <Icon className={cn(sizeStyles[size].icon, 'text-white drop-shadow-sm')} />
    </div>
  );
}
