import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';
import { Icon3D, IconColor } from './Icon3D';

export type GlassVariant = 'default' | 'primary' | 'accent' | 'soft';

interface GlassCardProps {
  children: ReactNode;
  title?: string;
  description?: string;
  icon?: LucideIcon;
  iconColor?: IconColor;
  variant?: GlassVariant;
  glow?: boolean;
  className?: string;
  onClick?: () => void;
}

const variantClasses: Record<GlassVariant, string> = {
  default: 'glass-card',
  primary: 'glass-card glass-primary',
  accent: 'glass-card glass-accent',
  soft: 'glass-card glass-soft',
};

export function GlassCard({
  children,
  title,
  description,
  icon: Icon,
  iconColor = 'primary',
  variant = 'default',
  glow = false,
  className,
  onClick,
}: GlassCardProps) {
  return (
    <div
      className={cn(
        variantClasses[variant],
        'p-6 cursor-pointer group',
        className
      )}
      onClick={onClick}
    >
      {Icon && (
        <div className="mb-4">
          <Icon3D icon={Icon} color={iconColor} size="lg" animated />
        </div>
      )}
      {title && (
        <h3 className="text-lg font-semibold text-foreground mb-1 font-display">{title}</h3>
      )}
      {description && (
        <p className="text-sm text-muted-foreground font-body">{description}</p>
      )}
      {children}
    </div>
  );
}

interface StatGlassCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon: LucideIcon;
  iconColor?: IconColor;
}

export function StatGlassCard({
  title,
  value,
  change,
  changeType = 'neutral',
  icon,
  iconColor = 'primary',
}: StatGlassCardProps) {
  return (
    <div className="glass-card">
      <div className="p-6 relative">
        <div className="flex items-start justify-between mb-4">
          <Icon3D icon={icon} color={iconColor} size="lg" animated />
        </div>
        <div className="space-y-1">
          <p className="text-sm text-muted-foreground font-body uppercase tracking-wide">{title}</p>
          <p className="text-3xl font-bold text-foreground font-display">{value}</p>
          {change && (
            <p className={cn(
              'text-sm font-medium font-body',
              changeType === 'positive' && 'text-success',
              changeType === 'negative' && 'text-destructive',
              changeType === 'neutral' && 'text-muted-foreground'
            )}>
              {change}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
