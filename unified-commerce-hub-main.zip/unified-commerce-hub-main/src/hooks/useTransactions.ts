import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { CartItem, PaymentMethod, SplitPayment } from '@/types/pos';
import type { Json } from '@/integrations/supabase/types';

type DbTransaction = {
  id: string;
  receipt_number: string;
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  payment_method: string;
  status: string;
  customer_id: string | null;
  cashier_id: string;
  split_payments: Json | null;
  created_at: string;
};

type DbTransactionItem = {
  id: string;
  transaction_id: string;
  product_id: string;
  product_name: string;
  product_sku: string;
  quantity: number;
  unit_price: number;
  discount: number;
  tax_rate: number;
  total: number;
  note: string | null;
  created_at: string;
};

const parseSplitPayments = (json: Json | null): SplitPayment[] | null => {
  if (!json || !Array.isArray(json)) return null;
  return json as unknown as SplitPayment[];
};

export function useTransactions(limit = 100) {
  return useQuery({
    queryKey: ['transactions', limit],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);
      if (error) throw error;
      return data.map(t => ({ ...t, split_payments: parseSplitPayments(t.split_payments) }));
    },
  });
}

export function useTransaction(id: string) {
  return useQuery({
    queryKey: ['transaction', id],
    queryFn: async () => {
      const { data: txData, error: txError } = await supabase
        .from('transactions')
        .select('*')
        .eq('id', id)
        .single();
      if (txError) throw txError;
      const transaction = { ...txData, split_payments: parseSplitPayments(txData.split_payments) };

      const { data: items, error: itemsError } = await supabase
        .from('transaction_items')
        .select('*')
        .eq('transaction_id', id);
      if (itemsError) throw itemsError;

      return {
        transaction,
        items: items as DbTransactionItem[],
      };
    },
    enabled: !!id,
  });
}

export function useCreateTransaction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      items,
      subtotal,
      tax,
      discount,
      total,
      paymentMethod,
      customerId,
      splitPayments,
    }: {
      items: CartItem[];
      subtotal: number;
      tax: number;
      discount: number;
      total: number;
      paymentMethod: PaymentMethod;
      customerId?: string;
      splitPayments?: SplitPayment[];
    }) => {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Generate receipt number
      const receiptNumber = `RCP-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;

      // Create transaction
      const { data: txData, error: txError } = await supabase
        .from('transactions')
        .insert({
          receipt_number: receiptNumber,
          subtotal,
          tax,
          discount,
          total,
          payment_method: paymentMethod,
          status: 'completed',
          customer_id: customerId || null,
          cashier_id: user.id,
          split_payments: (splitPayments as unknown as Json) || null,
        })
        .select()
        .single();
      if (txError) throw txError;
      const transaction = txData;

      // Create transaction items
      const transactionItems = items.map((item) => ({
        transaction_id: transaction.id,
        product_id: item.product.id,
        product_name: item.product.name,
        product_sku: item.product.sku,
        quantity: item.quantity,
        unit_price: item.product.price,
        discount: item.discount,
        tax_rate: item.product.taxRate,
        total: (item.product.price * item.quantity) - item.discount,
        note: item.note || null,
      }));

      const { error: itemsError } = await supabase
        .from('transaction_items')
        .insert(transactionItems);
      if (itemsError) throw itemsError;

      // Update product stock
      for (const item of items) {
        const { error: stockError } = await supabase
          .from('products')
          .update({ stock: item.product.stock - item.quantity })
          .eq('id', item.product.id);
        if (stockError) console.error('Failed to update stock:', stockError);

        // Record inventory movement
        await supabase.from('inventory_movements').insert({
          product_id: item.product.id,
          quantity: -item.quantity,
          movement_type: 'out',
          reason: 'Sale',
          reference_id: transaction.id,
          created_by: user.id,
        });
      }

      // Update customer stats if customer selected
      if (customerId) {
        const { data: customer } = await supabase
          .from('customers')
          .select('total_spent, visit_count, loyalty_points')
          .eq('id', customerId)
          .single();

        if (customer) {
          await supabase
            .from('customers')
            .update({
              total_spent: Number(customer.total_spent) + total,
              visit_count: customer.visit_count + 1,
              loyalty_points: customer.loyalty_points + Math.floor(total / 10),
              last_visit: new Date().toISOString(),
            })
            .eq('id', customerId);
        }
      }

      return { ...transaction, split_payments: parseSplitPayments(transaction.split_payments) };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}

export function useRefundTransaction() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (transactionId: string) => {
      const { data, error } = await supabase
        .from('transactions')
        .update({ status: 'refunded' })
        .eq('id', transactionId)
        .select()
        .single();
      if (error) throw error;
      return { ...data, split_payments: parseSplitPayments(data.split_payments) };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
    },
  });
}

export function useTodayStats() {
  return useQuery({
    queryKey: ['today-stats'],
    queryFn: async () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const { data, error } = await supabase
        .from('transactions')
        .select('total, id')
        .eq('status', 'completed')
        .gte('created_at', today.toISOString());
      if (error) throw error;

      const todaySales = data.reduce((sum, t) => sum + Number(t.total), 0);
      const todayOrders = data.length;
      const averageOrderValue = todayOrders > 0 ? todaySales / todayOrders : 0;

      return { todaySales, todayOrders, averageOrderValue };
    },
  });
}
