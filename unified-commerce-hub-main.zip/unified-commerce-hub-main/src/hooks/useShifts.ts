import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Shift {
  id: string;
  employee_id: string;
  shift_date: string;
  start_time: string;
  end_time: string;
  break_minutes: number | null;
  status: string;
  notes: string | null;
  created_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface ShiftWithEmployee extends Shift {
  employees: {
    id: string;
    full_name: string;
    position: string;
    department: string;
  } | null;
}

export interface ShiftInsert {
  employee_id: string;
  shift_date: string;
  start_time: string;
  end_time: string;
  break_minutes?: number;
  status?: string;
  notes?: string | null;
  created_by?: string | null;
}

export interface ShiftUpdate extends Partial<ShiftInsert> {
  id: string;
}

export function useShifts(startDate?: string, endDate?: string) {
  return useQuery({
    queryKey: ['shifts', startDate, endDate],
    queryFn: async () => {
      let query = supabase
        .from('shifts')
        .select(`
          *,
          employees (
            id,
            full_name,
            position,
            department
          )
        `)
        .order('shift_date')
        .order('start_time');

      if (startDate) {
        query = query.gte('shift_date', startDate);
      }
      if (endDate) {
        query = query.lte('shift_date', endDate);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as ShiftWithEmployee[];
    },
  });
}

export function useEmployeeShifts(employeeId: string) {
  return useQuery({
    queryKey: ['shifts', 'employee', employeeId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('shifts')
        .select('*')
        .eq('employee_id', employeeId)
        .order('shift_date', { ascending: false });

      if (error) throw error;
      return data as Shift[];
    },
    enabled: !!employeeId,
  });
}

export function useCreateShift() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (shift: ShiftInsert) => {
      const { data, error } = await supabase
        .from('shifts')
        .insert(shift)
        .select()
        .single();

      if (error) throw error;
      return data as Shift;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shifts'] });
      toast.success('Shift created successfully');
    },
    onError: (error) => {
      toast.error('Failed to create shift: ' + error.message);
    },
  });
}

export function useUpdateShift() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: ShiftUpdate) => {
      const { data, error } = await supabase
        .from('shifts')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data as Shift;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shifts'] });
      toast.success('Shift updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update shift: ' + error.message);
    },
  });
}

export function useDeleteShift() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('shifts')
        .delete()
        .eq('id', id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shifts'] });
      toast.success('Shift deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete shift: ' + error.message);
    },
  });
}
