import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Customer, CustomerSegment } from '@/types/pos';

type DbCustomer = {
  id: string;
  name: string;
  email: string | null;
  phone: string;
  loyalty_points: number;
  total_spent: number;
  birthday: string | null;
  segment: string | null;
  notes: string | null;
  last_visit: string | null;
  visit_count: number;
  preferences: string[] | null;
  created_at: string;
  updated_at: string;
};

const mapDbToCustomer = (db: DbCustomer): Customer => ({
  id: db.id,
  name: db.name,
  email: db.email || undefined,
  phone: db.phone,
  loyaltyPoints: db.loyalty_points,
  totalSpent: Number(db.total_spent),
  birthday: db.birthday ? new Date(db.birthday) : undefined,
  segment: (db.segment as CustomerSegment) || 'new',
  notes: db.notes || undefined,
  lastVisit: db.last_visit ? new Date(db.last_visit) : undefined,
  visitCount: db.visit_count,
  preferences: db.preferences || undefined,
  createdAt: new Date(db.created_at),
});

export function useCustomers() {
  return useQuery({
    queryKey: ['customers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .order('name');
      if (error) throw error;
      return (data as DbCustomer[]).map(mapDbToCustomer);
    },
  });
}

export function useCustomer(id: string) {
  return useQuery({
    queryKey: ['customer', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return mapDbToCustomer(data as DbCustomer);
    },
    enabled: !!id,
  });
}

export function useCreateCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (customer: Omit<Customer, 'id' | 'createdAt' | 'loyaltyPoints' | 'totalSpent' | 'visitCount'>) => {
      const { data, error } = await supabase
        .from('customers')
        .insert({
          name: customer.name,
          email: customer.email || null,
          phone: customer.phone,
          birthday: customer.birthday?.toISOString().split('T')[0] || null,
          segment: customer.segment || 'new',
          notes: customer.notes || null,
          preferences: customer.preferences || null,
        })
        .select()
        .single();
      if (error) throw error;
      return mapDbToCustomer(data as DbCustomer);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}

export function useUpdateCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...customer }: Partial<Customer> & { id: string }) => {
      const updateData: Record<string, unknown> = {};
      if (customer.name !== undefined) updateData.name = customer.name;
      if (customer.email !== undefined) updateData.email = customer.email || null;
      if (customer.phone !== undefined) updateData.phone = customer.phone;
      if (customer.birthday !== undefined) updateData.birthday = customer.birthday?.toISOString().split('T')[0] || null;
      if (customer.segment !== undefined) updateData.segment = customer.segment;
      if (customer.notes !== undefined) updateData.notes = customer.notes || null;
      if (customer.preferences !== undefined) updateData.preferences = customer.preferences || null;
      if (customer.loyaltyPoints !== undefined) updateData.loyalty_points = customer.loyaltyPoints;

      const { data, error } = await supabase
        .from('customers')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return mapDbToCustomer(data as DbCustomer);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}

export function useDeleteCustomer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('customers').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });
}

export function useCustomerStats() {
  return useQuery({
    queryKey: ['customer-stats'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('customers')
        .select('segment, loyalty_points, total_spent');
      if (error) throw error;

      const segments: Record<string, number> = {};
      let totalPoints = 0;
      let totalSpent = 0;

      data.forEach((c) => {
        segments[c.segment || 'new'] = (segments[c.segment || 'new'] || 0) + 1;
        totalPoints += c.loyalty_points;
        totalSpent += Number(c.total_spent);
      });

      return {
        totalCustomers: data.length,
        segments,
        totalPoints,
        totalSpent,
      };
    },
  });
}
