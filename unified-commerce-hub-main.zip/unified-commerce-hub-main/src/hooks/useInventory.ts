import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

type InventoryMovement = {
  id: string;
  product_id: string;
  quantity: number;
  movement_type: 'in' | 'out' | 'adjustment' | 'transfer';
  reason: string | null;
  reference_id: string | null;
  created_by: string | null;
  created_at: string;
};

export function useInventoryMovements(productId?: string) {
  return useQuery({
    queryKey: ['inventory-movements', productId],
    queryFn: async () => {
      let query = supabase
        .from('inventory_movements')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (productId) {
        query = query.eq('product_id', productId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as InventoryMovement[];
    },
  });
}

export function useCreateInventoryMovement() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      productId,
      quantity,
      movementType,
      reason,
      referenceId,
    }: {
      productId: string;
      quantity: number;
      movementType: 'in' | 'out' | 'adjustment' | 'transfer';
      reason?: string;
      referenceId?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();

      const { data, error } = await supabase
        .from('inventory_movements')
        .insert({
          product_id: productId,
          quantity,
          movement_type: movementType,
          reason: reason || null,
          reference_id: referenceId || null,
          created_by: user?.id || null,
        })
        .select()
        .single();
      if (error) throw error;

      // Update product stock
      const { data: product } = await supabase
        .from('products')
        .select('stock')
        .eq('id', productId)
        .single();

      if (product) {
        const newStock = product.stock + quantity;
        await supabase
          .from('products')
          .update({ stock: newStock })
          .eq('id', productId);
      }

      return data as InventoryMovement;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inventory-movements'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
  });
}

export function useLowStockProducts() {
  return useQuery({
    queryKey: ['low-stock-products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true);
      if (error) throw error;

      // Filter products where stock <= low_stock_alert
      return data.filter((p) => p.stock <= p.low_stock_alert);
    },
  });
}

export function useInventoryStats() {
  return useQuery({
    queryKey: ['inventory-stats'],
    queryFn: async () => {
      const { data: products, error } = await supabase
        .from('products')
        .select('stock, cost, low_stock_alert, is_active')
        .eq('is_active', true);
      if (error) throw error;

      const totalProducts = products.length;
      const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
      const totalValue = products.reduce((sum, p) => sum + (p.stock * Number(p.cost)), 0);
      const lowStockCount = products.filter((p) => p.stock <= p.low_stock_alert).length;
      const outOfStockCount = products.filter((p) => p.stock === 0).length;

      return {
        totalProducts,
        totalStock,
        totalValue,
        lowStockCount,
        outOfStockCount,
      };
    },
  });
}
