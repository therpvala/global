import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import type { Product } from '@/types/pos';

type DbProduct = {
  id: string;
  name: string;
  sku: string;
  barcode: string | null;
  price: number;
  cost: number;
  category: string;
  stock: number;
  low_stock_alert: number;
  image: string | null;
  tax_rate: number;
  is_active: boolean;
  expiry_date: string | null;
  batch_number: string | null;
  created_at: string;
  updated_at: string;
};

const mapDbToProduct = (db: DbProduct): Product => ({
  id: db.id,
  name: db.name,
  sku: db.sku,
  barcode: db.barcode || undefined,
  price: Number(db.price),
  cost: Number(db.cost),
  category: db.category,
  stock: db.stock,
  lowStockAlert: db.low_stock_alert,
  image: db.image || undefined,
  taxRate: Number(db.tax_rate),
  isActive: db.is_active,
  expiryDate: db.expiry_date ? new Date(db.expiry_date) : undefined,
  batchNumber: db.batch_number || undefined,
});

export function useProducts(category?: string) {
  return useQuery({
    queryKey: ['products', category],
    queryFn: async () => {
      let query = supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .order('name');

      if (category && category !== 'All') {
        query = query.eq('category', category);
      }

      const { data, error } = await query;
      if (error) throw error;
      return (data as DbProduct[]).map(mapDbToProduct);
    },
  });
}

export function useProduct(id: string) {
  return useQuery({
    queryKey: ['product', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', id)
        .single();
      if (error) throw error;
      return mapDbToProduct(data as DbProduct);
    },
    enabled: !!id,
  });
}

export function useCreateProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (product: Omit<Product, 'id'>) => {
      const { data, error } = await supabase
        .from('products')
        .insert({
          name: product.name,
          sku: product.sku,
          barcode: product.barcode || null,
          price: product.price,
          cost: product.cost,
          category: product.category,
          stock: product.stock,
          low_stock_alert: product.lowStockAlert,
          image: product.image || null,
          tax_rate: product.taxRate,
          is_active: product.isActive,
          expiry_date: product.expiryDate?.toISOString() || null,
          batch_number: product.batchNumber || null,
        })
        .select()
        .single();
      if (error) throw error;
      return mapDbToProduct(data as DbProduct);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
  });
}

export function useUpdateProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...product }: Partial<Product> & { id: string }) => {
      const updateData: Record<string, unknown> = {};
      if (product.name !== undefined) updateData.name = product.name;
      if (product.sku !== undefined) updateData.sku = product.sku;
      if (product.barcode !== undefined) updateData.barcode = product.barcode || null;
      if (product.price !== undefined) updateData.price = product.price;
      if (product.cost !== undefined) updateData.cost = product.cost;
      if (product.category !== undefined) updateData.category = product.category;
      if (product.stock !== undefined) updateData.stock = product.stock;
      if (product.lowStockAlert !== undefined) updateData.low_stock_alert = product.lowStockAlert;
      if (product.image !== undefined) updateData.image = product.image || null;
      if (product.taxRate !== undefined) updateData.tax_rate = product.taxRate;
      if (product.isActive !== undefined) updateData.is_active = product.isActive;
      if (product.expiryDate !== undefined) updateData.expiry_date = product.expiryDate?.toISOString() || null;
      if (product.batchNumber !== undefined) updateData.batch_number = product.batchNumber || null;

      const { data, error } = await supabase
        .from('products')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return mapDbToProduct(data as DbProduct);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
  });
}

export function useDeleteProduct() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('products').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
    },
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      if (error) throw error;
      return data;
    },
  });
}

export function useProductsByCategory() {
  return useQuery({
    queryKey: ['products-by-category'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('category')
        .eq('is_active', true);
      if (error) throw error;
      
      const counts: Record<string, number> = {};
      data.forEach((p) => {
        counts[p.category] = (counts[p.category] || 0) + 1;
      });
      return counts;
    },
  });
}
