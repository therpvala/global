import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface EmployeePerformance {
  id: string;
  employee_id: string;
  period_start: string;
  period_end: string;
  sales_amount: number | null;
  transactions_count: number | null;
  attendance_percentage: number | null;
  rating: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface PerformanceWithEmployee extends EmployeePerformance {
  employees: {
    id: string;
    full_name: string;
    position: string;
    department: string;
    avatar_url: string | null;
  } | null;
}

export interface PerformanceInsert {
  employee_id: string;
  period_start: string;
  period_end: string;
  sales_amount?: number;
  transactions_count?: number;
  attendance_percentage?: number;
  rating?: number;
  notes?: string | null;
}

export function useEmployeePerformances(periodStart?: string, periodEnd?: string) {
  return useQuery({
    queryKey: ['employee-performance', periodStart, periodEnd],
    queryFn: async () => {
      let query = supabase
        .from('employee_performance')
        .select(`
          *,
          employees (
            id,
            full_name,
            position,
            department,
            avatar_url
          )
        `)
        .order('sales_amount', { ascending: false });

      if (periodStart) {
        query = query.gte('period_start', periodStart);
      }
      if (periodEnd) {
        query = query.lte('period_end', periodEnd);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as PerformanceWithEmployee[];
    },
  });
}

export function useCreatePerformance() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (performance: PerformanceInsert) => {
      const { data, error } = await supabase
        .from('employee_performance')
        .insert(performance)
        .select()
        .single();

      if (error) throw error;
      return data as EmployeePerformance;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee-performance'] });
      toast.success('Performance record created');
    },
    onError: (error) => {
      toast.error('Failed to create performance record: ' + error.message);
    },
  });
}

export function useUpdatePerformance() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<PerformanceInsert> & { id: string }) => {
      const { data, error } = await supabase
        .from('employee_performance')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data as EmployeePerformance;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee-performance'] });
      toast.success('Performance record updated');
    },
    onError: (error) => {
      toast.error('Failed to update performance record: ' + error.message);
    },
  });
}
