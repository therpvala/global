import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  Plus, Search, Phone, Mail, MapPin, Building2, FileText, 
  Package, TrendingUp, Users, Edit, Trash2, Eye, Filter,
  ShoppingCart, Calendar, DollarSign, Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { categories } from '@/data/mockData';

interface Supplier {
  id: string;
  name: string;
  contact_person: string | null;
  email: string | null;
  phone: string;
  address: string | null;
  category: string;
  gst_number: string | null;
  payment_terms: string | null;
  notes: string | null;
  is_active: boolean;
  created_at: string;
}

interface PurchaseOrder {
  id: string;
  order_number: string;
  supplier_id: string;
  status: string;
  items: unknown;
  subtotal: number;
  tax: number;
  total: number;
  expected_delivery: string | null;
  received_at: string | null;
  notes: string | null;
  created_at: string;
  suppliers?: Supplier | null;
}

const supplierCategories = categories.filter(c => 
  ['Milk Men', 'Vegetable Supplier', 'Fruit Vendor', 'Meat Supplier', 'Fish & Seafood', 'Egg Supplier', 
   'Rice & Grains', 'Pulses & Lentils', 'Cooking Oil', 'Spices & Masala', 'Beverages', 'Dairy', 'Bakery'].includes(c.name)
);

export default function Suppliers() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isAddSupplierOpen, setIsAddSupplierOpen] = useState(false);
  const [isAddOrderOpen, setIsAddOrderOpen] = useState(false);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [activeTab, setActiveTab] = useState('suppliers');

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    contact_person: '',
    email: '',
    phone: '',
    address: '',
    category: '',
    gst_number: '',
    payment_terms: '30 days',
    notes: ''
  });

  const [orderFormData, setOrderFormData] = useState({
    supplier_id: '',
    expected_delivery: '',
    notes: '',
    items: [{ name: '', quantity: 1, price: 0 }]
  });

  useEffect(() => {
    fetchSuppliers();
    fetchPurchaseOrders();
  }, []);

  const fetchSuppliers = async () => {
    try {
      const { data, error } = await supabase
        .from('suppliers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSuppliers(data || []);
    } catch (error: any) {
      toast.error('Failed to fetch suppliers');
    } finally {
      setLoading(false);
    }
  };

  const fetchPurchaseOrders = async () => {
    try {
      const { data, error } = await supabase
        .from('purchase_orders')
        .select('*, suppliers(*)')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPurchaseOrders(data || []);
    } catch (error: any) {
      toast.error('Failed to fetch purchase orders');
    }
  };

  const handleAddSupplier = async () => {
    if (!formData.name || !formData.phone || !formData.category) {
      toast.error('Please fill required fields');
      return;
    }

    try {
      const { error } = await supabase
        .from('suppliers')
        .insert({
          name: formData.name,
          contact_person: formData.contact_person || null,
          email: formData.email || null,
          phone: formData.phone,
          address: formData.address || null,
          category: formData.category,
          gst_number: formData.gst_number || null,
          payment_terms: formData.payment_terms,
          notes: formData.notes || null
        });

      if (error) throw error;

      toast.success('Supplier added successfully');
      setIsAddSupplierOpen(false);
      setFormData({
        name: '',
        contact_person: '',
        email: '',
        phone: '',
        address: '',
        category: '',
        gst_number: '',
        payment_terms: '30 days',
        notes: ''
      });
      fetchSuppliers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add supplier');
    }
  };

  const handleCreateOrder = async () => {
    if (!orderFormData.supplier_id) {
      toast.error('Please select a supplier');
      return;
    }

    const validItems = orderFormData.items.filter(item => item.name && item.quantity > 0);
    if (validItems.length === 0) {
      toast.error('Please add at least one item');
      return;
    }

    const subtotal = validItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.18; // 18% GST
    const total = subtotal + tax;

    try {
      const orderNumber = `PO-${Date.now().toString(36).toUpperCase()}`;
      
      const { error } = await supabase
        .from('purchase_orders')
        .insert({
          order_number: orderNumber,
          supplier_id: orderFormData.supplier_id,
          items: validItems,
          subtotal,
          tax,
          total,
          expected_delivery: orderFormData.expected_delivery || null,
          notes: orderFormData.notes || null
        });

      if (error) throw error;

      toast.success('Purchase order created');
      setIsAddOrderOpen(false);
      setOrderFormData({
        supplier_id: '',
        expected_delivery: '',
        notes: '',
        items: [{ name: '', quantity: 1, price: 0 }]
      });
      fetchPurchaseOrders();
    } catch (error: any) {
      toast.error(error.message || 'Failed to create order');
    }
  };

  const handleDeleteSupplier = async (id: string) => {
    if (!confirm('Are you sure you want to delete this supplier?')) return;

    try {
      const { error } = await supabase
        .from('suppliers')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('Supplier deleted');
      fetchSuppliers();
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete supplier');
    }
  };

  const addOrderItem = () => {
    setOrderFormData(prev => ({
      ...prev,
      items: [...prev.items, { name: '', quantity: 1, price: 0 }]
    }));
  };

  const updateOrderItem = (index: number, field: string, value: any) => {
    setOrderFormData(prev => ({
      ...prev,
      items: prev.items.map((item, i) => i === index ? { ...item, [field]: value } : item)
    }));
  };

  const filteredSuppliers = suppliers.filter(supplier => {
    const matchesSearch = supplier.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      supplier.phone.includes(searchQuery) ||
      supplier.contact_person?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || supplier.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-warning/20 text-warning border-warning/30';
      case 'approved': return 'bg-accent/20 text-accent border-accent/30';
      case 'ordered': return 'bg-primary/20 text-primary border-primary/30';
      case 'received': return 'bg-success/20 text-success border-success/30';
      case 'cancelled': return 'bg-destructive/20 text-destructive border-destructive/30';
      default: return 'bg-secondary';
    }
  };

  const getCategoryColor = (categoryName: string) => {
    const cat = categories.find(c => c.name === categoryName);
    return cat?.color || '#3B82F6';
  };

  // Stats
  const activeSuppliers = suppliers.filter(s => s.is_active).length;
  const pendingOrders = purchaseOrders.filter(o => o.status === 'pending').length;
  const totalOrderValue = purchaseOrders.reduce((sum, o) => sum + Number(o.total), 0);

  return (
    <MainLayout>
      <div className="space-y-6 p-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold ocean-text">Supplier Management</h1>
            <p className="text-muted-foreground mt-1">Track vendors, contacts, and purchase orders</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isAddOrderOpen} onOpenChange={setIsAddOrderOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="border-primary/30 hover:border-primary/50">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  New Order
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create Purchase Order</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Supplier *</Label>
                      <Select value={orderFormData.supplier_id} onValueChange={(v) => setOrderFormData(prev => ({ ...prev, supplier_id: v }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select supplier" />
                        </SelectTrigger>
                        <SelectContent>
                          {suppliers.filter(s => s.is_active).map(s => (
                            <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Expected Delivery</Label>
                      <Input 
                        type="date" 
                        value={orderFormData.expected_delivery}
                        onChange={(e) => setOrderFormData(prev => ({ ...prev, expected_delivery: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Order Items</Label>
                    <div className="space-y-2 mt-2">
                      {orderFormData.items.map((item, index) => (
                        <div key={index} className="grid grid-cols-3 gap-2">
                          <Input 
                            placeholder="Item name"
                            value={item.name}
                            onChange={(e) => updateOrderItem(index, 'name', e.target.value)}
                          />
                          <Input 
                            type="number"
                            placeholder="Qty"
                            value={item.quantity}
                            onChange={(e) => updateOrderItem(index, 'quantity', parseInt(e.target.value) || 0)}
                          />
                          <Input 
                            type="number"
                            placeholder="Price"
                            value={item.price}
                            onChange={(e) => updateOrderItem(index, 'price', parseFloat(e.target.value) || 0)}
                          />
                        </div>
                      ))}
                      <Button type="button" variant="outline" size="sm" onClick={addOrderItem}>
                        <Plus className="h-3 w-3 mr-1" /> Add Item
                      </Button>
                    </div>
                  </div>

                  <div>
                    <Label>Notes</Label>
                    <Textarea 
                      value={orderFormData.notes}
                      onChange={(e) => setOrderFormData(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Additional notes..."
                    />
                  </div>

                  <Button onClick={handleCreateOrder} className="w-full">Create Order</Button>
                </div>
              </DialogContent>
            </Dialog>

            <Dialog open={isAddSupplierOpen} onOpenChange={setIsAddSupplierOpen}>
              <DialogTrigger asChild>
                <Button className="ocean-glow">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Supplier
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Supplier</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <Label>Business Name *</Label>
                    <Input 
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Supplier business name"
                    />
                  </div>
                  <div>
                    <Label>Contact Person</Label>
                    <Input 
                      value={formData.contact_person}
                      onChange={(e) => setFormData(prev => ({ ...prev, contact_person: e.target.value }))}
                      placeholder="Primary contact name"
                    />
                  </div>
                  <div>
                    <Label>Phone *</Label>
                    <Input 
                      value={formData.phone}
                      onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="+91 XXXXXXXXXX"
                    />
                  </div>
                  <div>
                    <Label>Email</Label>
                    <Input 
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="email@example.com"
                    />
                  </div>
                  <div>
                    <Label>Category *</Label>
                    <Select value={formData.category} onValueChange={(v) => setFormData(prev => ({ ...prev, category: v }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {supplierCategories.map(cat => (
                          <SelectItem key={cat.id} value={cat.name}>
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: cat.color }} />
                              {cat.name}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>GST Number</Label>
                    <Input 
                      value={formData.gst_number}
                      onChange={(e) => setFormData(prev => ({ ...prev, gst_number: e.target.value }))}
                      placeholder="GST Registration Number"
                    />
                  </div>
                  <div>
                    <Label>Payment Terms</Label>
                    <Select value={formData.payment_terms} onValueChange={(v) => setFormData(prev => ({ ...prev, payment_terms: v }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Immediate">Immediate</SelectItem>
                        <SelectItem value="7 days">7 days</SelectItem>
                        <SelectItem value="15 days">15 days</SelectItem>
                        <SelectItem value="30 days">30 days</SelectItem>
                        <SelectItem value="45 days">45 days</SelectItem>
                        <SelectItem value="60 days">60 days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Label>Address</Label>
                    <Textarea 
                      value={formData.address}
                      onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Full address"
                    />
                  </div>
                  <div className="col-span-2">
                    <Label>Notes</Label>
                    <Textarea 
                      value={formData.notes}
                      onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Additional notes about the supplier..."
                    />
                  </div>
                  <div className="col-span-2">
                    <Button onClick={handleAddSupplier} className="w-full">Add Supplier</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="glass-card ocean-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Suppliers</p>
                <p className="text-2xl font-bold">{suppliers.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-card ocean-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-green-500/20 flex items-center justify-center">
                <Building2 className="h-6 w-6 text-green-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Active Suppliers</p>
                <p className="text-2xl font-bold">{activeSuppliers}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-card ocean-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-yellow-500/20 flex items-center justify-center">
                <Clock className="h-6 w-6 text-yellow-400" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pending Orders</p>
                <p className="text-2xl font-bold">{pendingOrders}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="glass-card ocean-border">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-xl bg-accent/20 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Order Value</p>
                <p className="text-2xl font-bold">₹{totalOrderValue.toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
            <TabsTrigger value="orders">Purchase Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="suppliers" className="mt-4">
            {/* Search & Filter */}
            <div className="flex gap-3 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input 
                  placeholder="Search suppliers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={selectedCategory || 'all'} onValueChange={(v) => setSelectedCategory(v === 'all' ? null : v)}>
                <SelectTrigger className="w-48">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {supplierCategories.map(cat => (
                    <SelectItem key={cat.id} value={cat.name}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Suppliers Table */}
            <Card className="glass-card ocean-border">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader>
                    <TableRow className="border-primary/20">
                      <TableHead>Supplier</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>Payment Terms</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {loading ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8">Loading...</TableCell>
                      </TableRow>
                    ) : filteredSuppliers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          No suppliers found. Add your first supplier to get started.
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredSuppliers.map((supplier) => (
                        <TableRow key={supplier.id} className="border-primary/10 hover:bg-primary/5">
                          <TableCell>
                            <div>
                              <p className="font-medium">{supplier.name}</p>
                              {supplier.contact_person && (
                                <p className="text-xs text-muted-foreground">{supplier.contact_person}</p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge 
                              variant="outline"
                              style={{ 
                                borderColor: getCategoryColor(supplier.category),
                                color: getCategoryColor(supplier.category)
                              }}
                            >
                              {supplier.category}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              <div className="flex items-center gap-1 text-sm">
                                <Phone className="h-3 w-3" />
                                {supplier.phone}
                              </div>
                              {supplier.email && (
                                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                  <Mail className="h-3 w-3" />
                                  {supplier.email}
                                </div>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{supplier.payment_terms}</TableCell>
                          <TableCell>
                            <Badge className={supplier.is_active 
                              ? 'bg-green-500/20 text-green-400 border-green-500/30' 
                              : 'bg-red-500/20 text-red-400 border-red-500/30'
                            }>
                              {supplier.is_active ? 'Active' : 'Inactive'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 text-red-400 hover:text-red-300"
                                onClick={() => handleDeleteSupplier(supplier.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </Card>
          </TabsContent>

          <TabsContent value="orders" className="mt-4">
            {/* Purchase Orders Table */}
            <Card className="glass-card ocean-border">
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader>
                    <TableRow className="border-primary/20">
                      <TableHead>Order #</TableHead>
                      <TableHead>Supplier</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Expected Delivery</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {purchaseOrders.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                          No purchase orders found. Create your first order.
                        </TableCell>
                      </TableRow>
                    ) : (
                      purchaseOrders.map((order) => (
                        <TableRow key={order.id} className="border-primary/10 hover:bg-primary/5">
                          <TableCell className="font-mono font-medium">{order.order_number}</TableCell>
                          <TableCell>{(order.suppliers as Supplier)?.name || 'Unknown'}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{(order.items as any[]).length} items</Badge>
                          </TableCell>
                          <TableCell className="font-medium">₹{Number(order.total).toLocaleString()}</TableCell>
                          <TableCell>
                            {order.expected_delivery 
                              ? new Date(order.expected_delivery).toLocaleDateString()
                              : '-'
                            }
                          </TableCell>
                          <TableCell>
                            <Badge className={getStatusColor(order.status)}>
                              {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-1">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </ScrollArea>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}