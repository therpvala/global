import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { RecentTransactions } from '@/components/dashboard/RecentTransactions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';
import { dashboardStats } from '@/data/mockData';
import { 
  DollarSign, ShoppingCart, Clock, Target, Play, TrendingUp,
  Zap, ArrowRight, Package
} from 'lucide-react';

export default function CashierDashboard() {
  const { profile } = useAuth();
  const myStats = { todaySales: 2450, ordersProcessed: 34, itemsSold: 156 };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Cashier</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-1">Welcome, {profile?.full_name || 'Cashier'}!</p>
          </div>
          <Link to="/pos">
            <Button className="gap-2 gradient-primary px-6 h-11">
              <Play className="h-4 w-4" /> Start POS
            </Button>
          </Link>
        </div>

        {/* Quick POS */}
        <div className="stat-card-mixed group cursor-pointer" onClick={() => window.location.href = '/pos'}>
          <div className="flex items-center justify-between relative z-10">
            <div>
              <h2 className="font-display text-2xl font-bold text-white">READY TO BILL</h2>
              <p className="text-white/70 mt-1">Open Point of Sale terminal</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-14 w-14 rounded-2xl bg-white/15 backdrop-blur-sm flex items-center justify-center group-hover:scale-110 transition-transform">
                <Zap className="h-7 w-7 text-white" />
              </div>
              <ArrowRight className="h-6 w-6 text-white/70 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <StatCard title="Today's Sales" value={`$${myStats.todaySales.toLocaleString()}`} change="+18%" changeType="positive" icon={DollarSign} glowColor="pink" />
          <StatCard title="Orders Processed" value={myStats.ordersProcessed.toString()} change="+5" changeType="positive" icon={ShoppingCart} glowColor="blue" />
          <StatCard title="Items Sold" value={myStats.itemsSold.toString()} change="+12" changeType="positive" icon={Package} glowColor="dark" />
        </div>

        {/* Target & Products */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="card-3d neon-border">
            <CardHeader>
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" /> Daily Target
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Sales Target</span>
                  <span className="font-semibold text-sm">${myStats.todaySales} / $3,000</span>
                </div>
                <div className="h-4 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-primary to-secondary transition-all duration-500 rounded-full" style={{ width: `${(myStats.todaySales / 3000) * 100}%` }} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">{Math.round((myStats.todaySales / 3000) * 100)}% achieved</p>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground text-sm">Orders Target</span>
                  <span className="font-semibold text-sm">{myStats.ordersProcessed} / 50</span>
                </div>
                <div className="h-4 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-secondary to-primary transition-all duration-500 rounded-full" style={{ width: `${(myStats.ordersProcessed / 50) * 100}%` }} />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-3d neon-border">
            <CardHeader>
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-secondary" /> Popular Products
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {dashboardStats.topProducts.slice(0, 4).map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card/50">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-8 w-8 rounded-lg bg-primary/15 flex items-center justify-center text-primary font-bold text-sm shrink-0">#{i + 1}</div>
                    <span className="font-medium text-sm truncate">{item.product.name}</span>
                  </div>
                  <span className="text-sm font-bold text-primary shrink-0 ml-2">{item.quantity} sold</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <RecentTransactions />

        {/* Quick Actions */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <CardTitle className="font-display text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'New Sale', icon: ShoppingCart, path: '/pos' },
                { label: 'Customers', icon: Target, path: '/customers' },
                { label: 'Products', icon: Package, path: '/products' },
                { label: 'History', icon: Clock, path: '/transactions' },
              ].map(a => (
                <Link key={a.label} to={a.path}>
                  <Button variant="outline" className="w-full h-20 flex-col gap-2 hover:bg-primary/10 hover:border-primary rounded-xl">
                    <a.icon className="h-6 w-6 text-primary" />
                    <span className="text-sm font-medium">{a.label}</span>
                  </Button>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
