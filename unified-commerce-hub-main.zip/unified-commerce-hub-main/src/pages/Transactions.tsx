import { MainLayout } from '@/components/layout/MainLayout';
import { recentTransactions } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Search,
  Filter,
  Download,
  Eye,
  Printer,
  RotateCcw,
  CreditCard,
  Banknote,
  Smartphone,
  CheckCircle2,
  Clock,
  XCircle,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const paymentIcons = {
  cash: Banknote,
  card: CreditCard,
  upi: Smartphone,
  wallet: Smartphone,
  split: CreditCard,
};

const statusConfig = {
  completed: { icon: CheckCircle2, color: 'text-success', bg: 'bg-success/10' },
  pending: { icon: Clock, color: 'text-warning', bg: 'bg-warning/10' },
  refunded: { icon: RotateCcw, color: 'text-info', bg: 'bg-info/10' },
  cancelled: { icon: XCircle, color: 'text-destructive', bg: 'bg-destructive/10' },
};

// Generate more transactions for display
const allTransactions = [
  ...recentTransactions,
  ...Array(10)
    .fill(null)
    .map((_, i) => ({
      id: `${i + 4}`,
      items: [],
      subtotal: Math.random() * 100 + 10,
      tax: Math.random() * 5,
      discount: Math.random() > 0.7 ? Math.random() * 10 : 0,
      total: Math.random() * 100 + 15,
      paymentMethod: (['cash', 'card', 'upi'] as const)[Math.floor(Math.random() * 3)],
      status: (['completed', 'pending'] as const)[Math.floor(Math.random() * 2)],
      cashierId: '1',
      createdAt: new Date(Date.now() - Math.random() * 86400000 * 7),
      receiptNumber: `RCP-00${1231 - i}`,
    })),
];

export default function Transactions() {
  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Transactions</h1>
            <p className="text-muted-foreground">View and manage all transactions</p>
          </div>
          <Button variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <div className="pro-card p-4">
            <p className="text-sm text-muted-foreground">Today's Transactions</p>
            <p className="font-display text-2xl font-bold text-foreground">127</p>
          </div>
          <div className="pro-card p-4">
            <p className="text-sm text-muted-foreground">Completed</p>
            <p className="font-display text-2xl font-bold text-success">118</p>
          </div>
          <div className="pro-card p-4">
            <p className="text-sm text-muted-foreground">Pending</p>
            <p className="font-display text-2xl font-bold text-warning">6</p>
          </div>
          <div className="pro-card p-4">
            <p className="text-sm text-muted-foreground">Refunded</p>
            <p className="font-display text-2xl font-bold text-accent">3</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-4 items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search by receipt number..." className="pl-10" />
          </div>
          <Input type="date" className="w-40" />
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Transactions Table */}
        <div className="pro-card overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-secondary/50 border-b border-border">
                <TableHead>Receipt #</TableHead>
                <TableHead>Date & Time</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead className="text-right">Subtotal</TableHead>
                <TableHead className="text-right">Tax</TableHead>
                <TableHead className="text-right">Discount</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {allTransactions.map((transaction) => {
                const PaymentIcon = paymentIcons[transaction.paymentMethod];
                const status = statusConfig[transaction.status];
                const StatusIcon = status.icon;

                return (
                  <TableRow key={transaction.id} className="hover:bg-secondary/30">
                    <TableCell className="font-mono font-medium">
                      {transaction.receiptNumber}
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium text-foreground">
                          {transaction.createdAt.toLocaleDateString()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {transaction.createdAt.toLocaleTimeString()}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="gap-1.5">
                        <PaymentIcon className="h-3 w-3" />
                        {transaction.paymentMethod.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      ${transaction.subtotal.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      ${transaction.tax.toFixed(2)}
                    </TableCell>
                    <TableCell className="text-right">
                      {transaction.discount > 0 ? (
                        <span className="text-success">-${transaction.discount.toFixed(2)}</span>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-semibold">
                      ${transaction.total.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={cn('gap-1.5', status.bg, status.color, 'border-current/30')}
                      >
                        <StatusIcon className="h-3 w-3" />
                        {transaction.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Printer className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {allTransactions.length} transactions
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
