import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { TopProducts } from '@/components/dashboard/TopProducts';
import { RecentTransactions } from '@/components/dashboard/RecentTransactions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { dashboardStats } from '@/data/mockData';
import { 
  DollarSign, ShoppingCart, TrendingUp, Users, Clock,
  AlertTriangle, CheckCircle, Calendar, ArrowUpRight, BarChart3
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function ManagerDashboard() {
  const { profile } = useAuth();

  const performanceData = [
    { name: 'Mon', sales: 3200, target: 3000 },
    { name: 'Tue', sales: 4100, target: 3500 },
    { name: 'Wed', sales: 3800, target: 3500 },
    { name: 'Thu', sales: 4500, target: 4000 },
    { name: 'Fri', sales: 5200, target: 4500 },
    { name: 'Sat', sales: 6100, target: 5000 },
    { name: 'Sun', sales: 4567, target: 4000 },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Manager</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-1">Welcome, {profile?.full_name || 'Manager'}!</p>
          </div>
          <Button variant="outline" className="gap-2"><Calendar className="h-4 w-4" /> Today</Button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Daily Sales" value={`$${dashboardStats.todaySales.toLocaleString()}`} change="+12.5%" changeType="positive" icon={DollarSign} glowColor="pink" />
          <StatCard title="Weekly Sales" value={`$${(dashboardStats.todaySales * 7).toLocaleString()}`} change="+8.2%" changeType="positive" icon={TrendingUp} glowColor="blue" />
          <StatCard title="Order Count" value={dashboardStats.todayOrders.toString()} change="+5" changeType="positive" icon={ShoppingCart} glowColor="dark" />
          <StatCard title="Customer Visits" value="89" change="+12" changeType="positive" icon={Users} glowColor="rose" />
        </div>

        {/* Sales vs Target */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" /> Sales vs Target
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `$${v}`} />
                  <Tooltip />
                  <Bar dataKey="target" fill="hsl(var(--brand-medium))" radius={[6, 6, 0, 0]} opacity={0.4} name="Target" />
                  <Bar dataKey="sales" fill="hsl(var(--brand-pink))" radius={[6, 6, 0, 0]} name="Sales" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Staff & Alerts */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card className="card-3d neon-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="font-display text-lg flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" /> Staff Schedule
                </CardTitle>
                <Button variant="ghost" size="sm" className="text-primary gap-1">View All <ArrowUpRight className="h-4 w-4" /></Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: 'John Smith', role: 'Cashier', status: 'On Duty', time: '9 AM – 5 PM' },
                { name: 'Sarah Johnson', role: 'Cashier', status: 'On Duty', time: '10 AM – 6 PM' },
                { name: 'Mike Wilson', role: 'Cashier', status: 'Break', time: '12 PM – 8 PM' },
                { name: 'Emily Davis', role: 'Cashier', status: 'Arriving', time: '2 PM – 10 PM' },
              ].map((staff, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card/50">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="h-10 w-10 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                      <span className="text-primary font-semibold">{staff.name.charAt(0)}</span>
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium text-sm truncate">{staff.name}</p>
                      <p className="text-xs text-muted-foreground">{staff.role}</p>
                    </div>
                  </div>
                  <div className="text-right shrink-0 ml-3">
                    <Badge variant={staff.status === 'On Duty' ? 'default' : staff.status === 'Break' ? 'secondary' : 'outline'}>{staff.status}</Badge>
                    <p className="text-xs text-muted-foreground mt-1">{staff.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="card-3d neon-border">
            <CardHeader>
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-[hsl(var(--warning))]" /> Inventory Alerts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { product: 'Wireless Earbuds', stock: 5, threshold: 10, critical: true },
                { product: 'USB-C Cables', stock: 12, threshold: 20, critical: false },
                { product: 'Phone Cases', stock: 8, threshold: 15, critical: true },
                { product: 'Screen Protectors', stock: 18, threshold: 25, critical: false },
              ].map((item, i) => (
                <div key={i} className="p-3 rounded-xl border border-border bg-card/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-sm truncate mr-2">{item.product}</span>
                    <Badge variant={item.critical ? 'destructive' : 'secondary'} className="shrink-0">{item.critical ? 'Critical' : 'Low'}</Badge>
                  </div>
                  <Progress value={(item.stock / item.threshold) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-1">{item.stock} / {item.threshold}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Daily Tasks */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-[hsl(var(--success))]" /> Daily Tasks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                { task: 'Open store and verify cash register', done: true },
                { task: 'Check inventory levels', done: true },
                { task: 'Review staff schedule', done: true },
                { task: 'Process pending returns', done: false },
                { task: 'Update promotional displays', done: false },
                { task: 'End of day cash count', done: false },
              ].map((task, i) => (
                <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border border-border bg-card/50 ${task.done ? 'opacity-60' : ''}`}>
                  <div className={`h-5 w-5 rounded-full border-2 flex items-center justify-center shrink-0 ${task.done ? 'bg-[hsl(var(--success))] border-[hsl(var(--success))]' : 'border-muted-foreground'}`}>
                    {task.done && <CheckCircle className="h-3 w-3 text-white" />}
                  </div>
                  <span className={`text-sm truncate ${task.done ? 'line-through text-muted-foreground' : ''}`}>{task.task}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <TopProducts />
          <RecentTransactions />
        </div>
      </div>
    </MainLayout>
  );
}
