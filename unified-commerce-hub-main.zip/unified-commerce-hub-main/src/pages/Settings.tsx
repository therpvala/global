import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Store,
  CreditCard,
  Bell,
  Shield,
  Printer,
  Globe,
  Users,
  Palette,
} from 'lucide-react';

export default function Settings() {
  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Manage your POS system preferences</p>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="general" className="gap-2">
              <Store className="h-4 w-4" />
              General
            </TabsTrigger>
            <TabsTrigger value="payments" className="gap-2">
              <CreditCard className="h-4 w-4" />
              Payments
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="hardware" className="gap-2">
              <Printer className="h-4 w-4" />
              Hardware
            </TabsTrigger>
            <TabsTrigger value="team" className="gap-2">
              <Users className="h-4 w-4" />
              Team
            </TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Store Information</CardTitle>
                <CardDescription>
                  Basic information about your business
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Store Name</Label>
                    <Input defaultValue="SwiftPOS Demo Store" />
                  </div>
                  <div className="space-y-2">
                    <Label>Business ID</Label>
                    <Input defaultValue="BUS-123456" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input type="email" defaultValue="store@swiftpos.com" />
                  </div>
                  <div className="space-y-2">
                    <Label>Phone</Label>
                    <Input defaultValue="+1 234 567 8900" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Address</Label>
                  <Input defaultValue="123 Business Street, City, State 12345" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <CardTitle>Tax Settings</CardTitle>
                <CardDescription>
                  Configure tax rates for your region
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Default Tax Rate (%)</Label>
                    <Input type="number" defaultValue="5" />
                  </div>
                  <div className="space-y-2">
                    <Label>Tax ID / GST Number</Label>
                    <Input defaultValue="GST123456789" />
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Include Tax in Prices</p>
                    <p className="text-sm text-muted-foreground">
                      Show prices with tax included
                    </p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <CardTitle>Regional Settings</CardTitle>
                <CardDescription>
                  Currency and language preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Currency</Label>
                    <Input defaultValue="USD ($)" />
                  </div>
                  <div className="space-y-2">
                    <Label>Language</Label>
                    <Input defaultValue="English (US)" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Date Format</Label>
                    <Input defaultValue="MM/DD/YYYY" />
                  </div>
                  <div className="space-y-2">
                    <Label>Time Format</Label>
                    <Input defaultValue="12 Hour" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Settings */}
          <TabsContent value="payments" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>
                  Enable or disable payment options
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {['Cash', 'Credit/Debit Card', 'UPI', 'Digital Wallet', 'Split Payment'].map(
                  (method) => (
                    <div key={method} className="flex items-center justify-between py-2">
                      <div>
                        <p className="font-medium">{method}</p>
                        <p className="text-sm text-muted-foreground">
                          Accept {method.toLowerCase()} payments
                        </p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  )
                )}
              </CardContent>
            </Card>

            <Card className="border-border">
              <CardHeader>
                <CardTitle>Payment Gateway</CardTitle>
                <CardDescription>
                  Configure your payment processor
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>API Key</Label>
                  <Input type="password" placeholder="Enter your API key" />
                </div>
                <div className="space-y-2">
                  <Label>Merchant ID</Label>
                  <Input placeholder="Enter your merchant ID" />
                </div>
                <Button className="gradient-primary">Connect Payment Gateway</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Alert Preferences</CardTitle>
                <CardDescription>
                  Choose what notifications you receive
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { title: 'Low Stock Alerts', desc: 'Get notified when products are running low' },
                  { title: 'Daily Sales Summary', desc: 'Receive end of day sales report' },
                  { title: 'New Orders', desc: 'Notifications for new orders' },
                  { title: 'Payment Received', desc: 'Alerts for successful payments' },
                  { title: 'Staff Activity', desc: 'Track staff clock in/out' },
                ].map((item) => (
                  <div key={item.title} className="flex items-center justify-between py-2">
                    <div>
                      <p className="font-medium">{item.title}</p>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hardware */}
          <TabsContent value="hardware" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Connected Devices</CardTitle>
                <CardDescription>
                  Manage your POS hardware
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { name: 'Receipt Printer', status: 'Connected', model: 'Epson TM-T88VI' },
                  { name: 'Barcode Scanner', status: 'Connected', model: 'Zebra DS2208' },
                  { name: 'Cash Drawer', status: 'Connected', model: 'APG VB320' },
                  { name: 'Card Terminal', status: 'Not Connected', model: '-' },
                ].map((device) => (
                  <div
                    key={device.name}
                    className="flex items-center justify-between py-3 border-b border-border last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary">
                        <Printer className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium">{device.name}</p>
                        <p className="text-sm text-muted-foreground">{device.model}</p>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={
                        device.status === 'Connected'
                          ? 'border-success/30 bg-success/10 text-success'
                          : 'border-muted bg-muted/50 text-muted-foreground'
                      }
                    >
                      {device.status}
                    </Badge>
                  </div>
                ))}
                <Button variant="outline" className="w-full mt-4">
                  + Add Device
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team */}
          <TabsContent value="team" className="space-y-6">
            <Card className="border-border">
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
                <CardDescription>
                  Manage staff access and permissions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { name: 'Alex Johnson', role: 'Manager', email: 'alex@store.com' },
                  { name: 'Sarah Wilson', role: 'Cashier', email: 'sarah@store.com' },
                  { name: 'Mike Chen', role: 'Cashier', email: 'mike@store.com' },
                ].map((member) => (
                  <div
                    key={member.email}
                    className="flex items-center justify-between py-3 border-b border-border last:border-0"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-medium">{member.name}</p>
                        <p className="text-sm text-muted-foreground">{member.email}</p>
                      </div>
                    </div>
                    <Badge variant="secondary">{member.role}</Badge>
                  </div>
                ))}
                <Button className="w-full mt-4 gradient-primary">
                  + Invite Team Member
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button className="gradient-primary px-8">Save Changes</Button>
        </div>
      </div>
    </MainLayout>
  );
}
