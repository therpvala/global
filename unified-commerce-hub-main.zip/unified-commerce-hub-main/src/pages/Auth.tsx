import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { z } from "zod";
import { toast } from "sonner";
import { useAuth, AppRole } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import heroPOSBg from "@/assets/hero-pos-bg.jpg";
import { Briefcase, Crown, Loader2, Shield, Store, User, Receipt, Package, Calculator, type LucideIcon } from "lucide-react";

const emailSchema = z.string().email("Invalid email address").max(255);
const passwordSchema = z.string().min(6, "Password must be at least 6 characters").max(100);
const nameSchema = z.string().min(2, "Name must be at least 2 characters").max(100);

const roleOptions: { value: AppRole; label: string; icon: LucideIcon; description: string }[] = [
  { value: "super_admin", label: "Super Admin", icon: Crown, description: "Ultimate system control & oversight" },
  { value: "admin", label: "Admin", icon: Shield, description: "Full system access & user management" },
  { value: "owner", label: "Owner", icon: Store, description: "Business owner with all permissions" },
  { value: "manager", label: "Manager", icon: Briefcase, description: "Manage staff, inventory & reports" },
  { value: "inventory_manager", label: "Inventory Mgr", icon: Package, description: "Stock management & tracking" },
  { value: "accountant", label: "Accountant", icon: Calculator, description: "Financial reports & accounting" },
  { value: "cashier", label: "Cashier", icon: User, description: "POS billing & customer service" },
];

const demoCredentials: { role: string; email: string; password: string; label: string; icon: LucideIcon; color: string }[] = [
  { role: "super_admin", email: "superadmin@smartpos.demo", password: "demo123456", label: "Super Admin", icon: Crown, color: "from-[#E1035A] to-[#F946AB]" },
  { role: "admin", email: "admin@smartpos.demo", password: "demo123456", label: "Admin", icon: Shield, color: "from-[#415BA7] to-[#133072]" },
  { role: "owner", email: "owner@smartpos.demo", password: "demo123456", label: "Owner", icon: Store, color: "from-[#133072] to-[#E1035A]" },
  { role: "manager", email: "manager@smartpos.demo", password: "demo123456", label: "Manager", icon: Briefcase, color: "from-[#133072] to-[#415BA7]" },
  { role: "cashier", email: "cashier@smartpos.demo", password: "demo123456", label: "Cashier", icon: User, color: "from-[#415BA7] to-[#F946AB]" },
  { role: "inventory_manager", email: "inventory@smartpos.demo", password: "demo123456", label: "Inventory Mgr", icon: Package, color: "from-[#F946AB] to-[#E1035A]" },
  { role: "accountant", email: "accountant@smartpos.demo", password: "demo123456", label: "Accountant", icon: Calculator, color: "from-[#E1035A] to-[#133072]" },
];

export default function Auth() {
  const navigate = useNavigate();
  const { user, signIn, signUp, loading } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<"login" | "signup">("login");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupName, setSignupName] = useState("");
  const [selectedRole, setSelectedRole] = useState<AppRole>("cashier");

  useEffect(() => {
    if (user && !loading) navigate("/dashboard");
  }, [user, loading, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try { emailSchema.parse(loginEmail); passwordSchema.parse(loginPassword); }
    catch (err) { if (err instanceof z.ZodError) toast.error(err.errors[0].message); return; }
    setIsSubmitting(true);
    const { error } = await signIn(loginEmail, loginPassword);
    setIsSubmitting(false);
    if (error) { toast.error(error.message.includes("Invalid login credentials") ? "Invalid email or password" : error.message); return; }
    toast.success("Welcome back!");
  };

  const handleQuickFill = (email: string, password: string) => {
    setLoginEmail(email);
    setLoginPassword(password);
    const cred = demoCredentials.find(c => c.email === email);
    toast.info(`Credentials filled for ${cred?.label || "User"}. Click Sign In to continue.`);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    try { emailSchema.parse(signupEmail); passwordSchema.parse(signupPassword); nameSchema.parse(signupName); }
    catch (err) { if (err instanceof z.ZodError) toast.error(err.errors[0].message); return; }
    setIsSubmitting(true);
    const { error } = await signUp(signupEmail, signupPassword, signupName, selectedRole);
    setIsSubmitting(false);
    if (error) { toast.error(error.message.includes("User already registered") ? "An account with this email already exists" : error.message); return; }
    toast.success("Account created. Check your email to confirm, then sign in.");
    setActiveTab("login");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050831] flex items-center justify-center">
        <div className="rounded-2xl border border-[#F946AB]/30 bg-[#050831]/80 p-8 text-center backdrop-blur-xl">
          <Loader2 className="h-8 w-8 animate-spin text-[#F946AB] mx-auto" />
          <p className="mt-3 text-sm font-semibold text-white/70">Loading…</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-[#050831]">
      {/* Left: POS Image Card */}
      <section className="relative hidden lg:flex flex-col">
        <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${heroPOSBg})` }} />
        <div className="absolute inset-0 bg-gradient-to-br from-[#050831]/92 via-[#133072]/80 to-[#415BA7]/60" />
        <div className="relative z-10 p-10 h-full flex flex-col">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl border border-[#F946AB]/40 bg-gradient-to-br from-[#F946AB]/20 to-[#415BA7]/20 flex items-center justify-center">
              <Receipt className="h-6 w-6 text-[#F946AB]" />
            </div>
            <div>
              <p className="font-display text-2xl font-black text-white">Smart<span className="text-[#F946AB]">POS</span></p>
              <p className="text-sm font-semibold text-white/70">Premium POS & Billing</p>
            </div>
          </div>
          <div className="mt-auto mb-10">
            <div className="rounded-3xl border border-[#F946AB]/30 bg-[#050831]/70 p-8 backdrop-blur-xl max-w-xl">
              <p className="text-sm font-bold tracking-widest text-[#F946AB] uppercase">Counter-ready UI</p>
              <h1 className="mt-4 font-display text-4xl font-black text-white leading-tight">
                Fast billing, clean reports,
                <span className="block mt-2 bg-gradient-to-r from-[#F946AB] to-[#E1035A] bg-clip-text text-transparent">and premium control.</span>
              </h1>
              <p className="mt-5 text-white/80 text-base leading-relaxed">
                Sign in to manage products, process sales, and track performance.
              </p>
            </div>
          </div>
          <p className="text-sm font-medium text-white/60">
            Powered by <span className="font-bold text-[#F946AB]">Softwarewala</span><span className="text-white">™</span>
          </p>
        </div>
      </section>

      {/* Right: Form */}
      <section className="relative flex flex-col items-center justify-center px-5 py-10 lg:px-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#050831] to-[#133072]/40" />
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-[#F946AB]/8 rounded-full blur-3xl" />

        <div className="relative z-10 w-full max-w-md">
          {/* Mobile Logo */}
          <div className="flex items-center gap-3 lg:hidden mb-6">
            <div className="h-11 w-11 rounded-xl border border-[#F946AB]/40 bg-gradient-to-br from-[#F946AB]/20 to-[#415BA7]/20 flex items-center justify-center">
              <Receipt className="h-5 w-5 text-[#F946AB]" />
            </div>
            <p className="font-display text-xl font-black text-white">Smart<span className="text-[#F946AB]">POS</span></p>
          </div>

          {/* Auth Card */}
          <div className="rounded-3xl border border-white/10 bg-[#050831]/80 p-8 backdrop-blur-xl">
            <div className="text-center">
              <h2 className="font-display text-2xl font-black text-white">Welcome Back</h2>
              <p className="mt-2 text-sm text-white/70">Sign in to access your dashboard.</p>
            </div>

            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "login" | "signup")} className="mt-6">
              <TabsList className="grid w-full grid-cols-2 rounded-full bg-white/10 p-1">
                <TabsTrigger value="login" className="rounded-full data-[state=active]:bg-[#F946AB] data-[state=active]:text-white font-bold">Sign In</TabsTrigger>
                <TabsTrigger value="signup" className="rounded-full data-[state=active]:bg-[#F946AB] data-[state=active]:text-white font-bold">Sign Up</TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="mt-6">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="login-email" className="text-white">Email</Label>
                    <Input id="login-email" type="email" placeholder="you@company.com" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} required
                      className="border border-white/20 bg-white/5 text-white placeholder:text-white/40 focus:border-[#F946AB]" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="login-password" className="text-white">Password</Label>
                    <Input id="login-password" type="password" placeholder="••••••••" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} required
                      className="border border-white/20 bg-white/5 text-white placeholder:text-white/40 focus:border-[#F946AB]" />
                  </div>
                  <Button type="submit" className="w-full bg-gradient-to-r from-[#F946AB] to-[#E1035A] text-white font-bold hover:opacity-90 border border-[#F946AB]/50" size="lg" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Sign In
                  </Button>
                </form>

                {/* Quick Login */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <p className="text-center text-sm font-bold text-white/70 mb-4">Quick Demo Login</p>
                  <div className="grid grid-cols-3 gap-2">
                    {demoCredentials.map((cred) => (
                      <Button key={cred.email} type="button" size="sm" onClick={() => handleQuickFill(cred.email, cred.password)} disabled={isSubmitting}
                        className={`flex flex-col items-center gap-1 h-auto py-3 bg-gradient-to-r ${cred.color} text-white font-bold border border-white/20 hover:opacity-90`}
                        title={`Fill credentials for ${cred.label}\n${cred.email}`}>
                        <cred.icon className="h-4 w-4" />
                        <span className="text-[10px] font-bold truncate w-full text-center">{cred.label}</span>
                      </Button>
                    ))}
                  </div>
                  <p className="text-center text-xs text-white/50 mt-3">Click a role to fill credentials, then press Sign In</p>
                </div>
              </TabsContent>

              <TabsContent value="signup" className="mt-6">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="signup-name" className="text-white">Full name</Label>
                    <Input id="signup-name" type="text" placeholder="Your name" value={signupName} onChange={(e) => setSignupName(e.target.value)} required
                      className="border border-white/20 bg-white/5 text-white placeholder:text-white/40 focus:border-[#F946AB]" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email" className="text-white">Email</Label>
                    <Input id="signup-email" type="email" placeholder="you@company.com" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} required
                      className="border border-white/20 bg-white/5 text-white placeholder:text-white/40 focus:border-[#F946AB]" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password" className="text-white">Password</Label>
                    <Input id="signup-password" type="password" placeholder="Create a password" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} required
                      className="border border-white/20 bg-white/5 text-white placeholder:text-white/40 focus:border-[#F946AB]" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Role</Label>
                    <Select value={selectedRole} onValueChange={(v) => setSelectedRole(v as AppRole)}>
                      <SelectTrigger className="border border-white/20 bg-white/5 text-white"><SelectValue placeholder="Select role" /></SelectTrigger>
                      <SelectContent>
                        {roleOptions.map((r) => (
                          <SelectItem key={r.value} value={r.value}>
                            <div className="flex items-center gap-2"><r.icon className="h-4 w-4 text-[#F946AB]" /><span className="font-semibold">{r.label}</span></div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-white/60">{roleOptions.find((r) => r.value === selectedRole)?.description}</p>
                  </div>
                  <Button type="submit" className="w-full border border-[#F946AB] bg-transparent text-[#F946AB] hover:bg-[#F946AB] hover:text-white font-bold" size="lg" disabled={isSubmitting}>
                    {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Create Account
                  </Button>
                </form>
              </TabsContent>
            </Tabs>

            <div className="mt-6">
              <Button variant="ghost" className="w-full text-white/70 hover:text-[#F946AB] hover:bg-white/5" onClick={() => navigate("/")}>
                ← Back to landing
              </Button>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm font-medium text-white/60">
              Powered by <span className="font-bold text-[#F946AB]">Softwarewala</span><span className="text-white">™</span>
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
