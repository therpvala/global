import { MainLayout } from "@/components/layout/MainLayout";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StatCard } from "@/components/dashboard/StatCard";
import { useInventoryStats, useLowStockProducts, useInventoryMovements } from "@/hooks/useInventory";
import { useProducts } from "@/hooks/useProducts";
import { 
  Boxes, Package, AlertTriangle, ArrowUpRight, 
  ArrowDownRight, RefreshCw, Truck, BarChart3, ClipboardList, DollarSign
} from "lucide-react";
import { StockMovementModal } from "@/components/inventory/StockMovementModal";
import { useQueryClient } from "@tanstack/react-query";
import { format, subDays, startOfDay } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from "recharts";
import { useMemo } from "react";

export default function InventoryManagerDashboard() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: stats, isLoading: statsLoading } = useInventoryStats();
  const { data: lowStockProducts, isLoading: lowStockLoading } = useLowStockProducts();
  const { data: movements, isLoading: movementsLoading } = useInventoryMovements();
  const { data: allProducts } = useProducts();

  const productMap = new Map((allProducts || []).map(p => [p.id, p.name]));

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['inventory-stats'] });
    queryClient.invalidateQueries({ queryKey: ['low-stock-products'] });
    queryClient.invalidateQueries({ queryKey: ['inventory-movements'] });
    queryClient.invalidateQueries({ queryKey: ['products'] });
  };

  const movementChartData = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      return { date: startOfDay(date).getTime(), label: format(date, "EEE"), stockIn: 0, stockOut: 0 };
    });
    (movements || []).forEach((mov) => {
      const movDate = startOfDay(new Date(mov.created_at)).getTime();
      const day = days.find(d => d.date === movDate);
      if (day) { if (mov.quantity > 0) day.stockIn += mov.quantity; else day.stockOut += Math.abs(mov.quantity); }
    });
    return days;
  }, [movements]);

  const categoryStockData = useMemo(() => {
    const cats: Record<string, number> = {};
    (allProducts || []).forEach(p => { cats[p.category] = (cats[p.category] || 0) + Number(p.stock); });
    return Object.entries(cats).slice(0, 6).map(([name, value], i) => ({
      name: name.length > 10 ? name.substring(0, 10) + '…' : name, value,
      color: ['hsl(var(--brand-pink))', 'hsl(var(--brand-medium))', 'hsl(var(--brand-rose))', 'hsl(var(--brand-dark))', 'hsl(var(--success))', 'hsl(var(--warning))'][i] || 'hsl(var(--muted-foreground))',
    }));
  }, [allProducts]);

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Inventory</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="mt-1 text-muted-foreground">Welcome, {profile?.full_name || "Inventory Manager"}!</p>
          </div>
          <div className="flex gap-2">
            <StockMovementModal />
            <Button onClick={handleRefresh} variant="outline" className="gap-2"><RefreshCw className="h-4 w-4" /> Refresh</Button>
          </div>
        </div>

        {/* Gradient Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Products" value={statsLoading ? '—' : (stats?.totalProducts?.toLocaleString() ?? '—')} change={`${stats?.totalStock?.toLocaleString() ?? 0} units`} changeType="positive" icon={Package} glowColor="pink" />
          <StatCard title="Low Stock" value={statsLoading ? '—' : String(stats?.lowStockCount ?? '—')} change="needs attention" changeType="negative" icon={AlertTriangle} glowColor="rose" />
          <StatCard title="Out of Stock" value={statsLoading ? '—' : String(stats?.outOfStockCount ?? '—')} change="needs reorder" changeType="negative" icon={Truck} glowColor="dark" />
          <StatCard title="Stock Value" value={statsLoading ? '—' : `$${stats?.totalValue.toLocaleString(undefined, { minimumFractionDigits: 0 })}`} change={`${stats?.totalProducts ?? 0} SKUs`} changeType="positive" icon={DollarSign} glowColor="blue" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="card-3d neon-border p-5">
            <CardHeader className="p-0 pb-4">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                <CardTitle className="font-display text-lg">Daily Stock Movement</CardTitle>
                <Badge variant="outline" className="ml-auto text-xs">Last 7 Days</Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {movementsLoading ? <Skeleton className="h-[250px] w-full rounded-xl" /> : (
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={movementChartData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                      <XAxis dataKey="label" className="text-xs" />
                      <YAxis className="text-xs" />
                      <Tooltip />
                      <Bar dataKey="stockIn" fill="hsl(var(--success))" radius={[4, 4, 0, 0]} name="Stock In" />
                      <Bar dataKey="stockOut" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} name="Stock Out" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="card-3d neon-border p-5">
            <CardHeader className="p-0 pb-4">
              <div className="flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                <CardTitle className="font-display text-lg">Category Stock</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart><Pie data={categoryStockData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                    {categoryStockData.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie><Tooltip /></PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1 mt-2">
                {categoryStockData.map(c => (
                  <div key={c.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2"><div className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: c.color }} /><span className="text-muted-foreground truncate">{c.name}</span></div>
                    <span className="font-bold">{c.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Stock Alerts */}
          <Card className="card-3d neon-border">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-[hsl(var(--warning))]" />
                <CardTitle className="font-display text-lg">Stock Alerts</CardTitle>
                <Badge variant="outline" className="ml-auto text-xs">{lowStockProducts?.length ?? 0}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {lowStockLoading ? (
                <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
              ) : lowStockProducts && lowStockProducts.length > 0 ? (
                <div className="space-y-3">
                  {lowStockProducts.slice(0, 6).map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card/50">
                      <div className="min-w-0 mr-2">
                        <p className="font-bold text-sm truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground">{item.stock} in stock · Threshold: {item.low_stock_alert}</p>
                      </div>
                      <Badge variant={item.stock === 0 ? "destructive" : "secondary"} className="shrink-0">{item.stock === 0 ? "Out" : "Low"}</Badge>
                    </div>
                  ))}
                </div>
              ) : <p className="text-sm text-muted-foreground text-center py-8">All stock levels healthy! 🎉</p>}
            </CardContent>
          </Card>

          {/* Recent Movements */}
          <Card className="card-3d neon-border">
            <CardHeader>
              <div className="flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-primary" />
                <CardTitle className="font-display text-lg">Recent Movements</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {movementsLoading ? (
                <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
              ) : (movements || []).slice(0, 6).length > 0 ? (
                <div className="space-y-3">
                  {(movements || []).slice(0, 6).map((mov) => {
                    const isIn = mov.quantity > 0;
                    return (
                      <div key={mov.id} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card/50">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${isIn ? "bg-[hsl(var(--success)/0.15)]" : "bg-destructive/15"}`}>
                            <Boxes className={`h-4 w-4 ${isIn ? "text-[hsl(var(--success))]" : "text-destructive"}`} />
                          </div>
                          <div className="min-w-0">
                            <p className="font-bold text-sm truncate">{productMap.get(mov.product_id) || "Unknown"}</p>
                            <p className="text-xs text-muted-foreground truncate">{format(new Date(mov.created_at), "MMM d, h:mm a")} · {mov.movement_type}</p>
                          </div>
                        </div>
                        <Badge variant="outline" className={`font-bold shrink-0 ml-2 ${isIn ? "text-[hsl(var(--success))]" : "text-destructive"}`}>
                          {isIn ? "+" : ""}{mov.quantity}
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              ) : <p className="text-sm text-muted-foreground text-center py-8">No movements yet.</p>}
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}
