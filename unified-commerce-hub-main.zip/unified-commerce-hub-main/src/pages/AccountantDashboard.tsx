import { MainLayout } from "@/components/layout/MainLayout";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StatCard } from "@/components/dashboard/StatCard";
import { useTransactions, useTodayStats } from "@/hooks/useTransactions";
import { useProducts } from "@/hooks/useProducts";
import { 
  DollarSign, TrendingUp, TrendingDown, ArrowUpRight,
  ArrowDownRight, RefreshCw, FileText, Receipt, PieChart as PieChartIcon, BarChart3,
  Download, FileSpreadsheet, Percent
} from "lucide-react";
import { exportToCSV, exportToPDF } from "@/lib/exportUtils";
import { useQueryClient } from "@tanstack/react-query";
import { format, subDays, startOfDay, endOfDay, isWithinInterval } from "date-fns";
import { useMemo, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, BarChart, Bar, ResponsiveContainer, Tooltip, PieChart, Pie, Cell } from "recharts";
import { DateRangeFilter } from "@/components/accountant/DateRangeFilter";

export default function AccountantDashboard() {
  const { profile } = useAuth();
  const queryClient = useQueryClient();
  const { data: todayStats, isLoading: todayLoading } = useTodayStats();
  const { data: transactions, isLoading: txnLoading } = useTransactions(50);
  const { data: productsData } = useProducts();

  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['today-stats'] });
    queryClient.invalidateQueries({ queryKey: ['transactions'] });
  };

  const allTxns = useMemo(() => {
    const txns = transactions || [];
    if (!startDate && !endDate) return txns;
    return txns.filter(t => {
      const txnDate = new Date(t.created_at);
      if (startDate && endDate) return isWithinInterval(txnDate, { start: startOfDay(startDate), end: endOfDay(endDate) });
      if (startDate) return txnDate >= startOfDay(startDate);
      if (endDate) return txnDate <= endOfDay(endDate);
      return true;
    });
  }, [transactions, startDate, endDate]);

  const completedTxns = allTxns.filter(t => t.status === 'completed');
  const refundedTxns = allTxns.filter(t => t.status === 'refunded');
  const isFiltered = !!(startDate || endDate);

  const totalRevenue = isFiltered ? completedTxns.reduce((s, t) => s + Number(t.total), 0) : (todayStats?.todaySales ?? 0);
  const totalTax = completedTxns.reduce((s, t) => s + Number(t.tax), 0);
  const totalDiscount = completedTxns.reduce((s, t) => s + Number(t.discount), 0);
  const refundTotal = refundedTxns.reduce((s, t) => s + Number(t.total), 0);
  const orderCount = isFiltered ? completedTxns.length : (todayStats?.todayOrders ?? 0);
  const formatCurrency = (n: number) => `$${n.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const revenueChartData = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      return { date: startOfDay(date).getTime(), label: format(date, "EEE"), revenue: 0, cost: 0 };
    });
    completedTxns.forEach((txn) => {
      const txnDate = startOfDay(new Date(txn.created_at)).getTime();
      const day = days.find(d => d.date === txnDate);
      if (day) { day.revenue += Number(txn.total); day.cost += Number(txn.subtotal) * 0.6; }
    });
    return days;
  }, [completedTxns]);

  const paymentBreakdown = useMemo(() => {
    const methods: Record<string, number> = {};
    completedTxns.forEach(t => { methods[t.payment_method] = (methods[t.payment_method] || 0) + Number(t.total); });
    const colors = ['hsl(var(--brand-pink))', 'hsl(var(--brand-medium))', 'hsl(var(--brand-rose))', 'hsl(var(--brand-dark))', 'hsl(var(--success))'];
    return Object.entries(methods).map(([name, value], i) => ({ name, value: Math.round(value * 100) / 100, color: colors[i] || colors[0] }));
  }, [completedTxns]);

  const products = productsData || [];
  const totalCost = products.reduce((s, p) => s + Number(p.cost) * Number(p.stock), 0);
  const totalRevenueEst = products.reduce((s, p) => s + Number(p.price) * Number(p.stock), 0);
  const netProfit = totalRevenueEst - totalCost;
  const profitMarginPct = totalRevenueEst > 0 ? ((netProfit / totalRevenueEst) * 100).toFixed(1) : "0.0";

  const taxSummary = [
    { label: "Tax Collected", amount: formatCurrency(totalTax) },
    { label: "Discounts Given", amount: formatCurrency(totalDiscount) },
    { label: "Total Refunds", amount: formatCurrency(refundTotal) },
    { label: "Net Revenue", amount: formatCurrency(completedTxns.reduce((s, t) => s + Number(t.total), 0)) },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Accounts</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="mt-1 text-muted-foreground">Welcome, {profile?.full_name || "Accountant"}!</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" className="gap-2" onClick={() => {
              const rows = completedTxns.map(t => ({
                receipt: t.receipt_number, date: format(new Date(t.created_at), "yyyy-MM-dd HH:mm"),
                method: t.payment_method, subtotal: Number(t.subtotal).toFixed(2), tax: Number(t.tax).toFixed(2),
                discount: Number(t.discount).toFixed(2), total: Number(t.total).toFixed(2), status: t.status,
              }));
              exportToCSV(rows, `financial-report-${format(new Date(), "yyyy-MM-dd")}`);
            }}><FileSpreadsheet className="h-4 w-4" /> CSV</Button>
            <Button variant="outline" className="gap-2" onClick={() => {
              exportToPDF("Financial Report", [
                { heading: "Summary", rows: [{ label: "Revenue", value: formatCurrency(totalRevenue) }, { label: "Orders", value: String(orderCount) }] },
                { heading: "Financial", rows: taxSummary.map(s => ({ label: s.label, value: s.amount })) },
              ], allTxns.slice(0, 20).map(t => ({
                receipt: t.receipt_number, date: format(new Date(t.created_at), "MMM d"), method: t.payment_method,
                amount: `$${Number(t.total).toFixed(2)}`, status: t.status,
              })));
            }}><Download className="h-4 w-4" /> PDF</Button>
            <Button onClick={handleRefresh} className="gap-2 gradient-primary"><RefreshCw className="h-4 w-4" /> Refresh</Button>
          </div>
        </div>

        <DateRangeFilter startDate={startDate} endDate={endDate} onStartChange={setStartDate} onEndChange={setEndDate} onClear={() => { setStartDate(undefined); setEndDate(undefined); }} />

        {/* Gradient Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Total Revenue" value={todayLoading && !isFiltered ? '—' : formatCurrency(totalRevenue)} change={`${orderCount} orders`} changeType="positive" icon={DollarSign} glowColor="pink" />
          <StatCard title="Total Cost" value={formatCurrency(totalCost)} change="estimated" changeType="negative" icon={TrendingDown} glowColor="blue" />
          <StatCard title="Net Profit" value={formatCurrency(netProfit)} change={`${profitMarginPct}% margin`} changeType="positive" icon={TrendingUp} glowColor="dark" />
          <StatCard title="Profit Margin" value={`${profitMarginPct}%`} change="overall" changeType="positive" icon={Percent} glowColor="rose" />
        </div>

        {/* Revenue vs Cost */}
        <Card className="card-3d neon-border p-5">
          <CardHeader className="p-0 pb-4">
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-primary" /> Revenue vs Cost Trend
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {txnLoading ? <Skeleton className="h-[250px] w-full rounded-xl" /> : (
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenueChartData}>
                    <defs>
                      <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--brand-pink))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--brand-pink))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                    <XAxis dataKey="label" className="text-xs" />
                    <YAxis className="text-xs" tickFormatter={(v) => `$${v}`} />
                    <Tooltip />
                    <Area type="monotone" dataKey="revenue" stroke="hsl(var(--brand-pink))" fill="url(#revGrad)" strokeWidth={2} name="Revenue" />
                    <Area type="monotone" dataKey="cost" stroke="hsl(var(--brand-medium))" fill="transparent" strokeWidth={2} strokeDasharray="5 5" name="Cost" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Payment Breakdown */}
          <Card className="card-3d neon-border p-5">
            <CardHeader className="p-0 pb-4">
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <PieChartIcon className="h-5 w-5 text-primary" /> Payment Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {paymentBreakdown.length > 0 ? (
                <>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart><Pie data={paymentBreakdown} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                        {paymentBreakdown.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie><Tooltip /></PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="space-y-1 mt-2">
                    {paymentBreakdown.map(p => (
                      <div key={p.name} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2"><div className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: p.color }} /><span className="text-muted-foreground capitalize truncate">{p.name}</span></div>
                        <span className="font-bold">${p.value.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : <p className="text-sm text-muted-foreground text-center py-8">No payment data.</p>}
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <Card className="card-3d neon-border p-5">
            <CardHeader className="p-0 pb-4">
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" /> Financial Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 space-y-3">
              {taxSummary.map((item) => (
                <div key={item.label} className="flex items-center justify-between p-4 rounded-xl border border-border bg-card/50">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground truncate mr-2">{item.label}</p>
                  <p className="text-xl font-display font-bold shrink-0">{item.amount}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Receipt className="h-5 w-5 text-primary" /> Recent Transactions
            </CardTitle>
          </CardHeader>
          <CardContent>
            {txnLoading ? (
              <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl" />)}</div>
            ) : allTxns.slice(0, 6).length > 0 ? (
              <div className="space-y-3">
                {allTxns.slice(0, 6).map(txn => {
                  const isSale = txn.status === 'completed';
                  return (
                    <div key={txn.id} className="flex items-center justify-between p-3 rounded-xl border border-border bg-card/50">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${isSale ? "bg-[hsl(var(--success)/0.15)]" : "bg-destructive/15"}`}>
                          <DollarSign className={`h-4 w-4 ${isSale ? "text-[hsl(var(--success))]" : "text-destructive"}`} />
                        </div>
                        <div className="min-w-0">
                          <p className="font-bold text-sm truncate">{txn.receipt_number}</p>
                          <p className="text-xs text-muted-foreground truncate">{format(new Date(txn.created_at), "MMM d, h:mm a")} · {txn.payment_method}</p>
                        </div>
                      </div>
                      <span className={`font-bold text-sm shrink-0 ml-2 ${isSale ? "text-[hsl(var(--success))]" : "text-destructive"}`}>
                        {isSale ? "+" : "-"}${Number(txn.total).toFixed(2)}
                      </span>
                    </div>
                  );
                })}
              </div>
            ) : <p className="text-sm text-muted-foreground text-center py-8">No transactions.</p>}
          </CardContent>
        </Card>

        {/* Product Margin */}
        <Card className="card-3d neon-border p-5">
          <CardHeader className="p-0 pb-4">
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Percent className="h-5 w-5 text-primary" /> Product Margin Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {products.length > 0 && (
              <>
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={products.slice(0, 8).map(p => ({
                      name: p.name.length > 12 ? p.name.substring(0, 12) + '…' : p.name,
                      cost: Number(p.cost), price: Number(p.price),
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                      <XAxis dataKey="name" className="text-xs" tick={{ fontSize: 10 }} />
                      <YAxis className="text-xs" tickFormatter={(v) => `$${v}`} />
                      <Tooltip />
                      <Bar dataKey="cost" fill="hsl(var(--destructive))" name="Cost" radius={[4, 4, 0, 0]} opacity={0.7} />
                      <Bar dataKey="price" fill="hsl(var(--brand-pink))" name="Price" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="rounded-xl border border-border overflow-hidden mt-4">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-muted/50">
                          <th className="text-left p-3 font-bold text-muted-foreground">Product</th>
                          <th className="text-right p-3 font-bold text-muted-foreground">Cost</th>
                          <th className="text-right p-3 font-bold text-muted-foreground">Price</th>
                          <th className="text-right p-3 font-bold text-muted-foreground">Margin</th>
                        </tr>
                      </thead>
                      <tbody>
                        {products.slice(0, 8).map(p => {
                          const margin = Number(p.price) > 0 ? ((Number(p.price) - Number(p.cost)) / Number(p.price) * 100) : 0;
                          return (
                            <tr key={p.id} className="border-t border-border">
                              <td className="p-3 font-bold truncate max-w-[200px]">{p.name}</td>
                              <td className="p-3 text-right text-destructive font-bold">${Number(p.cost).toFixed(2)}</td>
                              <td className="p-3 text-right text-[hsl(var(--success))] font-bold">${Number(p.price).toFixed(2)}</td>
                              <td className="p-3 text-right">
                                <Badge variant={margin >= 40 ? 'default' : margin >= 20 ? 'secondary' : 'destructive'}>
                                  {margin.toFixed(1)}%
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
