import { useState } from 'react';
import { Sidebar } from '@/components/layout/Sidebar';
import { Footer } from '@/components/layout/Footer';
import { ProductGrid } from '@/components/pos/ProductGrid';
import { Cart } from '@/components/pos/Cart';
import { PaymentModal } from '@/components/pos/PaymentModal';
import { HeldOrdersModal } from '@/components/pos/HeldOrdersModal';
import { DiscountModal } from '@/components/pos/DiscountModal';
import { CustomerSelectModal } from '@/components/pos/CustomerSelectModal';
import { Product, CartItem, PaymentMethod, HeldOrder, Customer } from '@/types/pos';
import { heldOrders as initialHeldOrders } from '@/data/mockData';
import { toast } from 'sonner';
import { Wifi, WifiOff, User, Clock, Pause, Tag, Users, Receipt } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

export default function POS() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isHeldOrdersOpen, setIsHeldOrdersOpen] = useState(false);
  const [isDiscountModalOpen, setIsDiscountModalOpen] = useState(false);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [heldOrders, setHeldOrders] = useState<HeldOrder[]>(initialHeldOrders);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [cartDiscount, setCartDiscount] = useState(0);
  const [isOnline] = useState(navigator.onLine);
  const [currentTime] = useState(new Date());

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) return prev.map((item) => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { product, quantity: 1, discount: 0 }];
    });
    toast.success(`Added ${product.name}`);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) { handleRemoveItem(productId); return; }
    setCartItems((prev) => prev.map((item) => item.product.id === productId ? { ...item, quantity } : item));
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => { setCartItems([]); setCartDiscount(0); setSelectedCustomer(null); };

  const handlePaymentComplete = (method: PaymentMethod, amountPaid: number) => {
    setCartItems([]); setCartDiscount(0); setSelectedCustomer(null); setIsPaymentModalOpen(false);
    toast.success('Transaction completed!');
  };

  const handleHoldOrder = () => {
    if (cartItems.length === 0) { toast.error('Cart is empty'); return; }
    setHeldOrders((prev) => [...prev, { id: `hold-${Date.now()}`, items: [...cartItems], customerName: selectedCustomer?.name, createdAt: new Date() }]);
    setCartItems([]); setCartDiscount(0); setSelectedCustomer(null);
    toast.success('Order held');
  };

  const handleRecallOrder = (order: HeldOrder) => {
    setCartItems(order.items);
    setHeldOrders((prev) => prev.filter((o) => o.id !== order.id));
  };

  const handleApplyDiscount = (discount: number, type: 'percentage' | 'fixed') => {
    const subtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const amount = type === 'percentage' ? (subtotal * discount) / 100 : discount;
    setCartDiscount(amount);
    toast.success(`Discount of $${amount.toFixed(2)} applied`);
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const tax = (subtotal - cartDiscount) * 0.05;
  const total = subtotal - cartDiscount + tax;

  return (
    <div className="min-h-screen bg-background flex overflow-hidden">
      <Sidebar />
      <div className="flex-1 pl-64 flex flex-col h-screen overflow-hidden">
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 flex flex-col overflow-hidden">
            <header className="h-14 border-b border-border bg-card/80 flex items-center justify-between px-6 flex-shrink-0">
              <div className="flex items-center gap-3">
                <h1 className="text-lg font-bold font-display text-foreground">Point of Sale</h1>
                <Badge variant="outline" className="gap-1.5 text-xs">
                  <Clock className="h-3 w-3" />
                  {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Tooltip><TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setIsCustomerModalOpen(true)}><Users className="h-4 w-4" /></Button>
                </TooltipTrigger><TooltipContent>Customer</TooltipContent></Tooltip>
                <Tooltip><TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setIsDiscountModalOpen(true)}><Tag className="h-4 w-4" /></Button>
                </TooltipTrigger><TooltipContent>Discount</TooltipContent></Tooltip>
                <Tooltip><TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8 relative" onClick={() => setIsHeldOrdersOpen(true)}>
                    <Pause className="h-4 w-4" />
                    {heldOrders.length > 0 && <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-bold flex items-center justify-center text-white">{heldOrders.length}</span>}
                  </Button>
                </TooltipTrigger><TooltipContent>Held Orders</TooltipContent></Tooltip>
                <Tooltip><TooltipTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8" onClick={handleHoldOrder} disabled={cartItems.length === 0}><Receipt className="h-4 w-4" /></Button>
                </TooltipTrigger><TooltipContent>Hold Order</TooltipContent></Tooltip>
                {isOnline ? (
                  <Badge variant="outline" className="gap-1 text-xs text-success border-success/30 bg-success/10"><Wifi className="h-3 w-3" />Online</Badge>
                ) : (
                  <Badge variant="outline" className="gap-1 text-xs text-warning border-warning/30 bg-warning/10"><WifiOff className="h-3 w-3" />Offline</Badge>
                )}
              </div>
            </header>

            {selectedCustomer && (
              <div className="mx-4 mt-3 p-3 rounded-xl border border-primary/20 bg-primary/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center"><User className="h-4 w-4 text-primary" /></div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{selectedCustomer.name}</p>
                    <p className="text-xs text-muted-foreground">{selectedCustomer.loyaltyPoints} pts</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={() => setSelectedCustomer(null)}>Remove</Button>
              </div>
            )}

            <div className="flex-1 p-4 overflow-auto">
              <ProductGrid onAddToCart={handleAddToCart} />
            </div>
          </div>

          <div className="w-96 shrink-0 h-full overflow-hidden border-l border-border">
            <Cart items={cartItems} onUpdateQuantity={handleUpdateQuantity} onRemoveItem={handleRemoveItem} onCheckout={() => setIsPaymentModalOpen(true)} onClearCart={handleClearCart} cartDiscount={cartDiscount} selectedCustomer={selectedCustomer} />
          </div>
        </div>
        <Footer variant="minimal" />
      </div>

      <PaymentModal open={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} total={total} onComplete={handlePaymentComplete} />
      <HeldOrdersModal open={isHeldOrdersOpen} onClose={() => setIsHeldOrdersOpen(false)} heldOrders={heldOrders} onRecallOrder={handleRecallOrder} onDeleteOrder={(id) => setHeldOrders((p) => p.filter((o) => o.id !== id))} />
      <DiscountModal open={isDiscountModalOpen} onClose={() => setIsDiscountModalOpen(false)} subtotal={subtotal} onApplyDiscount={handleApplyDiscount} />
      <CustomerSelectModal open={isCustomerModalOpen} onClose={() => setIsCustomerModalOpen(false)} onSelectCustomer={setSelectedCustomer} selectedCustomer={selectedCustomer} />
    </div>
  );
}
