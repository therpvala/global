import { useNavigate } from "react-router-dom";
import { LandingNavbar } from "@/components/landing/LandingNavbar";
import { LandingHero } from "@/components/landing/LandingHero";
import { LandingFeatures } from "@/components/landing/LandingFeatures";
import { Footer } from "@/components/layout/Footer";
import { Icon3D } from "@/components/ui/Icon3D";
import { Check, Star, Users, Building, Award, Crown, Shield, Briefcase, User, Package, Mail, Phone, MapPin, Headphones } from "lucide-react";

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#050831]">
      <LandingNavbar onSignIn={() => navigate("/auth")} onPrimary={() => navigate("/auth")} />

      <main>
        <LandingHero onPrimaryCta={() => navigate("/auth")} onSecondaryCta={() => navigate("/auth")} />
        <LandingFeatures />

        {/* Why Choose Us Section */}
        <section id="why-us" className="py-24 bg-gradient-to-b from-[#133072] to-[#050831]">
          <div className="container-wide">
            <div className="text-center mb-16">
              <h2 className="font-display text-4xl md:text-5xl font-black text-white">
                Why Choose <span className="text-[#F946AB]">SmartPOS</span>
              </h2>
              <p className="mt-4 text-lg text-white/70 max-w-2xl mx-auto">
                Built for speed, designed for clarity, trusted by thousands.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {[
                { icon: Star, title: "Fast Checkout", desc: "Process transactions in under 8 seconds with smart auto-complete." },
                { icon: Package, title: "Easy Product Mgmt", desc: "Add, edit and manage products with barcode and category support." },
                { icon: Award, title: "Real Time Reports", desc: "Live analytics dashboards with sales trends and profit insights." },
                { icon: Building, title: "Multi Store Support", desc: "Manage multiple store branches from a single dashboard." },
              ].map((item) => (
                <div key={item.title} className="rounded-2xl border border-white/10 bg-white/5 p-6 transition-all hover:border-[#F946AB]/40 hover:shadow-[0_0_30px_rgba(249,70,171,0.1)]">
                  <div className="h-12 w-12 rounded-xl border border-[#F946AB]/30 bg-[#F946AB]/10 flex items-center justify-center mb-4">
                    <item.icon className="h-6 w-6 text-[#F946AB]" />
                  </div>
                  <h3 className="font-display text-lg font-bold text-white mb-2">{item.title}</h3>
                  <p className="text-sm text-white/65">{item.desc}</p>
                </div>
              ))}
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
              {[
                { icon: Users, value: "500+", label: "Active Stores" },
                { icon: Building, value: "50+", label: "Enterprise Clients" },
                { icon: Star, value: "4.9", label: "User Rating" },
                { icon: Award, value: "99.9%", label: "Uptime" },
              ].map((stat) => (
                <div key={stat.label} className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center">
                  <stat.icon className="h-6 w-6 text-[#F946AB] mx-auto mb-3" />
                  <p className="font-display text-3xl font-black text-white">{stat.value}</p>
                  <p className="text-sm text-white/60 mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            {/* Testimonial */}
            <div className="mt-16 rounded-3xl border border-[#F946AB]/20 bg-gradient-to-r from-[#133072]/50 to-[#F946AB]/5 p-8 md:p-12 text-center">
              <div className="flex justify-center gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-[#F946AB] text-[#F946AB]" />
                ))}
              </div>
              <blockquote className="font-display text-xl md:text-2xl font-bold text-white max-w-3xl mx-auto">
                "SmartPOS transformed our checkout experience. Staff training dropped from days to hours, 
                and our average transaction time improved by 40%."
              </blockquote>
              <div className="mt-6">
                <p className="font-bold text-white">Rajesh Kumar</p>
                <p className="text-sm text-white/60">Owner, 12-store retail chain</p>
              </div>
            </div>
          </div>
        </section>

        {/* POS Screen Preview */}
        <section className="py-24 bg-[#050831]">
          <div className="container-wide">
            <div className="text-center mb-12">
              <h2 className="font-display text-4xl font-black text-white">
                See It In <span className="text-[#F946AB]">Action</span>
              </h2>
              <p className="mt-4 text-white/70">A glimpse of the powerful POS dashboard interface.</p>
            </div>
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-[#133072]/30 to-[#050831] p-8 md:p-12">
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { title: "POS Billing", desc: "Quick product search, barcode scan, cart management with instant checkout." },
                  { title: "Inventory Dashboard", desc: "Stock levels, low-stock alerts, supplier management all in one view." },
                  { title: "Sales Analytics", desc: "Revenue charts, top products, daily/weekly/monthly performance reports." },
                ].map((screen) => (
                  <div key={screen.title} className="rounded-2xl border border-white/15 bg-white/5 p-6">
                    <div className="h-32 rounded-xl bg-gradient-to-br from-[#415BA7]/20 to-[#F946AB]/10 border border-white/10 mb-4 flex items-center justify-center">
                      <span className="text-white/30 text-sm font-bold">Preview</span>
                    </div>
                    <h4 className="font-display font-bold text-white">{screen.title}</h4>
                    <p className="text-xs text-white/60 mt-1">{screen.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Roles Section */}
        <section id="roles" className="py-24 bg-gradient-to-b from-[#050831] to-[#133072]">
          <div className="container-wide">
            <div className="text-center mb-16">
              <h2 className="font-display text-4xl font-black text-white">
                Role Based <span className="text-[#F946AB]">Access System</span>
              </h2>
              <p className="mt-4 text-white/70 max-w-2xl mx-auto">Every team member gets the right tools with the right permissions.</p>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[
                { icon: Crown, role: "Super Admin", desc: "Complete system oversight, all modules, user management, system logs." },
                { icon: Shield, role: "Admin", desc: "Products, inventory, customers, sales, reports, staff management." },
                { icon: Building, role: "Manager", desc: "Sales monitoring, inventory monitoring, customer data, reports." },
                { icon: User, role: "Cashier", desc: "POS billing, customer search, payment processing, receipt printing." },
                { icon: Package, role: "Inventory Manager", desc: "Stock updates, supplier management, purchase orders, inventory reports." },
                { icon: Briefcase, role: "Accountant", desc: "Financial reports, revenue analytics, payment records, tax reports." },
              ].map((r) => (
                <div key={r.role} className="rounded-2xl border border-white/10 bg-white/5 p-6 flex items-start gap-4 transition-all hover:border-[#F946AB]/40">
                  <div className="h-12 w-12 rounded-xl border border-[#F946AB]/30 bg-[#F946AB]/10 flex items-center justify-center flex-shrink-0">
                    <r.icon className="h-6 w-6 text-[#F946AB]" />
                  </div>
                  <div>
                    <h4 className="font-display font-bold text-white">{r.role}</h4>
                    <p className="text-sm text-white/60 mt-1">{r.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-24 bg-[#050831]">
          <div className="container-wide">
            <div className="text-center mb-16">
              <h2 className="font-display text-4xl md:text-5xl font-black text-white">
                Simple, Transparent <span className="text-[#F946AB]">Pricing</span>
              </h2>
              <p className="mt-4 text-lg text-white/70 max-w-2xl mx-auto">
                Choose the plan that fits your business. Upgrade anytime.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3 max-w-5xl mx-auto items-stretch">
              {/* Free */}
              <div className="rounded-3xl border border-white/10 bg-white/5 p-8 flex flex-col">
                <p className="text-sm font-bold uppercase tracking-wider text-white/50">Free</p>
                <p className="mt-4 font-display text-5xl font-black text-white">₹0</p>
                <p className="text-sm text-white/50 mt-1">per month</p>
                <ul className="mt-8 space-y-3 flex-1">
                  {["1 store location", "Up to 50 products", "Basic POS billing", "Daily sales report", "Email support"].map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-white/70">
                      <Check className="h-4 w-4 text-[#F946AB] flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => navigate("/auth")} className="mt-8 w-full rounded-xl border border-white/20 bg-white/5 py-3 text-sm font-bold text-white hover:bg-white/10 transition-colors">
                  Get Started Free
                </button>
              </div>

              {/* Pro — highlighted */}
              <div className="rounded-3xl border-2 border-[#F946AB] bg-gradient-to-b from-[#F946AB]/10 to-[#050831] p-8 flex flex-col relative">
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2">
                  <span className="bg-[#F946AB] text-white text-xs font-black uppercase px-4 py-1 rounded-full">Most Popular</span>
                </div>
                <p className="text-sm font-bold uppercase tracking-wider text-[#F946AB]">Pro</p>
                <p className="mt-4 font-display text-5xl font-black text-white">₹999</p>
                <p className="text-sm text-white/50 mt-1">per month</p>
                <ul className="mt-8 space-y-3 flex-1">
                  {["Up to 5 store locations", "Unlimited products", "Full POS + inventory", "Role-based access (6 roles)", "Advanced analytics", "Priority email & chat support"].map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-white/70">
                      <Check className="h-4 w-4 text-[#F946AB] flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => navigate("/auth")} className="mt-8 w-full rounded-xl bg-[#F946AB] py-3 text-sm font-black text-white hover:bg-[#E1035A] transition-colors">
                  Start Pro Trial
                </button>
              </div>

              {/* Enterprise */}
              <div className="rounded-3xl border border-white/10 bg-white/5 p-8 flex flex-col">
                <p className="text-sm font-bold uppercase tracking-wider text-white/50">Enterprise</p>
                <p className="mt-4 font-display text-5xl font-black text-white">Custom</p>
                <p className="text-sm text-white/50 mt-1">contact sales</p>
                <ul className="mt-8 space-y-3 flex-1">
                  {["Unlimited stores", "Unlimited products", "Custom integrations", "Dedicated account manager", "SLA & 24/7 phone support", "On-premise deployment option"].map(f => (
                    <li key={f} className="flex items-center gap-2 text-sm text-white/70">
                      <Check className="h-4 w-4 text-[#F946AB] flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => navigate("/auth")} className="mt-8 w-full rounded-xl border border-white/20 bg-white/5 py-3 text-sm font-bold text-white hover:bg-white/10 transition-colors">
                  Contact Sales
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-[#050831]">
          <div className="container-wide">
            <div className="text-center mb-12">
              <h2 className="font-display text-4xl font-black text-white">
                Get In <span className="text-[#F946AB]">Touch</span>
              </h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { icon: Mail, label: "Email", value: "support@smartpos.com" },
                { icon: Phone, label: "Phone", value: "+91 98765 43210" },
                { icon: MapPin, label: "Address", value: "Mumbai, India" },
                { icon: Headphones, label: "Support", value: "24/7 Live Chat" },
              ].map((c) => (
                <div key={c.label} className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center">
                  <c.icon className="h-6 w-6 text-[#F946AB] mx-auto mb-3" />
                  <p className="font-bold text-white">{c.label}</p>
                  <p className="text-sm text-white/60 mt-1">{c.value}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12 bg-[#050831] border-t border-white/10">
          <div className="container-wide">
            <div className="rounded-2xl border border-white/10 bg-white/5 p-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between mb-8">
              <div>
                <p className="font-display text-xl font-black text-white">
                  Smart<span className="text-[#F946AB]">POS</span>
                </p>
                <p className="text-sm text-white/70">Premium billing, inventory, and reports for modern retail.</p>
              </div>
              <div className="text-sm font-bold text-[#F946AB]">
                © {new Date().getFullYear()} SmartPOS
              </div>
            </div>
            <div className="text-center">
              <p className="text-sm font-medium text-white/60">
                Powered by <span className="font-bold text-[#F946AB]">Softwarewala</span><span className="text-white">™</span>
              </p>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
