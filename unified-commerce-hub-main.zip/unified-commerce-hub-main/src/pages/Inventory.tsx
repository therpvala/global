import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { products, stockTransfers, getExpiringProducts } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  Search,
  Plus,
  AlertTriangle,
  Package,
  TrendingDown,
  RefreshCw,
  ArrowUpDown,
  Download,
  Zap,
  Calendar,
  Truck,
  RotateCcw,
  CheckSquare,
  Archive,
  Clock,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { Icon3D } from '@/components/ui/Icon3D';

const lowStockProducts = products.filter((p) => p.stock <= p.lowStockAlert);
const expiringProducts = getExpiringProducts(30);
const outOfStockProducts = products.filter((p) => p.stock === 0);

const branches = ['Main Store', 'Downtown Branch', 'Warehouse', 'Mall Outlet'];

export default function Inventory() {
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isAddStockModalOpen, setIsAddStockModalOpen] = useState(false);
  const [transferFrom, setTransferFrom] = useState('');
  const [transferTo, setTransferTo] = useState('');
  const [transferQty, setTransferQty] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'low' | 'expiring'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         p.sku.toLowerCase().includes(searchQuery.toLowerCase());
    if (activeTab === 'low') return matchesSearch && p.stock <= p.lowStockAlert;
    if (activeTab === 'expiring') return matchesSearch && expiringProducts.some(ep => ep.id === p.id);
    return matchesSearch;
  });

  const handleSelectAll = () => {
    if (selectedProducts.length === filteredProducts.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(filteredProducts.map(p => p.id));
    }
  };

  const handleSelectProduct = (productId: string) => {
    setSelectedProducts(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const handleBulkAction = (action: string) => {
    switch (action) {
      case 'transfer':
        setIsTransferModalOpen(true);
        break;
      case 'archive':
        toast.success(`${selectedProducts.length} products archived`);
        setSelectedProducts([]);
        break;
      case 'reorder':
        toast.success(`Reorder initiated for ${selectedProducts.length} products`);
        setSelectedProducts([]);
        break;
    }
  };

  const handleTransfer = () => {
    if (!transferFrom || !transferTo || !transferQty) {
      toast.error('Please fill all fields');
      return;
    }
    toast.success(`Transfer initiated: ${selectedProducts.length} products from ${transferFrom} to ${transferTo}`);
    setIsTransferModalOpen(false);
    setSelectedProducts([]);
    setTransferFrom('');
    setTransferTo('');
    setTransferQty('');
  };

  const totalStockValue = products.reduce((sum, p) => sum + p.cost * p.stock, 0);

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Inventory</h1>
            <p className="text-muted-foreground mt-1">Track and manage your stock levels</p>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline" 
              className="gap-2"
              onClick={() => setIsTransferModalOpen(true)}
              disabled={selectedProducts.length === 0}
            >
              <RefreshCw className="h-4 w-4" />
              Stock Transfer
              {selectedProducts.length > 0 && (
                <Badge variant="secondary" className="ml-1">{selectedProducts.length}</Badge>
              )}
            </Button>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button 
              className="gap-2"
              onClick={() => setIsAddStockModalOpen(true)}
            >
              <Plus className="h-4 w-4" />
              Add Stock
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider uppercase">Total Products</p>
                <p className="font-display text-2xl font-bold text-foreground mt-1">{products.length}</p>
              </div>
              <Icon3D icon={Package} color="primary" size="md" />
            </div>
          </div>

          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider uppercase">Stock Value</p>
                <p className="font-display text-2xl font-semibold text-foreground mt-1">${totalStockValue.toLocaleString()}</p>
              </div>
              <Icon3D icon={TrendingDown} color="accent" size="md" />
            </div>
          </div>

          <div
            className={cn(
              "rounded-xl glass-card p-6 border card-hover cursor-pointer",
              activeTab === 'low' ? 'border-warning' : 'border-warning/20'
            )}
            onClick={() => setActiveTab(activeTab === 'low' ? 'all' : 'low')}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider uppercase">Low Stock</p>
                <p className="font-display text-2xl font-semibold text-warning mt-1">{lowStockProducts.length}</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-warning/15">
                <AlertTriangle className="h-5 w-5 text-warning" />
              </div>
            </div>
          </div>

          <div className="rounded-xl glass-card p-6 border border-destructive/20 card-hover">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider uppercase">Out of Stock</p>
                <p className="font-display text-2xl font-semibold text-destructive mt-1">{outOfStockProducts.length}</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-destructive/15">
                <Package className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </div>

          <div 
            className={cn(
              "rounded-xl glass-card p-6 border card-hover cursor-pointer",
              activeTab === 'expiring' ? 'border-info' : 'border-info/20'
            )}
            onClick={() => setActiveTab(activeTab === 'expiring' ? 'all' : 'expiring')}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider uppercase">Expiring Soon</p>
                <p className="font-display text-2xl font-semibold text-info mt-1">{expiringProducts.length}</p>
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-info/15">
                <Calendar className="h-5 w-5 text-info" />
              </div>
            </div>
          </div>
        </div>

        {/* Pending Transfers */}
        {stockTransfers.filter(t => t.status !== 'completed').length > 0 && (
          <div className="rounded-xl glass-card p-6 border border-info/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-info/15">
                <Truck className="h-5 w-5 text-info" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-info">Active Transfers</h3>
                <p className="text-sm text-muted-foreground">Stock movements in progress</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {stockTransfers.filter(t => t.status !== 'completed').map((transfer) => {
                const product = products.find(p => p.id === transfer.productId);
                return (
                  <div
                    key={transfer.id}
                    className="flex items-center gap-3 rounded-lg bg-card/50 p-3 border border-info/10"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-foreground text-sm">{product?.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {transfer.fromBranch} → {transfer.toBranch}
                      </p>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        transfer.status === 'in-transit' 
                          ? 'border-info/30 bg-info/10 text-info'
                          : 'border-warning/30 bg-warning/10 text-warning'
                      )}
                    >
                      {transfer.status === 'in-transit' ? (
                        <><Truck className="h-3 w-3 mr-1" /> In Transit</>
                      ) : (
                        <><Clock className="h-3 w-3 mr-1" /> Pending</>
                      )}
                    </Badge>
                    <span className="font-semibold text-info">×{transfer.quantity}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Low Stock Alert */}
        {lowStockProducts.length > 0 && activeTab === 'all' && (
          <div className="rounded-xl glass-card p-6 border border-warning/20">
            <div className="flex items-center gap-3 mb-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/15">
                <Zap className="h-5 w-5 text-warning" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-warning">Low Stock Alert</h3>
                <p className="text-sm text-muted-foreground">Items requiring immediate attention</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="ml-auto border-warning/30 text-warning hover:bg-warning/10"
                onClick={() => {
                  setSelectedProducts(lowStockProducts.map(p => p.id));
                  toast.info(`Selected ${lowStockProducts.length} low stock products`);
                }}
              >
                Select All Low Stock
              </Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {lowStockProducts.slice(0, 4).map((product) => (
                <div
                  key={product.id}
                  className="flex items-center gap-3 rounded-lg bg-card/50 p-3 border border-warning/10 hover:border-warning/30 transition-colors cursor-pointer"
                  onClick={() => handleSelectProduct(product.id)}
                >
                  <Checkbox 
                    checked={selectedProducts.includes(product.id)}
                    className="border-warning/50"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-foreground truncate text-sm">{product.name}</p>
                    <p className="text-xs text-destructive font-medium">{product.stock} left</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bulk Actions */}
        {selectedProducts.length > 0 && (
          <div className="rounded-xl glass-card p-4 border border-primary/30 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckSquare className="h-5 w-5 text-primary" />
              <span className="font-medium">{selectedProducts.length} products selected</span>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => handleBulkAction('transfer')}
              >
                <RefreshCw className="h-4 w-4" />
                Transfer
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => handleBulkAction('reorder')}
              >
                <RotateCcw className="h-4 w-4" />
                Reorder
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="gap-2 text-destructive hover:bg-destructive/10"
                onClick={() => handleBulkAction('archive')}
              >
                <Archive className="h-4 w-4" />
                Archive
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedProducts([])}
              >
                Clear
              </Button>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="flex gap-4 items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search inventory..." 
              className="pl-10 bg-secondary/50 border-primary/15 focus:border-primary/30 focus:ocean-glow"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button 
              variant={activeTab === 'all' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setActiveTab('all')}
            >
              All
            </Button>
            <Button 
              variant={activeTab === 'low' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setActiveTab('low')}
              className={activeTab === 'low' ? '' : 'text-warning border-warning/30 hover:bg-warning/10'}
            >
              Low Stock
            </Button>
            <Button 
              variant={activeTab === 'expiring' ? 'default' : 'outline'} 
              size="sm"
              onClick={() => setActiveTab('expiring')}
              className={activeTab === 'expiring' ? '' : 'text-info border-info/30 hover:bg-info/10'}
            >
              Expiring
            </Button>
          </div>
          <Button variant="outline" className="gap-2 border-primary/20 hover:bg-primary/10 hover:text-primary">
            <ArrowUpDown className="h-4 w-4" />
            Sort
          </Button>
        </div>

        {/* Inventory Table */}
        <div className="rounded-xl glass-card overflow-hidden ocean-border">
          <Table>
            <TableHeader>
              <TableRow className="bg-primary/10 border-b border-primary/15 hover:bg-primary/10">
                <TableHead className="w-12">
                  <Checkbox 
                    checked={selectedProducts.length === filteredProducts.length && filteredProducts.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                </TableHead>
                <TableHead className="text-primary font-medium">Product</TableHead>
                <TableHead className="text-primary font-medium">SKU</TableHead>
                <TableHead className="text-primary font-medium">Category</TableHead>
                <TableHead className="text-right text-primary font-medium">In Stock</TableHead>
                <TableHead className="text-primary font-medium">Stock Level</TableHead>
                <TableHead className="text-primary font-medium">Expiry</TableHead>
                <TableHead className="text-right text-primary font-medium">Value</TableHead>
                <TableHead className="text-primary font-medium">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map((product) => {
                const stockPercentage = Math.min(
                  (product.stock / (product.lowStockAlert * 5)) * 100,
                  100
                );
                const isLowStock = product.stock <= product.lowStockAlert;
                const isExpiring = product.expiryDate && product.expiryDate <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

                return (
                  <TableRow 
                    key={product.id} 
                    className={cn(
                      "border-b border-primary/5 hover:bg-primary/5 transition-colors cursor-pointer",
                      selectedProducts.includes(product.id) && "bg-primary/10"
                    )}
                    onClick={() => handleSelectProduct(product.id)}
                  >
                    <TableCell onClick={e => e.stopPropagation()}>
                      <Checkbox 
                        checked={selectedProducts.includes(product.id)}
                        onCheckedChange={() => handleSelectProduct(product.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-primary/15 to-accent/10">
                          <span className="text-sm font-semibold text-primary">
                            {product.name.charAt(0)}
                          </span>
                        </div>
                        <div>
                          <span className="font-medium">{product.name}</span>
                          {product.batchNumber && (
                            <p className="text-xs text-muted-foreground">{product.batchNumber}</p>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">{product.sku}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="border-primary/20 bg-primary/5 text-primary">
                        {product.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <span
                        className={cn(
                          'font-medium',
                          isLowStock ? 'text-destructive' : 'text-foreground'
                        )}
                      >
                        {product.stock}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="w-32">
                        <Progress
                          value={stockPercentage}
                          className={cn(
                            'h-1.5 bg-secondary',
                            isLowStock 
                              ? '[&>div]:bg-destructive' 
                              : '[&>div]:bg-primary'
                          )}
                        />
                      </div>
                    </TableCell>
                    <TableCell>
                      {product.expiryDate && (
                        <span className={cn(
                          "text-sm",
                          isExpiring ? "text-warning font-medium" : "text-muted-foreground"
                        )}>
                          {format(product.expiryDate, 'MMM dd, yyyy')}
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      ${(product.cost * product.stock).toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Badge
                          variant="outline"
                          className={cn(
                            isLowStock
                              ? 'border-warning/30 bg-warning/10 text-warning'
                              : 'border-success/30 bg-success/10 text-success'
                          )}
                        >
                          {isLowStock ? 'Low Stock' : 'In Stock'}
                        </Badge>
                        {isExpiring && (
                          <Badge variant="outline" className="border-info/30 bg-info/10 text-info">
                            Expiring
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Transfer Modal */}
      <Dialog open={isTransferModalOpen} onOpenChange={setIsTransferModalOpen}>
        <DialogContent className="glass-card border-primary/20">
          <DialogHeader>
            <DialogTitle className="ocean-text">Stock Transfer</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm text-muted-foreground">
              Transfer {selectedProducts.length} selected product(s)
            </p>
            <div className="space-y-2">
              <Label>From Branch</Label>
              <Select value={transferFrom} onValueChange={setTransferFrom}>
                <SelectTrigger>
                  <SelectValue placeholder="Select source" />
                </SelectTrigger>
                <SelectContent>
                  {branches.map(branch => (
                    <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>To Branch</Label>
              <Select value={transferTo} onValueChange={setTransferTo}>
                <SelectTrigger>
                  <SelectValue placeholder="Select destination" />
                </SelectTrigger>
                <SelectContent>
                  {branches.filter(b => b !== transferFrom).map(branch => (
                    <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity (per product)</Label>
              <Input
                type="number"
                placeholder="Enter quantity"
                value={transferQty}
                onChange={(e) => setTransferQty(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTransferModalOpen(false)}>Cancel</Button>
            <Button onClick={handleTransfer}>Initiate Transfer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Stock Modal */}
      <Dialog open={isAddStockModalOpen} onOpenChange={setIsAddStockModalOpen}>
        <DialogContent className="glass-card border-primary/20">
          <DialogHeader>
            <DialogTitle className="ocean-text">Add Stock</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Product</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map(product => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name} ({product.sku})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Quantity</Label>
              <Input type="number" placeholder="Enter quantity" />
            </div>
            <div className="space-y-2">
              <Label>Batch Number</Label>
              <Input placeholder="Enter batch number" />
            </div>
            <div className="space-y-2">
              <Label>Expiry Date</Label>
              <Input type="date" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddStockModalOpen(false)}>Cancel</Button>
            <Button onClick={() => {
              toast.success('Stock added successfully');
              setIsAddStockModalOpen(false);
            }}>Add Stock</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
