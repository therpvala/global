import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { EmployeeList } from '@/components/employees/EmployeeList';
import { ShiftScheduler } from '@/components/employees/ShiftScheduler';
import { PerformanceMetrics } from '@/components/employees/PerformanceMetrics';
import { EmployeeStats } from '@/components/employees/EmployeeStats';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Plus, Download, Filter } from 'lucide-react';

export default function Employees() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="font-display text-2xl font-bold text-foreground">Employee Management</h1>
            <p className="text-muted-foreground text-sm">Manage team members, schedules, and performance</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-2">
              <Filter className="h-4 w-4" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
            <Button size="sm" className="gap-2 bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4" />
              Add Employee
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <EmployeeStats />

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-secondary/50 border border-border p-1">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Overview
            </TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Shift Schedule
            </TabsTrigger>
            <TabsTrigger value="performance" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Performance
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <EmployeeList />
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <ShiftScheduler />
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <PerformanceMetrics />
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
