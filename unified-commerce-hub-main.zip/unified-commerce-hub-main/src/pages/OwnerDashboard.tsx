import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { SalesChart } from '@/components/dashboard/SalesChart';
import { TopProducts } from '@/components/dashboard/TopProducts';
import { RecentTransactions } from '@/components/dashboard/RecentTransactions';
import { QuickActions } from '@/components/dashboard/QuickActions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { dashboardStats } from '@/data/mockData';
import { 
  DollarSign, ShoppingCart, TrendingUp, Users,
  Building, ArrowUpRight, Calendar, Store
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function OwnerDashboard() {
  const { profile } = useAuth();

  const branchData = [
    { name: 'Main', revenue: 45230, orders: 342 },
    { name: 'Downtown', revenue: 32450, orders: 256 },
    { name: 'Mall', revenue: 28900, orders: 198 },
    { name: 'Airport', revenue: 22100, orders: 145 },
    { name: 'Station', revenue: 18500, orders: 120 },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Owner</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-1">Welcome, {profile?.full_name || 'Owner'}! Business overview.</p>
          </div>
          <Button variant="outline" className="gap-2"><Calendar className="h-4 w-4" /> This Month</Button>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Total Revenue" value={`$${(dashboardStats.todaySales * 30).toLocaleString()}`} change="+15.2%" changeType="positive" icon={DollarSign} glowColor="pink" />
          <StatCard title="Net Profit" value={`$${(dashboardStats.todaySales * 30 * 0.35).toLocaleString()}`} change="+12.8%" changeType="positive" icon={TrendingUp} glowColor="blue" />
          <StatCard title="Total Orders" value={(dashboardStats.todayOrders * 30).toString()} change="+8.5%" changeType="positive" icon={ShoppingCart} glowColor="dark" />
          <StatCard title="Active Branches" value="5" change="+1" changeType="positive" icon={Building} glowColor="rose" />
        </div>

        {/* Branch Performance */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <Store className="h-5 w-5 text-primary" /> Branch Performance
              </CardTitle>
              <Button variant="ghost" size="sm" className="text-primary gap-1">View All <ArrowUpRight className="h-4 w-4" /></Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={branchData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/50" />
                  <XAxis dataKey="name" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
                  <Tooltip />
                  <Bar dataKey="revenue" fill="hsl(var(--brand-pink))" radius={[6, 6, 0, 0]} name="Revenue" />
                  <Bar dataKey="orders" fill="hsl(var(--brand-medium))" radius={[6, 6, 0, 0]} name="Orders" />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-4">
              {branchData.map((b, i) => (
                <div key={i} className="p-3 rounded-xl border border-border bg-card/50 text-center">
                  <p className="font-bold text-sm truncate">{b.name}</p>
                  <p className="text-lg font-display font-bold text-foreground">${(b.revenue / 1000).toFixed(1)}k</p>
                  <p className="text-xs text-muted-foreground">{b.orders} orders</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2"><SalesChart /></div>
          <QuickActions />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <TopProducts />
          <RecentTransactions />
        </div>

        {/* Team Overview */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Users className="h-5 w-5 text-secondary" /> Team Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { role: 'Managers', count: 3 },
                { role: 'Cashiers', count: 12 },
                { role: 'On Duty', count: 8 },
                { role: 'Total Staff', count: 15 },
              ].map((item, i) => (
                <div key={i} className="text-center p-4 rounded-xl border border-border bg-card/50">
                  <p className="text-3xl font-display font-bold text-primary">{item.count}</p>
                  <p className="text-sm text-muted-foreground mt-1">{item.role}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
