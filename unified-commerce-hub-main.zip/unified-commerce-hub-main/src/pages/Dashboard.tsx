import { MainLayout } from '@/components/layout/MainLayout';
import { StatCard } from '@/components/dashboard/StatCard';
import { StoreTrackingCard } from '@/components/dashboard/StoreTrackingCard';
import { StoreMap } from '@/components/dashboard/StoreMap';
import { EmployeePerformance } from '@/components/dashboard/EmployeePerformance';
import { OrdersChart } from '@/components/dashboard/OrdersChart';
import { TopProducts } from '@/components/dashboard/TopProducts';
import { RecentTransactions } from '@/components/dashboard/RecentTransactions';
import { dashboardStats } from '@/data/mockData';
import { DollarSign, ShoppingCart, TrendingUp, Package, Store, Users, Clock, CreditCard } from 'lucide-react';

export default function Dashboard() {
  return (
    <MainLayout>
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">Welcome back! Here's your business overview.</p>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Today's Revenue" value={`$${dashboardStats.todaySales.toLocaleString()}`} change="+12.5%" changeType="positive" icon={DollarSign} glowColor="primary" />
          <StatCard title="Total Orders" value={dashboardStats.todayOrders.toString()} change="+8.2%" changeType="positive" icon={ShoppingCart} glowColor="accent" />
          <StatCard title="Avg Order Value" value={`$${dashboardStats.averageOrderValue.toFixed(2)}`} change="+4.1%" changeType="positive" icon={TrendingUp} glowColor="soft" />
          <StatCard title="Products Sold" value="342" change="-2.3%" changeType="negative" icon={Package} glowColor="dark" />
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StoreTrackingCard title="Active Stores" value="3" subtitle="All operational" icon={Store} color="primary" />
          <StoreTrackingCard title="Staff On Duty" value="12" subtitle="Across all locations" icon={Users} color="accent" />
          <StoreTrackingCard title="Avg Wait Time" value="2.4 min" subtitle="Last hour" icon={Clock} trend={{ value: '15%', isPositive: true }} color="soft" />
          <StoreTrackingCard title="Payment Success" value="99.2%" subtitle="Today's rate" icon={CreditCard} color="dark" />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <StoreMap />
          <OrdersChart />
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <EmployeePerformance />
          <TopProducts />
        </div>

        <RecentTransactions />
      </div>
    </MainLayout>
  );
}
