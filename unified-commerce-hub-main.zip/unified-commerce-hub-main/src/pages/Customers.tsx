import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { customers, loyaltyRewards, getUpcomingBirthdays, getCustomersBySegment } from '@/data/mockData';
import { Customer, CustomerSegment } from '@/types/pos';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Search,
  Plus,
  Filter,
  Mail,
  Phone,
  Gift,
  DollarSign,
  Calendar,
  MoreHorizontal,
  Star,
  Users,
  UserPlus,
  AlertTriangle,
  TrendingUp,
  Cake,
  Crown,
  ShoppingBag,
  Clock,
  Award,
  Target,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format, formatDistanceToNow } from 'date-fns';

const segmentConfig: Record<CustomerSegment, { label: string; color: string; icon: typeof Star }> = {
  new: { label: 'New', color: 'border-success/50 bg-success/10 text-success', icon: UserPlus },
  regular: { label: 'Regular', color: 'border-primary/50 bg-primary/10 text-primary', icon: Users },
  vip: { label: 'VIP', color: 'border-warning/50 bg-warning/10 text-warning', icon: Crown },
  'at-risk': { label: 'At Risk', color: 'border-destructive/50 bg-destructive/10 text-destructive', icon: AlertTriangle },
  churned: { label: 'Churned', color: 'border-muted-foreground/50 bg-muted/50 text-muted-foreground', icon: Clock },
};

export default function Customers() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSegment, setActiveSegment] = useState<CustomerSegment | 'all'>('all');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const upcomingBirthdays = getUpcomingBirthdays(14);
  
  const vipCustomers = customers.filter(c => c.segment === 'vip');
  const atRiskCustomers = customers.filter(c => c.segment === 'at-risk');
  const newCustomers = customers.filter(c => c.segment === 'new');

  const filteredCustomers = customers.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         c.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         c.phone.includes(searchQuery);
    if (activeSegment === 'all') return matchesSearch;
    return matchesSearch && c.segment === activeSegment;
  });

  const totalLoyaltyPoints = customers.reduce((sum, c) => sum + c.loyaltyPoints, 0);
  const totalRevenue = customers.reduce((sum, c) => sum + c.totalSpent, 0);
  const avgLifetimeValue = totalRevenue / customers.length;

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Customers & CRM</h1>
            <p className="text-muted-foreground">Manage customer relationships and loyalty</p>
          </div>
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Customer
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-5 gap-4">
          <div className="pro-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Customers</p>
                <p className="font-display text-2xl font-bold text-foreground mt-1">{customers.length}</p>
              </div>
              <div className="icon-box icon-box-lg rounded-xl bg-primary/15">
                <Users className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="pro-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">VIP Members</p>
                <p className="font-display text-2xl font-bold text-primary mt-1">{vipCustomers.length}</p>
              </div>
              <div className="icon-box icon-box-lg rounded-xl bg-primary/15">
                <Crown className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="pro-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Points</p>
                <p className="font-display text-2xl font-bold text-accent mt-1">{totalLoyaltyPoints.toLocaleString()}</p>
              </div>
              <div className="icon-box icon-box-lg rounded-xl bg-accent/15">
                <Gift className="h-5 w-5 text-accent" />
              </div>
            </div>
          </div>
          <div className="pro-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Avg. Lifetime Value</p>
                <p className="font-display text-2xl font-bold text-primary mt-1">${avgLifetimeValue.toFixed(0)}</p>
              </div>
              <div className="icon-box icon-box-lg rounded-xl bg-primary/15">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
            </div>
          </div>
          <div className="pro-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">At Risk</p>
                <p className="font-display text-2xl font-bold text-destructive mt-1">{atRiskCustomers.length}</p>
              </div>
              <div className="icon-box icon-box-lg rounded-xl bg-destructive/15">
                <AlertTriangle className="h-5 w-5 text-destructive" />
              </div>
            </div>
          </div>
        </div>

        {/* Upcoming Birthdays */}
        {upcomingBirthdays.length > 0 && (
          <Card className="glass-card border-primary/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Cake className="h-5 w-5 text-primary" />
                <span className="text-primary">Upcoming Birthdays</span>
                <Badge variant="secondary" className="ml-2">{upcomingBirthdays.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 overflow-x-auto pb-2">
                {upcomingBirthdays.map((customer) => (
                  <div
                    key={customer.id}
                    className="flex-shrink-0 flex items-center gap-3 rounded-xl bg-primary/5 border border-primary/20 p-4 min-w-[250px] cursor-pointer hover:border-primary/40 transition-colors"
                    onClick={() => setSelectedCustomer(customer)}
                  >
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/20">
                      <span className="text-lg font-bold text-primary">{customer.name.charAt(0)}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-foreground">{customer.name}</p>
                      <p className="text-sm text-primary">
                        {customer.birthday && format(customer.birthday, 'MMM dd')}
                      </p>
                    </div>
                    <Button size="sm" variant="outline" className="ml-auto border-primary/30 text-primary hover:bg-primary/10">
                      <Gift className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loyalty Rewards */}
        <Card className="glass-card ocean-border">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Award className="h-5 w-5 text-primary" />
              <span className="ocean-text">Loyalty Rewards</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              {loyaltyRewards.map((reward) => (
                <div
                  key={reward.id}
                  className="rounded-xl border border-primary/20 p-4 hover:border-primary/40 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="border-warning/30 bg-warning/10 text-warning">
                      {reward.pointsCost.toLocaleString()} pts
                    </Badge>
                    {reward.isActive && (
                      <Badge variant="outline" className="border-success/30 bg-success/10 text-success text-xs">
                        Active
                      </Badge>
                    )}
                  </div>
                  <p className="font-semibold text-foreground">{reward.name}</p>
                  {reward.discount > 0 && (
                    <p className="text-sm text-muted-foreground">${reward.discount.toFixed(2)} value</p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Segment Filters & Search */}
        <div className="flex gap-4 items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input 
              placeholder="Search customers..." 
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button
              variant={activeSegment === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveSegment('all')}
            >
              All
            </Button>
            {(Object.entries(segmentConfig) as [CustomerSegment, typeof segmentConfig[CustomerSegment]][]).map(([segment, config]) => {
              const Icon = config.icon;
              return (
                <Button
                  key={segment}
                  variant={activeSegment === segment ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveSegment(segment)}
                  className={cn(
                    activeSegment !== segment && config.color,
                    "gap-1"
                  )}
                >
                  <Icon className="h-3 w-3" />
                  {config.label}
                </Button>
              );
            })}
          </div>
        </div>

        {/* Customer Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredCustomers.map((customer) => {
            const segmentInfo = customer.segment ? segmentConfig[customer.segment] : null;
            const SegmentIcon = segmentInfo?.icon || Users;
            
            return (
              <Card
                key={customer.id}
                className="glass-card border-border hover:border-primary/30 transition-all cursor-pointer hover:shadow-lg"
                onClick={() => setSelectedCustomer(customer)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-primary/5">
                        <span className="text-lg font-bold text-primary">
                          {customer.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-foreground">{customer.name}</h3>
                          {segmentInfo && (
                            <Badge variant="outline" className={cn("text-xs gap-1", segmentInfo.color)}>
                              <SegmentIcon className="h-3 w-3" />
                              {segmentInfo.label}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {customer.visitCount} visits • Last {customer.lastVisit && formatDistanceToNow(customer.lastVisit, { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Mail className="h-4 w-4" />
                      {customer.email}
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      {customer.phone}
                    </div>
                    {customer.birthday && (
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Cake className="h-4 w-4" />
                        {format(customer.birthday, 'MMM dd, yyyy')}
                      </div>
                    )}
                  </div>

                  {customer.preferences && customer.preferences.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-4">
                      {customer.preferences.map((pref, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs">
                          {pref}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div className="flex items-center gap-1">
                      <Gift className="h-4 w-4 text-warning" />
                      <span className="font-semibold text-foreground">
                        {customer.loyaltyPoints.toLocaleString()}
                      </span>
                      <span className="text-xs text-muted-foreground">pts</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4 text-success" />
                      <span className="font-semibold text-foreground">
                        ${customer.totalSpent.toLocaleString()}
                      </span>
                      <span className="text-xs text-muted-foreground">spent</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Customer Detail Modal */}
      <Dialog open={!!selectedCustomer} onOpenChange={() => setSelectedCustomer(null)}>
        <DialogContent className="max-w-2xl glass-card border-primary/20">
          {selectedCustomer && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/10">
                    <span className="text-2xl font-bold text-primary">
                      {selectedCustomer.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <span className="ocean-text">{selectedCustomer.name}</span>
                    {selectedCustomer.segment && (
                      <Badge variant="outline" className={cn("ml-2", segmentConfig[selectedCustomer.segment].color)}>
                        {segmentConfig[selectedCustomer.segment].label}
                      </Badge>
                    )}
                  </div>
                </DialogTitle>
              </DialogHeader>
              
              <div className="grid grid-cols-2 gap-6 py-4">
                <div className="space-y-4">
                  <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Contact Info</h4>
                  <div className="space-y-2">
                    <p className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      {selectedCustomer.email}
                    </p>
                    <p className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      {selectedCustomer.phone}
                    </p>
                    {selectedCustomer.birthday && (
                      <p className="flex items-center gap-2 text-sm">
                        <Cake className="h-4 w-4 text-muted-foreground" />
                        {format(selectedCustomer.birthday, 'MMMM dd, yyyy')}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider">Statistics</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-lg bg-primary/10 p-3 text-center">
                      <p className="text-2xl font-bold text-primary">{selectedCustomer.visitCount}</p>
                      <p className="text-xs text-muted-foreground">Total Visits</p>
                    </div>
                    <div className="rounded-lg bg-success/10 p-3 text-center">
                      <p className="text-2xl font-bold text-success">${selectedCustomer.totalSpent.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">Total Spent</p>
                    </div>
                    <div className="rounded-lg bg-warning/10 p-3 text-center">
                      <p className="text-2xl font-bold text-warning">{selectedCustomer.loyaltyPoints.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">Loyalty Points</p>
                    </div>
                    <div className="rounded-lg bg-info/10 p-3 text-center">
                      <p className="text-2xl font-bold text-info">${(selectedCustomer.totalSpent / selectedCustomer.visitCount).toFixed(0)}</p>
                      <p className="text-xs text-muted-foreground">Avg. Order</p>
                    </div>
                  </div>
                </div>
              </div>

              {selectedCustomer.preferences && selectedCustomer.preferences.length > 0 && (
                <div className="py-4 border-t border-border">
                  <h4 className="font-semibold text-sm text-muted-foreground uppercase tracking-wider mb-3">Preferences</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedCustomer.preferences.map((pref, idx) => (
                      <Badge key={idx} variant="outline" className="border-primary/30 bg-primary/5">
                        {pref}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4 border-t border-border">
                <Button className="flex-1 gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  View Orders
                </Button>
                <Button variant="outline" className="flex-1 gap-2">
                  <Gift className="h-4 w-4" />
                  Redeem Points
                </Button>
                <Button variant="outline" className="gap-2">
                  <Mail className="h-4 w-4" />
                  Send Email
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}
