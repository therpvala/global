import { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { dashboardStats, products, customers } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Download,
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShoppingCart,
  Package,
  Users,
  FileText,
  Printer,
  Mail,
  BarChart3,
  PieChartIcon,
  Target,
  Percent,
} from 'lucide-react';
import { toast } from 'sonner';

const categoryData = [
  { name: 'Beverages', value: 4500, color: 'hsl(var(--primary))' },
  { name: 'Snacks', value: 3200, color: 'hsl(39, 100%, 50%)' },
  { name: 'Dairy', value: 2800, color: 'hsl(160, 84%, 39%)' },
  { name: 'Bakery', value: 2100, color: 'hsl(330, 80%, 60%)' },
  { name: 'Frozen', value: 1800, color: 'hsl(270, 70%, 60%)' },
];

const hourlyData = [
  { hour: '9AM', sales: 450, orders: 12 },
  { hour: '10AM', sales: 680, orders: 18 },
  { hour: '11AM', sales: 890, orders: 24 },
  { hour: '12PM', sales: 1200, orders: 35 },
  { hour: '1PM', sales: 1100, orders: 32 },
  { hour: '2PM', sales: 780, orders: 22 },
  { hour: '3PM', sales: 650, orders: 18 },
  { hour: '4PM', sales: 920, orders: 26 },
  { hour: '5PM', sales: 1150, orders: 33 },
  { hour: '6PM', sales: 980, orders: 28 },
  { hour: '7PM', sales: 750, orders: 21 },
  { hour: '8PM', sales: 520, orders: 15 },
];

const paymentMethodData = [
  { method: 'Card', amount: 8500, percentage: 45, color: 'hsl(var(--primary))' },
  { method: 'Cash', amount: 5600, percentage: 30, color: 'hsl(160, 84%, 39%)' },
  { method: 'UPI', amount: 3800, percentage: 20, color: 'hsl(39, 100%, 50%)' },
  { method: 'Wallet', amount: 950, percentage: 5, color: 'hsl(270, 70%, 60%)' },
];

const weeklyComparison = [
  { day: 'Mon', thisWeek: 3200, lastWeek: 2800 },
  { day: 'Tue', thisWeek: 4100, lastWeek: 3500 },
  { day: 'Wed', thisWeek: 3800, lastWeek: 4200 },
  { day: 'Thu', thisWeek: 4500, lastWeek: 3900 },
  { day: 'Fri', thisWeek: 5200, lastWeek: 4800 },
  { day: 'Sat', thisWeek: 6100, lastWeek: 5500 },
  { day: 'Sun', thisWeek: 4567, lastWeek: 4100 },
];

const profitMarginData = products.slice(0, 8).map(p => ({
  name: p.name.length > 12 ? p.name.substring(0, 12) + '...' : p.name,
  margin: ((p.price - p.cost) / p.price * 100).toFixed(1),
  profit: p.price - p.cost,
  revenue: p.price * (Math.floor(Math.random() * 50) + 10),
}));

const dateRanges = [
  { value: '7d', label: 'Last 7 Days' },
  { value: '30d', label: 'Last 30 Days' },
  { value: '90d', label: 'Last 90 Days' },
  { value: 'ytd', label: 'Year to Date' },
  { value: 'custom', label: 'Custom Range' },
];

export default function Reports() {
  const [dateRange, setDateRange] = useState('7d');
  const [activeTab, setActiveTab] = useState('overview');

  const handleExport = (format: string) => {
    toast.success(`Exporting report as ${format.toUpperCase()}...`);
  };

  // Calculate metrics
  const totalRevenue = weeklyComparison.reduce((sum, d) => sum + d.thisWeek, 0);
  const lastWeekRevenue = weeklyComparison.reduce((sum, d) => sum + d.lastWeek, 0);
  const revenueGrowth = ((totalRevenue - lastWeekRevenue) / lastWeekRevenue * 100).toFixed(1);
  
  const totalOrders = hourlyData.reduce((sum, h) => sum + h.orders, 0);
  const avgOrderValue = totalRevenue / totalOrders;
  
  const grossProfit = products.reduce((sum, p) => sum + (p.price - p.cost) * p.stock * 0.1, 0);
  const profitMargin = (grossProfit / totalRevenue * 100).toFixed(1);

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">Reports & Analytics</h1>
            <p className="text-muted-foreground">Comprehensive business insights and trends</p>
          </div>
          <div className="flex gap-3">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-40 border-border">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {dateRanges.map(range => (
                  <SelectItem key={range.value} value={range.value}>{range.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex border border-border rounded-lg overflow-hidden">
              <Button variant="ghost" size="icon" className="rounded-none" onClick={() => handleExport('pdf')}>
                <FileText className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-none border-x border-border" onClick={() => handleExport('csv')}>
                <Download className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-none border-r border-border" onClick={() => handleExport('print')}>
                <Printer className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="rounded-none" onClick={() => handleExport('email')}>
                <Mail className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-5 gap-4">
          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Revenue</p>
                <p className="font-display text-2xl font-bold text-foreground">${totalRevenue.toLocaleString()}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-success" />
                  <span className="text-xs text-success">+{revenueGrowth}%</span>
                  <span className="text-xs text-muted-foreground">vs last week</span>
                </div>
              </div>
              <div className="icon-box icon-box-xl rounded-xl bg-primary/15">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
            </div>
          </div>

          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Orders</p>
                <p className="font-display text-2xl font-bold text-foreground">{totalOrders}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-success" />
                  <span className="text-xs text-success">+8.2%</span>
                </div>
              </div>
              <div className="icon-box icon-box-xl rounded-xl bg-success/15">
                <ShoppingCart className="h-6 w-6 text-success" />
              </div>
            </div>
          </div>

          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Avg Order Value</p>
                <p className="font-display text-2xl font-bold text-foreground">${avgOrderValue.toFixed(2)}</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-success" />
                  <span className="text-xs text-success">+3.5%</span>
                </div>
              </div>
              <div className="icon-box icon-box-xl rounded-xl bg-accent/15">
                <Target className="h-6 w-6 text-accent" />
              </div>
            </div>
          </div>

          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">Profit Margin</p>
                <p className="font-display text-2xl font-bold text-foreground">{profitMargin}%</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingDown className="h-3 w-3 text-destructive" />
                  <span className="text-xs text-destructive">-1.2%</span>
                </div>
              </div>
              <div className="icon-box icon-box-xl rounded-xl bg-secondary/15">
                <Percent className="h-6 w-6 text-secondary" />
              </div>
            </div>
          </div>

          <div className="pro-card p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">New Customers</p>
                <p className="font-display text-2xl font-bold text-foreground">48</p>
                <div className="flex items-center gap-1 mt-1">
                  <TrendingUp className="h-3 w-3 text-success" />
                  <span className="text-xs text-success">+15.8%</span>
                </div>
              </div>
              <div className="icon-box icon-box-xl rounded-xl bg-primary/15">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
          </div>
        </div>

        {/* Report Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-secondary/50">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="sales" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              Sales Analysis
            </TabsTrigger>
            <TabsTrigger value="products" className="gap-2">
              <Package className="h-4 w-4" />
              Product Performance
            </TabsTrigger>
            <TabsTrigger value="customers" className="gap-2">
              <Users className="h-4 w-4" />
              Customer Insights
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            {/* Charts Row 1 */}
            <div className="grid grid-cols-3 gap-6">
              {/* Weekly Comparison */}
              <Card className="col-span-2 pro-card">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Weekly Comparison</CardTitle>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-primary" />
                      <span className="text-muted-foreground">This Week</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-3 rounded-full bg-muted-foreground/50" />
                      <span className="text-muted-foreground">Last Week</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={weeklyComparison}>
                        <XAxis dataKey="day" axisLine={false} tickLine={false} />
                        <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `$${v / 1000}k`} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '12px',
                          }}
                          formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
                        />
                        <Bar dataKey="lastWeek" fill="hsl(var(--muted-foreground))" opacity={0.3} radius={[4, 4, 0, 0]} />
                        <Bar dataKey="thisWeek" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                        <Line type="monotone" dataKey="thisWeek" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Category Distribution */}
              <Card className="pro-card">
                <CardHeader>
                  <CardTitle>Sales by Category</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          innerRadius={50}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '12px',
                          }}
                          formatter={(value: number) => [`$${value}`, 'Sales']}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="mt-4 space-y-2">
                    {categoryData.map((cat) => (
                      <div key={cat.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                          <div
                            className="h-3 w-3 rounded-full"
                            style={{ backgroundColor: cat.color }}
                          />
                          <span className="text-muted-foreground">{cat.name}</span>
                        </div>
                        <span className="font-medium">${cat.value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Charts Row 2 */}
            <div className="grid grid-cols-2 gap-6">
              {/* Hourly Sales */}
              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Hourly Sales & Orders</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[250px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={hourlyData}>
                        <XAxis dataKey="hour" axisLine={false} tickLine={false} />
                        <YAxis yAxisId="left" axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                        <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '12px',
                          }}
                        />
                        <Bar yAxisId="left" dataKey="sales" fill="hsl(160, 84%, 39%)" radius={[4, 4, 0, 0]} opacity={0.8} />
                        <Line yAxisId="right" type="monotone" dataKey="orders" stroke="hsl(var(--primary))" strokeWidth={2} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Methods */}
              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {paymentMethodData.map((item) => (
                      <div key={item.method} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{item.method}</span>
                          <span className="text-sm text-muted-foreground">
                            ${item.amount.toLocaleString()} ({item.percentage}%)
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-secondary overflow-hidden">
                          <div
                            className="h-2 rounded-full transition-all duration-500"
                            style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="sales" className="space-y-6 mt-6">
            <div className="grid grid-cols-2 gap-6">
              <Card className="glass-card ocean-border">
                <CardHeader>
                  <CardTitle className="ocean-text">Revenue Trend</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={dashboardStats.salesTrend}>
                        <defs>
                          <linearGradient id="colorRevenue2" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <XAxis dataKey="date" axisLine={false} tickLine={false} />
                        <YAxis axisLine={false} tickLine={false} tickFormatter={(v) => `$${v}`} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '12px',
                          }}
                          formatter={(value: number) => [`$${value}`, 'Revenue']}
                        />
                        <Area
                          type="monotone"
                          dataKey="amount"
                          stroke="hsl(var(--primary))"
                          strokeWidth={3}
                          fill="url(#colorRevenue2)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Sales Goals</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Daily Target</span>
                      <span className="font-medium">$4,567 / $5,000</span>
                    </div>
                    <div className="h-3 rounded-full bg-secondary overflow-hidden">
                      <div className="h-3 rounded-full bg-success" style={{ width: '91%' }} />
                    </div>
                    <p className="text-xs text-success">91% achieved</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Weekly Target</span>
                      <span className="font-medium">${totalRevenue.toLocaleString()} / $35,000</span>
                    </div>
                    <div className="h-3 rounded-full bg-secondary overflow-hidden">
                      <div className="h-3 rounded-full bg-primary" style={{ width: `${(totalRevenue / 35000 * 100)}%` }} />
                    </div>
                    <p className="text-xs text-primary">{(totalRevenue / 35000 * 100).toFixed(0)}% achieved</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Monthly Target</span>
                      <span className="font-medium">$89,450 / $150,000</span>
                    </div>
                    <div className="h-3 rounded-full bg-secondary overflow-hidden">
                      <div className="h-3 rounded-full bg-warning" style={{ width: '60%' }} />
                    </div>
                    <p className="text-xs text-warning">60% achieved</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="products" className="space-y-6 mt-6">
            <div className="grid grid-cols-2 gap-6">
              <Card className="glass-card ocean-border">
                <CardHeader>
                  <CardTitle className="ocean-text">Profit Margins by Product</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[350px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={profitMarginData} layout="vertical">
                        <XAxis type="number" axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                        <YAxis type="category" dataKey="name" axisLine={false} tickLine={false} width={100} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '12px',
                          }}
                          formatter={(value: number) => [`${value}%`, 'Margin']}
                        />
                        <Bar dataKey="margin" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Top Selling Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardStats.topProducts.map((item, index) => (
                      <div key={item.product.id} className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <span className="text-sm font-bold text-primary">#{index + 1}</span>
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{item.product.name}</p>
                          <p className="text-sm text-muted-foreground">{item.quantity} units sold</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">${(item.product.price * item.quantity).toFixed(2)}</p>
                          <p className="text-xs text-success">
                            {((item.product.price - item.product.cost) / item.product.price * 100).toFixed(0)}% margin
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="customers" className="space-y-6 mt-6">
            <div className="grid grid-cols-3 gap-6">
              <Card className="glass-card ocean-border">
                <CardHeader>
                  <CardTitle className="ocean-text">Customer Segments</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { segment: 'VIP', count: customers.filter(c => c.segment === 'vip').length, color: 'bg-warning' },
                      { segment: 'Regular', count: customers.filter(c => c.segment === 'regular').length, color: 'bg-primary' },
                      { segment: 'New', count: customers.filter(c => c.segment === 'new').length, color: 'bg-success' },
                      { segment: 'At Risk', count: customers.filter(c => c.segment === 'at-risk').length, color: 'bg-destructive' },
                    ].map(seg => (
                      <div key={seg.segment} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`h-3 w-3 rounded-full ${seg.color}`} />
                          <span>{seg.segment}</span>
                        </div>
                        <Badge variant="secondary">{seg.count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Customer Retention</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4">
                    <p className="text-5xl font-bold text-success">78%</p>
                    <p className="text-sm text-muted-foreground mt-2">Retention Rate</p>
                    <div className="flex items-center justify-center gap-1 mt-1">
                      <TrendingUp className="h-3 w-3 text-success" />
                      <span className="text-xs text-success">+5.2% vs last month</span>
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Repeat Customers</span>
                      <span className="font-medium">234</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Churned (30d)</span>
                      <span className="font-medium text-destructive">12</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card border-border">
                <CardHeader>
                  <CardTitle>Loyalty Program</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <p className="text-3xl font-bold text-warning">{customers.reduce((sum, c) => sum + c.loyaltyPoints, 0).toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">Total Points Issued</p>
                    </div>
                    <div className="space-y-2 pt-4 border-t border-border">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Points Redeemed</span>
                        <span className="font-medium">45,230</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Avg Points/Customer</span>
                        <span className="font-medium">{Math.round(customers.reduce((sum, c) => sum + c.loyaltyPoints, 0) / customers.length)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
