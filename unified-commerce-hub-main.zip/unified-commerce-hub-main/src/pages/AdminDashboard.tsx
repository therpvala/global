import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { useAuth, AppRole } from '@/contexts/AuthContext';
import { StatCard } from '@/components/dashboard/StatCard';
import { SalesChart } from '@/components/dashboard/SalesChart';
import { TopProducts } from '@/components/dashboard/TopProducts';
import { RecentTransactions } from '@/components/dashboard/RecentTransactions';
import { dashboardStats } from '@/data/mockData';
import { 
  Shield, Users, Search, Activity, Server, Database,
  Loader2, RefreshCw, DollarSign, ShoppingCart, Package, TrendingUp,
  AlertTriangle, BarChart3
} from 'lucide-react';
import { toast } from 'sonner';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

interface UserWithRole {
  id: string; email: string | null; full_name: string | null;
  is_active: boolean; created_at: string; role: AppRole | null;
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [updating, setUpdating] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    const { data: profiles, error: pe } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (pe) { toast.error('Failed to fetch users'); setLoading(false); return; }
    const { data: roles } = await supabase.from('user_roles').select('user_id, role');
    setUsers((profiles || []).map(p => ({
      id: p.id, email: p.email, full_name: p.full_name, is_active: p.is_active ?? true,
      created_at: p.created_at || '', role: roles?.find(r => r.user_id === p.id)?.role as AppRole | null,
    })));
    setLoading(false);
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleUpdateRole = async (userId: string, newRole: AppRole) => {
    setUpdating(true);
    const { data: existing } = await supabase.from('user_roles').select('id').eq('user_id', userId).maybeSingle();
    const { error } = existing
      ? await supabase.from('user_roles').update({ role: newRole }).eq('user_id', userId)
      : await supabase.from('user_roles').insert({ user_id: userId, role: newRole, assigned_by: user?.id });
    if (error) { toast.error('Failed to update role'); setUpdating(false); return; }
    toast.success('Role updated');
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
    setUpdating(false);
  };

  const handleToggleActive = async (userId: string, isActive: boolean) => {
    setUpdating(true);
    const { error } = await supabase.from('profiles').update({ is_active: isActive }).eq('id', userId);
    if (error) { toast.error('Failed to update status'); setUpdating(false); return; }
    toast.success(isActive ? 'Activated' : 'Deactivated');
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_active: isActive } : u));
    setUpdating(false);
  };

  const filteredUsers = users.filter(u => {
    const ms = !searchQuery || u.email?.toLowerCase().includes(searchQuery.toLowerCase()) || u.full_name?.toLowerCase().includes(searchQuery.toLowerCase());
    return ms && (roleFilter === 'all' || u.role === roleFilter);
  });

  const categoryData = [
    { name: 'Beverages', value: 35, color: 'hsl(var(--brand-pink))' },
    { name: 'Bakery', value: 25, color: 'hsl(var(--brand-medium))' },
    { name: 'Snacks', value: 20, color: 'hsl(var(--brand-rose))' },
    { name: 'Dairy', value: 20, color: 'hsl(var(--brand-dark))' },
  ];

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight">
              <span className="neon-text">Admin</span> <span className="text-foreground">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-1">Manage users, roles & store operations</p>
          </div>
          <Button onClick={fetchUsers} variant="outline" className="gap-2"><RefreshCw className="h-4 w-4" /> Refresh</Button>
        </div>

        {/* Gradient Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard title="Today Sales" value={`$${dashboardStats.todaySales.toLocaleString()}`} change="+12%" changeType="positive" icon={DollarSign} glowColor="pink" />
          <StatCard title="Today Orders" value={dashboardStats.todayOrders.toString()} change="+5" changeType="positive" icon={ShoppingCart} glowColor="blue" />
          <StatCard title="Inventory" value="48" change="items" changeType="neutral" icon={Package} glowColor="dark" />
          <StatCard title="Customers" value="6" change="+2 new" changeType="positive" icon={Users} glowColor="rose" />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2"><SalesChart /></div>
          <Card className="card-3d neon-border p-5">
            <CardHeader className="p-0 pb-4">
              <CardTitle className="font-display text-lg flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-primary" /> Category Performance
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart><Pie data={categoryData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={3}>
                    {categoryData.map((e, i) => <Cell key={i} fill={e.color} />)}
                  </Pie><Tooltip /></PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1 mt-2">
                {categoryData.map(c => (
                  <div key={c.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2"><div className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: c.color }} /><span className="text-muted-foreground">{c.name}</span></div>
                    <span className="font-bold">{c.value}%</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Alerts & Products */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="card-3d neon-border">
            <CardHeader><CardTitle className="font-display text-lg flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-[hsl(var(--warning))]" /> Inventory Alerts</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {[
                { product: 'Greek Yogurt', stock: 8, threshold: 15 },
                { product: 'Almond Cookies', stock: 5, threshold: 10 },
                { product: 'Organic Milk', stock: 3, threshold: 10 },
              ].map((item, i) => (
                <div key={i} className="p-3 rounded-xl border border-border bg-card/50">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm truncate mr-2">{item.product}</span>
                    <Badge variant={item.stock <= 5 ? 'destructive' : 'secondary'} className="shrink-0">{item.stock <= 5 ? 'Critical' : 'Low'}</Badge>
                  </div>
                  <Progress value={(item.stock / item.threshold) * 100} className="h-2" />
                  <p className="text-xs text-muted-foreground mt-1">{item.stock} / {item.threshold}</p>
                </div>
              ))}
            </CardContent>
          </Card>
          <TopProducts />
        </div>

        <RecentTransactions />

        {/* User Management */}
        <Card className="card-3d neon-border">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-3">
              <CardTitle className="font-display text-lg">User Management</CardTitle>
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-9 w-56 bg-muted/50" />
                </div>
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-36 bg-muted/50"><SelectValue placeholder="Role" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="cashier">Cashier</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow><TableHead>User</TableHead><TableHead>Email</TableHead><TableHead>Role</TableHead><TableHead>Status</TableHead><TableHead>Joined</TableHead></TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map(u => (
                      <TableRow key={u.id} className="hover:bg-muted/30">
                        <TableCell className="font-medium">{u.full_name || 'N/A'}</TableCell>
                        <TableCell className="text-muted-foreground max-w-[200px] truncate">{u.email}</TableCell>
                        <TableCell>
                          <Select value={u.role || ''} onValueChange={(v) => handleUpdateRole(u.id, v as AppRole)} disabled={updating || u.id === user?.id}>
                            <SelectTrigger className="w-32 h-8 bg-muted/50"><SelectValue><Badge className="bg-primary/20 text-primary border-0">{u.role?.toUpperCase().replace('_', ' ') || 'NO ROLE'}</Badge></SelectValue></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="admin">Admin</SelectItem>
                              <SelectItem value="manager">Manager</SelectItem>
                              <SelectItem value="cashier">Cashier</SelectItem>
                              <SelectItem value="inventory_manager">Inv. Manager</SelectItem>
                              <SelectItem value="accountant">Accountant</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Switch checked={u.is_active} onCheckedChange={(c) => handleToggleActive(u.id, c)} disabled={updating || u.id === user?.id} />
                            <span className={u.is_active ? 'text-[hsl(var(--success))] text-sm' : 'text-destructive text-sm'}>{u.is_active ? 'Active' : 'Inactive'}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-muted-foreground text-sm">{new Date(u.created_at).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* System Health */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {[
            { name: 'System Health', icon: Activity, status: 'All operational' },
            { name: 'Server Status', icon: Server, status: '99.9% uptime' },
            { name: 'Database', icon: Database, status: 'Connected' },
          ].map(s => (
            <div key={s.name} className="pro-card p-4">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <s.icon className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">{s.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{s.status}</p>
                </div>
                <div className="h-3 w-3 rounded-full bg-[hsl(var(--success))] animate-pulse shrink-0" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}
