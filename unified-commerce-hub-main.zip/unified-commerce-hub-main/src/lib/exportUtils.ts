import { format } from "date-fns";

type ExportRow = Record<string, string | number | null | undefined>;

export function exportToCSV(data: ExportRow[], filename: string, headers?: string[]) {
  if (!data.length) return;
  const keys = headers || Object.keys(data[0]);
  const csvRows = [
    keys.join(","),
    ...data.map(row =>
      keys.map(k => {
        const val = row[k];
        const str = val == null ? "" : String(val);
        return str.includes(",") || str.includes('"') ? `"${str.replace(/"/g, '""')}"` : str;
      }).join(",")
    ),
  ];
  const blob = new Blob([csvRows.join("\n")], { type: "text/csv" });
  downloadBlob(blob, `${filename}.csv`);
}

export function exportToPDF(title: string, sections: { heading: string; rows: { label: string; value: string }[] }[], transactions?: { receipt: string; date: string; method: string; amount: string; status: string }[]) {
  const now = format(new Date(), "MMM d, yyyy h:mm a");
  const html = `
<!DOCTYPE html><html><head><meta charset="utf-8">
<title>${title}</title>
<style>
  body{font-family:system-ui,sans-serif;margin:40px;color:#1a1a2e}
  h1{font-size:22px;margin-bottom:4px}
  .meta{color:#666;font-size:12px;margin-bottom:24px}
  h2{font-size:15px;margin:20px 0 8px;color:#333;border-bottom:1px solid #e5e5e5;padding-bottom:4px}
  table{width:100%;border-collapse:collapse;font-size:13px}
  td,th{padding:6px 10px;text-align:left;border-bottom:1px solid #eee}
  th{background:#f5f5f5;font-weight:600}
  .amount{text-align:right}
  .completed{color:#16a34a} .refunded{color:#dc2626} .pending{color:#d97706}
</style></head><body>
<h1>${title}</h1>
<p class="meta">Generated on ${now}</p>
${sections.map(s => `
<h2>${s.heading}</h2>
<table>${s.rows.map(r => `<tr><td>${r.label}</td><td class="amount">${r.value}</td></tr>`).join("")}</table>
`).join("")}
${transactions?.length ? `
<h2>Recent Transactions</h2>
<table>
<tr><th>Receipt</th><th>Date</th><th>Method</th><th>Status</th><th class="amount">Amount</th></tr>
${transactions.map(t => `<tr><td>${t.receipt}</td><td>${t.date}</td><td>${t.method}</td><td class="${t.status}">${t.status}</td><td class="amount">${t.amount}</td></tr>`).join("")}
</table>` : ""}
</body></html>`;

  const printWindow = window.open("", "_blank");
  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.print();
  }
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
