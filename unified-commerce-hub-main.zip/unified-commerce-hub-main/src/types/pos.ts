export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode?: string;
  price: number;
  cost: number;
  category: string;
  stock: number;
  lowStockAlert: number;
  image?: string;
  variants?: ProductVariant[];
  taxRate: number;
  isActive: boolean;
  expiryDate?: Date;
  batchNumber?: string;
}

export interface ProductVariant {
  id: string;
  name: string;
  sku: string;
  price: number;
  stock: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  discount: number;
  variant?: ProductVariant;
  note?: string;
}

export interface Transaction {
  id: string;
  items: CartItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  status: TransactionStatus;
  customerId?: string;
  cashierId: string;
  createdAt: Date;
  receiptNumber: string;
  splitPayments?: SplitPayment[];
}

export interface SplitPayment {
  method: PaymentMethod;
  amount: number;
}

export interface HeldOrder {
  id: string;
  items: CartItem[];
  customerName?: string;
  note?: string;
  createdAt: Date;
}

export type PaymentMethod = 'cash' | 'card' | 'upi' | 'wallet' | 'split';
export type TransactionStatus = 'completed' | 'pending' | 'refunded' | 'cancelled' | 'held';

export interface Customer {
  id: string;
  name: string;
  email?: string;
  phone: string;
  loyaltyPoints: number;
  totalSpent: number;
  createdAt: Date;
  birthday?: Date;
  segment?: CustomerSegment;
  notes?: string;
  lastVisit?: Date;
  visitCount: number;
  preferences?: string[];
}

export type CustomerSegment = 'new' | 'regular' | 'vip' | 'at-risk' | 'churned';

export interface Category {
  id: string;
  name: string;
  color: string;
  icon?: string;
  productCount: number;
}

export interface DashboardStats {
  todaySales: number;
  todayOrders: number;
  averageOrderValue: number;
  topProducts: { product: Product; quantity: number }[];
  recentTransactions: Transaction[];
  salesTrend: { date: string; amount: number }[];
}

export interface StockTransfer {
  id: string;
  productId: string;
  fromBranch: string;
  toBranch: string;
  quantity: number;
  status: 'pending' | 'in-transit' | 'completed';
  createdAt: Date;
}

export interface LoyaltyReward {
  id: string;
  name: string;
  pointsCost: number;
  discount: number;
  isActive: boolean;
}
