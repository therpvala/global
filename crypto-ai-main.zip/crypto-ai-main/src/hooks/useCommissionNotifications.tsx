import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { toast } from "sonner";

export const useCommissionNotifications = () => {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Subscribe to new commission records for the current user
    const channel = supabase
      .channel(`commissions-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "commissions",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const commission = payload.new as {
            amount: number;
            generation_level: number;
            status: string;
          };

          if (commission.status === "completed") {
            toast.success("Commission Earned! 🎉", {
              description: `You earned $${commission.amount.toFixed(2)} from Level ${commission.generation_level}`,
              duration: 5000,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);
};
