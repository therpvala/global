import { useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { useSecurity } from "./useSecurity";
import { z } from "zod";

// Validation schema for withdrawal
const withdrawSchema = z.object({
  amount: z.number()
    .positive("Amount must be positive")
    .max(100000, "Amount exceeds maximum limit"),
  walletAddress: z.string()
    .min(26, "Invalid wallet address")
    .max(62, "Invalid wallet address")
    .regex(/^[a-zA-Z0-9]+$/, "Invalid wallet address characters"),
});

interface WithdrawResult {
  success: boolean;
  error?: string;
  withdrawalId?: string;
}

interface PendingWithdrawal {
  id: string;
  amount: number;
  status: string;
  created_at: string;
  wallet_address: string;
}

export const useSecureWithdraw = () => {
  const { user } = useAuth();
  const { checkWithdrawEligibility, checkRateLimit, platformStatus } = useSecurity();
  const [isProcessing, setIsProcessing] = useState(false);
  const [pendingWithdrawals, setPendingWithdrawals] = useState<PendingWithdrawal[]>([]);

  const fetchPendingWithdrawals = useCallback(async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from("withdrawals")
      .select("id, amount, status, created_at, wallet_address")
      .eq("user_id", user.id)
      .in("status", ["pending", "processing"])
      .order("created_at", { ascending: false });
    
    setPendingWithdrawals(data || []);
  }, [user]);

  const requestWithdraw = useCallback(async (
    amount: number,
    walletAddress: string
  ): Promise<WithdrawResult> => {
    if (!user) {
      return { success: false, error: "Not authenticated" };
    }

    if (!platformStatus.isActive) {
      return { success: false, error: "Platform is in maintenance mode" };
    }

    setIsProcessing(true);

    try {
      // 1. Validate input
      const validation = withdrawSchema.safeParse({ amount, walletAddress });
      if (!validation.success) {
        const error = validation.error.errors[0]?.message || "Invalid input";
        return { success: false, error };
      }

      // 2. Check rate limit (max 5 withdraw requests per 10 minutes)
      const rateCheck = await checkRateLimit("withdraw_request", 5, 10);
      if (!rateCheck.allowed) {
        return { success: false, error: rateCheck.reason || "Too many requests" };
      }

      // 3. Check withdraw eligibility
      const eligibility = await checkWithdrawEligibility();
      if (!eligibility.allowed) {
        return { success: false, error: eligibility.reason || "Withdrawal not allowed" };
      }

      // 4. Check amount limits
      if (eligibility.min_amount && amount < eligibility.min_amount) {
        return { 
          success: false, 
          error: `Minimum withdrawal is $${eligibility.min_amount}` 
        };
      }

      if (eligibility.remaining_daily !== undefined && amount > eligibility.remaining_daily) {
        return { 
          success: false, 
          error: `Daily limit exceeded. Remaining: $${eligibility.remaining_daily.toFixed(2)}` 
        };
      }

      // 5. Get user's wallet
      const { data: wallet, error: walletError } = await supabase
        .from("wallets")
        .select("id, available_balance")
        .eq("user_id", user.id)
        .single();

      if (walletError || !wallet) {
        return { success: false, error: "Wallet not found" };
      }

      // 6. Check balance
      const availableBalance = Number(wallet.available_balance) || 0;
      if (amount > availableBalance) {
        return { success: false, error: "Insufficient balance" };
      }

      // 7. Calculate fee (example: 2% fee)
      const feePercentage = 0.02;
      const fee = amount * feePercentage;
      const netAmount = amount - fee;

      // 8. Create withdrawal request (status: pending for admin approval)
      const { data: withdrawal, error: withdrawError } = await supabase
        .from("withdrawals")
        .insert({
          user_id: user.id,
          wallet_id: wallet.id,
          amount,
          fee,
          net_amount: netAmount,
          wallet_address: walletAddress,
          status: "pending", // Requires admin approval
        })
        .select("id")
        .single();

      if (withdrawError) {
        console.error("Withdrawal error:", withdrawError);
        return { success: false, error: "Failed to create withdrawal request" };
      }

      // 9. Lock the amount in wallet (move from available to locked)
      const { data: currentWallet } = await supabase
        .from("wallets")
        .select("locked_balance")
        .eq("id", wallet.id)
        .single();

      const currentLocked = Number(currentWallet?.locked_balance) || 0;

      const { error: lockError } = await supabase
        .from("wallets")
        .update({
          available_balance: availableBalance - amount,
          locked_balance: currentLocked + amount,
        })
        .eq("id", wallet.id);

      if (lockError) {
        // Rollback withdrawal
        await supabase.from("withdrawals").delete().eq("id", withdrawal.id);
        return { success: false, error: "Failed to process withdrawal" };
      }

      // Refresh pending withdrawals list
      await fetchPendingWithdrawals();

      return { success: true, withdrawalId: withdrawal.id };
    } catch (error) {
      console.error("Withdraw error:", error);
      return { success: false, error: "An unexpected error occurred" };
    } finally {
      setIsProcessing(false);
    }
  }, [user, platformStatus, checkRateLimit, checkWithdrawEligibility, fetchPendingWithdrawals]);

  const cancelWithdrawal = useCallback(async (withdrawalId: string): Promise<WithdrawResult> => {
    if (!user) {
      return { success: false, error: "Not authenticated" };
    }

    setIsProcessing(true);

    try {
      // Get the withdrawal details
      const { data: withdrawal, error: fetchError } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("id", withdrawalId)
        .eq("user_id", user.id)
        .eq("status", "pending")
        .single();

      if (fetchError || !withdrawal) {
        return { success: false, error: "Withdrawal not found or cannot be cancelled" };
      }

      // Get user's wallet
      const { data: wallet } = await supabase
        .from("wallets")
        .select("id, available_balance, locked_balance")
        .eq("user_id", user.id)
        .single();

      if (!wallet) {
        return { success: false, error: "Wallet not found" };
      }

      // Refund the amount
      const { error: refundError } = await supabase
        .from("wallets")
        .update({
          available_balance: (Number(wallet.available_balance) || 0) + Number(withdrawal.amount),
          locked_balance: Math.max(0, (Number(wallet.locked_balance) || 0) - Number(withdrawal.amount)),
        })
        .eq("id", wallet.id);

      if (refundError) {
        return { success: false, error: "Failed to refund amount" };
      }

      // Update withdrawal status
      const { error: updateError } = await supabase
        .from("withdrawals")
        .update({ status: "rejected", rejection_reason: "Cancelled by user" })
        .eq("id", withdrawalId);

      if (updateError) {
        return { success: false, error: "Failed to cancel withdrawal" };
      }

      await fetchPendingWithdrawals();
      return { success: true };
    } catch (error) {
      console.error("Cancel withdrawal error:", error);
      return { success: false, error: "An unexpected error occurred" };
    } finally {
      setIsProcessing(false);
    }
  }, [user, fetchPendingWithdrawals]);

  return {
    requestWithdraw,
    cancelWithdrawal,
    fetchPendingWithdrawals,
    pendingWithdrawals,
    isProcessing,
  };
};
