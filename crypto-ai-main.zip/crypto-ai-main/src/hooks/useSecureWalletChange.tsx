import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { useSecurity } from "./useSecurity";
import { toast } from "sonner";
import { z } from "zod";

// Validation schema for wallet address
const walletSchema = z.object({
  walletAddress: z.string()
    .min(26, "Wallet address is too short")
    .max(62, "Wallet address is too long")
    .regex(/^[a-zA-Z0-9]+$/, "Invalid wallet address format"),
});

interface WalletChangeResult {
  success: boolean;
  error?: string;
  cooldownDays?: number;
}

export const useSecureWalletChange = () => {
  const { user } = useAuth();
  const { checkRateLimit, logWalletChange, platformStatus } = useSecurity();
  const [isProcessing, setIsProcessing] = useState(false);

  const changeWalletAddress = async (
    newWalletAddress: string
  ): Promise<WalletChangeResult> => {
    if (!user) {
      return { success: false, error: "Not authenticated" };
    }

    if (!platformStatus.isActive) {
      return { success: false, error: "Platform is in maintenance mode" };
    }

    setIsProcessing(true);

    try {
      // 1. Validate input
      const validation = walletSchema.safeParse({ walletAddress: newWalletAddress });
      if (!validation.success) {
        const error = validation.error.errors[0]?.message || "Invalid wallet address";
        return { success: false, error };
      }

      // 2. Check rate limit (max 3 wallet changes per day)
      const rateCheck = await checkRateLimit("wallet_change", 3, 1440);
      if (!rateCheck.allowed) {
        return { success: false, error: rateCheck.reason || "Too many wallet changes today" };
      }

      // 3. Get current wallet address
      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("wallet_address")
        .eq("user_id", user.id)
        .single();

      if (profileError) {
        return { success: false, error: "Failed to fetch profile" };
      }

      const oldAddress = profile?.wallet_address;

      // 4. Check if address is the same
      if (oldAddress === newWalletAddress) {
        return { success: false, error: "New address is the same as current" };
      }

      // 5. Update wallet address
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ 
          wallet_address: newWalletAddress,
          updated_at: new Date().toISOString()
        })
        .eq("user_id", user.id);

      if (updateError) {
        return { success: false, error: "Failed to update wallet address" };
      }

      // 6. Log the change (triggers cooldown)
      await logWalletChange(oldAddress, newWalletAddress);

      // 7. Log admin action for audit
      await supabase.from("admin_actions").insert({
        admin_id: user.id,
        action: "wallet_address_changed",
        reference_id: `${oldAddress || 'none'} -> ${newWalletAddress}`,
      });

      return { success: true };
    } catch (error) {
      console.error("Wallet change error:", error);
      return { success: false, error: "An unexpected error occurred" };
    } finally {
      setIsProcessing(false);
    }
  };

  return {
    changeWalletAddress,
    isProcessing,
  };
};
