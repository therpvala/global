import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { toast } from "sonner";

// Generate a unique device ID and store in localStorage
const getDeviceId = (): string => {
  const storageKey = "device_id";
  let deviceId = localStorage.getItem(storageKey);
  
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    localStorage.setItem(storageKey, deviceId);
  }
  
  return deviceId;
};

// Get device info
const getDeviceInfo = () => {
  return {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    language: navigator.language,
    screenWidth: window.screen.width,
    screenHeight: window.screen.height,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
  };
};

interface WithdrawEligibility {
  allowed: boolean;
  reason?: string;
  min_amount?: number;
  max_daily?: number;
  today_withdrawn?: number;
  remaining_daily?: number;
  cooldown_ends?: string;
}

interface PlatformStatus {
  isActive: boolean;
  isLoading: boolean;
}

export const useSecurity = () => {
  const { user } = useAuth();
  const [platformStatus, setPlatformStatus] = useState<PlatformStatus>({
    isActive: true,
    isLoading: true,
  });
  const [sessionId, setSessionId] = useState<string | null>(null);

  // Check platform status
  const checkPlatformStatus = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from("platform_settings")
        .select("value")
        .eq("key", "platform_status")
        .maybeSingle();

      if (error) throw error;

      setPlatformStatus({
        isActive: data?.value === "active" || data === null,
        isLoading: false,
      });
    } catch (error) {
      console.error("Error checking platform status:", error);
      setPlatformStatus({ isActive: true, isLoading: false });
    }
  }, []);

  // Register device session
  const registerDeviceSession = useCallback(async () => {
    if (!user) return;

    try {
      const deviceId = getDeviceId();
      const deviceInfo = getDeviceInfo();

      const { data, error } = await supabase.rpc("manage_device_session", {
        _user_id: user.id,
        _device_id: deviceId,
        _device_info: deviceInfo,
      });

      if (error) {
        console.error("Error registering device:", error);
        return;
      }

      const result = data as { session_id?: string; status?: string } | null;

      if (result?.status === "created") {
        // New session created, old sessions on other devices were killed
        toast.info("New device logged in", {
          description: "Other active sessions have been signed out",
        });
      }

      setSessionId(result?.session_id || null);
    } catch (error) {
      console.error("Error in device registration:", error);
    }
  }, [user]);

  // Check withdraw eligibility
  const checkWithdrawEligibility = useCallback(async (): Promise<WithdrawEligibility> => {
    if (!user) {
      return { allowed: false, reason: "Not authenticated" };
    }

    try {
      const { data, error } = await supabase.rpc("can_user_withdraw", {
        _user_id: user.id,
      });

      if (error) throw error;

      return data as unknown as WithdrawEligibility;
    } catch (error) {
      console.error("Error checking withdraw eligibility:", error);
      return { allowed: false, reason: "Error checking eligibility" };
    }
  }, [user]);

  // Check rate limit
  const checkRateLimit = useCallback(async (
    action: string,
    maxRequests: number = 10,
    windowMinutes: number = 1
  ): Promise<{ allowed: boolean; reason?: string }> => {
    if (!user) {
      return { allowed: false, reason: "Not authenticated" };
    }

    try {
      const { data, error } = await supabase.rpc("check_rate_limit", {
        _user_id: user.id,
        _action: action,
        _max_requests: maxRequests,
        _window_minutes: windowMinutes,
      });

      if (error) throw error;

      const result = data as unknown as { allowed: boolean; reason?: string };

      if (!result?.allowed) {
        toast.error("Too many requests", {
          description: result?.reason || "Please wait before trying again",
        });
      }

      return result;
    } catch (error) {
      console.error("Error checking rate limit:", error);
      return { allowed: true }; // Fail open for rate limiting
    }
  }, [user]);

  // Log wallet address change
  const logWalletChange = useCallback(async (
    oldAddress: string | null,
    newAddress: string
  ): Promise<boolean> => {
    if (!user) return false;

    try {
      // Get cooldown setting
      const { data: settings } = await supabase
        .from("platform_settings")
        .select("value")
        .eq("key", "wallet_change_cooldown")
        .maybeSingle();

      const cooldownDays = parseInt(settings?.value || "7", 10);
      const cooldownExpires = new Date();
      cooldownExpires.setDate(cooldownExpires.getDate() + cooldownDays);

      const { error } = await supabase
        .from("wallet_change_logs")
        .insert({
          user_id: user.id,
          old_wallet_address: oldAddress,
          new_wallet_address: newAddress,
          cooldown_expires_at: cooldownExpires.toISOString(),
        });

      if (error) throw error;

      toast.warning("Wallet Cooldown Active", {
        description: `Withdrawals disabled for ${cooldownDays} days after wallet change`,
        duration: 5000,
      });

      return true;
    } catch (error) {
      console.error("Error logging wallet change:", error);
      return false;
    }
  }, [user]);

  // Refresh session on activity
  const refreshSession = useCallback(async () => {
    if (!user || !sessionId) return;

    try {
      const deviceId = getDeviceId();
      await supabase.rpc("manage_device_session", {
        _user_id: user.id,
        _device_id: deviceId,
      });
    } catch (error) {
      // Silent fail for session refresh
    }
  }, [user, sessionId]);

  // Initialize on mount
  useEffect(() => {
    checkPlatformStatus();
  }, [checkPlatformStatus]);

  // Register device when user logs in
  useEffect(() => {
    if (user) {
      registerDeviceSession();
    }
  }, [user, registerDeviceSession]);

  // Refresh session periodically (every 5 minutes)
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(refreshSession, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, [user, refreshSession]);

  // Refresh on user activity
  useEffect(() => {
    if (!user) return;

    const handleActivity = () => {
      refreshSession();
    };

    // Debounce activity detection
    let timeout: NodeJS.Timeout;
    const debouncedActivity = () => {
      clearTimeout(timeout);
      timeout = setTimeout(handleActivity, 30000); // Refresh after 30s of activity
    };

    window.addEventListener("click", debouncedActivity);
    window.addEventListener("keypress", debouncedActivity);

    return () => {
      window.removeEventListener("click", debouncedActivity);
      window.removeEventListener("keypress", debouncedActivity);
      clearTimeout(timeout);
    };
  }, [user, refreshSession]);

  return {
    platformStatus,
    sessionId,
    checkWithdrawEligibility,
    checkRateLimit,
    logWalletChange,
    refreshSession,
    checkPlatformStatus,
  };
};
