import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import { toast } from "sonner";

interface WalletData {
  available_balance: number;
  locked_balance: number;
  total_earned: number;
}

export const useRealtimeWallet = () => {
  const { user } = useAuth();
  const [wallet, setWallet] = useState<WalletData>({
    available_balance: 0,
    locked_balance: 0,
    total_earned: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  const fetchWallet = useCallback(async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("wallets")
      .select("available_balance, locked_balance, total_earned")
      .eq("user_id", user.id)
      .maybeSingle();

    if (error) {
      console.error("Error fetching wallet:", error);
    } else if (data) {
      setWallet({
        available_balance: Number(data.available_balance) || 0,
        locked_balance: Number(data.locked_balance) || 0,
        total_earned: Number(data.total_earned) || 0,
      });
    }
    setIsLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) {
      setIsLoading(false);
      return;
    }

    // Initial fetch
    fetchWallet();

    // Subscribe to wallet changes for the current user
    const channel = supabase
      .channel(`wallet-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "wallets",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newData = payload.new as {
            available_balance: number;
            locked_balance: number;
            total_earned: number;
          };

          const oldBalance = wallet.available_balance;
          const newBalance = Number(newData.available_balance) || 0;
          const difference = newBalance - oldBalance;

          setWallet({
            available_balance: newBalance,
            locked_balance: Number(newData.locked_balance) || 0,
            total_earned: Number(newData.total_earned) || 0,
          });

          // Show toast for balance increase (commission/profit received)
          if (difference > 0 && oldBalance > 0) {
            toast.success("Balance Updated! 💰", {
              description: `+$${difference.toFixed(2)} added to your wallet`,
              duration: 4000,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, fetchWallet]);

  return { wallet, isLoading, refetch: fetchWallet };
};
