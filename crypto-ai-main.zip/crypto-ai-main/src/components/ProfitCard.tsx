import AnimatedNumber from "./AnimatedNumber";

interface ProfitCardProps {
  amount: number;
}

const ProfitCard = ({ amount }: ProfitCardProps) => {
  return (
    <div className="profit-card animate-fade-up animation-delay-200">
      {/* Label */}
      <div className="flex items-center justify-center gap-2 mb-2">
        <span className="text-2xl">📈</span>
        <span className="text-muted-foreground text-lg font-bold uppercase tracking-wide">
          TODAY PROFIT
        </span>
      </div>
      
      {/* Big Profit Number */}
      <div className="flex items-center justify-center">
        <AnimatedNumber 
          value={amount}
          className="text-5xl font-extrabold text-profit"
          prefix="+$"
        />
      </div>
      
      {/* Simple update text */}
      <div className="text-center mt-2">
        <span className="text-muted-foreground text-base">Updated automatically ✨</span>
      </div>
    </div>
  );
};

export default ProfitCard;
