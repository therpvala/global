import { Landmark, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedNumber from "@/components/AnimatedNumber";

interface Transaction {
  id: string;
  date: string;
  type: "added" | "profit" | "withdraw";
  amount: number;
}

interface WalletScreenProps {
  availableBalance: number;
  processingBalance: number;
  transactions: Transaction[];
  onViewAllHistory?: () => void;
}

const WalletScreen = ({ 
  availableBalance, 
  processingBalance, 
  transactions,
  onViewAllHistory 
}: WalletScreenProps) => {
  const getTypeStyle = (type: string) => {
    switch (type) {
      case "added":
        return { color: "text-crypto", icon: "💳", label: "Added" };
      case "profit":
        return { color: "text-profit", icon: "📈", label: "Profit" };
      case "withdraw":
        return { color: "text-muted-foreground", icon: "💸", label: "Withdraw" };
      default:
        return { color: "text-foreground", icon: "💰", label: type };
    }
  };

  // Only show last 5 transactions
  const recentTransactions = transactions.slice(0, 5);

  return (
    <div className="p-5 pb-32 space-y-6">
      {/* Available Balance Card - BIG */}
      <div className="balance-card animate-fade-up">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Landmark className="w-7 h-7 text-white/90" />
          <span className="text-white/90 text-xl font-bold uppercase tracking-wide">
            Available Balance
          </span>
        </div>
        <div className="flex items-center justify-center">
          <AnimatedNumber 
            value={availableBalance} 
            className="text-6xl font-extrabold text-white"
            prefix="$"
          />
        </div>
      </div>

      {/* Processing Balance (if any) */}
      {processingBalance > 0 && (
        <div className="profit-card animate-fade-up animation-delay-100">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Clock className="w-6 h-6 text-gold" />
            <span className="text-muted-foreground text-lg font-bold uppercase">
              Processing
            </span>
          </div>
          <div className="flex items-center justify-center">
            <AnimatedNumber 
              value={processingBalance}
              className="text-4xl font-bold text-gold"
              prefix="$"
            />
          </div>
        </div>
      )}

      {/* Recent Transactions - SIMPLE LIST */}
      <div className="profit-card animate-fade-up animation-delay-200">
        <h3 className="text-xl font-bold text-foreground mb-4 text-center">
          📋 Recent Activity
        </h3>
        
        {recentTransactions.length === 0 ? (
          <div className="text-center py-8">
            <span className="text-5xl mb-4 block">📭</span>
            <p className="text-muted-foreground text-xl">No transactions yet</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recentTransactions.map((tx) => {
              const style = getTypeStyle(tx.type);
              return (
                <div 
                  key={tx.id}
                  className="flex items-center justify-between p-4 bg-secondary rounded-2xl"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{style.icon}</span>
                    <div>
                      <p className="font-bold text-lg text-foreground">{style.label}</p>
                      <p className="text-muted-foreground text-base">{tx.date}</p>
                    </div>
                  </div>
                  <span className={`font-bold text-xl ${style.color}`}>
                    {tx.type === "withdraw" ? "-" : "+"}${tx.amount.toLocaleString()}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* View All Button */}
      {transactions.length > 5 && onViewAllHistory && (
        <Button 
          variant="secondary" 
          size="lg" 
          className="w-full h-16 text-xl font-bold"
          onClick={onViewAllHistory}
        >
          VIEW ALL HISTORY 📜
        </Button>
      )}
    </div>
  );
};

export default WalletScreen;
