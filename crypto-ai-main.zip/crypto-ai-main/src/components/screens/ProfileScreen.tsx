import { RefreshCw, MessageCircle, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ProfileScreenProps {
  userName: string;
  walletAddress: string;
  onChangeWallet: () => void;
  onSupport: () => void;
  onLogout: () => void;
}

const ProfileScreen = ({ 
  userName, 
  walletAddress, 
  onChangeWallet, 
  onSupport, 
  onLogout 
}: ProfileScreenProps) => {
  const truncateWallet = (address: string) => {
    if (!address || address === "Not set") return "Not set";
    if (address.length <= 16) return address;
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  return (
    <div className="p-5 pb-32 space-y-6">
      {/* User Card - BIG & CLEAR */}
      <div className="balance-card animate-fade-up text-center">
        {/* Avatar */}
        <div className="flex justify-center mb-4">
          <div className="w-24 h-24 rounded-full bg-white/20 flex items-center justify-center text-5xl">
            👤
          </div>
        </div>
        
        {/* Name */}
        <h2 className="text-3xl font-extrabold text-white mb-3">
          {userName}
        </h2>
        
        {/* Wallet Address - Read Only */}
        <div className="bg-white/10 rounded-2xl p-4">
          <span className="text-white/70 text-base uppercase tracking-wide block mb-1">
            Wallet Address 🔐
          </span>
          <span className="text-xl font-mono text-white/90 break-all">
            {truncateWallet(walletAddress)}
          </span>
        </div>
      </div>

      {/* Action Buttons - BIG */}
      <div className="space-y-4 animate-fade-up animation-delay-100">
        <Button 
          variant="secondary" 
          size="xl" 
          className="w-full h-18 text-xl font-bold justify-start px-6"
          onClick={onChangeWallet}
        >
          <RefreshCw className="w-7 h-7 text-primary" />
          <span className="flex-1 text-left ml-2">CHANGE WALLET</span>
          <span className="text-2xl">🔄</span>
        </Button>

        <Button 
          variant="secondary" 
          size="xl" 
          className="w-full h-18 text-xl font-bold justify-start px-6"
          onClick={onSupport}
        >
          <MessageCircle className="w-7 h-7 text-crypto" />
          <span className="flex-1 text-left ml-2">SUPPORT</span>
          <span className="text-2xl">💬</span>
        </Button>

        <Button 
          variant="secondary" 
          size="xl" 
          className="w-full h-18 text-xl font-bold justify-start px-6 hover:bg-destructive/10"
          onClick={onLogout}
        >
          <LogOut className="w-7 h-7 text-destructive" />
          <span className="flex-1 text-left ml-2 text-destructive">LOGOUT</span>
          <span className="text-2xl">🚪</span>
        </Button>
      </div>
    </div>
  );
};

export default ProfileScreen;
