import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, CheckCircle, XCircle, Loader2 } from "lucide-react";

interface Withdrawal {
  id: string;
  amount: number;
  fee: number;
  net_amount: number;
  status: string;
  wallet_address: string;
  created_at: string;
  processed_at: string | null;
  tx_hash: string | null;
  rejection_reason: string | null;
}

interface WithdrawalHistoryScreenProps {
  onBack: () => void;
}

const WithdrawalHistoryScreen = ({ onBack }: WithdrawalHistoryScreenProps) => {
  const { user } = useAuth();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchWithdrawals();
    }
  }, [user]);

  const fetchWithdrawals = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("withdrawals")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching withdrawals:", error);
        return;
      }

      setWithdrawals(data || []);
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-profit/10 text-profit border-0 text-base px-3 py-1">
            <CheckCircle className="w-4 h-4 mr-1" />
            Completed
          </Badge>
        );
      case "pending":
        return (
          <Badge className="bg-gold/10 text-gold border-0 text-base px-3 py-1">
            <Clock className="w-4 h-4 mr-1" />
            Pending
          </Badge>
        );
      case "processing":
      case "approved":
        return (
          <Badge className="bg-crypto/10 text-crypto border-0 text-base px-3 py-1">
            <Loader2 className="w-4 h-4 mr-1 animate-spin" />
            Processing
          </Badge>
        );
      case "rejected":
        return (
          <Badge className="bg-destructive/10 text-destructive border-0 text-base px-3 py-1">
            <XCircle className="w-4 h-4 mr-1" />
            Rejected
          </Badge>
        );
      default:
        return (
          <Badge className="bg-muted text-muted-foreground border-0 text-base px-3 py-1">
            {status}
          </Badge>
        );
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const truncateAddress = (address: string) => {
    if (address.length <= 16) return address;
    return `${address.slice(0, 8)}...${address.slice(-8)}`;
  };

  if (isLoading) {
    return (
      <div className="p-5 pb-32 flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-crypto mx-auto mb-4" />
          <p className="text-muted-foreground text-lg">Loading withdrawals...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-5 pb-32 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="h-12 w-12 rounded-full"
        >
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold text-foreground">Withdrawal History</h1>
      </div>

      {/* Withdrawals List */}
      {withdrawals.length === 0 ? (
        <div className="profit-card text-center py-12">
          <span className="text-6xl mb-4 block">💸</span>
          <p className="text-xl font-bold text-foreground mb-2">No withdrawals yet</p>
          <p className="text-muted-foreground">Your withdrawal history will appear here</p>
        </div>
      ) : (
        <div className="space-y-4">
          {withdrawals.map((withdrawal) => (
            <div
              key={withdrawal.id}
              className="profit-card space-y-4"
            >
              {/* Amount & Status Row */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-3xl font-bold text-foreground">
                    ${withdrawal.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                  <p className="text-muted-foreground text-base">
                    Net: ${withdrawal.net_amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    <span className="text-sm ml-2">(Fee: ${withdrawal.fee?.toFixed(2) || "0.00"})</span>
                  </p>
                </div>
                {getStatusBadge(withdrawal.status)}
              </div>

              {/* Details */}
              <div className="space-y-2 pt-3 border-t border-border">
                <div className="flex justify-between text-base">
                  <span className="text-muted-foreground">Date</span>
                  <span className="text-foreground font-medium">
                    {formatDate(withdrawal.created_at)}
                  </span>
                </div>
                <div className="flex justify-between text-base">
                  <span className="text-muted-foreground">Wallet</span>
                  <span className="text-foreground font-mono text-sm">
                    {truncateAddress(withdrawal.wallet_address)}
                  </span>
                </div>
                {withdrawal.tx_hash && (
                  <div className="flex justify-between text-base">
                    <span className="text-muted-foreground">TX Hash</span>
                    <span className="text-crypto font-mono text-sm">
                      {truncateAddress(withdrawal.tx_hash)}
                    </span>
                  </div>
                )}
                {withdrawal.rejection_reason && (
                  <div className="mt-2 p-3 bg-destructive/10 rounded-lg">
                    <p className="text-destructive text-sm">
                      <strong>Reason:</strong> {withdrawal.rejection_reason}
                    </p>
                  </div>
                )}
                {withdrawal.processed_at && (
                  <div className="flex justify-between text-base">
                    <span className="text-muted-foreground">Processed</span>
                    <span className="text-foreground font-medium">
                      {formatDate(withdrawal.processed_at)}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WithdrawalHistoryScreen;
