import { Copy, CheckCircle, Gift, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { toast } from "sonner";
import AnimatedNumber from "@/components/AnimatedNumber";

interface ShareScreenProps {
  referralLink: string;
  referralCode: string;
  peopleReferred: number;
  totalEarnings: number;
}

const ShareScreen = ({ 
  referralLink, 
  referralCode,
  peopleReferred,
  totalEarnings,
}: ShareScreenProps) => {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(referralLink);
      setCopied(true);
      toast.success("Link copied!", { icon: "✅" });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast.error("Failed to copy link");
    }
  };

  return (
    <div className="p-5 pb-32 space-y-5">
      {/* Stats Cards - ULTRA SIMPLE */}
      <div className="grid grid-cols-2 gap-4 animate-fade-up">
        {/* People Referred */}
        <div className="profit-card text-center">
          <div className="flex justify-center mb-2">
            <div className="p-3 rounded-full bg-crypto/10">
              <Users className="w-8 h-8 text-crypto" />
            </div>
          </div>
          <span className="text-muted-foreground text-base font-bold uppercase block">
            Your People
          </span>
          <span className="text-4xl font-extrabold text-foreground">
            {peopleReferred}
          </span>
          <span className="text-2xl ml-1">👥</span>
        </div>

        {/* Total Earnings */}
        <div className="profit-card text-center">
          <div className="flex justify-center mb-2">
            <div className="p-3 rounded-full bg-profit/10">
              <span className="text-3xl">💵</span>
            </div>
          </div>
          <span className="text-muted-foreground text-base font-bold uppercase block">
            You Earned
          </span>
          <AnimatedNumber 
            value={totalEarnings}
            className="text-4xl font-extrabold text-profit"
            prefix="$"
          />
        </div>
      </div>

      {/* Main Share Card - ULTRA SIMPLE */}
      <div className="balance-card animate-fade-up animation-delay-100 text-center">
        {/* Big Gift Icon */}
        <div className="flex justify-center mb-3">
          <div className="p-4 rounded-full bg-white/10">
            <Gift className="w-16 h-16 text-white" />
          </div>
        </div>
        
        {/* Clear Message */}
        <h2 className="text-2xl font-extrabold text-white mb-2">
          Share & Earn More 🎁
        </h2>
        
        <p className="text-white/80 text-lg mb-4">
          When your people earn, you earn
        </p>

        {/* Referral Code - BIG */}
        <div className="bg-white/10 rounded-2xl p-4 mb-5">
          <span className="text-white/70 text-sm uppercase tracking-wide">
            Your Code
          </span>
          <div className="text-3xl font-extrabold text-white mt-1 font-mono tracking-widest">
            {referralCode}
          </div>
        </div>

        {/* BIG Copy Button */}
        <Button 
          variant="gold" 
          size="xl" 
          className="w-full h-18 text-xl font-bold rounded-3xl"
          onClick={handleCopyLink}
        >
          {copied ? (
            <>
              <CheckCircle className="w-7 h-7" />
              <span>COPIED!</span>
              <span className="text-2xl ml-2">✅</span>
            </>
          ) : (
            <>
              <Copy className="w-7 h-7" />
              <span>COPY LINK</span>
              <span className="text-2xl ml-2">🔗</span>
            </>
          )}
        </Button>
      </div>

      {/* Simple Info Text */}
      <div className="text-center animate-fade-up animation-delay-200">
        <p className="text-muted-foreground text-lg">
          Share with friends to grow together 🚀
        </p>
      </div>
    </div>
  );
};

export default ShareScreen;
