import { Plus, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import BalanceCard from "@/components/BalanceCard";
import ProfitCard from "@/components/ProfitCard";

interface HomeScreenProps {
  balance: number;
  todayProfit: number;
  onAddMoney: () => void;
  onWithdraw: () => void;
}

const HomeScreen = ({ balance, todayProfit, onAddMoney, onWithdraw }: HomeScreenProps) => {
  return (
    <div className="p-5 pb-32 space-y-6">
      {/* Main Balance Card - BIG & CLEAR */}
      <BalanceCard balance={balance} />

      {/* Today Profit Card */}
      <ProfitCard amount={todayProfit} />

      {/* Primary Action Buttons - VERY BIG */}
      <div className="space-y-4 pt-2 animate-fade-up animation-delay-100">
        <Button 
          variant="crypto" 
          size="xl" 
          className="w-full h-20 text-2xl font-bold rounded-3xl"
          onClick={onAddMoney}
        >
          <Plus className="w-8 h-8" />
          <span>ADD MONEY</span>
          <span className="text-3xl ml-2">💳</span>
        </Button>

        <Button 
          variant="navy" 
          size="xl" 
          className="w-full h-20 text-2xl font-bold rounded-3xl"
          onClick={onWithdraw}
        >
          <ArrowDown className="w-8 h-8" />
          <span>WITHDRAW</span>
          <span className="text-3xl ml-2">💸</span>
        </Button>
      </div>
    </div>
  );
};

export default HomeScreen;
