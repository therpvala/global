import { Users, Share2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import AnimatedNumber from "@/components/AnimatedNumber";
import { toast } from "sonner";

interface TeamScreenProps {
  teamCount: number;
  todayEarnings: number;
}

const TeamScreen = ({ teamCount, todayEarnings }: TeamScreenProps) => {
  const handleShareLink = () => {
    const referralLink = "https://app.cryptoai.trade/ref/YOUR_CODE";
    navigator.clipboard.writeText(referralLink);
    toast.success("Link copied!", {
      description: "Share it with your friends",
      icon: "🔗",
    });
  };

  return (
    <div className="p-4 pb-28 space-y-4">
      {/* Team Count Card */}
      <div className="balance-card animate-fade-up">
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-5 h-5 text-white/80" />
          <span className="text-white/80 text-base font-medium uppercase tracking-wide">
            Your Team
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-3xl">👥</span>
          <span className="text-5xl font-bold text-white">{teamCount}</span>
          <span className="text-white/70 text-lg">people</span>
        </div>
      </div>

      {/* Earnings Card */}
      <div className="profit-card animate-fade-up animation-delay-100">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-muted-foreground text-sm font-medium uppercase tracking-wide">
              You Earned Today
            </span>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-2xl">⚡️</span>
              <AnimatedNumber 
                value={todayEarnings}
                className="text-3xl font-bold text-profit"
                prefix="$"
              />
              <span className="text-lg">💵</span>
            </div>
          </div>
          <div className="p-3 rounded-2xl bg-gold/10">
            <Zap className="w-6 h-6 text-gold" />
          </div>
        </div>
      </div>

      {/* Share Button */}
      <div className="animate-fade-up animation-delay-200">
        <Button 
          variant="crypto" 
          size="lg" 
          className="w-full animate-pulse-glow"
          onClick={handleShareLink}
        >
          <Share2 className="w-5 h-5" />
          <span>SHARE LINK</span>
          <span className="text-xl ml-1">🔗👥</span>
        </Button>
      </div>

      {/* Info Text */}
      <div className="text-center pt-4 animate-fade-up animation-delay-300">
        <p className="text-muted-foreground text-lg">
          Invite friends & earn together! 🚀
        </p>
      </div>
    </div>
  );
};

export default TeamScreen;
