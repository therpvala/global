import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PlatformStatusGuardProps {
  children: React.ReactNode;
}

const PlatformStatusGuard = ({ children }: PlatformStatusGuardProps) => {
  const [isActive, setIsActive] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  const checkStatus = async () => {
    try {
      const { data, error } = await supabase
        .from("platform_settings")
        .select("value")
        .eq("key", "platform_status")
        .maybeSingle();

      if (error) throw error;

      setIsActive(data?.value === "active" || data === null);
    } catch (error) {
      console.error("Error checking platform status:", error);
      setIsActive(true); // Fail open
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    checkStatus();

    // Subscribe to status changes
    const channel = supabase
      .channel("platform-status")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "platform_settings",
          filter: "key=eq.platform_status",
        },
        (payload) => {
          const newValue = (payload.new as { value?: string })?.value;
          setIsActive(newValue === "active");
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isActive) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gold/10 flex items-center justify-center">
            <AlertTriangle className="w-10 h-10 text-gold" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-3">
            Maintenance Mode
          </h1>
          <p className="text-muted-foreground mb-6">
            We're currently performing scheduled maintenance to improve your experience. 
            Please check back shortly.
          </p>
          <Button onClick={checkStatus} variant="outline" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Check Again
          </Button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default PlatformStatusGuard;
