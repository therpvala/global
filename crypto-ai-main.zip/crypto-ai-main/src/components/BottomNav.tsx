import { Home, Wallet, Share2, User } from "lucide-react";
import { cn } from "@/lib/utils";

interface BottomNavProps {
  activeTab: "home" | "wallet" | "share" | "profile";
  onTabChange: (tab: "home" | "wallet" | "share" | "profile") => void;
}

const BottomNav = ({ activeTab, onTabChange }: BottomNavProps) => {
  const tabs = [
    { id: "home" as const, label: "Home", icon: Home, emoji: "🏠" },
    { id: "wallet" as const, label: "Wallet", icon: Wallet, emoji: "💰" },
    { id: "share" as const, label: "Share", icon: Share2, emoji: "👥" },
    { id: "profile" as const, label: "Profile", icon: User, emoji: "⚙️" },
  ];

  return (
    <nav className="bottom-nav z-50">
      <div className="flex items-center justify-around py-3">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "nav-item flex-1 py-2",
              activeTab === tab.id && "active"
            )}
          >
            <div className={cn(
              "nav-icon flex items-center justify-center w-14 h-14 mx-auto rounded-2xl transition-all",
              activeTab === tab.id ? "bg-primary/15 scale-110" : "bg-transparent"
            )}>
              <span className="text-3xl">{tab.emoji}</span>
            </div>
            <span className={cn(
              "text-base font-bold mt-1",
              activeTab === tab.id ? "text-primary" : "text-muted-foreground"
            )}>
              {tab.label}
            </span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNav;
