import { useState, useEffect } from "react";
import { X, ArrowDown, CheckCircle, AlertCircle, Loader2, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AnimatedNumber from "@/components/AnimatedNumber";
import { useSecureWithdraw } from "@/hooks/useSecureWithdraw";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableBalance: number;
  onConfirm?: (amount: number) => void;
}

const WithdrawModal = ({ isOpen, onClose, availableBalance, onConfirm }: WithdrawModalProps) => {
  const { user } = useAuth();
  const { requestWithdraw, isProcessing } = useSecureWithdraw();
  const [amount, setAmount] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [savedWalletAddress, setSavedWalletAddress] = useState<string | null>(null);
  const [status, setStatus] = useState<"input" | "processing" | "success" | "error">("input");
  const [errorMessage, setErrorMessage] = useState("");

  // Fetch user's saved wallet address
  useEffect(() => {
    const fetchWalletAddress = async () => {
      if (!user) return;
      const { data } = await supabase
        .from("profiles")
        .select("wallet_address")
        .eq("user_id", user.id)
        .single();
      
      if (data?.wallet_address) {
        setSavedWalletAddress(data.wallet_address);
        setWalletAddress(data.wallet_address);
      }
    };
    
    if (isOpen) {
      fetchWalletAddress();
    }
  }, [user, isOpen]);

  const handleWithdraw = async () => {
    const numAmount = parseFloat(amount);
    
    if (!walletAddress || walletAddress.length < 26) {
      setErrorMessage("Please enter a valid wallet address");
      setStatus("error");
      return;
    }

    if (numAmount <= 0 || numAmount > availableBalance) {
      setErrorMessage("Invalid amount");
      setStatus("error");
      return;
    }

    setStatus("processing");
    
    const result = await requestWithdraw(numAmount, walletAddress);
    
    if (result.success) {
      setStatus("success");
      setTimeout(() => {
        onConfirm?.(numAmount);
        resetForm();
        onClose();
      }, 2000);
    } else {
      setErrorMessage(result.error || "Withdrawal failed");
      setStatus("error");
    }
  };

  const resetForm = () => {
    setAmount("");
    setStatus("input");
    setErrorMessage("");
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  const numAmount = parseFloat(amount) || 0;
  const fee = numAmount * 0.02;
  const netAmount = numAmount - fee;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 animate-fade-up">
      <div className="bg-card rounded-t-[2rem] w-full max-w-md p-6 pb-10 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-extrabold text-foreground">💸 Withdraw</h2>
          <button 
            onClick={handleClose}
            className="p-3 rounded-full hover:bg-secondary transition-colors"
          >
            <X className="w-7 h-7 text-muted-foreground" />
          </button>
        </div>

        {status === "success" ? (
          /* Success State */
          <div className="flex flex-col items-center justify-center py-12 animate-scale-in">
            <div className="w-24 h-24 rounded-full bg-profit/10 flex items-center justify-center mb-4 animate-bounce-success">
              <CheckCircle className="w-16 h-16 text-profit" />
            </div>
            <h3 className="text-3xl font-extrabold text-profit">Requested! ✅</h3>
            <p className="text-muted-foreground mt-3 text-xl text-center">
              ${netAmount.toLocaleString()} will be sent soon
            </p>
            <p className="text-muted-foreground mt-2 text-base text-center">
              Pending admin approval
            </p>
          </div>
        ) : status === "processing" ? (
          /* Processing State */
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="w-16 h-16 text-crypto animate-spin mb-4" />
            <p className="text-xl text-muted-foreground">Processing...</p>
          </div>
        ) : (
          <>
            {/* Error Message */}
            {status === "error" && (
              <div className="bg-destructive/10 border border-destructive/30 rounded-2xl p-4 mb-4 flex items-center gap-3">
                <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0" />
                <p className="text-destructive font-medium">{errorMessage}</p>
              </div>
            )}

            {/* Available Balance Card - BIG */}
            <div className="bg-secondary rounded-2xl p-5 mb-6 text-center">
              <span className="text-muted-foreground text-lg uppercase font-bold block mb-2">
                Available Balance 🏦
              </span>
              <AnimatedNumber 
                value={availableBalance}
                className="text-5xl font-extrabold text-foreground"
                prefix="$"
              />
            </div>

            {/* Wallet Address Input */}
            <div className="mb-4">
              <label className="text-muted-foreground text-base mb-2 block uppercase font-bold flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Your Wallet Address
              </label>
              <Input
                type="text"
                placeholder="Enter USDT (TRC20) address"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                className="text-lg font-mono h-14 rounded-xl border-2"
              />
              {savedWalletAddress && (
                <p className="text-sm text-muted-foreground mt-2">
                  ✓ Using your saved wallet address
                </p>
              )}
            </div>

            {/* Amount Input - BIG */}
            <div className="mb-6">
              <label className="text-muted-foreground text-base mb-2 block uppercase font-bold">
                Enter Amount
              </label>
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setStatus("input");
                }}
                className="text-4xl font-extrabold h-20 text-center rounded-2xl border-2"
              />
              
              {/* Fee breakdown */}
              {numAmount > 0 && (
                <div className="mt-3 bg-secondary/50 rounded-xl p-3 space-y-1">
                  <div className="flex justify-between text-base">
                    <span className="text-muted-foreground">Fee (2%)</span>
                    <span className="text-muted-foreground">-${fee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold">
                    <span className="text-foreground">You'll Receive</span>
                    <span className="text-profit">${netAmount.toFixed(2)}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Withdraw Button - VERY BIG */}
            <Button
              variant="navy"
              size="xl"
              className="w-full h-20 text-2xl font-bold rounded-3xl"
              disabled={!amount || numAmount <= 0 || numAmount > availableBalance || !walletAddress || isProcessing}
              onClick={handleWithdraw}
            >
              {isProcessing ? (
                <Loader2 className="w-8 h-8 animate-spin" />
              ) : (
                <>
                  <ArrowDown className="w-8 h-8" />
                  <span>WITHDRAW</span>
                  <span className="text-3xl ml-2">💸</span>
                </>
              )}
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default WithdrawModal;
