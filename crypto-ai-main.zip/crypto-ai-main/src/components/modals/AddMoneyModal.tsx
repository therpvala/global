import { useState } from "react";
import { X, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

interface AddMoneyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (amount: number) => void;
}

const AddMoneyModal = ({ isOpen, onClose, onConfirm }: AddMoneyModalProps) => {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);

  const amounts = [100, 500, 1000];

  const getCurrentAmount = () => {
    if (customAmount) return parseFloat(customAmount);
    return selectedAmount;
  };

  const handlePayNow = () => {
    const amount = getCurrentAmount();
    if (amount && amount > 0) {
      setIsSuccess(true);
      setTimeout(() => {
        onConfirm(amount);
        setIsSuccess(false);
        setSelectedAmount(null);
        setCustomAmount("");
        onClose();
      }, 1500);
    }
  };

  const handleAmountSelect = (amount: number) => {
    setSelectedAmount(amount);
    setCustomAmount("");
  };

  const handleCustomChange = (value: string) => {
    setCustomAmount(value);
    setSelectedAmount(null);
  };

  if (!isOpen) return null;

  const currentAmount = getCurrentAmount();

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 animate-fade-up">
      <div className="bg-card rounded-t-[2rem] w-full max-w-md p-6 pb-10 animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-extrabold text-foreground">💳 Add Money</h2>
          <button 
            onClick={onClose}
            className="p-3 rounded-full hover:bg-secondary transition-colors"
          >
            <X className="w-7 h-7 text-muted-foreground" />
          </button>
        </div>

        {isSuccess ? (
          /* Success State */
          <div className="flex flex-col items-center justify-center py-12 animate-scale-in">
            <div className="w-24 h-24 rounded-full bg-profit/10 flex items-center justify-center mb-4 animate-bounce-success">
              <CheckCircle className="w-16 h-16 text-profit" />
            </div>
            <h3 className="text-3xl font-extrabold text-profit">Success! ✅</h3>
            <p className="text-muted-foreground mt-3 text-xl text-center">
              ${currentAmount?.toLocaleString()} added to your balance
            </p>
          </div>
        ) : (
          <>
            {/* Amount Selection - BIG BUTTONS */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              {amounts.map((amount) => (
                <button
                  key={amount}
                  onClick={() => handleAmountSelect(amount)}
                  className={cn(
                    "py-5 rounded-2xl text-2xl font-bold transition-all",
                    selectedAmount === amount 
                      ? "bg-primary text-primary-foreground scale-105" 
                      : "bg-secondary text-foreground hover:bg-secondary/80"
                  )}
                >
                  ${amount}
                </button>
              ))}
            </div>

            {/* Custom Amount Input */}
            <div className="mb-6">
              <label className="text-muted-foreground text-base mb-2 block uppercase font-bold">
                Or enter custom amount
              </label>
              <Input
                type="number"
                placeholder="Enter amount..."
                value={customAmount}
                onChange={(e) => handleCustomChange(e.target.value)}
                className="text-3xl font-bold h-16 text-center rounded-2xl border-2"
              />
            </div>

            {/* Selected Amount Display */}
            {currentAmount && currentAmount > 0 && (
              <div className="text-center mb-6 animate-fade-up bg-secondary rounded-2xl p-4">
                <span className="text-muted-foreground text-lg">You will add</span>
                <div className="text-5xl font-extrabold text-foreground mt-1">
                  ${currentAmount.toLocaleString()}
                </div>
              </div>
            )}

            {/* PAY Button - VERY BIG */}
            <Button
              variant="crypto"
              size="xl"
              className="w-full h-20 text-2xl font-bold rounded-3xl"
              disabled={!currentAmount || currentAmount <= 0}
              onClick={handlePayNow}
            >
              <span>PAY NOW</span>
              <span className="text-3xl ml-2">⚡</span>
            </Button>
          </>
        )}
      </div>
    </div>
  );
};

export default AddMoneyModal;
