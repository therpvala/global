import { Home, Users, Wallet, Settings, GitBranch } from "lucide-react";
import { cn } from "@/lib/utils";

type AdminTab = "overview" | "users" | "network" | "money" | "settings";

interface AdminBottomNavProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
}

const AdminBottomNav = ({ activeTab, onTabChange }: AdminBottomNavProps) => {
  const tabs = [
    { id: "overview" as const, label: "Overview", icon: Home },
    { id: "users" as const, label: "Users", icon: Users },
    { id: "network" as const, label: "Network", icon: GitBranch },
    { id: "money" as const, label: "Money", icon: Wallet },
    { id: "settings" as const, label: "Settings", icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 safe-area-bottom">
      <div className="flex items-center justify-around py-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all min-w-[60px]",
              activeTab === tab.id 
                ? "text-primary bg-primary/10" 
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <tab.icon className={cn(
              "w-5 h-5",
              activeTab === tab.id && "text-primary"
            )} />
            <span className="text-[10px] font-medium">{tab.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default AdminBottomNav;
