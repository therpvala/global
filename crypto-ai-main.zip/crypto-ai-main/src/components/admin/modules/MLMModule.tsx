import { useState, useEffect } from "react";
import { Network, Play, Pause, Settings, AlertCircle, Save, Plus, Trash2, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface GenerationRate {
  id: string;
  generation_level: number;
  percentage: number;
  is_active: boolean;
  min_team_size: number;
}

interface Commission {
  id: string;
  user_id: string;
  from_user_id: string | null;
  generation_level: number;
  amount: number;
  percentage: number;
  status: string;
  created_at: string;
}

interface CommissionStats {
  totalToday: number;
  totalAllTime: number;
  uniqueEarners: number;
  avgPerUser: number;
}

const MLMModule = () => {
  const [isPaused, setIsPaused] = useState(false);
  const [generationRates, setGenerationRates] = useState<GenerationRate[]>([]);
  const [commissions, setCommissions] = useState<Commission[]>([]);
  const [stats, setStats] = useState<CommissionStats>({
    totalToday: 0,
    totalAllTime: 0,
    uniqueEarners: 0,
    avgPerUser: 0,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editedRates, setEditedRates] = useState<GenerationRate[]>([]);
  const [mlmConfig, setMlmConfig] = useState({
    minDeposit: 100,
    commissionEnabled: true,
    instantPayout: true,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([
        fetchGenerationRates(),
        fetchCommissions(),
        fetchStats(),
        fetchMlmConfig(),
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchGenerationRates = async () => {
    const { data, error } = await supabase
      .from("generation_rates")
      .select("*")
      .order("generation_level", { ascending: true });

    if (error) {
      console.error("Error fetching rates:", error);
      toast.error("Failed to load generation rates");
    } else {
      setGenerationRates(data || []);
      setEditedRates(data || []);
    }
  };

  const fetchCommissions = async () => {
    const { data, error } = await supabase
      .from("commissions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) {
      console.error("Error fetching commissions:", error);
    } else {
      setCommissions(data || []);
    }
  };

  const fetchStats = async () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Get today's commissions
    const { data: todayData } = await supabase
      .from("commissions")
      .select("amount, user_id")
      .gte("created_at", today.toISOString())
      .eq("status", "completed");

    // Get all-time commissions
    const { data: allTimeData } = await supabase
      .from("commissions")
      .select("amount, user_id")
      .eq("status", "completed");

    const totalToday = todayData?.reduce((sum, c) => sum + Number(c.amount), 0) || 0;
    const totalAllTime = allTimeData?.reduce((sum, c) => sum + Number(c.amount), 0) || 0;
    const uniqueEarners = new Set(allTimeData?.map(c => c.user_id)).size;
    const avgPerUser = uniqueEarners > 0 ? totalAllTime / uniqueEarners : 0;

    setStats({
      totalToday,
      totalAllTime,
      uniqueEarners,
      avgPerUser,
    });
  };

  const fetchMlmConfig = async () => {
    const { data } = await supabase
      .from("mlm_config")
      .select("key, value");

    if (data) {
      const config: Record<string, string> = {};
      data.forEach(item => {
        config[item.key] = typeof item.value === 'string' ? item.value : JSON.stringify(item.value);
      });
      
      setMlmConfig({
        minDeposit: parseInt(config.min_deposit_for_commission || "100"),
        commissionEnabled: config.commission_enabled === "true",
        instantPayout: config.instant_payout === "true",
      });
      setIsPaused(config.commission_enabled !== "true");
    }
  };

  const handleSaveRates = async () => {
    try {
      for (const rate of editedRates) {
        const { error } = await supabase
          .from("generation_rates")
          .update({
            percentage: rate.percentage,
            is_active: rate.is_active,
            min_team_size: rate.min_team_size,
          })
          .eq("id", rate.id);

        if (error) throw error;
      }
      
      toast.success("Generation rates updated successfully");
      setIsEditing(false);
      fetchGenerationRates();
    } catch (error) {
      console.error("Error saving rates:", error);
      toast.error("Failed to save generation rates");
    }
  };

  const handleRateChange = (id: string, field: keyof GenerationRate, value: number | boolean) => {
    setEditedRates(rates =>
      rates.map(rate =>
        rate.id === id ? { ...rate, [field]: value } : rate
      )
    );
  };

  const handleTogglePause = async () => {
    const newValue = isPaused ? "true" : "false";
    
    const { error } = await supabase
      .from("mlm_config")
      .update({ value: newValue })
      .eq("key", "commission_enabled");

    if (error) {
      toast.error("Failed to update commission status");
    } else {
      setIsPaused(!isPaused);
      toast.success(isPaused ? "Commission payouts resumed" : "Commission payouts paused");
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (seconds < 60) return `${seconds}s ago`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
  };

  const truncateId = (id: string | null) => {
    if (!id) return "System";
    return `${id.slice(0, 6)}...${id.slice(-4)}`;
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">MLM Engine</h1>
          <p className="text-muted-foreground mt-1">Configure and monitor referral commissions</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" size="sm" onClick={fetchData} disabled={isLoading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${isPaused ? "bg-destructive/10" : "bg-profit/10"}`}>
            {isPaused ? (
              <Pause className="w-4 h-4 text-destructive" />
            ) : (
              <Play className="w-4 h-4 text-profit" />
            )}
            <span className={`text-sm font-medium ${isPaused ? "text-destructive" : "text-profit"}`}>
              {isPaused ? "Paused" : "Active"}
            </span>
          </div>
          <Button 
            variant={isPaused ? "crypto" : "destructive"} 
            size="sm"
            onClick={handleTogglePause}
          >
            {isPaused ? "Resume Payouts" : "Pause Payouts"}
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Today's Commissions</p>
          <p className="text-2xl font-bold text-profit mt-1">
            ${stats.totalToday.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-5">
          <p className="text-sm text-muted-foreground">All-Time Commissions</p>
          <p className="text-2xl font-bold text-foreground mt-1">
            ${stats.totalAllTime.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
        </div>
        <div className="bg-card rounded-xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Unique Earners</p>
          <p className="text-2xl font-bold text-foreground mt-1">{stats.uniqueEarners.toLocaleString()}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-5">
          <p className="text-sm text-muted-foreground">Avg Per User</p>
          <p className="text-2xl font-bold text-foreground mt-1">
            ${stats.avgPerUser.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
        </div>
      </div>

      {/* Configuration */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Commission Structure */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-foreground">Generation Rates</h3>
            {isEditing ? (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => {
                  setEditedRates(generationRates);
                  setIsEditing(false);
                }}>
                  Cancel
                </Button>
                <Button variant="crypto" size="sm" onClick={handleSaveRates}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            ) : (
              <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                <Settings className="w-4 h-4 mr-2" />
                Edit
              </Button>
            )}
          </div>
          
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {(isEditing ? editedRates : generationRates).map((rate) => (
              <div 
                key={rate.id} 
                className={`flex items-center justify-between p-3 rounded-lg transition-colors ${
                  rate.is_active ? "bg-secondary/50" : "bg-secondary/20 opacity-60"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{rate.generation_level}</span>
                  </div>
                  <span className="text-sm text-foreground">Level {rate.generation_level}</span>
                </div>
                
                {isEditing ? (
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        value={rate.percentage}
                        onChange={(e) => handleRateChange(rate.id, "percentage", parseFloat(e.target.value) || 0)}
                        className="w-20 h-8 text-right"
                        step="0.1"
                        min="0"
                        max="100"
                      />
                      <span className="text-sm text-muted-foreground">%</span>
                    </div>
                    <Switch
                      checked={rate.is_active}
                      onCheckedChange={(checked) => handleRateChange(rate.id, "is_active", checked)}
                    />
                  </div>
                ) : (
                  <div className="flex items-center gap-3">
                    <span className={`text-lg font-bold ${rate.is_active ? "text-crypto" : "text-muted-foreground"}`}>
                      {rate.percentage}%
                    </span>
                    {!rate.is_active && (
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">Disabled</span>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-4 p-3 bg-gold/5 border border-gold/20 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-gold mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground">
                  Total Levels: {generationRates.length}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Active levels: {generationRates.filter(r => r.is_active).length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Rules & Settings */}
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Rules & Settings</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Minimum Deposit</p>
                <p className="text-xs text-muted-foreground">Required to trigger commissions</p>
              </div>
              <span className="text-lg font-bold text-foreground">${mlmConfig.minDeposit}</span>
            </div>

            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Commission Distribution</p>
                <p className="text-xs text-muted-foreground">Enable/disable commission payouts</p>
              </div>
              <Switch checked={mlmConfig.commissionEnabled} disabled />
            </div>

            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Instant Payout</p>
                <p className="text-xs text-muted-foreground">Pay commissions immediately on deposit</p>
              </div>
              <Switch checked={mlmConfig.instantPayout} disabled />
            </div>

            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Auto-Distribution</p>
                <p className="text-xs text-muted-foreground">Triggered by deposit completion</p>
              </div>
              <Switch defaultChecked disabled />
            </div>
          </div>
        </div>
      </div>

      {/* Commission Distribution Reports */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Commission Distribution History</h3>
            <p className="text-sm text-muted-foreground mt-1">Recent commission payouts to upline users</p>
          </div>
          <span className="text-sm text-muted-foreground">{commissions.length} records</span>
        </div>
        
        {commissions.length === 0 ? (
          <div className="p-12 text-center">
            <Network className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No commission distributions yet</p>
            <p className="text-sm text-muted-foreground mt-1">
              Commissions will appear here when users make deposits
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-secondary/50">
                  <TableHead>Earner ID</TableHead>
                  <TableHead>From User</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {commissions.map((commission) => (
                  <TableRow key={commission.id} className="hover:bg-secondary/30 transition-colors">
                    <TableCell className="font-mono text-sm">{truncateId(commission.user_id)}</TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">
                      {truncateId(commission.from_user_id)}
                    </TableCell>
                    <TableCell>
                      <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-primary/10 text-xs font-bold text-primary">
                        L{commission.generation_level}
                      </span>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{commission.percentage}%</TableCell>
                    <TableCell className="font-semibold text-profit">
                      +${Number(commission.amount).toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                        commission.status === "completed" 
                          ? "bg-profit/10 text-profit" 
                          : commission.status === "pending"
                          ? "bg-gold/10 text-gold"
                          : "bg-destructive/10 text-destructive"
                      }`}>
                        {commission.status}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatTimeAgo(commission.created_at)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
};

export default MLMModule;
