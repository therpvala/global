import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  ArrowDownToLine,
  AlertTriangle,
  Activity
} from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  changeType?: "positive" | "negative" | "neutral";
  icon: React.ReactNode;
}

const StatCard = ({ title, value, change, changeType = "neutral", icon }: StatCardProps) => (
  <div className="bg-card rounded-xl border border-border p-5 hover:shadow-card transition-shadow">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-sm text-muted-foreground font-medium">{title}</p>
        <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
        {change && (
          <p className={`text-sm mt-1 font-medium ${
            changeType === "positive" ? "text-profit" : 
            changeType === "negative" ? "text-loss" : "text-muted-foreground"
          }`}>
            {change}
          </p>
        )}
      </div>
      <div className="p-3 rounded-xl bg-secondary">
        {icon}
      </div>
    </div>
  </div>
);

const OverviewModule = () => {
  const stats = [
    { 
      title: "Total Users", 
      value: "12,847", 
      change: "+324 this week",
      changeType: "positive" as const,
      icon: <Users className="w-5 h-5 text-primary" />
    },
    { 
      title: "Active Traders", 
      value: "8,432", 
      change: "65.6% of users",
      changeType: "neutral" as const,
      icon: <Activity className="w-5 h-5 text-crypto" />
    },
    { 
      title: "Total Volume (USDT)", 
      value: "$4.2M", 
      change: "+12.5% vs last week",
      changeType: "positive" as const,
      icon: <DollarSign className="w-5 h-5 text-gold" />
    },
    { 
      title: "Today Profit Distributed", 
      value: "$48,320", 
      change: "2.1% avg ROI",
      changeType: "positive" as const,
      icon: <TrendingUp className="w-5 h-5 text-profit" />
    },
    { 
      title: "Pending Withdrawals", 
      value: "$126,450", 
      change: "47 requests",
      changeType: "neutral" as const,
      icon: <ArrowDownToLine className="w-5 h-5 text-muted-foreground" />
    },
    { 
      title: "System Risk Level", 
      value: "Low", 
      change: "All systems normal",
      changeType: "positive" as const,
      icon: <AlertTriangle className="w-5 h-5 text-profit" />
    },
  ];

  const alerts = [
    { type: "warning", message: "AI anomaly detected in EURUSD pair - Under review", time: "2m ago" },
    { type: "info", message: "Withdrawal spike: 23 requests in last hour", time: "15m ago" },
    { type: "success", message: "Smart contract verified - All functions operational", time: "1h ago" },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">System Overview</h1>
        <p className="text-muted-foreground mt-1">Real-time platform health and metrics</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, index) => (
          <StatCard key={index} {...stat} />
        ))}
      </div>

      {/* Charts & Alerts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Capital vs Profit Chart Placeholder */}
        <div className="lg:col-span-2 bg-card rounded-xl border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Capital vs Profit</h3>
          <div className="h-64 flex items-center justify-center bg-secondary/50 rounded-lg">
            <div className="text-center">
              <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">Chart visualization</p>
              <p className="text-sm text-muted-foreground">Connect to backend for live data</p>
            </div>
          </div>
        </div>

        {/* Alerts Panel */}
        <div className="bg-card rounded-xl border border-border p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">System Alerts</h3>
          <div className="space-y-3">
            {alerts.map((alert, index) => (
              <div 
                key={index} 
                className={`p-3 rounded-lg border ${
                  alert.type === "warning" ? "bg-gold/5 border-gold/20" :
                  alert.type === "success" ? "bg-profit/5 border-profit/20" :
                  "bg-secondary border-border"
                }`}
              >
                <p className="text-sm text-foreground">{alert.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{alert.time}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="text-lg font-semibold text-foreground">Recent Transactions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">User</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Type</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Amount</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Status</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                { user: "0x7a3...f2b1", type: "Deposit", amount: "$5,000", status: "Completed", time: "2 min ago" },
                { user: "0x8c4...a3d2", type: "Withdrawal", amount: "$2,500", status: "Pending", time: "5 min ago" },
                { user: "0x9d5...b4e3", type: "Profit", amount: "+$125", status: "Distributed", time: "10 min ago" },
                { user: "0x1e6...c5f4", type: "Deposit", amount: "$1,000", status: "Completed", time: "15 min ago" },
                { user: "0x2f7...d6g5", type: "Commission", amount: "+$45", status: "Distributed", time: "20 min ago" },
              ].map((tx, index) => (
                <tr key={index} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-mono text-foreground">{tx.user}</td>
                  <td className="px-6 py-4">
                    <span className={`text-sm font-medium ${
                      tx.type === "Deposit" ? "text-crypto" :
                      tx.type === "Withdrawal" ? "text-primary" :
                      tx.type === "Profit" ? "text-profit" : "text-gold"
                    }`}>
                      {tx.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-semibold text-foreground">{tx.amount}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      tx.status === "Completed" || tx.status === "Distributed" 
                        ? "bg-profit/10 text-profit" 
                        : "bg-gold/10 text-gold"
                    }`}>
                      {tx.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{tx.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default OverviewModule;
