import { Settings, Bell, Globe, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";

const SettingsModule = () => {
  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">System Settings</h1>
        <p className="text-muted-foreground mt-1">Configure platform settings and limits</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General Settings */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-secondary">
              <Settings className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">General</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground">Platform Name</label>
              <Input defaultValue="CryptoAI Trading" className="mt-1" />
            </div>
            
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Maintenance Mode</p>
                <p className="text-xs text-muted-foreground">Disable user access temporarily</p>
              </div>
              <Switch />
            </div>
          </div>
        </div>

        {/* Limits */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-secondary">
              <Shield className="w-5 h-5 text-crypto" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Limits</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground">Max Deposit (USDT)</label>
              <Input type="number" defaultValue="100000" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">Max Withdrawal (USDT)</label>
              <Input type="number" defaultValue="50000" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">Daily Withdrawal Limit</label>
              <Input type="number" defaultValue="10000" className="mt-1" />
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-secondary">
              <Bell className="w-5 h-5 text-gold" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Notifications</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Email Notifications</p>
                <p className="text-xs text-muted-foreground">Send email alerts for critical events</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">SMS Alerts</p>
                <p className="text-xs text-muted-foreground">Send SMS for urgent notifications</p>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
              <div>
                <p className="text-sm font-medium text-foreground">Webhooks</p>
                <p className="text-xs text-muted-foreground">Trigger webhooks on events</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </div>

        {/* Regional */}
        <div className="bg-card rounded-xl border border-border p-6">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 rounded-lg bg-secondary">
              <Globe className="w-5 h-5 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Regional</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground">Default Timezone</label>
              <Input defaultValue="UTC" className="mt-1" />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">Currency Display</label>
              <Input defaultValue="USD" className="mt-1" />
            </div>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button variant="crypto" size="lg">
          Save Changes
        </Button>
      </div>
    </div>
  );
};

export default SettingsModule;
