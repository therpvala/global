import { useState } from "react";
import { Search, Filter, MoreVertical, UserCheck, UserX, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";

type UserRole = "super_admin" | "admin" | "partner" | "user";
type UserStatus = "active" | "frozen";

interface User {
  id: string;
  walletAddress: string;
  role: UserRole;
  status: UserStatus;
  joinedDate: string;
  totalDeposit: string;
  totalWithdrawn: string;
}

const mockUsers: User[] = [
  { id: "USR001", walletAddress: "0x7a3b...f2b1", role: "user", status: "active", joinedDate: "2024-01-15", totalDeposit: "$5,000", totalWithdrawn: "$1,200" },
  { id: "USR002", walletAddress: "0x8c4d...a3d2", role: "partner", status: "active", joinedDate: "2024-01-10", totalDeposit: "$25,000", totalWithdrawn: "$8,500" },
  { id: "USR003", walletAddress: "0x9d5e...b4e3", role: "user", status: "frozen", joinedDate: "2024-01-08", totalDeposit: "$2,000", totalWithdrawn: "$0" },
  { id: "USR004", walletAddress: "0x1e6f...c5f4", role: "admin", status: "active", joinedDate: "2023-12-20", totalDeposit: "$50,000", totalWithdrawn: "$15,000" },
  { id: "USR005", walletAddress: "0x2f7g...d6g5", role: "user", status: "active", joinedDate: "2024-01-18", totalDeposit: "$3,500", totalWithdrawn: "$500" },
];

const UsersModule = () => {
  const [activeTab, setActiveTab] = useState<UserRole | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const tabs = [
    { id: "all" as const, label: "All Users" },
    { id: "super_admin" as const, label: "Super Admin" },
    { id: "admin" as const, label: "Admin" },
    { id: "partner" as const, label: "Partner" },
    { id: "user" as const, label: "User" },
  ];

  const filteredUsers = mockUsers.filter(user => {
    const matchesTab = activeTab === "all" || user.role === activeTab;
    const matchesSearch = user.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         user.walletAddress.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case "super_admin": return "bg-destructive/10 text-destructive";
      case "admin": return "bg-primary/10 text-primary";
      case "partner": return "bg-gold/10 text-gold";
      default: return "bg-secondary text-muted-foreground";
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Users & Roles</h1>
          <p className="text-muted-foreground mt-1">Manage platform users and access levels</p>
        </div>
        <Button variant="default" size="sm">
          Export Users
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-border pb-4 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              activeTab === tab.id
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Search & Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by ID or wallet..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-secondary rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
        <Button variant="outline" size="sm">
          <Filter className="w-4 h-4 mr-2" />
          Filters
        </Button>
      </div>

      {/* Users Table */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">User ID</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Wallet Address</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Role</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Status</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Joined</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Total Deposit</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Withdrawn</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-foreground">{user.id}</td>
                  <td className="px-6 py-4 text-sm font-mono text-muted-foreground">{user.walletAddress}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize ${getRoleBadgeColor(user.role)}`}>
                      {user.role.replace("_", " ")}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      user.status === "active" ? "bg-profit/10 text-profit" : "bg-destructive/10 text-destructive"
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{user.joinedDate}</td>
                  <td className="px-6 py-4 text-sm font-semibold text-foreground">{user.totalDeposit}</td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{user.totalWithdrawn}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <button className="p-1.5 rounded-lg hover:bg-secondary transition-colors" title="View">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </button>
                      {user.status === "active" ? (
                        <button className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors" title="Freeze">
                          <UserX className="w-4 h-4 text-destructive" />
                        </button>
                      ) : (
                        <button className="p-1.5 rounded-lg hover:bg-profit/10 transition-colors" title="Unfreeze">
                          <UserCheck className="w-4 h-4 text-profit" />
                        </button>
                      )}
                      <button className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
                        <MoreVertical className="w-4 h-4 text-muted-foreground" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 border-t border-border flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {filteredUsers.length} of {mockUsers.length} users
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" disabled>Previous</Button>
            <Button variant="outline" size="sm">Next</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UsersModule;
