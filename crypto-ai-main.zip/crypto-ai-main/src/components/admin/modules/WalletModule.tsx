import { Wallet, ArrowUpRight, ArrowDownRight, RefreshCw, CheckCircle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const WalletModule = () => {
  const wallets = [
    { name: "User Wallets (Total)", balance: "$3,842,500", icon: Wallet, color: "text-primary" },
    { name: "Platform Reserve", balance: "$1,250,000", icon: Wallet, color: "text-crypto" },
    { name: "Fee Wallet", balance: "$89,420", icon: Wallet, color: "text-gold" },
  ];

  const pendingWithdrawals = [
    { id: "WD001", user: "0x7a3...f2b1", amount: "$5,000", requested: "10 min ago", status: "pending" },
    { id: "WD002", user: "0x8c4...a3d2", amount: "$2,500", requested: "25 min ago", status: "pending" },
    { id: "WD003", user: "0x9d5...b4e3", amount: "$10,000", requested: "1 hour ago", status: "review" },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Wallet & Finance</h1>
        <p className="text-muted-foreground mt-1">Manage platform wallets and transactions</p>
      </div>

      {/* Wallet Balances */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {wallets.map((wallet, index) => (
          <div key={index} className="bg-card rounded-xl border border-border p-5">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-secondary">
                <wallet.icon className={`w-5 h-5 ${wallet.color}`} />
              </div>
              <span className="text-sm text-muted-foreground">{wallet.name}</span>
            </div>
            <p className="text-2xl font-bold text-foreground">{wallet.balance}</p>
          </div>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 text-profit mb-2">
            <ArrowDownRight className="w-4 h-4" />
            <span className="text-sm">Today Deposits</span>
          </div>
          <p className="text-xl font-bold text-foreground">$125,400</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 text-loss mb-2">
            <ArrowUpRight className="w-4 h-4" />
            <span className="text-sm">Today Withdrawals</span>
          </div>
          <p className="text-xl font-bold text-foreground">$48,200</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 text-gold mb-2">
            <RefreshCw className="w-4 h-4" />
            <span className="text-sm">Internal Transfers</span>
          </div>
          <p className="text-xl font-bold text-foreground">$15,800</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <div className="flex items-center gap-2 text-primary mb-2">
            <Clock className="w-4 h-4" />
            <span className="text-sm">Pending Approvals</span>
          </div>
          <p className="text-xl font-bold text-foreground">47</p>
        </div>
      </div>

      {/* Pending Withdrawals */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">Pending Withdrawals</h3>
          <Button variant="outline" size="sm">View All</Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">ID</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">User</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Amount</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Requested</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Status</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {pendingWithdrawals.map((wd) => (
                <tr key={wd.id} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-foreground">{wd.id}</td>
                  <td className="px-6 py-4 text-sm font-mono text-muted-foreground">{wd.user}</td>
                  <td className="px-6 py-4 text-sm font-semibold text-foreground">{wd.amount}</td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{wd.requested}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      wd.status === "pending" ? "bg-gold/10 text-gold" : "bg-primary/10 text-primary"
                    }`}>
                      {wd.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <Button variant="crypto" size="sm" className="h-8">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Approve
                      </Button>
                      <Button variant="outline" size="sm" className="h-8">Reject</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WalletModule;
