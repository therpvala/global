import { useState } from "react";
import { Brain, Play, Pause, AlertTriangle, TrendingUp, TrendingDown, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const TradingAIModule = () => {
  const [isActive, setIsActive] = useState(true);

  const aiStatus = {
    strategyVersion: "v2.4.1",
    riskMode: "Conservative",
    lastUpdated: "2 hours ago",
  };

  const metrics = {
    capitalDeployed: "$2,450,000",
    openTrades: 12,
    winRate: 73.4,
    drawdown: 4.2,
    netProfit: "$148,320",
    todayProfit: "$12,450",
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Trading AI</h1>
          <p className="text-muted-foreground mt-1">Monitor and control AI trading operations</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="gold" size="sm">
            <Zap className="w-4 h-4 mr-2" />
            Push Profit to Blockchain
          </Button>
        </div>
      </div>

      {/* AI Status Card */}
      <div className="bg-card rounded-xl border border-border p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${isActive ? "bg-crypto/10" : "bg-destructive/10"}`}>
              <Brain className={`w-8 h-8 ${isActive ? "text-crypto" : "text-destructive"}`} />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h3 className="text-xl font-bold text-foreground">AI Trading Engine</h3>
                <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${
                  isActive ? "bg-profit/10 text-profit" : "bg-destructive/10 text-destructive"
                }`}>
                  {isActive ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                  {isActive ? "Active" : "Paused"}
                </span>
              </div>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <span>Strategy: {aiStatus.strategyVersion}</span>
                <span>•</span>
                <span>Risk: {aiStatus.riskMode}</span>
                <span>•</span>
                <span>Updated: {aiStatus.lastUpdated}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button 
              variant={isActive ? "destructive" : "crypto"} 
              onClick={() => setIsActive(!isActive)}
            >
              {isActive ? "Pause Trading" : "Resume Trading"}
            </Button>
            <Button variant="outline">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Emergency Exit
            </Button>
          </div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Capital Deployed</p>
          <p className="text-xl font-bold text-foreground mt-1">{metrics.capitalDeployed}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Open Trades</p>
          <p className="text-xl font-bold text-foreground mt-1">{metrics.openTrades}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Win Rate</p>
          <div className="flex items-center gap-2 mt-1">
            <TrendingUp className="w-4 h-4 text-profit" />
            <p className="text-xl font-bold text-profit">{metrics.winRate}%</p>
          </div>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Drawdown</p>
          <div className="flex items-center gap-2 mt-1">
            <TrendingDown className="w-4 h-4 text-loss" />
            <p className="text-xl font-bold text-loss">{metrics.drawdown}%</p>
          </div>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Net Profit</p>
          <p className="text-xl font-bold text-profit mt-1">{metrics.netProfit}</p>
        </div>
        <div className="bg-card rounded-xl border border-border p-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wide">Today's Profit</p>
          <p className="text-xl font-bold text-crypto mt-1">{metrics.todayProfit}</p>
        </div>
      </div>

      {/* Open Positions */}
      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-6 border-b border-border">
          <h3 className="text-lg font-semibold text-foreground">Open Positions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-secondary/50">
              <tr>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Pair</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Type</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Size</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Entry</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Current</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">P&L</th>
                <th className="text-left text-sm font-medium text-muted-foreground px-6 py-3">Duration</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {[
                { pair: "EUR/USD", type: "Long", size: "$50,000", entry: "1.0842", current: "1.0856", pnl: "+$280", duration: "2h 15m" },
                { pair: "GBP/USD", type: "Short", size: "$35,000", entry: "1.2654", current: "1.2641", pnl: "+$165", duration: "45m" },
                { pair: "BTC/USD", type: "Long", size: "$100,000", entry: "67,450", current: "67,320", pnl: "-$130", duration: "3h 20m" },
                { pair: "USD/JPY", type: "Long", size: "$45,000", entry: "154.32", current: "154.48", pnl: "+$72", duration: "1h 10m" },
              ].map((pos, index) => (
                <tr key={index} className="hover:bg-secondary/30 transition-colors">
                  <td className="px-6 py-4 text-sm font-semibold text-foreground">{pos.pair}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      pos.type === "Long" ? "bg-profit/10 text-profit" : "bg-loss/10 text-loss"
                    }`}>
                      {pos.type}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-foreground">{pos.size}</td>
                  <td className="px-6 py-4 text-sm font-mono text-muted-foreground">{pos.entry}</td>
                  <td className="px-6 py-4 text-sm font-mono text-foreground">{pos.current}</td>
                  <td className="px-6 py-4">
                    <span className={`text-sm font-semibold ${pos.pnl.startsWith("+") ? "text-profit" : "text-loss"}`}>
                      {pos.pnl}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-muted-foreground">{pos.duration}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TradingAIModule;
