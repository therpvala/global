 import { useEffect, useState, useCallback } from "react";
 import { supabase } from "@/integrations/supabase/client";
 import { 
   Users, 
   ChevronDown, 
   ChevronRight, 
   RefreshCw, 
   Search,
   User,
   DollarSign,
   Calendar
 } from "lucide-react";
 import { Button } from "@/components/ui/button";
 import { Input } from "@/components/ui/input";
 
 interface ReferralNode {
   id: string;
   user_id: string;
   full_name: string | null;
   email: string | null;
   referral_code: string;
   total_referrals: number;
   total_team_size: number;
   created_at: string;
   parent_id: string | null;
   children: ReferralNode[];
   total_deposited?: number;
   total_earned?: number;
   is_active?: boolean;
 }
 
interface TreeNodeProps {
  node: ReferralNode;
  level: number;
  expandedNodes: Set<string>;
  onToggle: (userId: string) => void;
  onSelectUser?: (userId: string) => void;
}
 
const TreeNode = ({ node, level, expandedNodes, onToggle, onSelectUser }: TreeNodeProps) => {
  const isExpanded = expandedNodes.has(node.user_id);
  const hasChildren = node.children && node.children.length > 0;
  const indent = level * 16;
 
  return (
    <div className="animate-fade-up">
      <div 
        className={`flex items-center gap-2 p-3 rounded-xl transition-all hover:bg-secondary/50 cursor-pointer ${
          level === 0 ? 'bg-primary/10 border border-primary/20' : ''
        }`}
        style={{ marginLeft: indent }}
        onClick={() => onSelectUser?.(node.user_id)}
      >
        {/* Expand/Collapse Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            hasChildren && onToggle(node.user_id);
          }}
          className={`w-8 h-8 flex items-center justify-center rounded-lg transition-colors ${
            hasChildren ? 'hover:bg-secondary cursor-pointer' : 'opacity-30'
          }`}
          disabled={!hasChildren}
        >
          {hasChildren ? (
            isExpanded ? (
              <ChevronDown className="w-5 h-5 text-primary" />
            ) : (
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            )
          ) : (
            <User className="w-4 h-4 text-muted-foreground" />
          )}
        </button>

        {/* User Avatar */}
        <div className={`w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold ${
          level === 0 ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground'
        }`}>
          {(node.full_name || node.email || '?')[0].toUpperCase()}
        </div>

        {/* User Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-semibold text-foreground truncate">
              {node.full_name || 'Unnamed User'}
            </p>
            {!node.is_active && (
              <span className="text-xs bg-destructive/20 text-destructive px-2 py-0.5 rounded">
                Inactive
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground truncate">
            {node.email || 'No email'}
          </p>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Users className="w-4 h-4" />
            <span className="font-medium">{node.total_referrals}</span>
          </div>
          {node.total_deposited !== undefined && (
            <div className="flex items-center gap-1 text-profit">
              <DollarSign className="w-4 h-4" />
              <span className="font-medium">{node.total_deposited.toLocaleString()}</span>
            </div>
          )}
        </div>

        {/* Level Badge */}
        <div className={`px-2 py-1 rounded-lg text-xs font-bold ${
          level === 0 
            ? 'bg-primary text-primary-foreground' 
            : 'bg-secondary text-muted-foreground'
        }`}>
          L{level}
        </div>
      </div>
 
      {/* Children */}
      {isExpanded && hasChildren && (
        <div className="border-l-2 border-border/50 ml-6">
          {node.children.map((child) => (
            <TreeNode
              key={child.user_id}
              node={child}
              level={level + 1}
              expandedNodes={expandedNodes}
              onToggle={onToggle}
              onSelectUser={onSelectUser}
            />
          ))}
        </div>
      )}
    </div>
  );
};

interface ReferralTreeScreenProps {
  onSelectUser?: (userId: string) => void;
}

const ReferralTreeScreen = ({ onSelectUser }: ReferralTreeScreenProps) => {
   const [rootNodes, setRootNodes] = useState<ReferralNode[]>([]);
   const [allNodes, setAllNodes] = useState<Map<string, ReferralNode>>(new Map());
   const [isLoading, setIsLoading] = useState(true);
   const [isRefreshing, setIsRefreshing] = useState(false);
   const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set());
   const [searchQuery, setSearchQuery] = useState("");
   const [stats, setStats] = useState({
     totalUsers: 0,
     totalDeposits: 0,
     activeUsers: 0,
   });
 
   const fetchReferralTree = useCallback(async (showRefresh = false) => {
     if (showRefresh) setIsRefreshing(true);
     
     try {
       // Fetch all referrals
       const { data: referrals, error: refError } = await supabase
         .from("referrals")
         .select("user_id, parent_id, referral_code, total_referrals, total_team_size, created_at")
         .order("created_at", { ascending: true });
 
       if (refError) throw refError;
 
       // Fetch all profiles
       const userIds = referrals?.map(r => r.user_id) || [];
       const { data: profiles } = await supabase
         .from("profiles")
         .select("user_id, full_name, email, is_active")
         .in("user_id", userIds.length > 0 ? userIds : ['']);
 
       // Fetch all wallets
       const { data: wallets } = await supabase
         .from("wallets")
         .select("user_id, total_deposited, total_earned")
         .in("user_id", userIds.length > 0 ? userIds : ['']);
 
       // Create lookup maps
       const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);
       const walletMap = new Map(wallets?.map(w => [w.user_id, w]) || []);
 
       // Build nodes
       const nodeMap = new Map<string, ReferralNode>();
       
       referrals?.forEach(ref => {
         const profile = profileMap.get(ref.user_id);
         const wallet = walletMap.get(ref.user_id);
         
         nodeMap.set(ref.user_id, {
           id: ref.user_id,
           user_id: ref.user_id,
           full_name: profile?.full_name || null,
           email: profile?.email || null,
           referral_code: ref.referral_code,
           total_referrals: ref.total_referrals || 0,
           total_team_size: ref.total_team_size || 0,
           created_at: ref.created_at,
           parent_id: ref.parent_id,
           children: [],
           total_deposited: Number(wallet?.total_deposited) || 0,
           total_earned: Number(wallet?.total_earned) || 0,
           is_active: profile?.is_active ?? true,
         });
       });
 
       // Build tree structure
       const roots: ReferralNode[] = [];
       
       nodeMap.forEach(node => {
         if (node.parent_id && nodeMap.has(node.parent_id)) {
           const parent = nodeMap.get(node.parent_id)!;
           parent.children.push(node);
         } else {
           roots.push(node);
         }
       });
 
       // Sort children by referral count
       const sortChildren = (node: ReferralNode) => {
         node.children.sort((a, b) => b.total_referrals - a.total_referrals);
         node.children.forEach(sortChildren);
       };
       roots.forEach(sortChildren);
 
       // Calculate stats
       let totalDeposits = 0;
       let activeUsers = 0;
       nodeMap.forEach(node => {
         totalDeposits += node.total_deposited || 0;
         if (node.is_active) activeUsers++;
       });
 
       setRootNodes(roots);
       setAllNodes(nodeMap);
       setStats({
         totalUsers: nodeMap.size,
         totalDeposits,
         activeUsers,
       });
 
       // Auto-expand first level
       if (roots.length > 0 && expandedNodes.size === 0) {
         setExpandedNodes(new Set(roots.map(r => r.user_id)));
       }
     } catch (error) {
       console.error("Error fetching referral tree:", error);
     } finally {
       setIsLoading(false);
       setIsRefreshing(false);
     }
   }, []);
 
   useEffect(() => {
     fetchReferralTree();
   }, [fetchReferralTree]);
 
   const handleToggle = (userId: string) => {
     setExpandedNodes(prev => {
       const next = new Set(prev);
       if (next.has(userId)) {
         next.delete(userId);
       } else {
         next.add(userId);
       }
       return next;
     });
   };
 
   const expandAll = () => {
     const all = new Set<string>();
     allNodes.forEach((_, key) => all.add(key));
     setExpandedNodes(all);
   };
 
   const collapseAll = () => {
     setExpandedNodes(new Set());
   };
 
   // Filter nodes based on search
   const filteredRoots = searchQuery
     ? rootNodes.filter(node => {
         const searchLower = searchQuery.toLowerCase();
         const matchesNode = (n: ReferralNode): boolean => {
           const matches = 
             n.full_name?.toLowerCase().includes(searchLower) ||
             n.email?.toLowerCase().includes(searchLower) ||
             n.referral_code.toLowerCase().includes(searchLower);
           if (matches) return true;
           return n.children.some(matchesNode);
         };
         return matchesNode(node);
       })
     : rootNodes;
 
   if (isLoading) {
     return (
       <div className="flex items-center justify-center min-h-[60vh]">
         <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
       </div>
     );
   }
 
   return (
     <div className="p-4 pb-24 space-y-4">
       {/* Header */}
       <div className="flex items-center justify-between pt-2">
         <div>
           <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
             <Users className="w-6 h-6 text-primary" />
             Referral Network
           </h1>
           <p className="text-muted-foreground text-sm mt-1">MLM hierarchy visualization</p>
         </div>
         <Button
           variant="outline"
           size="icon"
           onClick={() => fetchReferralTree(true)}
           disabled={isRefreshing}
         >
           <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
         </Button>
       </div>
 
       {/* Stats Cards */}
       <div className="grid grid-cols-3 gap-3">
         <div className="bg-card rounded-xl border border-border p-3 text-center">
           <p className="text-2xl font-bold text-foreground">{stats.totalUsers}</p>
           <p className="text-xs text-muted-foreground">Total Users</p>
         </div>
         <div className="bg-card rounded-xl border border-border p-3 text-center">
           <p className="text-2xl font-bold text-profit">${stats.totalDeposits.toLocaleString()}</p>
           <p className="text-xs text-muted-foreground">Total Deposits</p>
         </div>
         <div className="bg-card rounded-xl border border-border p-3 text-center">
           <p className="text-2xl font-bold text-crypto">{stats.activeUsers}</p>
           <p className="text-xs text-muted-foreground">Active Users</p>
         </div>
       </div>
 
       {/* Search & Controls */}
       <div className="flex gap-2">
         <div className="relative flex-1">
           <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
           <Input
             placeholder="Search by name, email, or code..."
             value={searchQuery}
             onChange={(e) => setSearchQuery(e.target.value)}
             className="pl-10"
           />
         </div>
         <Button variant="outline" size="sm" onClick={expandAll}>
           Expand
         </Button>
         <Button variant="outline" size="sm" onClick={collapseAll}>
           Collapse
         </Button>
       </div>
 
       {/* Tree View */}
       <div className="bg-card rounded-2xl border border-border p-4 min-h-[300px]">
         {filteredRoots.length === 0 ? (
           <div className="flex flex-col items-center justify-center py-12 text-center">
             <Users className="w-16 h-16 text-muted-foreground/30 mb-4" />
             <p className="text-lg font-medium text-muted-foreground">
               {searchQuery ? "No users match your search" : "No referral data yet"}
             </p>
             <p className="text-sm text-muted-foreground mt-1">
               {searchQuery ? "Try a different search term" : "Users will appear here once they register"}
             </p>
           </div>
         ) : (
            <div className="space-y-1">
              {filteredRoots.map((node) => (
                <TreeNode
                  key={node.user_id}
                  node={node}
                  level={0}
                  expandedNodes={expandedNodes}
                  onToggle={handleToggle}
                  onSelectUser={onSelectUser}
                />
              ))}
            </div>
         )}
       </div>
 
       {/* Legend */}
       <div className="bg-secondary/30 rounded-xl p-3">
         <p className="text-xs text-muted-foreground mb-2 font-medium">Legend</p>
         <div className="flex flex-wrap gap-4 text-xs">
           <div className="flex items-center gap-1">
             <Users className="w-3 h-3" />
             <span>Direct Referrals</span>
           </div>
           <div className="flex items-center gap-1">
             <DollarSign className="w-3 h-3 text-profit" />
             <span>Total Deposited</span>
           </div>
           <div className="flex items-center gap-1">
             <div className="w-4 h-4 rounded bg-primary text-[8px] text-primary-foreground flex items-center justify-center font-bold">L0</div>
             <span>Generation Level</span>
           </div>
         </div>
       </div>
     </div>
   );
 };
 
 export default ReferralTreeScreen;