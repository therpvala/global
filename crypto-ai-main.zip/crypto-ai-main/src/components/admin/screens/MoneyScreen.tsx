import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Clock, CheckCircle, XCircle, RefreshCw, Copy, Plus, Search, DollarSign, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface Withdrawal {
  id: string;
  user_id: string;
  amount: number;
  fee: number;
  net_amount: number;
  wallet_address: string;
  status: string;
  created_at: string;
  user_name?: string;
  user_email?: string;
}

interface UserProfile {
  user_id: string;
  full_name: string | null;
  email: string | null;
}

const MoneyScreen = () => {
  const { user: adminUser, session } = useAuth();
  const [pendingWithdrawals, setPendingWithdrawals] = useState<Withdrawal[]>([]);
  const [approvedWithdrawals, setApprovedWithdrawals] = useState<Withdrawal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeTab, setActiveTab] = useState<"pending" | "approved" | "deposit">("pending");
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [txHashInputs, setTxHashInputs] = useState<Record<string, string>>({});
  const [rejectReasons, setRejectReasons] = useState<Record<string, string>>({});
  
  // Deposit state
  const [showDepositDialog, setShowDepositDialog] = useState(false);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [userSearchQuery, setUserSearchQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [depositAmount, setDepositAmount] = useState("");
  const [depositTxHash, setDepositTxHash] = useState("");
  const [isProcessingDeposit, setIsProcessingDeposit] = useState(false);

  useEffect(() => {
    fetchWithdrawals();
    fetchUsers();
    
    // Set up realtime subscription
    const channel = supabase
      .channel('withdrawals-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'withdrawals' },
        () => {
          fetchWithdrawals();
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchWithdrawals = async (showRefresh = false) => {
    if (showRefresh) setIsRefreshing(true);
    
    try {
      // Fetch pending withdrawals
      const { data: pending } = await supabase
        .from("withdrawals")
        .select("id, user_id, amount, fee, net_amount, wallet_address, status, created_at")
        .eq("status", "pending")
        .order("created_at", { ascending: false });

      // Fetch approved/completed withdrawals
      const { data: approved } = await supabase
        .from("withdrawals")
        .select("id, user_id, amount, fee, net_amount, wallet_address, status, created_at")
        .in("status", ["approved", "completed"])
        .order("created_at", { ascending: false })
        .limit(50);

      // Get user profiles for names
      const userIds = [...new Set([
        ...(pending?.map(w => w.user_id) || []),
        ...(approved?.map(w => w.user_id) || [])
      ])];

      let profileMap = new Map<string, { name: string | null; email: string | null }>();
      
      if (userIds.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("user_id, full_name, email")
          .in("user_id", userIds);

        profileMap = new Map(
          profiles?.map(p => [p.user_id, { name: p.full_name, email: p.email }]) || []
        );
      }

      const enrichWithProfile = (withdrawal: any) => ({
        ...withdrawal,
        user_name: profileMap.get(withdrawal.user_id)?.name,
        user_email: profileMap.get(withdrawal.user_id)?.email,
      });

      setPendingWithdrawals(pending?.map(enrichWithProfile) || []);
      setApprovedWithdrawals(approved?.map(enrichWithProfile) || []);
    } catch (error) {
      console.error("Error fetching withdrawals:", error);
      toast.error("Failed to load withdrawals");
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const fetchUsers = async () => {
    try {
      const { data } = await supabase
        .from("profiles")
        .select("user_id, full_name, email")
        .order("full_name", { ascending: true });
      
      setUsers(data || []);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleProcessDeposit = async () => {
    if (!selectedUser || !depositAmount || !session?.access_token) {
      toast.error("Please select a user and enter an amount");
      return;
    }

    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid positive amount");
      return;
    }

    setIsProcessingDeposit(true);

    try {
      const { data, error } = await supabase.functions.invoke("process-deposit", {
        body: {
          user_id: selectedUser.user_id,
          amount,
          tx_hash: depositTxHash || undefined,
          description: `Manual deposit by admin`,
        },
      });

      if (error) {
        console.error("Deposit error:", error);
        toast.error(error.message || "Failed to process deposit");
        return;
      }

      if (data?.success) {
        toast.success("Deposit processed successfully! 🎉", {
          description: `$${amount.toLocaleString()} added to ${selectedUser.full_name || selectedUser.email}`,
        });
        
        // Reset form
        setShowDepositDialog(false);
        setSelectedUser(null);
        setDepositAmount("");
        setDepositTxHash("");
        setUserSearchQuery("");
      } else {
        toast.error(data?.error || "Failed to process deposit");
      }
    } catch (error) {
      console.error("Deposit error:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsProcessingDeposit(false);
    }
  };

  const filteredUsers = users.filter(user => {
    const query = userSearchQuery.toLowerCase();
    return (
      user.full_name?.toLowerCase().includes(query) ||
      user.email?.toLowerCase().includes(query)
    );
  });

  const handleApprove = async (withdrawal: Withdrawal, txHash?: string) => {
    setProcessingId(withdrawal.id);
    try {
      // Update withdrawal status with optional tx_hash
      const { error } = await supabase
        .from("withdrawals")
        .update({ 
          status: "completed",
          processed_at: new Date().toISOString(),
          processed_by: adminUser?.id,
          tx_hash: txHash || null,
        })
        .eq("id", withdrawal.id);

      if (error) throw error;

      // Update user's wallet - reduce locked balance, increase total_withdrawn
      const { data: wallet } = await supabase
        .from("wallets")
        .select("id, locked_balance, total_withdrawn")
        .eq("user_id", withdrawal.user_id)
        .single();

      if (wallet) {
        await supabase
          .from("wallets")
          .update({
            locked_balance: Math.max(0, (Number(wallet.locked_balance) || 0) - Number(withdrawal.amount)),
            total_withdrawn: (Number(wallet.total_withdrawn) || 0) + Number(withdrawal.net_amount),
          })
          .eq("id", wallet.id);
      }

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: "approved_withdrawal",
        reference_id: withdrawal.id,
      });

      toast.success("Withdrawal approved", {
        description: `$${Number(withdrawal.net_amount).toLocaleString()} sent to user`,
      });
      
      // Clear the tx hash input
      setTxHashInputs(prev => {
        const updated = { ...prev };
        delete updated[withdrawal.id];
        return updated;
      });
      
      await fetchWithdrawals();
    } catch (error) {
      console.error("Error approving withdrawal:", error);
      toast.error("Failed to approve withdrawal");
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (withdrawal: Withdrawal, reason?: string) => {
    setProcessingId(withdrawal.id);
    try {
      // Get the user's wallet to refund
      const { data: wallet } = await supabase
        .from("wallets")
        .select("id, available_balance, locked_balance")
        .eq("user_id", withdrawal.user_id)
        .single();

      if (wallet) {
        // Refund the amount back to available balance
        await supabase
          .from("wallets")
          .update({ 
            available_balance: (wallet.available_balance || 0) + withdrawal.amount,
            locked_balance: Math.max(0, (wallet.locked_balance || 0) - withdrawal.amount)
          })
          .eq("id", wallet.id);
      }

      // Update withdrawal status
      const { error } = await supabase
        .from("withdrawals")
        .update({ 
          status: "rejected",
          processed_at: new Date().toISOString(),
          processed_by: adminUser?.id,
          rejection_reason: reason || "Rejected by admin",
        })
        .eq("id", withdrawal.id);

      if (error) throw error;

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: "rejected_withdrawal",
        reference_id: withdrawal.id,
      });

      toast.success("Withdrawal rejected & refunded", {
        description: `$${Number(withdrawal.amount).toLocaleString()} returned to user`,
      });
      
      // Clear the reject reason input
      setRejectReasons(prev => {
        const updated = { ...prev };
        delete updated[withdrawal.id];
        return updated;
      });
      
      await fetchWithdrawals();
    } catch (error) {
      console.error("Error rejecting withdrawal:", error);
      toast.error("Failed to reject withdrawal");
    } finally {
      setProcessingId(null);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard");
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24 space-y-4">
      {/* Header */}
      <div className="pt-2 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Money Control</h1>
          <p className="text-muted-foreground text-sm mt-1">Manage deposits & withdrawals</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="crypto"
            size="sm"
            onClick={() => setShowDepositDialog(true)}
          >
            <Plus className="w-4 h-4 mr-1" />
            Deposit
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={() => fetchWithdrawals(true)}
            disabled={isRefreshing}
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-secondary/50 p-1 rounded-xl">
        <button
          onClick={() => setActiveTab("deposit")}
          className={`flex-1 py-3 rounded-lg font-medium text-sm transition-all ${
            activeTab === "deposit"
              ? "bg-profit text-white shadow-sm"
              : "text-muted-foreground"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <DollarSign className="w-4 h-4" />
            Deposit
          </div>
        </button>
        <button
          onClick={() => setActiveTab("pending")}
          className={`flex-1 py-3 rounded-lg font-medium text-sm transition-all ${
            activeTab === "pending"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <Clock className="w-4 h-4" />
            Pending ({pendingWithdrawals.length})
          </div>
        </button>
        <button
          onClick={() => setActiveTab("approved")}
          className={`flex-1 py-3 rounded-lg font-medium text-sm transition-all ${
            activeTab === "approved"
              ? "bg-card text-foreground shadow-sm"
              : "text-muted-foreground"
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <CheckCircle className="w-4 h-4" />
            Done
          </div>
        </button>
      </div>

      {/* Deposit Tab */}
      {activeTab === "deposit" && (
        <div className="space-y-4">
          <div className="bg-card rounded-2xl border border-border p-5 text-center">
            <DollarSign className="w-12 h-12 text-profit mx-auto mb-3" />
            <h3 className="text-xl font-bold text-foreground mb-2">Process Deposit</h3>
            <p className="text-muted-foreground mb-4">
              Add funds to user wallets and trigger MLM commissions
            </p>
            <Button
              variant="crypto"
              size="lg"
              className="w-full h-14"
              onClick={() => setShowDepositDialog(true)}
            >
              <Plus className="w-5 h-5 mr-2" />
              Add New Deposit
            </Button>
          </div>
          
          <div className="bg-secondary/30 rounded-xl p-4">
            <h4 className="font-medium text-foreground mb-2">How it works:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Select a user and enter the USDT amount</li>
              <li>• The deposit is added to their available balance</li>
              <li>• MLM commissions are automatically distributed to uplines</li>
              <li>• Commission rates follow the configured generation levels</li>
            </ul>
          </div>
        </div>
      )}

      {/* Pending Withdrawals */}
      {activeTab === "pending" && (
        <div className="space-y-3">
          {pendingWithdrawals.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-muted-foreground">No pending withdrawals</p>
            </div>
          ) : (
            pendingWithdrawals.map((withdrawal) => (
              <div 
                key={withdrawal.id}
                className="bg-card rounded-2xl border border-border p-4 space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-semibold text-foreground">
                      {withdrawal.user_name || "Unknown"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(withdrawal.created_at)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-foreground">
                      ${Number(withdrawal.amount).toLocaleString()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Fee: ${Number(withdrawal.fee || 0).toFixed(2)}
                    </p>
                  </div>
                </div>
                
                <div className="bg-secondary/50 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-muted-foreground">Wallet Address</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 px-2"
                      onClick={() => copyToClipboard(withdrawal.wallet_address)}
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy
                    </Button>
                  </div>
                  <p className="font-mono text-sm text-foreground break-all">{withdrawal.wallet_address}</p>
                  <div className="flex justify-between items-center pt-2 border-t border-border/50">
                    <span className="text-sm text-muted-foreground">Net to send:</span>
                    <span className="text-lg font-bold text-profit">${Number(withdrawal.net_amount).toFixed(2)}</span>
                  </div>
                </div>

                {/* TX Hash Input */}
                <div>
                  <Input
                    placeholder="Transaction hash (optional)"
                    value={txHashInputs[withdrawal.id] || ""}
                    onChange={(e) => setTxHashInputs(prev => ({ ...prev, [withdrawal.id]: e.target.value }))}
                    className="font-mono text-sm h-10"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleApprove(withdrawal, txHashInputs[withdrawal.id])}
                    disabled={processingId === withdrawal.id}
                    className="flex-1 h-12 rounded-xl"
                    variant="crypto"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    onClick={() => handleReject(withdrawal, rejectReasons[withdrawal.id])}
                    disabled={processingId === withdrawal.id}
                    className="flex-1 h-12 rounded-xl"
                    variant="outline"
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Approved Withdrawals */}
      {activeTab === "approved" && (
        <div className="space-y-3">
          {approvedWithdrawals.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
              <p className="text-muted-foreground">No approved withdrawals yet</p>
            </div>
          ) : (
            approvedWithdrawals.map((withdrawal) => (
              <div 
                key={withdrawal.id}
                className="bg-card rounded-2xl border border-border p-4"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">
                      {withdrawal.user_name || "Unknown"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(withdrawal.created_at)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-foreground">
                      ${Number(withdrawal.amount).toLocaleString()}
                    </p>
                    <span className="text-xs text-profit">Completed</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Deposit Dialog */}
      <Dialog open={showDepositDialog} onOpenChange={setShowDepositDialog}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Process New Deposit</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* User Search */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Select User</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name or email..."
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              {/* User List */}
              {userSearchQuery && (
                <div className="max-h-40 overflow-y-auto border border-border rounded-lg divide-y divide-border">
                  {filteredUsers.slice(0, 5).map((user) => (
                    <button
                      key={user.user_id}
                      onClick={() => {
                        setSelectedUser(user);
                        setUserSearchQuery("");
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-secondary transition-colors"
                    >
                      <p className="font-medium text-foreground truncate">
                        {user.full_name || "No Name"}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">
                        {user.email}
                      </p>
                    </button>
                  ))}
                  {filteredUsers.length === 0 && (
                    <p className="px-3 py-2 text-sm text-muted-foreground">No users found</p>
                  )}
                </div>
              )}
              
              {/* Selected User */}
              {selectedUser && !userSearchQuery && (
                <div className="bg-secondary rounded-lg p-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">
                      {selectedUser.full_name || "No Name"}
                    </p>
                    <p className="text-xs text-muted-foreground">{selectedUser.email}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedUser(null)}
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Amount (USDT)</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="number"
                  placeholder="Enter deposit amount"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="pl-10 text-lg font-semibold"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>

            {/* TX Hash Input */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Transaction Hash <span className="text-muted-foreground">(Optional)</span>
              </label>
              <Input
                placeholder="Enter blockchain tx hash..."
                value={depositTxHash}
                onChange={(e) => setDepositTxHash(e.target.value)}
                className="font-mono text-sm"
              />
            </div>

            {/* Summary */}
            {selectedUser && depositAmount && parseFloat(depositAmount) > 0 && (
              <div className="bg-profit/10 rounded-lg p-4 border border-profit/20">
                <p className="text-sm text-muted-foreground">Deposit Summary</p>
                <p className="text-2xl font-bold text-profit mt-1">
                  +${parseFloat(depositAmount).toLocaleString()}
                </p>
                <p className="text-sm text-muted-foreground mt-1">
                  To: {selectedUser.full_name || selectedUser.email}
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDepositDialog(false)}>
              Cancel
            </Button>
            <Button
              variant="crypto"
              onClick={handleProcessDeposit}
              disabled={!selectedUser || !depositAmount || isProcessingDeposit}
            >
              {isProcessingDeposit ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Process Deposit
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MoneyScreen;
