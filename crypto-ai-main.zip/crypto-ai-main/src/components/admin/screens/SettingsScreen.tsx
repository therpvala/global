import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Settings, DollarSign, Clock, Power } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface PlatformSettings {
  min_withdraw_amount: string;
  max_withdraw_per_day: string;
  wallet_change_cooldown: string;
  platform_status: string;
}

const SettingsScreen = () => {
  const { user: adminUser } = useAuth();
  const [settings, setSettings] = useState<PlatformSettings>({
    min_withdraw_amount: "10",
    max_withdraw_per_day: "10000",
    wallet_change_cooldown: "7",
    platform_status: "active",
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from("platform_settings")
        .select("key, value");

      if (error) throw error;

      const settingsMap: Record<string, string> = {};
      data?.forEach(s => {
        settingsMap[s.key] = s.value;
      });

      setSettings({
        min_withdraw_amount: settingsMap.min_withdraw_amount || "10",
        max_withdraw_per_day: settingsMap.max_withdraw_per_day || "10000",
        wallet_change_cooldown: settingsMap.wallet_change_cooldown || "7",
        platform_status: settingsMap.platform_status || "active",
      });
    } catch (error) {
      console.error("Error fetching settings:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const settingsToSave = Object.entries(settings).map(([key, value]) => ({
        key,
        value,
        updated_by: adminUser?.id,
        updated_at: new Date().toISOString(),
      }));

      for (const setting of settingsToSave) {
        await supabase
          .from("platform_settings")
          .upsert(setting, { onConflict: "key" });
      }

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: "updated_settings",
        reference_id: JSON.stringify(settings),
      });

      toast.success("Settings saved successfully");
    } catch (error) {
      console.error("Error saving settings:", error);
      toast.error("Failed to save settings");
    } finally {
      setIsSaving(false);
    }
  };

  const handleTogglePlatform = () => {
    setSettings(prev => ({
      ...prev,
      platform_status: prev.platform_status === "active" ? "maintenance" : "active"
    }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24 space-y-6">
      {/* Header */}
      <div className="pt-2">
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground text-sm mt-1">Platform configuration</p>
      </div>

      {/* Platform Status */}
      <div className="bg-card rounded-2xl border border-border p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`p-2.5 rounded-xl ${
              settings.platform_status === "active" 
                ? "bg-profit/10 text-profit" 
                : "bg-loss/10 text-loss"
            }`}>
              <Power className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-foreground">Platform Status</p>
              <p className="text-sm text-muted-foreground">
                {settings.platform_status === "active" ? "Platform is live" : "Maintenance mode"}
              </p>
            </div>
          </div>
          <Switch
            checked={settings.platform_status === "active"}
            onCheckedChange={handleTogglePlatform}
          />
        </div>
      </div>

      {/* Withdrawal Settings */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-muted-foreground">
          <DollarSign className="w-4 h-4" />
          <span className="text-sm font-medium">Withdrawal Limits</span>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              Minimum Withdraw Amount (USDT)
            </label>
            <Input
              type="number"
              value={settings.min_withdraw_amount}
              onChange={(e) => setSettings(prev => ({ ...prev, min_withdraw_amount: e.target.value }))}
              className="h-12 rounded-xl text-lg"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">
              Maximum Withdraw Per Day (USDT)
            </label>
            <Input
              type="number"
              value={settings.max_withdraw_per_day}
              onChange={(e) => setSettings(prev => ({ ...prev, max_withdraw_per_day: e.target.value }))}
              className="h-12 rounded-xl text-lg"
            />
          </div>
        </div>
      </div>

      {/* Cooldown Settings */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Clock className="w-4 h-4" />
          <span className="text-sm font-medium">Cooldown Settings</span>
        </div>

        <div className="bg-card rounded-2xl border border-border p-5">
          <label className="text-sm text-muted-foreground mb-2 block">
            Wallet Change Cooldown (Days)
          </label>
          <Input
            type="number"
            value={settings.wallet_change_cooldown}
            onChange={(e) => setSettings(prev => ({ ...prev, wallet_change_cooldown: e.target.value }))}
            className="h-12 rounded-xl text-lg"
          />
          <p className="text-xs text-muted-foreground mt-2">
            Users must wait this many days after changing wallet before withdrawing
          </p>
        </div>
      </div>

      {/* Save Button */}
      <div className="pt-4">
        <Button 
          onClick={handleSave}
          disabled={isSaving}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="crypto"
        >
          <Settings className="w-5 h-5 mr-2" />
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
};

export default SettingsScreen;
