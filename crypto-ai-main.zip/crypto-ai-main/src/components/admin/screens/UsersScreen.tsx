import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ChevronRight, Search, UserCheck, UserX } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface UserProfile {
  id: string;
  user_id: string;
  full_name: string | null;
  email: string | null;
  is_active: boolean;
  wallet_balance: number;
}

interface UsersScreenProps {
  onSelectUser: (userId: string) => void;
}

const UsersScreen = ({ onSelectUser }: UsersScreenProps) => {
  const { user: adminUser } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      // Fetch profiles with their wallet balances
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("id, user_id, full_name, email, is_active")
        .order("created_at", { ascending: false });

      if (error) throw error;

      // Fetch wallets for all users
      const { data: wallets } = await supabase
        .from("wallets")
        .select("user_id, available_balance");

      const walletMap = new Map(
        wallets?.map(w => [w.user_id, Number(w.available_balance) || 0]) || []
      );

      const usersWithBalance = profiles?.map(p => ({
        ...p,
        wallet_balance: walletMap.get(p.user_id) || 0,
      })) || [];

      setUsers(usersWithBalance);
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Failed to load users");
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from("profiles")
        .update({ is_active: !currentStatus })
        .eq("user_id", userId);

      if (error) throw error;

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: currentStatus ? "blocked_user" : "unblocked_user",
        reference_id: userId,
      });

      toast.success(currentStatus ? "User blocked" : "User unblocked");
      fetchUsers();
    } catch (error) {
      console.error("Error updating user status:", error);
      toast.error("Failed to update user status");
    }
  };

  const filteredUsers = users.filter(user => {
    const query = searchQuery.toLowerCase();
    return (
      user.full_name?.toLowerCase().includes(query) ||
      user.email?.toLowerCase().includes(query)
    );
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24 space-y-4">
      {/* Header */}
      <div className="pt-2">
        <h1 className="text-2xl font-bold text-foreground">Users</h1>
        <p className="text-muted-foreground text-sm mt-1">
          {users.length} total users
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          placeholder="Search users..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 h-12 rounded-xl"
        />
      </div>

      {/* User List */}
      <div className="space-y-3">
        {filteredUsers.map((user) => (
          <div
            key={user.id}
            className="bg-card rounded-2xl border border-border p-4"
          >
            <div className="flex items-center justify-between">
              <div className="flex-1 min-w-0" onClick={() => onSelectUser(user.user_id)}>
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-foreground truncate">
                    {user.full_name || "No Name"}
                  </p>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                    user.is_active 
                      ? "bg-profit/10 text-profit" 
                      : "bg-loss/10 text-loss"
                  }`}>
                    {user.is_active ? "Active" : "Blocked"}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground truncate mt-0.5">
                  {user.email}
                </p>
                <p className="text-lg font-bold text-primary mt-1">
                  ${user.wallet_balance.toLocaleString()}
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleToggleStatus(user.user_id, user.is_active)}
                  className={user.is_active ? "text-loss" : "text-profit"}
                >
                  {user.is_active ? (
                    <UserX className="w-5 h-5" />
                  ) : (
                    <UserCheck className="w-5 h-5" />
                  )}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onSelectUser(user.user_id)}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        ))}

        {filteredUsers.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No users found
          </div>
        )}
      </div>
    </div>
  );
};

export default UsersScreen;
