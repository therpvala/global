import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { ArrowLeft, Wallet, Users, Clock, History } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";

interface UserDetail {
  full_name: string | null;
  email: string | null;
  wallet_address: string | null;
  is_active: boolean;
}

interface WalletDetail {
  id: string;
  available_balance: number;
  locked_balance: number;
}

interface Transaction {
  id: string;
  type: string;
  amount: number;
  status: string;
  created_at: string;
}

interface UserDetailScreenProps {
  userId: string;
  onBack: () => void;
}

const UserDetailScreen = ({ userId, onBack }: UserDetailScreenProps) => {
  const { user: adminUser } = useAuth();
  const [profile, setProfile] = useState<UserDetail | null>(null);
  const [wallet, setWallet] = useState<WalletDetail | null>(null);
  const [referralCount, setReferralCount] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showAdjustDialog, setShowAdjustDialog] = useState(false);
  const [adjustAmount, setAdjustAmount] = useState("");
  const [showTransactions, setShowTransactions] = useState(false);

  useEffect(() => {
    fetchUserDetails();
  }, [userId]);

  const fetchUserDetails = async () => {
    try {
      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("full_name, email, wallet_address, is_active")
        .eq("user_id", userId)
        .single();

      setProfile(profileData);

      // Fetch wallet
      const { data: walletData } = await supabase
        .from("wallets")
        .select("id, available_balance, locked_balance")
        .eq("user_id", userId)
        .single();

      setWallet(walletData);

      // Fetch referral count
      const { count } = await supabase
        .from("referrals")
        .select("*", { count: "exact", head: true })
        .eq("parent_id", userId);

      setReferralCount(count || 0);

      // Fetch recent transactions
      const { data: txData } = await supabase
        .from("transactions")
        .select("id, type, amount, status, created_at")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(20);

      setTransactions(txData || []);
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdjustBalance = async () => {
    if (!wallet || !adjustAmount) return;

    const amount = parseFloat(adjustAmount);
    if (isNaN(amount)) {
      toast.error("Please enter a valid amount");
      return;
    }

    try {
      const newBalance = (wallet.available_balance || 0) + amount;
      
      if (newBalance < 0) {
        toast.error("Balance cannot go below zero");
        return;
      }

      const { error } = await supabase
        .from("wallets")
        .update({ available_balance: newBalance })
        .eq("id", wallet.id);

      if (error) throw error;

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: `adjusted_balance_${amount >= 0 ? 'add' : 'subtract'}`,
        reference_id: `${userId}:${amount}`,
      });

      toast.success(`Balance adjusted by $${amount}`);
      setShowAdjustDialog(false);
      setAdjustAmount("");
      fetchUserDetails();
    } catch (error) {
      console.error("Error adjusting balance:", error);
      toast.error("Failed to adjust balance");
    }
  };

  const handleResetCooldown = async () => {
    try {
      // Reset wallet address change cooldown by clearing the updated_at
      const { error } = await supabase
        .from("profiles")
        .update({ updated_at: new Date().toISOString() })
        .eq("user_id", userId);

      if (error) throw error;

      // Log admin action
      await supabase.from("admin_actions").insert({
        admin_id: adminUser?.id,
        action: "reset_wallet_cooldown",
        reference_id: userId,
      });

      toast.success("Wallet cooldown reset");
    } catch (error) {
      console.error("Error resetting cooldown:", error);
      toast.error("Failed to reset cooldown");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="p-4 pb-24 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 pt-2">
        <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="text-xl font-bold text-foreground">User Details</h1>
          <p className="text-muted-foreground text-sm">{profile?.email}</p>
        </div>
      </div>

      {/* User Info Card */}
      <div className="bg-card rounded-2xl border border-border p-5 space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Name</span>
          <span className="font-medium text-foreground">{profile?.full_name || "—"}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Status</span>
          <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
            profile?.is_active 
              ? "bg-profit/10 text-profit" 
              : "bg-loss/10 text-loss"
          }`}>
            {profile?.is_active ? "Active" : "Blocked"}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Wallet Address</span>
          <span className="font-mono text-sm text-foreground truncate max-w-[150px]">
            {profile?.wallet_address || "Not set"}
          </span>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Wallet className="w-4 h-4" />
            <span className="text-sm">Balance</span>
          </div>
          <p className="text-2xl font-bold text-foreground">
            ${(wallet?.available_balance || 0).toLocaleString()}
          </p>
        </div>
        <div className="bg-card rounded-2xl border border-border p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Users className="w-4 h-4" />
            <span className="text-sm">Referrals</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{referralCount}</p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button 
          onClick={() => setShowAdjustDialog(true)}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="crypto"
        >
          <Wallet className="w-5 h-5 mr-2" />
          Adjust Balance
        </Button>
        <Button 
          onClick={handleResetCooldown}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="outline"
        >
          <Clock className="w-5 h-5 mr-2" />
          Reset Wallet Cooldown
        </Button>
        <Button 
          onClick={() => setShowTransactions(!showTransactions)}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="outline"
        >
          <History className="w-5 h-5 mr-2" />
          {showTransactions ? "Hide" : "View"} Transactions
        </Button>
      </div>

      {/* Transactions List */}
      {showTransactions && (
        <div className="space-y-3">
          <h3 className="font-semibold text-foreground">Recent Transactions</h3>
          {transactions.length === 0 ? (
            <p className="text-center text-muted-foreground py-6">No transactions</p>
          ) : (
            transactions.map((tx) => (
              <div 
                key={tx.id}
                className="bg-card rounded-xl border border-border p-4 flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-foreground capitalize">{tx.type}</p>
                  <p className="text-xs text-muted-foreground">{formatDate(tx.created_at)}</p>
                </div>
                <div className="text-right">
                  <p className={`font-bold ${
                    tx.type === "withdrawal" ? "text-loss" : "text-profit"
                  }`}>
                    {tx.type === "withdrawal" ? "-" : "+"}${Number(tx.amount).toLocaleString()}
                  </p>
                  <p className={`text-xs ${
                    tx.status === "completed" ? "text-profit" : "text-gold"
                  }`}>
                    {tx.status}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Adjust Balance Dialog */}
      <Dialog open={showAdjustDialog} onOpenChange={setShowAdjustDialog}>
        <DialogContent className="rounded-2xl">
          <DialogHeader>
            <DialogTitle>Adjust Balance</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <p className="text-sm text-muted-foreground mb-3">
              Current balance: ${(wallet?.available_balance || 0).toLocaleString()}
            </p>
            <Input
              type="number"
              placeholder="Enter amount (use - for subtract)"
              value={adjustAmount}
              onChange={(e) => setAdjustAmount(e.target.value)}
              className="h-12 rounded-xl"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Use negative number to subtract (e.g. -100)
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdjustDialog(false)}>
              Cancel
            </Button>
            <Button variant="crypto" onClick={handleAdjustBalance}>
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserDetailScreen;
