import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Users, DollarSign, Clock, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface OverviewStats {
  totalUsers: number;
  totalDeposits: number;
  pendingWithdrawals: number;
  paidWithdrawals: number;
}

interface OverviewScreenProps {
  onNavigate: (screen: string) => void;
}

const OverviewScreen = ({ onNavigate }: OverviewScreenProps) => {
  const [stats, setStats] = useState<OverviewStats>({
    totalUsers: 0,
    totalDeposits: 0,
    pendingWithdrawals: 0,
    paidWithdrawals: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      // Fetch total users
      const { count: usersCount } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true });

      // Fetch total deposits
      const { data: deposits } = await supabase
        .from("transactions")
        .select("amount")
        .eq("type", "deposit")
        .eq("status", "completed");

      const totalDeposits = deposits?.reduce((sum, d) => sum + Number(d.amount), 0) || 0;

      // Fetch pending withdrawals
      const { data: pending } = await supabase
        .from("withdrawals")
        .select("amount")
        .eq("status", "pending");

      const pendingTotal = pending?.reduce((sum, w) => sum + Number(w.amount), 0) || 0;

      // Fetch paid withdrawals
      const { data: paid } = await supabase
        .from("withdrawals")
        .select("amount")
        .eq("status", "completed");

      const paidTotal = paid?.reduce((sum, w) => sum + Number(w.amount), 0) || 0;

      setStats({
        totalUsers: usersCount || 0,
        totalDeposits,
        pendingWithdrawals: pendingTotal,
        paidWithdrawals: paidTotal,
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const statCards = [
    { 
      label: "Total Users", 
      value: stats.totalUsers, 
      icon: Users, 
      color: "text-primary",
      format: "number" 
    },
    { 
      label: "Total Money Added", 
      value: stats.totalDeposits, 
      icon: DollarSign, 
      color: "text-profit",
      format: "currency" 
    },
    { 
      label: "Withdraw Requested", 
      value: stats.pendingWithdrawals, 
      icon: Clock, 
      color: "text-gold",
      format: "currency" 
    },
    { 
      label: "Withdraw Paid", 
      value: stats.paidWithdrawals, 
      icon: CheckCircle, 
      color: "text-crypto",
      format: "currency" 
    },
  ];

  const formatValue = (value: number, format: string) => {
    if (format === "currency") {
      return `$${value.toLocaleString()}`;
    }
    return value.toLocaleString();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24 space-y-6">
      {/* Header */}
      <div className="text-center pt-2">
        <h1 className="text-2xl font-bold text-foreground">Admin Panel</h1>
        <p className="text-muted-foreground text-sm mt-1">Platform Overview</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        {statCards.map((stat, index) => (
          <div 
            key={index}
            className="bg-card rounded-2xl border border-border p-4 space-y-3"
          >
            <div className={`p-2.5 rounded-xl bg-secondary/50 w-fit ${stat.color}`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {formatValue(stat.value, stat.format)}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="space-y-3 pt-4">
        <Button 
          onClick={() => onNavigate("pending-withdrawals")}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="crypto"
        >
          <Clock className="w-5 h-5 mr-2" />
          View Pending Withdrawals
        </Button>
        <Button 
          onClick={() => onNavigate("users")}
          className="w-full h-14 text-base font-semibold rounded-xl"
          variant="outline"
        >
          <Users className="w-5 h-5 mr-2" />
          View All Users
        </Button>
      </div>
    </div>
  );
};

export default OverviewScreen;
