import AnimatedNumber from "./AnimatedNumber";

interface BalanceCardProps {
  balance: number;
}

const BalanceCard = ({ balance }: BalanceCardProps) => {
  return (
    <div className="balance-card animate-fade-up">
      {/* Label */}
      <div className="flex items-center justify-center gap-2 mb-3">
        <span className="text-3xl">💰</span>
        <span className="text-white/90 text-xl font-bold uppercase tracking-wider">
          TOTAL BALANCE
        </span>
      </div>
      
      {/* Big Number - Very Large for trust */}
      <div className="flex items-center justify-center gap-2">
        <AnimatedNumber 
          value={balance} 
          className="text-6xl md:text-7xl font-extrabold text-white"
          prefix="$"
        />
      </div>
      
      {/* Currency label */}
      <div className="text-center mt-3">
        <span className="text-white/70 text-lg font-medium">USDT</span>
      </div>
    </div>
  );
};

export default BalanceCard;
