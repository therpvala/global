import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  DollarSign,
  Users,
  Wallet,
  ArrowDownToLine,
  FileText,
  UserCog,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Home,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type PartnerModule =
  | "dashboard"
  | "earnings"
  | "team"
  | "wallet"
  | "withdraw"
  | "reports"
  | "profile";

interface PartnerLayoutProps {
  activeModule: PartnerModule;
  onModuleChange: (module: PartnerModule) => void;
  children: React.ReactNode;
  totalBalance: number;
}

const menuItems: { id: PartnerModule; label: string; icon: React.ReactNode }[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard className="w-5 h-5" /> },
  { id: "earnings", label: "My Earnings", icon: <DollarSign className="w-5 h-5" /> },
  { id: "team", label: "My Team", icon: <Users className="w-5 h-5" /> },
  { id: "wallet", label: "Wallet", icon: <Wallet className="w-5 h-5" /> },
  { id: "withdraw", label: "Withdraw", icon: <ArrowDownToLine className="w-5 h-5" /> },
  { id: "reports", label: "Reports", icon: <FileText className="w-5 h-5" /> },
  { id: "profile", label: "Profile & Security", icon: <UserCog className="w-5 h-5" /> },
];

const PartnerLayout = ({
  activeModule,
  onModuleChange,
  children,
  totalBalance,
}: PartnerLayoutProps) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(true);
  const navigate = useNavigate();
  const { signOut } = useAuth();

  const handleLogout = async () => {
    await signOut();
    toast.success("Logged out successfully");
    navigate("/auth");
  };

  const handleGoHome = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside
        className={cn(
          "bg-card border-r border-border transition-all duration-300 flex flex-col",
          sidebarCollapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo Area */}
        <div className="h-16 border-b border-border flex items-center justify-between px-4">
          {!sidebarCollapsed && (
            <span className="font-bold text-lg text-foreground">Partner Portal</span>
          )}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="ml-auto"
          >
            {sidebarCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-4">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onModuleChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 text-left transition-colors",
                activeModule === item.id
                  ? "bg-primary/10 text-primary border-r-2 border-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {item.icon}
              {!sidebarCollapsed && (
                <span className="font-medium">{item.label}</span>
              )}
            </button>
          ))}
        </nav>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-border space-y-1">
          <button
            onClick={handleGoHome}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors rounded-lg",
              sidebarCollapsed && "justify-center px-0"
            )}
          >
            <Home className="w-5 h-5" />
            {!sidebarCollapsed && <span className="font-medium">Back to App</span>}
          </button>
          <button
            onClick={handleLogout}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 text-muted-foreground hover:text-destructive transition-colors rounded-lg",
              sidebarCollapsed && "justify-center px-0"
            )}
          >
            <LogOut className="w-5 h-5" />
            {!sidebarCollapsed && <span className="font-medium">Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <header className="h-16 bg-card border-b border-border flex items-center justify-between px-6">
          <div>
            <h1 className="text-xl font-semibold text-foreground">
              {menuItems.find((m) => m.id === activeModule)?.label}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="text-xl font-bold text-crypto">
                ${totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </p>
            </div>
            <Button
              variant="crypto"
              size="sm"
              onClick={() => onModuleChange("withdraw")}
            >
              <ArrowDownToLine className="w-4 h-4 mr-2" />
              Withdraw
            </Button>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">{children}</main>
      </div>
    </div>
  );
};

export default PartnerLayout;
