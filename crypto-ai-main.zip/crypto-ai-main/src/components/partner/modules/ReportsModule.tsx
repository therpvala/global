import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download, Calendar, Users, TrendingUp, DollarSign } from "lucide-react";
import { toast } from "sonner";

const ReportsModule = () => {
  const handleDownload = (reportName: string, format: string) => {
    toast.success(`Downloading ${reportName} as ${format}...`, {
      description: "Your report will be ready shortly.",
    });
  };

  const reports = [
    {
      title: "Earnings Summary",
      description: "Complete breakdown of all your earnings by source and date.",
      icon: <DollarSign className="w-6 h-6" />,
      color: "text-crypto",
    },
    {
      title: "Team Performance",
      description: "Overview of your team's activity, volume, and contributions.",
      icon: <Users className="w-6 h-6" />,
      color: "text-primary",
    },
    {
      title: "Monthly Statement",
      description: "Detailed monthly statement with all transactions and balances.",
      icon: <Calendar className="w-6 h-6" />,
      color: "text-gold",
    },
    {
      title: "Growth Report",
      description: "Track your earnings and team growth over time.",
      icon: <TrendingUp className="w-6 h-6" />,
      color: "text-profit",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-lg bg-primary/10">
              <FileText className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">
                Downloadable Reports
              </h2>
              <p className="text-muted-foreground">
                Export your data in CSV or PDF format for your records.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reports.map((report, index) => (
          <Card key={index}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className={`p-3 rounded-lg bg-muted ${report.color}`}>
                  {report.icon}
                </div>
                <CardTitle className="text-lg">{report.title}</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {report.description}
              </p>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownload(report.title, "CSV")}
                >
                  <Download className="w-4 h-4 mr-2" />
                  CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDownload(report.title, "PDF")}
                >
                  <Download className="w-4 h-4 mr-2" />
                  PDF
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Note */}
      <div className="text-sm text-muted-foreground text-center py-4">
        Reports are generated in real-time and reflect your latest data.
      </div>
    </div>
  );
};

export default ReportsModule;
