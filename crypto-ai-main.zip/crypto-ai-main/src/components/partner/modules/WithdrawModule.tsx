import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Wallet, ArrowDownToLine, Clock, CheckCircle } from "lucide-react";
import { toast } from "sonner";

interface WithdrawModuleProps {
  availableBalance: number;
  walletAddress: string;
  onWithdraw: (amount: number) => void;
}

const WithdrawModule = ({
  availableBalance,
  walletAddress,
  onWithdraw,
}: WithdrawModuleProps) => {
  const [amount, setAmount] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const minimumWithdraw = 50;
  const processingTime = "24-48 hours";

  const handleWithdraw = () => {
    const numAmount = parseFloat(amount);
    if (numAmount < minimumWithdraw) {
      toast.error(`Minimum withdrawal is $${minimumWithdraw}`);
      return;
    }
    if (numAmount > availableBalance) {
      toast.error("Insufficient balance");
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      onWithdraw(numAmount);
      setAmount("");
      setIsSubmitting(false);
      toast.success("Withdrawal request submitted!", {
        description: `$${numAmount} will be sent to your wallet within ${processingTime}`,
      });
    }, 1000);
  };

  const withdrawHistory = [
    {
      id: 1,
      date: "2024-01-13",
      amount: 100.0,
      status: "completed",
      refId: "WD-20240113-001",
    },
    {
      id: 2,
      date: "2024-01-10",
      amount: 250.0,
      status: "completed",
      refId: "WD-20240110-003",
    },
    {
      id: 3,
      date: "2024-01-05",
      amount: 75.0,
      status: "completed",
      refId: "WD-20240105-002",
    },
    {
      id: 4,
      date: "2024-01-02",
      amount: 150.0,
      status: "processing",
      refId: "WD-20240102-001",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Withdraw Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Request Withdrawal</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Available Balance */}
            <div className="bg-muted rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Available Balance</p>
                  <p className="text-2xl font-bold text-crypto">
                    ${availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <Wallet className="w-8 h-8 text-crypto" />
              </div>
            </div>

            {/* Amount Input */}
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (USD)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="text-lg h-12"
              />
            </div>

            {/* Wallet Address (Read-only) */}
            <div className="space-y-2">
              <Label>Wallet Address (TRC20)</Label>
              <div className="bg-muted rounded-lg px-4 py-3 font-mono text-sm truncate">
                {walletAddress}
              </div>
            </div>

            {/* Submit Button */}
            <Button
              variant="navy"
              size="lg"
              className="w-full"
              disabled={!amount || parseFloat(amount) <= 0 || isSubmitting}
              onClick={handleWithdraw}
            >
              {isSubmitting ? (
                "Processing..."
              ) : (
                <>
                  <ArrowDownToLine className="w-5 h-5 mr-2" />
                  Submit Withdrawal
                </>
              )}
            </Button>

            {/* Rules */}
            <div className="space-y-2 pt-4 border-t border-border">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle className="w-4 h-4 text-crypto" />
                <span>Minimum withdrawal: ${minimumWithdraw}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-4 h-4 text-gold" />
                <span>Processing time: {processingTime}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Withdraw History */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Withdrawal History</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Reference</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {withdrawHistory.map((withdrawal) => (
                  <TableRow key={withdrawal.id}>
                    <TableCell className="font-medium">{withdrawal.date}</TableCell>
                    <TableCell className="font-semibold">
                      ${withdrawal.amount.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={
                          withdrawal.status === "completed"
                            ? "bg-profit/10 text-profit"
                            : "bg-gold/10 text-gold"
                        }
                      >
                        {withdrawal.status === "completed" ? "Completed" : "Processing"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground font-mono text-xs">
                      {withdrawal.refId}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default WithdrawModule;
