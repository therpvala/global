import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Wallet, Lock } from "lucide-react";

interface PartnerWalletModuleProps {
  availableBalance: number;
  lockedBalance: number;
}

const PartnerWalletModule = ({
  availableBalance,
  lockedBalance,
}: PartnerWalletModuleProps) => {
  const transactions = [
    {
      id: 1,
      date: "2024-01-15",
      type: "Commission",
      description: "Direct referral bonus",
      amount: 50.0,
      status: "completed",
    },
    {
      id: 2,
      date: "2024-01-15",
      type: "Profit",
      description: "Trading profit share",
      amount: 15.75,
      status: "completed",
    },
    {
      id: 3,
      date: "2024-01-14",
      type: "Commission",
      description: "Team earnings",
      amount: 25.0,
      status: "completed",
    },
    {
      id: 4,
      date: "2024-01-13",
      type: "Withdrawal",
      description: "Withdrawal to TRC20",
      amount: -100.0,
      status: "completed",
    },
    {
      id: 5,
      date: "2024-01-12",
      type: "Commission",
      description: "Direct referral bonus",
      amount: 50.0,
      status: "pending",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Available Balance</p>
                <p className="text-3xl font-bold mt-1 text-crypto">
                  ${availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
              </div>
              <div className="p-4 rounded-lg bg-crypto/10">
                <Wallet className="w-6 h-6 text-crypto" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Locked Balance</p>
                <p className="text-3xl font-bold mt-1 text-muted-foreground">
                  ${lockedBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Pending commissions & bonuses
                </p>
              </div>
              <div className="p-4 rounded-lg bg-muted">
                <Lock className="w-6 h-6 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Transaction History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Transaction History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Description</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {transactions.map((tx) => (
                <TableRow key={tx.id}>
                  <TableCell className="font-medium">{tx.date}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        tx.type === "Commission"
                          ? "default"
                          : tx.type === "Profit"
                          ? "secondary"
                          : "outline"
                      }
                    >
                      {tx.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {tx.description}
                  </TableCell>
                  <TableCell
                    className={`text-right font-semibold ${
                      tx.amount > 0 ? "text-profit" : "text-loss"
                    }`}
                  >
                    {tx.amount > 0 ? "+" : ""}${Math.abs(tx.amount).toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={
                        tx.status === "completed"
                          ? "bg-profit/10 text-profit"
                          : "bg-gold/10 text-gold"
                      }
                    >
                      {tx.status === "completed" ? "Completed" : "Pending"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default PartnerWalletModule;
