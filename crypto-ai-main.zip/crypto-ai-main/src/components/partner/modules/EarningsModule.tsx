import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Users, TrendingUp, Clock } from "lucide-react";

interface EarningsModuleProps {
  directEarnings: number;
  teamEarnings: number;
  tradingProfit: number;
  pendingEarnings: number;
}

const EarningsModule = ({
  directEarnings,
  teamEarnings,
  tradingProfit,
  pendingEarnings,
}: EarningsModuleProps) => {
  const [dateFilter, setDateFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const summaryCards = [
    {
      title: "Direct Earnings",
      value: directEarnings,
      icon: <DollarSign className="w-5 h-5" />,
      color: "text-crypto",
    },
    {
      title: "Team Earnings",
      value: teamEarnings,
      icon: <Users className="w-5 h-5" />,
      color: "text-primary",
    },
    {
      title: "Trading Profit Share",
      value: tradingProfit,
      icon: <TrendingUp className="w-5 h-5" />,
      color: "text-profit",
    },
    {
      title: "Pending Earnings",
      value: pendingEarnings,
      icon: <Clock className="w-5 h-5" />,
      color: "text-gold",
    },
  ];

  const earningsData = [
    {
      id: 1,
      date: "2024-01-15",
      source: "Direct",
      user: "User ***4521",
      amount: 50.0,
      status: "credited",
    },
    {
      id: 2,
      date: "2024-01-15",
      source: "Team",
      user: "User ***8832",
      amount: 25.0,
      status: "credited",
    },
    {
      id: 3,
      date: "2024-01-14",
      source: "Trading",
      user: "AI Engine",
      amount: 15.75,
      status: "credited",
    },
    {
      id: 4,
      date: "2024-01-14",
      source: "Direct",
      user: "User ***1290",
      amount: 50.0,
      status: "pending",
    },
    {
      id: 5,
      date: "2024-01-13",
      source: "Team",
      user: "User ***7654",
      amount: 12.5,
      status: "credited",
    },
  ];

  const filteredData = earningsData.filter((item) => {
    if (typeFilter !== "all" && item.source.toLowerCase() !== typeFilter) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  <p className={`text-2xl font-bold mt-1 ${card.color}`}>
                    ${card.value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </p>
                </div>
                <div className={`p-3 rounded-lg bg-muted ${card.color}`}>
                  {card.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Earnings Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="text-lg">Earnings History</CardTitle>
            <div className="flex items-center gap-3">
              <Input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="w-40"
              />
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="direct">Direct</SelectItem>
                  <SelectItem value="team">Team</SelectItem>
                  <SelectItem value="trading">Trading</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>From</TableHead>
                <TableHead className="text-right">Amount</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.map((earning) => (
                <TableRow key={earning.id}>
                  <TableCell className="font-medium">{earning.date}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        earning.source === "Direct"
                          ? "default"
                          : earning.source === "Team"
                          ? "secondary"
                          : "outline"
                      }
                    >
                      {earning.source}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {earning.user}
                  </TableCell>
                  <TableCell className="text-right font-semibold text-profit">
                    +${earning.amount.toFixed(2)}
                  </TableCell>
                  <TableCell>
                    <Badge
                      variant={earning.status === "credited" ? "default" : "secondary"}
                      className={
                        earning.status === "credited"
                          ? "bg-profit/10 text-profit"
                          : "bg-gold/10 text-gold"
                      }
                    >
                      {earning.status === "credited" ? "Credited" : "Pending"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default EarningsModule;
