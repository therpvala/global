import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Users, UserCheck, UserPlus } from "lucide-react";

interface TeamModuleProps {
  totalTeamSize: number;
  activeMembers: number;
  newThisMonth: number;
}

const TeamModule = ({ totalTeamSize, activeMembers, newThisMonth }: TeamModuleProps) => {
  const statCards = [
    {
      title: "Total Team Size",
      value: totalTeamSize,
      icon: <Users className="w-5 h-5" />,
      color: "text-primary",
    },
    {
      title: "Active Members",
      value: activeMembers,
      icon: <UserCheck className="w-5 h-5" />,
      color: "text-crypto",
    },
    {
      title: "New This Month",
      value: newThisMonth,
      icon: <UserPlus className="w-5 h-5" />,
      color: "text-profit",
    },
  ];

  const teamMembers = [
    {
      id: 1,
      oderId: "USR-4521",
      joinDate: "2024-01-10",
      status: "active",
      volume: 5000,
      earnings: 125.0,
    },
    {
      id: 2,
      oderId: "USR-8832",
      joinDate: "2024-01-08",
      status: "active",
      volume: 3500,
      earnings: 87.5,
    },
    {
      id: 3,
      oderId: "USR-1290",
      joinDate: "2024-01-05",
      status: "active",
      volume: 10000,
      earnings: 250.0,
    },
    {
      id: 4,
      oderId: "USR-7654",
      joinDate: "2024-01-03",
      status: "inactive",
      volume: 1000,
      earnings: 25.0,
    },
    {
      id: 5,
      oderId: "USR-9901",
      joinDate: "2024-01-01",
      status: "active",
      volume: 7500,
      earnings: 187.5,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statCards.map((card, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  <p className={`text-3xl font-bold mt-1 ${card.color}`}>
                    {card.value}
                  </p>
                </div>
                <div className={`p-3 rounded-lg bg-muted ${card.color}`}>
                  {card.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Team Members Table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Team Members</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>Join Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Contribution Volume</TableHead>
                <TableHead className="text-right">Earnings Generated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {teamMembers.map((member) => (
                <TableRow key={member.id}>
                  <TableCell className="font-medium">{member.oderId}</TableCell>
                  <TableCell className="text-muted-foreground">
                    {member.joinDate}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={
                        member.status === "active"
                          ? "bg-crypto/10 text-crypto"
                          : "bg-muted text-muted-foreground"
                      }
                    >
                      {member.status === "active" ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    ${member.volume.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right font-semibold text-profit">
                    ${member.earnings.toFixed(2)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Note */}
      <div className="text-sm text-muted-foreground text-center py-4">
        Your team includes all users referred through your link and their network.
      </div>
    </div>
  );
};

export default TeamModule;
