import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Check, Wallet, TrendingUp, Users, DollarSign } from "lucide-react";
import { toast } from "sonner";

interface DashboardModuleProps {
  totalBalance: number;
  totalEarned: number;
  todayEarnings: number;
  activeMembers: number;
  referralCode: string;
}

const DashboardModule = ({
  totalBalance,
  totalEarned,
  todayEarnings,
  activeMembers,
  referralCode,
}: DashboardModuleProps) => {
  const [copied, setCopied] = useState(false);

  const referralLink = `https://cryptoai.app/ref/${referralCode}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast.success("Referral link copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  const kpiCards = [
    {
      title: "Total Balance",
      value: `$${totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      icon: <Wallet className="w-5 h-5" />,
      color: "text-crypto",
    },
    {
      title: "Total Earned (All Time)",
      value: `$${totalEarned.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      icon: <TrendingUp className="w-5 h-5" />,
      color: "text-profit",
    },
    {
      title: "Today's Earnings",
      value: `$${todayEarnings.toLocaleString(undefined, { minimumFractionDigits: 2 })}`,
      icon: <DollarSign className="w-5 h-5" />,
      color: "text-gold",
    },
    {
      title: "Active Team Members",
      value: activeMembers.toString(),
      icon: <Users className="w-5 h-5" />,
      color: "text-primary",
    },
  ];

  const recentEarnings = [
    { id: 1, source: "Direct Referral", amount: 25.0, time: "2 hours ago" },
    { id: 2, source: "Team Commission", amount: 12.5, time: "5 hours ago" },
    { id: 3, source: "Trading Profit", amount: 8.75, time: "Yesterday" },
  ];

  const recentJoins = [
    { id: 1, user: "User ***4521", time: "1 hour ago" },
    { id: 2, user: "User ***8832", time: "3 hours ago" },
    { id: 3, user: "User ***1290", time: "Yesterday" },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((card, index) => (
          <Card key={index}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{card.title}</p>
                  <p className={`text-2xl font-bold mt-1 ${card.color}`}>
                    {card.value}
                  </p>
                </div>
                <div className={`p-3 rounded-lg bg-muted ${card.color}`}>
                  {card.icon}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Referral Link Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Your Referral Link</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-3">
            <div className="flex-1 bg-muted rounded-lg px-4 py-3 font-mono text-sm truncate">
              {referralLink}
            </div>
            <Button
              variant={copied ? "outline" : "crypto"}
              onClick={handleCopyLink}
              className="shrink-0"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Link
                </>
              )}
            </Button>
          </div>
          <p className="text-sm text-muted-foreground mt-3">
            Share this link to earn commissions when users join and trade.
          </p>
        </CardContent>
      </Card>

      {/* Activity Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Earnings */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Latest Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentEarnings.map((earning) => (
                <div
                  key={earning.id}
                  className="flex items-center justify-between py-2 border-b border-border last:border-0"
                >
                  <div>
                    <p className="font-medium text-foreground">{earning.source}</p>
                    <p className="text-sm text-muted-foreground">{earning.time}</p>
                  </div>
                  <span className="text-profit font-semibold">
                    +${earning.amount.toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Latest Team Joins */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Latest Team Joins</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentJoins.map((join) => (
                <div
                  key={join.id}
                  className="flex items-center justify-between py-2 border-b border-border last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{join.user}</p>
                      <p className="text-sm text-muted-foreground">{join.time}</p>
                    </div>
                  </div>
                  <span className="text-sm text-crypto font-medium">New Member</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardModule;
