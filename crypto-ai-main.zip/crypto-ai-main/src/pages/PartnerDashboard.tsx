import { useState } from "react";
import PartnerLayout from "@/components/partner/PartnerLayout";
import DashboardModule from "@/components/partner/modules/DashboardModule";
import EarningsModule from "@/components/partner/modules/EarningsModule";
import TeamModule from "@/components/partner/modules/TeamModule";
import PartnerWalletModule from "@/components/partner/modules/PartnerWalletModule";
import WithdrawModule from "@/components/partner/modules/WithdrawModule";
import ReportsModule from "@/components/partner/modules/ReportsModule";
import ProfileSecurityModule from "@/components/partner/modules/ProfileSecurityModule";

type PartnerModule =
  | "dashboard"
  | "earnings"
  | "team"
  | "wallet"
  | "withdraw"
  | "reports"
  | "profile";

const PartnerDashboard = () => {
  const [activeModule, setActiveModule] = useState<PartnerModule>("dashboard");

  // Mock partner data
  const partnerData = {
    totalBalance: 1250.75,
    totalEarned: 5420.5,
    todayEarnings: 85.25,
    activeMembers: 24,
    referralCode: "PARTNER2024",
    directEarnings: 2500.0,
    teamEarnings: 1850.5,
    tradingProfit: 820.0,
    pendingEarnings: 250.0,
    totalTeamSize: 42,
    newThisMonth: 8,
    lockedBalance: 150.0,
    userName: "John Partner",
    email: "john.partner@example.com",
    walletAddress: "TRx7K8pQG3N4mWL9vE2hJc5YfD8bA1sZq",
  };

  const handleWithdraw = (amount: number) => {
    console.log("Withdrawal requested:", amount);
  };

  const renderModule = () => {
    switch (activeModule) {
      case "dashboard":
        return (
          <DashboardModule
            totalBalance={partnerData.totalBalance}
            totalEarned={partnerData.totalEarned}
            todayEarnings={partnerData.todayEarnings}
            activeMembers={partnerData.activeMembers}
            referralCode={partnerData.referralCode}
          />
        );
      case "earnings":
        return (
          <EarningsModule
            directEarnings={partnerData.directEarnings}
            teamEarnings={partnerData.teamEarnings}
            tradingProfit={partnerData.tradingProfit}
            pendingEarnings={partnerData.pendingEarnings}
          />
        );
      case "team":
        return (
          <TeamModule
            totalTeamSize={partnerData.totalTeamSize}
            activeMembers={partnerData.activeMembers}
            newThisMonth={partnerData.newThisMonth}
          />
        );
      case "wallet":
        return (
          <PartnerWalletModule
            availableBalance={partnerData.totalBalance}
            lockedBalance={partnerData.lockedBalance}
          />
        );
      case "withdraw":
        return (
          <WithdrawModule
            availableBalance={partnerData.totalBalance}
            walletAddress={partnerData.walletAddress}
            onWithdraw={handleWithdraw}
          />
        );
      case "reports":
        return <ReportsModule />;
      case "profile":
        return (
          <ProfileSecurityModule
            userName={partnerData.userName}
            email={partnerData.email}
            walletAddress={partnerData.walletAddress}
          />
        );
      default:
        return null;
    }
  };

  return (
    <PartnerLayout
      activeModule={activeModule}
      onModuleChange={setActiveModule}
      totalBalance={partnerData.totalBalance}
    >
      {renderModule()}
    </PartnerLayout>
  );
};

export default PartnerDashboard;
