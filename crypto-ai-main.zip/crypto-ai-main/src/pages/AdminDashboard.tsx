import { useState } from "react";
import AdminBottomNav from "@/components/admin/AdminBottomNav";
import OverviewScreen from "@/components/admin/screens/OverviewScreen";
import UsersScreen from "@/components/admin/screens/UsersScreen";
import UserDetailScreen from "@/components/admin/screens/UserDetailScreen";
import MoneyScreen from "@/components/admin/screens/MoneyScreen";
import SettingsScreen from "@/components/admin/screens/SettingsScreen";
import ReferralTreeScreen from "@/components/admin/screens/ReferralTreeScreen";

type AdminTab = "overview" | "users" | "network" | "money" | "settings";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [previousTab, setPreviousTab] = useState<AdminTab>("users");

  const handleNavigate = (screen: string) => {
    if (screen === "pending-withdrawals") {
      setActiveTab("money");
    } else if (screen === "users") {
      setActiveTab("users");
    } else if (screen === "network") {
      setActiveTab("network");
    }
  };

  const handleSelectUser = (userId: string, fromTab?: AdminTab) => {
    setSelectedUserId(userId);
    if (fromTab) {
      setPreviousTab(fromTab);
    } else {
      setPreviousTab(activeTab);
    }
  };

  const handleBackFromUserDetail = () => {
    setSelectedUserId(null);
  };

  const renderScreen = () => {
    // Show user detail if a user is selected (from any tab)
    if (selectedUserId) {
      return (
        <UserDetailScreen 
          userId={selectedUserId} 
          onBack={handleBackFromUserDetail} 
        />
      );
    }

    switch (activeTab) {
      case "overview":
        return <OverviewScreen onNavigate={handleNavigate} />;
      case "users":
        return <UsersScreen onSelectUser={(userId) => handleSelectUser(userId, "users")} />;
      case "network":
        return <ReferralTreeScreen onSelectUser={(userId) => handleSelectUser(userId, "network")} />;
      case "money":
        return <MoneyScreen />;
      case "settings":
        return <SettingsScreen />;
      default:
        return <OverviewScreen onNavigate={handleNavigate} />;
    }
  };

  // Reset selected user when changing tabs
  const handleTabChange = (tab: AdminTab) => {
    setSelectedUserId(null);
    setActiveTab(tab);
  };

  return (
    <div className="min-h-screen bg-background">
      {renderScreen()}
      <AdminBottomNav activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
};

export default AdminDashboard;
