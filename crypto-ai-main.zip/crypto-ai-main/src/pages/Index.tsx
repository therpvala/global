import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCommissionNotifications } from "@/hooks/useCommissionNotifications";
import { useRealtimeWallet } from "@/hooks/useRealtimeWallet";
import BottomNav from "@/components/BottomNav";
import HomeScreen from "@/components/screens/HomeScreen";
import WalletScreen from "@/components/screens/WalletScreen";
import ShareScreen from "@/components/screens/ShareScreen";
import ProfileScreen from "@/components/screens/ProfileScreen";
import AddMoneyModal from "@/components/modals/AddMoneyModal";
import WithdrawModal from "@/components/modals/WithdrawModal";
import WithdrawalHistoryScreen from "@/components/screens/WithdrawalHistoryScreen";
import { toast } from "sonner";

type Tab = "home" | "wallet" | "share" | "profile";
type Screen = Tab | "withdrawal-history";

interface Transaction {
  id: string;
  date: string;
  type: "added" | "profit" | "withdraw";
  amount: number;
}


interface ProfileData {
  full_name: string | null;
  wallet_address: string | null;
  email: string | null;
}

interface ReferralData {
  referral_code: string;
  total_referrals: number;
  total_team_size: number;
  total_earnings: number;
}

const Index = () => {
  const navigate = useNavigate();
  const { user, isAdmin, isPartner, signOut } = useAuth();
  
  const [activeScreen, setActiveScreen] = useState<Screen>("home");
  
  // Enable real-time commission notifications
  useCommissionNotifications();
  
  // Use real-time wallet updates
  const { wallet, isLoading: walletLoading, refetch: refetchWallet } = useRealtimeWallet();
  
  const [profile, setProfile] = useState<ProfileData>({
    full_name: null,
    wallet_address: null,
    email: null,
  });
  const [referral, setReferral] = useState<ReferralData>({
    referral_code: "",
    total_referrals: 0,
    total_team_size: 0,
    total_earnings: 0,
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isAddMoneyOpen, setIsAddMoneyOpen] = useState(false);
  const [isWithdrawOpen, setIsWithdrawOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch user data on mount
  useEffect(() => {
    if (user) {
      fetchUserData();
    }
  }, [user]);

  const fetchUserData = async () => {
    if (!user) return;

    try {

      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("full_name, wallet_address, email")
        .eq("user_id", user.id)
        .maybeSingle();

      if (profileData) {
        setProfile({
          full_name: profileData.full_name,
          wallet_address: profileData.wallet_address,
          email: profileData.email,
        });
      }

      // Fetch referral with stats
      const { data: referralData } = await supabase
        .from("referrals")
        .select("referral_code, total_referrals, total_team_size")
        .eq("user_id", user.id)
        .maybeSingle();

      // Fetch total commission earnings
      const { data: commissionsData } = await supabase
        .from("commissions")
        .select("amount")
        .eq("user_id", user.id)
        .eq("status", "completed");

      const totalEarnings = commissionsData?.reduce((sum, c) => sum + Number(c.amount), 0) || 0;

      if (referralData) {
        setReferral({ 
          referral_code: referralData.referral_code,
          total_referrals: referralData.total_referrals || 0,
          total_team_size: referralData.total_team_size || 0,
          total_earnings: totalEarnings,
        });
      }

      // Fetch transactions (for display purposes, map to UI format)
      const { data: txData } = await supabase
        .from("transactions")
        .select("id, type, amount, created_at, status")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(10);

      if (txData) {
        const mappedTx: Transaction[] = txData.map((tx) => ({
          id: tx.id,
          date: new Date(tx.created_at).toLocaleDateString(),
          type: mapTransactionType(tx.type),
          amount: Number(tx.amount),
        }));
        setTransactions(mappedTx);
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const mapTransactionType = (type: string): "added" | "profit" | "withdraw" => {
    switch (type) {
      case "deposit":
        return "added";
      case "profit":
      case "commission":
      case "bonus":
        return "profit";
      case "withdrawal":
      case "fee":
        return "withdraw";
      default:
        return "added";
    }
  };

  const handleAddMoney = async (amount: number) => {
    // In a real app, this would integrate with a payment gateway
    // For now, we'll just show success and refresh
    toast.success(`$${amount} added successfully!`, { icon: "💰" });
    await fetchUserData();
  };

  const handleWithdraw = async (amount: number) => {
    // In a real app, this would create a withdrawal request
    toast.success("Withdrawal requested!", {
      description: `$${amount} will be sent to your wallet`,
      icon: "✅",
    });
    await fetchUserData();
  };

  const handleChangeWallet = () => {
    toast.info("Wallet change coming soon!", { icon: "🔄" });
  };

  const handleSupport = () => {
    toast.info("Opening support chat...", { icon: "💬" });
  };

  const handleLogout = async () => {
    await signOut();
    toast.success("Logged out successfully", { icon: "👋" });
    navigate("/auth");
  };

  const handleViewAllHistory = () => {
    setActiveScreen("withdrawal-history");
  };

  const userName = profile.full_name || user?.email?.split("@")[0] || "User";
  const walletAddress = profile.wallet_address || "Not set";
  const referralCode = referral.referral_code || "LOADING...";
  const referralLink = `${window.location.origin}/auth?ref=${referralCode}`;

  // Get the active tab for BottomNav (maps screen to valid tab)
  const activeTab: Tab = activeScreen === "withdrawal-history" ? "wallet" : activeScreen;

  const handleTabChange = (tab: Tab) => {
    setActiveScreen(tab);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header - Simple & Trust-focused */}
      <header className="bg-card border-b border-border px-5 py-5 sticky top-0 z-40">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-4xl">⚡️</span>
            <h1 className="text-2xl font-extrabold text-foreground">CryptoAI</h1>
          </div>
          <div className="flex items-center gap-2">
            {/* Admin/Partner Quick Links */}
            {isAdmin && (
              <button
                onClick={() => navigate("/admin")}
                className="px-4 py-2 bg-primary/10 rounded-full text-base font-bold text-primary hover:bg-primary/20 transition-colors"
              >
                Admin
              </button>
            )}
            {isPartner && !isAdmin && (
              <button
                onClick={() => navigate("/partner")}
                className="px-4 py-2 bg-gold/10 rounded-full text-base font-bold text-gold hover:bg-gold/20 transition-colors"
              >
                Partner
              </button>
            )}
            <div className="flex items-center gap-2 px-4 py-2 bg-profit/10 rounded-full">
              <span className="w-3 h-3 rounded-full bg-profit animate-pulse"></span>
              <span className="text-base font-bold text-profit">Active</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-md mx-auto">
        {activeScreen === "home" && (
          <HomeScreen
            balance={wallet.available_balance}
            todayProfit={wallet.total_earned}
            onAddMoney={() => setIsAddMoneyOpen(true)}
            onWithdraw={() => setIsWithdrawOpen(true)}
          />
        )}

        {activeScreen === "wallet" && (
          <WalletScreen
            availableBalance={wallet.available_balance}
            processingBalance={wallet.locked_balance}
            transactions={transactions}
            onViewAllHistory={handleViewAllHistory}
          />
        )}

        {activeScreen === "share" && (
          <ShareScreen
            referralLink={referralLink}
            referralCode={referralCode}
            peopleReferred={referral.total_referrals}
            totalEarnings={referral.total_earnings}
          />
        )}

        {activeScreen === "profile" && (
          <ProfileScreen
            userName={userName}
            walletAddress={walletAddress}
            onChangeWallet={handleChangeWallet}
            onSupport={handleSupport}
            onLogout={handleLogout}
          />
        )}

        {activeScreen === "withdrawal-history" && (
          <WithdrawalHistoryScreen onBack={() => setActiveScreen("wallet")} />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />

      {/* Modals */}
      <AddMoneyModal
        isOpen={isAddMoneyOpen}
        onClose={() => setIsAddMoneyOpen(false)}
        onConfirm={handleAddMoney}
      />

      <WithdrawModal
        isOpen={isWithdrawOpen}
        onClose={() => setIsWithdrawOpen(false)}
        availableBalance={wallet.available_balance}
        onConfirm={handleWithdraw}
      />
    </div>
  );
};

export default Index;
