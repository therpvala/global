import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ProcessDepositRequest {
  user_id: string;
  amount: number;
  tx_hash?: string;
  description?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    // Verify authorization
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      console.error("Missing or invalid authorization header");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Create admin client for database operations
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    // Create user client to verify the caller
    const supabaseUser = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    // Verify user and check admin role
    const token = authHeader.replace("Bearer ", "");
    const { data: claimsData, error: claimsError } = await supabaseUser.auth.getClaims(token);
    
    if (claimsError || !claimsData?.claims) {
      console.error("Claims verification failed:", claimsError);
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const adminUserId = claimsData.claims.sub;
    console.log("Admin user ID:", adminUserId);

    // Check if user is admin
    const { data: roleData, error: roleError } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", adminUserId)
      .in("role", ["admin", "super_admin"]);

    if (roleError || !roleData || roleData.length === 0) {
      console.error("Admin role check failed:", roleError);
      return new Response(
        JSON.stringify({ error: "Admin access required" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Admin verified, processing deposit...");

    // Parse request body
    const body: ProcessDepositRequest = await req.json();
    const { user_id, amount, tx_hash, description } = body;

    // Validate input
    if (!user_id || !amount || amount <= 0) {
      console.error("Invalid input:", { user_id, amount });
      return new Response(
        JSON.stringify({ error: "Invalid input: user_id and positive amount required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Processing deposit for user:", user_id, "amount:", amount);

    // Get user's wallet
    const { data: wallet, error: walletError } = await supabaseAdmin
      .from("wallets")
      .select("id, available_balance, total_deposited")
      .eq("user_id", user_id)
      .single();

    if (walletError || !wallet) {
      console.error("Wallet not found:", walletError);
      return new Response(
        JSON.stringify({ error: "User wallet not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Found wallet:", wallet.id);

    // Create completed deposit transaction
    // This will trigger the commission distribution via the database trigger
    const { data: transaction, error: txError } = await supabaseAdmin
      .from("transactions")
      .insert({
        user_id,
        wallet_id: wallet.id,
        type: "deposit",
        amount,
        status: "completed",
        description: description || `USDT Deposit${tx_hash ? ` (TxHash: ${tx_hash})` : ""}`,
        reference_id: tx_hash || null,
      })
      .select()
      .single();

    if (txError) {
      console.error("Transaction creation failed:", txError);
      return new Response(
        JSON.stringify({ error: "Failed to create transaction", details: txError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Transaction created:", transaction.id);

    // Update wallet balance
    const newBalance = Number(wallet.available_balance) + amount;
    const newTotalDeposited = Number(wallet.total_deposited) + amount;

    const { error: updateError } = await supabaseAdmin
      .from("wallets")
      .update({
        available_balance: newBalance,
        total_deposited: newTotalDeposited,
        updated_at: new Date().toISOString(),
      })
      .eq("id", wallet.id);

    if (updateError) {
      console.error("Wallet update failed:", updateError);
      return new Response(
        JSON.stringify({ error: "Failed to update wallet balance", details: updateError.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log("Wallet updated, new balance:", newBalance);

    // Log admin action
    await supabaseAdmin.from("admin_actions").insert({
      admin_id: adminUserId,
      action: "processed_deposit",
      reference_id: `${user_id}:${amount}:${transaction.id}`,
    });

    console.log("Deposit processed successfully");

    return new Response(
      JSON.stringify({
        success: true,
        transaction_id: transaction.id,
        new_balance: newBalance,
        message: `Successfully deposited $${amount} for user. Commission distribution triggered.`,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Unexpected error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error", details: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
