-- Create admin_actions table for logging admin activities
CREATE TABLE public.admin_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid NOT NULL,
  action text NOT NULL,
  reference_id text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_actions ENABLE ROW LEVEL SECURITY;

-- Only admins can view and manage admin actions
CREATE POLICY "Admins can manage admin actions"
ON public.admin_actions
FOR ALL
USING (is_admin(auth.uid()));

CREATE POLICY "Admins can insert admin actions"
ON public.admin_actions
FOR INSERT
WITH CHECK (is_admin(auth.uid()));