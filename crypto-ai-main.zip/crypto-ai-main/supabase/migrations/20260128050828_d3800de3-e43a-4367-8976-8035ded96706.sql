-- Enable realtime for commissions table
ALTER PUBLICATION supabase_realtime ADD TABLE public.commissions;