-- Create user_sessions table for device security
CREATE TABLE public.user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  device_id text NOT NULL,
  device_info jsonb DEFAULT '{}'::jsonb,
  ip_address text,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  last_activity_at timestamp with time zone DEFAULT now(),
  expires_at timestamp with time zone DEFAULT (now() + interval '24 hours')
);

-- Create index for fast lookups
CREATE INDEX idx_user_sessions_user_id ON public.user_sessions(user_id);
CREATE INDEX idx_user_sessions_device_id ON public.user_sessions(device_id);

-- Enable RLS
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

-- Users can view their own sessions
CREATE POLICY "Users can view own sessions"
ON public.user_sessions FOR SELECT
USING (user_id = auth.uid());

-- Admins can manage all sessions
CREATE POLICY "Admins can manage sessions"
ON public.user_sessions FOR ALL
USING (is_admin(auth.uid()));

-- Create rate_limits table for tracking API calls
CREATE TABLE public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  action_type text NOT NULL,
  request_count integer DEFAULT 1,
  window_start timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now()
);

-- Create index for rate limit lookups
CREATE INDEX idx_rate_limits_lookup ON public.rate_limits(user_id, action_type, window_start);

-- Enable RLS
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

-- Only system can manage rate limits
CREATE POLICY "System manages rate limits"
ON public.rate_limits FOR ALL
USING (is_admin(auth.uid()));

-- Create wallet_change_logs table
CREATE TABLE public.wallet_change_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  old_wallet_address text,
  new_wallet_address text NOT NULL,
  changed_at timestamp with time zone DEFAULT now(),
  cooldown_expires_at timestamp with time zone
);

-- Enable RLS
ALTER TABLE public.wallet_change_logs ENABLE ROW LEVEL SECURITY;

-- Users can view own wallet changes
CREATE POLICY "Users can view own wallet changes"
ON public.wallet_change_logs FOR SELECT
USING (user_id = auth.uid());

-- Admins can manage wallet changes
CREATE POLICY "Admins can manage wallet changes"
ON public.wallet_change_logs FOR ALL
USING (is_admin(auth.uid()));

-- Function to check if platform is active
CREATE OR REPLACE FUNCTION public.is_platform_active()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT value = 'active' FROM public.platform_settings WHERE key = 'platform_status'),
    true
  )
$$;

-- Function to check user withdraw eligibility
CREATE OR REPLACE FUNCTION public.can_user_withdraw(_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
  user_active boolean;
  platform_active boolean;
  min_amount numeric;
  max_daily numeric;
  today_withdrawn numeric;
  cooldown_days integer;
  last_wallet_change timestamp with time zone;
  wallet_cooldown_end timestamp with time zone;
BEGIN
  -- Check platform status
  SELECT public.is_platform_active() INTO platform_active;
  IF NOT platform_active THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'Platform is in maintenance mode');
  END IF;

  -- Check user status
  SELECT is_active INTO user_active FROM public.profiles WHERE user_id = _user_id;
  IF NOT user_active THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'Your account is blocked');
  END IF;

  -- Get settings
  SELECT COALESCE((SELECT value::numeric FROM public.platform_settings WHERE key = 'min_withdraw_amount'), 10) INTO min_amount;
  SELECT COALESCE((SELECT value::numeric FROM public.platform_settings WHERE key = 'max_withdraw_per_day'), 10000) INTO max_daily;
  SELECT COALESCE((SELECT value::integer FROM public.platform_settings WHERE key = 'wallet_change_cooldown'), 7) INTO cooldown_days;

  -- Check today's withdrawals
  SELECT COALESCE(SUM(amount), 0) INTO today_withdrawn
  FROM public.withdrawals
  WHERE user_id = _user_id
    AND status IN ('pending', 'approved', 'completed')
    AND created_at >= CURRENT_DATE;

  -- Check wallet cooldown
  SELECT changed_at INTO last_wallet_change
  FROM public.wallet_change_logs
  WHERE user_id = _user_id
  ORDER BY changed_at DESC
  LIMIT 1;

  IF last_wallet_change IS NOT NULL THEN
    wallet_cooldown_end := last_wallet_change + (cooldown_days || ' days')::interval;
    IF wallet_cooldown_end > now() THEN
      RETURN jsonb_build_object(
        'allowed', false, 
        'reason', 'Wallet cooldown active until ' || to_char(wallet_cooldown_end, 'Mon DD, YYYY'),
        'cooldown_ends', wallet_cooldown_end
      );
    END IF;
  END IF;

  RETURN jsonb_build_object(
    'allowed', true,
    'min_amount', min_amount,
    'max_daily', max_daily,
    'today_withdrawn', today_withdrawn,
    'remaining_daily', GREATEST(0, max_daily - today_withdrawn)
  );
END;
$$;

-- Function to register/validate device session
CREATE OR REPLACE FUNCTION public.manage_device_session(_user_id uuid, _device_id text, _device_info jsonb DEFAULT '{}', _ip_address text DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_session record;
  new_session_id uuid;
BEGIN
  -- Check for existing active session with different device
  SELECT * INTO existing_session
  FROM public.user_sessions
  WHERE user_id = _user_id
    AND is_active = true
    AND device_id != _device_id
    AND expires_at > now()
  LIMIT 1;

  -- If found, deactivate old session (one device policy)
  IF existing_session IS NOT NULL THEN
    UPDATE public.user_sessions
    SET is_active = false
    WHERE id = existing_session.id;
  END IF;

  -- Check for existing session on this device
  SELECT * INTO existing_session
  FROM public.user_sessions
  WHERE user_id = _user_id
    AND device_id = _device_id
    AND is_active = true
    AND expires_at > now()
  LIMIT 1;

  IF existing_session IS NOT NULL THEN
    -- Update last activity
    UPDATE public.user_sessions
    SET last_activity_at = now(),
        expires_at = now() + interval '24 hours'
    WHERE id = existing_session.id;
    
    RETURN jsonb_build_object('session_id', existing_session.id, 'status', 'refreshed');
  ELSE
    -- Create new session
    INSERT INTO public.user_sessions (user_id, device_id, device_info, ip_address)
    VALUES (_user_id, _device_id, _device_info, _ip_address)
    RETURNING id INTO new_session_id;
    
    RETURN jsonb_build_object('session_id', new_session_id, 'status', 'created');
  END IF;
END;
$$;

-- Function to check rate limit
CREATE OR REPLACE FUNCTION public.check_rate_limit(_user_id uuid, _action text, _max_requests integer, _window_minutes integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_count integer;
  window_start_time timestamp with time zone;
BEGIN
  window_start_time := now() - (_window_minutes || ' minutes')::interval;
  
  -- Count requests in window
  SELECT COALESCE(SUM(request_count), 0) INTO current_count
  FROM public.rate_limits
  WHERE user_id = _user_id
    AND action_type = _action
    AND window_start >= window_start_time;

  IF current_count >= _max_requests THEN
    RETURN jsonb_build_object('allowed', false, 'reason', 'Rate limit exceeded. Please wait.', 'retry_after', _window_minutes);
  END IF;

  -- Log this request
  INSERT INTO public.rate_limits (user_id, action_type, window_start)
  VALUES (_user_id, _action, now());

  -- Clean old entries
  DELETE FROM public.rate_limits
  WHERE window_start < now() - interval '1 hour';

  RETURN jsonb_build_object('allowed', true, 'remaining', _max_requests - current_count - 1);
END;
$$;