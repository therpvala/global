-- Seed default generation rates (10 levels)
INSERT INTO public.generation_rates (generation_level, percentage, is_active, min_team_size)
VALUES 
  (1, 10.00, true, 0),
  (2, 5.00, true, 0),
  (3, 3.00, true, 0),
  (4, 2.00, true, 0),
  (5, 1.00, true, 0),
  (6, 0.50, true, 0),
  (7, 0.50, true, 0),
  (8, 0.50, true, 0),
  (9, 0.50, true, 0),
  (10, 0.50, true, 0)
ON CONFLICT DO NOTHING;

-- Create function to distribute commissions
CREATE OR REPLACE FUNCTION public.distribute_commissions(
  _transaction_id uuid,
  _from_user_id uuid,
  _amount numeric
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  upline_record RECORD;
  rate_record RECORD;
  commission_amount numeric;
  user_wallet_id uuid;
BEGIN
  -- Loop through each upline member
  FOR upline_record IN 
    SELECT * FROM public.get_upline(_from_user_id, 10)
  LOOP
    -- Get the commission rate for this generation level
    SELECT * INTO rate_record 
    FROM public.generation_rates 
    WHERE generation_level = upline_record.generation_level 
      AND is_active = true;
    
    -- Skip if no rate found for this level
    IF rate_record IS NULL THEN
      CONTINUE;
    END IF;
    
    -- Calculate commission amount
    commission_amount := (_amount * rate_record.percentage) / 100;
    
    -- Skip if commission is zero or negative
    IF commission_amount <= 0 THEN
      CONTINUE;
    END IF;
    
    -- Get the upline user's wallet
    SELECT id INTO user_wallet_id 
    FROM public.wallets 
    WHERE user_id = upline_record.user_id;
    
    -- Skip if wallet not found
    IF user_wallet_id IS NULL THEN
      CONTINUE;
    END IF;
    
    -- Create commission record
    INSERT INTO public.commissions (
      user_id,
      from_user_id,
      transaction_id,
      generation_level,
      percentage,
      amount,
      status
    ) VALUES (
      upline_record.user_id,
      _from_user_id,
      _transaction_id,
      upline_record.generation_level,
      rate_record.percentage,
      commission_amount,
      'completed'
    );
    
    -- Update upline user's wallet balance
    UPDATE public.wallets
    SET 
      available_balance = available_balance + commission_amount,
      total_earned = total_earned + commission_amount,
      updated_at = now()
    WHERE id = user_wallet_id;
    
    -- Create transaction record for the commission
    INSERT INTO public.transactions (
      user_id,
      wallet_id,
      type,
      amount,
      status,
      description,
      reference_id
    ) VALUES (
      upline_record.user_id,
      user_wallet_id,
      'commission',
      commission_amount,
      'completed',
      'Level ' || upline_record.generation_level || ' commission',
      _transaction_id::text
    );
  END LOOP;
END;
$$;

-- Create trigger function for automatic commission distribution on deposit
CREATE OR REPLACE FUNCTION public.trigger_commission_distribution()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only trigger on completed deposits
  IF NEW.type = 'deposit' AND NEW.status = 'completed' AND 
     (OLD IS NULL OR OLD.status != 'completed') THEN
    -- Distribute commissions to upline
    PERFORM public.distribute_commissions(NEW.id, NEW.user_id, NEW.amount);
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger on transactions table
DROP TRIGGER IF EXISTS on_deposit_distribute_commissions ON public.transactions;
CREATE TRIGGER on_deposit_distribute_commissions
  AFTER INSERT OR UPDATE ON public.transactions
  FOR EACH ROW
  EXECUTE FUNCTION public.trigger_commission_distribution();

-- Add mlm_config default settings
INSERT INTO public.mlm_config (key, value, description)
VALUES 
  ('max_generations', '10', 'Maximum number of generations for commission distribution'),
  ('min_deposit_for_commission', '100', 'Minimum deposit amount to trigger commissions'),
  ('commission_enabled', 'true', 'Whether commission distribution is enabled'),
  ('instant_payout', 'true', 'Whether commissions are paid instantly or require approval')
ON CONFLICT (key) DO NOTHING;