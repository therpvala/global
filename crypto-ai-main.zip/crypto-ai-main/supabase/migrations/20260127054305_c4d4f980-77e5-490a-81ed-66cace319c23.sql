-- ============================================
-- COMPLETE ERD: CRYPTO MLM + FOREX AI TRADING PLATFORM
-- ============================================

-- 1. CUSTOM TYPES (ENUMS)
-- ============================================

-- User roles enum
CREATE TYPE public.app_role AS ENUM ('super_admin', 'admin', 'partner', 'user');

-- Transaction types
CREATE TYPE public.transaction_type AS ENUM ('deposit', 'withdrawal', 'profit', 'commission', 'bonus', 'fee');

-- Transaction status
CREATE TYPE public.transaction_status AS ENUM ('pending', 'processing', 'completed', 'failed', 'cancelled');

-- KYC status
CREATE TYPE public.kyc_status AS ENUM ('pending', 'submitted', 'verified', 'rejected');

-- Withdrawal status
CREATE TYPE public.withdrawal_status AS ENUM ('pending', 'approved', 'processing', 'completed', 'rejected');

-- Trade status
CREATE TYPE public.trade_status AS ENUM ('open', 'closed', 'cancelled');

-- ============================================
-- 2. CORE TABLES
-- ============================================

-- PROFILES TABLE (User identity & basic info)
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    full_name TEXT,
    email TEXT,
    phone TEXT,
    avatar_url TEXT,
    wallet_address TEXT,
    kyc_status public.kyc_status DEFAULT 'pending',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- USER ROLES TABLE (Separate for security)
CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role public.app_role NOT NULL DEFAULT 'user',
    assigned_by UUID REFERENCES auth.users(id),
    assigned_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(user_id, role)
);

-- WALLETS TABLE
CREATE TABLE public.wallets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    available_balance DECIMAL(20, 2) DEFAULT 0.00,
    locked_balance DECIMAL(20, 2) DEFAULT 0.00,
    total_deposited DECIMAL(20, 2) DEFAULT 0.00,
    total_withdrawn DECIMAL(20, 2) DEFAULT 0.00,
    total_earned DECIMAL(20, 2) DEFAULT 0.00,
    currency TEXT DEFAULT 'USDT',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- TRANSACTIONS TABLE
CREATE TABLE public.transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    wallet_id UUID REFERENCES public.wallets(id) ON DELETE CASCADE NOT NULL,
    type public.transaction_type NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    fee DECIMAL(20, 2) DEFAULT 0.00,
    status public.transaction_status DEFAULT 'pending',
    description TEXT,
    reference_id TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- REFERRALS TABLE (MLM Tree Structure)
CREATE TABLE public.referrals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    parent_id UUID REFERENCES auth.users(id),
    referral_code TEXT NOT NULL UNIQUE,
    generation_level INT DEFAULT 1,
    total_referrals INT DEFAULT 0,
    total_team_size INT DEFAULT 0,
    is_partner BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- COMMISSIONS TABLE
CREATE TABLE public.commissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    from_user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    transaction_id UUID REFERENCES public.transactions(id) ON DELETE SET NULL,
    generation_level INT NOT NULL,
    percentage DECIMAL(5, 2) NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    status public.transaction_status DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT now()
);

-- WITHDRAWALS TABLE
CREATE TABLE public.withdrawals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    wallet_id UUID REFERENCES public.wallets(id) ON DELETE CASCADE NOT NULL,
    amount DECIMAL(20, 2) NOT NULL,
    fee DECIMAL(20, 2) DEFAULT 0.00,
    net_amount DECIMAL(20, 2) NOT NULL,
    wallet_address TEXT NOT NULL,
    status public.withdrawal_status DEFAULT 'pending',
    processed_by UUID REFERENCES auth.users(id),
    processed_at TIMESTAMPTZ,
    rejection_reason TEXT,
    tx_hash TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- AI TRADES TABLE
CREATE TABLE public.ai_trades (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trade_pair TEXT NOT NULL,
    trade_type TEXT NOT NULL,
    entry_price DECIMAL(20, 8) NOT NULL,
    exit_price DECIMAL(20, 8),
    capital_used DECIMAL(20, 2) NOT NULL,
    profit_loss DECIMAL(20, 2) DEFAULT 0.00,
    profit_percentage DECIMAL(10, 4) DEFAULT 0.00,
    status public.trade_status DEFAULT 'open',
    opened_at TIMESTAMPTZ DEFAULT now(),
    closed_at TIMESTAMPTZ,
    metadata JSONB DEFAULT '{}'
);

-- MLM CONFIGURATION TABLE
CREATE TABLE public.mlm_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT NOT NULL UNIQUE,
    value JSONB NOT NULL,
    description TEXT,
    updated_by UUID REFERENCES auth.users(id),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- GENERATION RATES TABLE (MLM Commission Rates per Level)
CREATE TABLE public.generation_rates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    generation_level INT NOT NULL UNIQUE CHECK (generation_level >= 1 AND generation_level <= 20),
    percentage DECIMAL(5, 2) NOT NULL CHECK (percentage >= 0 AND percentage <= 100),
    min_team_size INT DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- PLATFORM SETTINGS TABLE
CREATE TABLE public.platform_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    description TEXT,
    updated_by UUID REFERENCES auth.users(id),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- SUPPORT TICKETS TABLE
CREATE TABLE public.support_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'open',
    priority TEXT DEFAULT 'normal',
    assigned_to UUID REFERENCES auth.users(id),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- ============================================
-- 3. DATABASE FUNCTIONS
-- ============================================

-- Function to check user role (Security Definer to avoid RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_roles
        WHERE user_id = _user_id
          AND role = _role
    )
$$;

-- Function to check if user is admin or super_admin
CREATE OR REPLACE FUNCTION public.is_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.user_roles
        WHERE user_id = _user_id
          AND role IN ('admin', 'super_admin')
    )
$$;

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
AS $$
DECLARE
    chars TEXT := 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    result TEXT := '';
    i INT;
BEGIN
    FOR i IN 1..8 LOOP
        result := result || substr(chars, floor(random() * length(chars) + 1)::INT, 1);
    END LOOP;
    RETURN result;
END;
$$;

-- Function to get upline chain (recursive)
CREATE OR REPLACE FUNCTION public.get_upline(_user_id UUID, _max_levels INT DEFAULT 10)
RETURNS TABLE(user_id UUID, generation_level INT)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    RETURN QUERY
    WITH RECURSIVE upline AS (
        SELECT r.parent_id AS uid, 1 AS gen
        FROM public.referrals r
        WHERE r.user_id = _user_id AND r.parent_id IS NOT NULL
        
        UNION ALL
        
        SELECT r.parent_id, u.gen + 1
        FROM public.referrals r
        INNER JOIN upline u ON r.user_id = u.uid
        WHERE r.parent_id IS NOT NULL AND u.gen < _max_levels
    )
    SELECT uid, gen FROM upline;
END;
$$;

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    ref_code TEXT;
BEGIN
    -- Generate unique referral code
    LOOP
        ref_code := public.generate_referral_code();
        EXIT WHEN NOT EXISTS (SELECT 1 FROM public.referrals WHERE referral_code = ref_code);
    END LOOP;

    -- Create profile
    INSERT INTO public.profiles (user_id, email, full_name)
    VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)));

    -- Create wallet
    INSERT INTO public.wallets (user_id)
    VALUES (NEW.id);

    -- Create referral entry
    INSERT INTO public.referrals (user_id, referral_code)
    VALUES (NEW.id, ref_code);

    -- Assign default user role
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'user');

    RETURN NEW;
END;
$$;

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;

-- ============================================
-- 4. TRIGGERS
-- ============================================

-- Trigger: Auto-create profile, wallet, referral on user signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- Trigger: Update timestamps on profiles
CREATE TRIGGER update_profiles_timestamp
    BEFORE UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- Trigger: Update timestamps on wallets
CREATE TRIGGER update_wallets_timestamp
    BEFORE UPDATE ON public.wallets
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- Trigger: Update timestamps on transactions
CREATE TRIGGER update_transactions_timestamp
    BEFORE UPDATE ON public.transactions
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- Trigger: Update timestamps on withdrawals
CREATE TRIGGER update_withdrawals_timestamp
    BEFORE UPDATE ON public.withdrawals
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at();

-- ============================================
-- 5. ROW LEVEL SECURITY (RLS)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mlm_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.generation_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;

-- PROFILES POLICIES
CREATE POLICY "Users can view own profile"
    ON public.profiles FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Admins can view all profiles"
    ON public.profiles FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update all profiles"
    ON public.profiles FOR UPDATE
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- USER ROLES POLICIES
CREATE POLICY "Users can view own roles"
    ON public.user_roles FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Admins can view all roles"
    ON public.user_roles FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage roles"
    ON public.user_roles FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- WALLETS POLICIES
CREATE POLICY "Users can view own wallet"
    ON public.wallets FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Admins can view all wallets"
    ON public.wallets FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can update wallets"
    ON public.wallets FOR UPDATE
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- TRANSACTIONS POLICIES
CREATE POLICY "Users can view own transactions"
    ON public.transactions FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Users can create own transactions"
    ON public.transactions FOR INSERT
    TO authenticated
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all transactions"
    ON public.transactions FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage transactions"
    ON public.transactions FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- REFERRALS POLICIES
CREATE POLICY "Users can view own referral"
    ON public.referrals FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Partners can view downline referrals"
    ON public.referrals FOR SELECT
    TO authenticated
    USING (parent_id = auth.uid());

CREATE POLICY "Admins can view all referrals"
    ON public.referrals FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage referrals"
    ON public.referrals FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- COMMISSIONS POLICIES
CREATE POLICY "Users can view own commissions"
    ON public.commissions FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Admins can view all commissions"
    ON public.commissions FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage commissions"
    ON public.commissions FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- WITHDRAWALS POLICIES
CREATE POLICY "Users can view own withdrawals"
    ON public.withdrawals FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Users can create own withdrawals"
    ON public.withdrawals FOR INSERT
    TO authenticated
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all withdrawals"
    ON public.withdrawals FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage withdrawals"
    ON public.withdrawals FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- AI TRADES POLICIES (Viewable by all authenticated users)
CREATE POLICY "Authenticated users can view trades"
    ON public.ai_trades FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Admins can manage trades"
    ON public.ai_trades FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- MLM CONFIG POLICIES (Admin only)
CREATE POLICY "Admins can view mlm config"
    ON public.mlm_config FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage mlm config"
    ON public.mlm_config FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- GENERATION RATES POLICIES
CREATE POLICY "Authenticated can view generation rates"
    ON public.generation_rates FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Admins can manage generation rates"
    ON public.generation_rates FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- PLATFORM SETTINGS POLICIES
CREATE POLICY "Authenticated can view settings"
    ON public.platform_settings FOR SELECT
    TO authenticated
    USING (true);

CREATE POLICY "Admins can manage settings"
    ON public.platform_settings FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- SUPPORT TICKETS POLICIES
CREATE POLICY "Users can view own tickets"
    ON public.support_tickets FOR SELECT
    TO authenticated
    USING (user_id = auth.uid());

CREATE POLICY "Users can create own tickets"
    ON public.support_tickets FOR INSERT
    TO authenticated
    WITH CHECK (user_id = auth.uid());

CREATE POLICY "Admins can view all tickets"
    ON public.support_tickets FOR SELECT
    TO authenticated
    USING (public.is_admin(auth.uid()));

CREATE POLICY "Admins can manage tickets"
    ON public.support_tickets FOR ALL
    TO authenticated
    USING (public.is_admin(auth.uid()));

-- ============================================
-- 6. INITIAL DATA (MLM Generation Rates)
-- ============================================

INSERT INTO public.generation_rates (generation_level, percentage, min_team_size, is_active) VALUES
    (1, 10.00, 0, true),
    (2, 5.00, 3, true),
    (3, 3.00, 5, true),
    (4, 2.00, 10, true),
    (5, 1.50, 15, true),
    (6, 1.00, 20, true),
    (7, 0.75, 30, true),
    (8, 0.50, 50, true),
    (9, 0.25, 75, true),
    (10, 0.25, 100, true);

-- Default platform settings
INSERT INTO public.platform_settings (key, value, category, description) VALUES
    ('min_deposit', '100', 'wallet', 'Minimum deposit amount in USDT'),
    ('max_deposit', '100000', 'wallet', 'Maximum deposit amount in USDT'),
    ('min_withdrawal', '50', 'wallet', 'Minimum withdrawal amount in USDT'),
    ('max_withdrawal', '50000', 'wallet', 'Maximum daily withdrawal limit'),
    ('withdrawal_fee', '2', 'wallet', 'Withdrawal fee percentage'),
    ('ai_trading_enabled', 'true', 'trading', 'Enable AI trading system'),
    ('daily_profit_rate', '1.5', 'trading', 'Expected daily profit rate percentage'),
    ('platform_name', 'CryptoAI', 'general', 'Platform name'),
    ('support_email', 'support@cryptoai.com', 'general', 'Support email address');

-- Default MLM configuration
INSERT INTO public.mlm_config (key, value, description) VALUES
    ('max_generations', '10', 'Maximum MLM generation levels'),
    ('min_team_for_partner', '5', 'Minimum team size to become partner'),
    ('commission_distribution', '"auto"', 'Commission distribution mode: auto or manual');