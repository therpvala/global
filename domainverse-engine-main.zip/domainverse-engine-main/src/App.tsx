import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { AuthProvider } from "@/hooks/useAuth";
import ProtectedRoute from "@/components/ProtectedRoute";
import RoleBasedRoute from "@/components/RoleBasedRoute";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import Marketplace from "./pages/Marketplace";
import AddDomain from "./pages/AddDomain";
import Wallet from "./pages/Wallet";
import Auctions from "./pages/Auctions";
import AuctionDetail from "./pages/AuctionDetail";
import CreateAuction from "./pages/CreateAuction";
import DomainDetail from "./pages/DomainDetail";
import Watchlist from "./pages/Watchlist";
import Parking from "./pages/Parking";
import NotFound from "./pages/NotFound";
import Investors from "./pages/Investors";
import Settings from "./pages/Settings";
// Admin pages
import AdminDashboardNew from "./pages/admin/AdminDashboardNew";
import AdminUsersNew from "./pages/admin/AdminUsersNew";
import AdminDomains from "./pages/admin/AdminDomains";
import AdminAuctions from "./pages/admin/AdminAuctions";
import AdminInvestors from "./pages/admin/AdminInvestors";
import AdminExperts from "./pages/admin/AdminExperts";
import AdminPayments from "./pages/admin/AdminPayments";
import AdminParking from "./pages/admin/AdminParking";
import AdminReports from "./pages/admin/AdminReports";
import AdminSecurity from "./pages/admin/AdminSecurity";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminLogs from "./pages/admin/AdminLogs";
import AdminDomainHealth from "./pages/admin/AdminDomainHealth";
import AdminDomainValuation from "./pages/admin/AdminDomainValuation";
import AdminDomainOwnership from "./pages/admin/AdminDomainOwnership";
// Role dashboards
import InvestorDashboard from "./pages/investor/InvestorDashboard";
import ExpertDashboard from "./pages/expert/ExpertDashboard";
import ResellerDashboard from "./pages/reseller/ResellerDashboard";
import FranchiseDashboard from "./pages/franchise/FranchiseDashboard";
import BuyerDashboard from "./pages/buyer/BuyerDashboard";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={<Auth />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDashboardNew />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/users"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminUsersNew />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/domains"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDomains />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/domains/:filter"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDomains />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/domains/health"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDomainHealth />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/domains/valuation"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDomainValuation />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/domains/ownership"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminDomainOwnership />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/auctions"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminAuctions />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/auctions/:filter"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminAuctions />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/investors"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminInvestors />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/investors/:section"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminInvestors />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/experts"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminExperts />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/experts/:section"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminExperts />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/payments"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminPayments />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/payments/:section"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminPayments />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/parking"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminParking />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/reports"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminReports />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/security"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminSecurity />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/settings"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminSettings />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/admin/logs"
                element={
                  <RoleBasedRoute allowedRoles={["admin"]}>
                    <AdminLogs />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/investor"
                element={
                  <RoleBasedRoute allowedRoles={["investor", "admin"]}>
                    <InvestorDashboard />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/expert"
                element={
                  <RoleBasedRoute allowedRoles={["expert", "admin"]}>
                    <ExpertDashboard />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/reseller"
                element={
                  <RoleBasedRoute allowedRoles={["reseller", "admin"]}>
                    <ResellerDashboard />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/franchise"
                element={
                  <RoleBasedRoute allowedRoles={["franchise", "admin"]}>
                    <FranchiseDashboard />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/buyer"
                element={
                  <RoleBasedRoute allowedRoles={["buyer", "admin"]}>
                    <BuyerDashboard />
                  </RoleBasedRoute>
                }
              />
              <Route
                path="/profile"
                element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                }
              />
              <Route path="/marketplace" element={<Marketplace />} />
              <Route
                path="/add-domain"
                element={
                  <ProtectedRoute>
                    <AddDomain />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/wallet"
                element={
                  <ProtectedRoute>
                    <Wallet />
                  </ProtectedRoute>
                }
              />
              <Route path="/auctions" element={<Auctions />} />
              <Route
                path="/settings"
                element={
                  <ProtectedRoute>
                    <Settings />
                  </ProtectedRoute>
                }
              />
              <Route path="/parking" element={<Parking />} />
              <Route path="/investors" element={<Investors />} />
              <Route path="/auction/:id" element={<AuctionDetail />} />
              <Route path="/domain/:id" element={<DomainDetail />} />
              <Route
                path="/create-auction"
                element={
                  <ProtectedRoute>
                    <CreateAuction />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/watchlist"
                element={
                  <ProtectedRoute>
                    <Watchlist />
                  </ProtectedRoute>
                }
              />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;