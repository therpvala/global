export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          created_at: string
          entity_id: string | null
          entity_name: string | null
          entity_type: string
          id: string
          ip_address: string | null
          metadata: Json | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          entity_id?: string | null
          entity_name?: string | null
          entity_type: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          entity_id?: string | null
          entity_name?: string | null
          entity_type?: string
          id?: string
          ip_address?: string | null
          metadata?: Json | null
          user_id?: string | null
        }
        Relationships: []
      }
      auctions: {
        Row: {
          buy_now_price: number | null
          created_at: string
          current_bid: number
          current_bidder_id: string | null
          domain_id: string
          end_time: string
          id: string
          min_bid_increment: number
          seller_id: string
          start_time: string
          starting_price: number
          status: string
          updated_at: string
        }
        Insert: {
          buy_now_price?: number | null
          created_at?: string
          current_bid?: number
          current_bidder_id?: string | null
          domain_id: string
          end_time: string
          id?: string
          min_bid_increment?: number
          seller_id: string
          start_time?: string
          starting_price?: number
          status?: string
          updated_at?: string
        }
        Update: {
          buy_now_price?: number | null
          created_at?: string
          current_bid?: number
          current_bidder_id?: string | null
          domain_id?: string
          end_time?: string
          id?: string
          min_bid_increment?: number
          seller_id?: string
          start_time?: string
          starting_price?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "auctions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "auctions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      bids: {
        Row: {
          amount: number
          auction_id: string
          created_at: string
          id: string
          is_auto: boolean | null
          user_id: string
        }
        Insert: {
          amount: number
          auction_id: string
          created_at?: string
          id?: string
          is_auto?: boolean | null
          user_id: string
        }
        Update: {
          amount?: number
          auction_id?: string
          created_at?: string
          id?: string
          is_auto?: boolean | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bids_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "auctions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bids_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "public_auctions"
            referencedColumns: ["id"]
          },
        ]
      }
      domain_health: {
        Row: {
          blacklist_status: string
          created_at: string
          dns_status: string
          domain_id: string
          id: string
          last_check_at: string | null
          ssl_status: string
          updated_at: string
        }
        Insert: {
          blacklist_status?: string
          created_at?: string
          dns_status?: string
          domain_id: string
          id?: string
          last_check_at?: string | null
          ssl_status?: string
          updated_at?: string
        }
        Update: {
          blacklist_status?: string
          created_at?: string
          dns_status?: string
          domain_id?: string
          id?: string
          last_check_at?: string | null
          ssl_status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "domain_health_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: true
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "domain_health_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: true
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      domain_watchlist: {
        Row: {
          created_at: string
          domain_id: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          domain_id: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          domain_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "domain_watchlist_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "domain_watchlist_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      domains: {
        Row: {
          category: string
          created_at: string
          description: string | null
          domain_name: string
          expiration_date: string | null
          health_score: number | null
          id: string
          price: number
          status: string
          title: string
          updated_at: string
          user_id: string
        }
        Insert: {
          category?: string
          created_at?: string
          description?: string | null
          domain_name: string
          expiration_date?: string | null
          health_score?: number | null
          id?: string
          price: number
          status?: string
          title: string
          updated_at?: string
          user_id: string
        }
        Update: {
          category?: string
          created_at?: string
          description?: string | null
          domain_name?: string
          expiration_date?: string | null
          health_score?: number | null
          id?: string
          price?: number
          status?: string
          title?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      escrow: {
        Row: {
          amount: number
          buyer_id: string
          created_at: string
          domain_id: string
          id: string
          released_at: string | null
          seller_id: string
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          buyer_id: string
          created_at?: string
          domain_id: string
          id?: string
          released_at?: string | null
          seller_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          buyer_id?: string
          created_at?: string
          domain_id?: string
          id?: string
          released_at?: string | null
          seller_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "escrow_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "escrow_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      expert_suggestions: {
        Row: {
          created_at: string
          domain_id: string
          expert_id: string
          id: string
          notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          suggested_price: number | null
          suggestion_type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          domain_id: string
          expert_id: string
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          suggested_price?: number | null
          suggestion_type?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          domain_id?: string
          expert_id?: string
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          suggested_price?: number | null
          suggestion_type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "expert_suggestions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expert_suggestions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "expert_suggestions_expert_id_fkey"
            columns: ["expert_id"]
            isOneToOne: false
            referencedRelation: "experts"
            referencedColumns: ["id"]
          },
        ]
      }
      experts: {
        Row: {
          approved_suggestions: number
          commission_rate: number
          created_at: string
          id: string
          rating: number
          status: string
          success_rate: number
          total_suggestions: number
          updated_at: string
          user_id: string
        }
        Insert: {
          approved_suggestions?: number
          commission_rate?: number
          created_at?: string
          id?: string
          rating?: number
          status?: string
          success_rate?: number
          total_suggestions?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          approved_suggestions?: number
          commission_rate?: number
          created_at?: string
          id?: string
          rating?: number
          status?: string
          success_rate?: number
          total_suggestions?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      fraud_alerts: {
        Row: {
          alert_type: string
          auction_id: string | null
          bid_id: string | null
          confidence_score: number
          created_at: string
          description: string
          id: string
          patterns_detected: Json | null
          reviewed_at: string | null
          reviewed_by: string | null
          severity: string
          status: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          alert_type: string
          auction_id?: string | null
          bid_id?: string | null
          confidence_score?: number
          created_at?: string
          description: string
          id?: string
          patterns_detected?: Json | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          severity?: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          alert_type?: string
          auction_id?: string | null
          bid_id?: string | null
          confidence_score?: number
          created_at?: string
          description?: string
          id?: string
          patterns_detected?: Json | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          severity?: string
          status?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fraud_alerts_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "auctions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fraud_alerts_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "public_auctions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fraud_alerts_bid_id_fkey"
            columns: ["bid_id"]
            isOneToOne: false
            referencedRelation: "bids"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fraud_alerts_bid_id_fkey"
            columns: ["bid_id"]
            isOneToOne: false
            referencedRelation: "public_bids"
            referencedColumns: ["id"]
          },
        ]
      }
      investments: {
        Row: {
          amount: number
          created_at: string
          domain_id: string
          id: string
          investor_id: string
          share_percentage: number
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          created_at?: string
          domain_id: string
          id?: string
          investor_id: string
          share_percentage?: number
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          domain_id?: string
          id?: string
          investor_id?: string
          share_percentage?: number
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "investments_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "investments_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          auction_id: string | null
          created_at: string
          id: string
          message: string
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          auction_id?: string | null
          created_at?: string
          id?: string
          message: string
          read?: boolean
          title: string
          type?: string
          user_id: string
        }
        Update: {
          auction_id?: string | null
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "auctions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "public_auctions"
            referencedColumns: ["id"]
          },
        ]
      }
      offers: {
        Row: {
          amount: number
          buyer_id: string
          counter_amount: number | null
          counter_message: string | null
          created_at: string
          domain_id: string
          expires_at: string
          id: string
          message: string | null
          seller_id: string
          status: string
          updated_at: string
        }
        Insert: {
          amount: number
          buyer_id: string
          counter_amount?: number | null
          counter_message?: string | null
          created_at?: string
          domain_id: string
          expires_at?: string
          id?: string
          message?: string | null
          seller_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          buyer_id?: string
          counter_amount?: number | null
          counter_message?: string | null
          created_at?: string
          domain_id?: string
          expires_at?: string
          id?: string
          message?: string | null
          seller_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "offers_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "offers_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      ownership_verification: {
        Row: {
          created_at: string
          domain_id: string
          expires_at: string
          id: string
          method: string
          token: string
          updated_at: string
          verified: boolean
          verified_at: string | null
        }
        Insert: {
          created_at?: string
          domain_id: string
          expires_at?: string
          id?: string
          method?: string
          token: string
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
        }
        Update: {
          created_at?: string
          domain_id?: string
          expires_at?: string
          id?: string
          method?: string
          token?: string
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ownership_verification_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ownership_verification_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      parked_domains: {
        Row: {
          clicks: number
          created_at: string
          domain_id: string
          id: string
          impressions: number
          last_earning_date: string | null
          monthly_earnings: number
          parked_at: string
          status: string
          total_earnings: number
          updated_at: string
          user_id: string
        }
        Insert: {
          clicks?: number
          created_at?: string
          domain_id: string
          id?: string
          impressions?: number
          last_earning_date?: string | null
          monthly_earnings?: number
          parked_at?: string
          status?: string
          total_earnings?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          clicks?: number
          created_at?: string
          domain_id?: string
          id?: string
          impressions?: number
          last_earning_date?: string | null
          monthly_earnings?: number
          parked_at?: string
          status?: string
          total_earnings?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "parked_domains_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: true
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "parked_domains_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: true
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      payouts: {
        Row: {
          amount: number
          created_at: string
          id: string
          method: string
          processed_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          method?: string
          processed_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          method?: string
          processed_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string
          description: string | null
          id: string
          type: Database["public"]["Enums"]["transaction_type"]
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          type: Database["public"]["Enums"]["transaction_type"]
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          type?: Database["public"]["Enums"]["transaction_type"]
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wallets: {
        Row: {
          balance: number
          created_at: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      public_auctions: {
        Row: {
          buy_now_price: number | null
          created_at: string | null
          current_bid: number | null
          domain_id: string | null
          domain_name: string | null
          end_time: string | null
          id: string | null
          min_bid_increment: number | null
          start_time: string | null
          starting_price: number | null
          status: string | null
          title: string | null
        }
        Relationships: [
          {
            foreignKeyName: "auctions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "domains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "auctions_domain_id_fkey"
            columns: ["domain_id"]
            isOneToOne: false
            referencedRelation: "public_domains"
            referencedColumns: ["id"]
          },
        ]
      }
      public_bids: {
        Row: {
          amount: number | null
          auction_id: string | null
          created_at: string | null
          id: string | null
          is_auto: boolean | null
          user_id: string | null
        }
        Insert: {
          amount?: number | null
          auction_id?: string | null
          created_at?: string | null
          id?: string | null
          is_auto?: boolean | null
          user_id?: string | null
        }
        Update: {
          amount?: number | null
          auction_id?: string | null
          created_at?: string | null
          id?: string | null
          is_auto?: boolean | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bids_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "auctions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bids_auction_id_fkey"
            columns: ["auction_id"]
            isOneToOne: false
            referencedRelation: "public_auctions"
            referencedColumns: ["id"]
          },
        ]
      }
      public_domains: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          domain_name: string | null
          expiration_date: string | null
          health_score: number | null
          id: string | null
          price: number | null
          status: string | null
          title: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          domain_name?: string | null
          expiration_date?: string | null
          health_score?: number | null
          id?: string | null
          price?: number | null
          status?: string | null
          title?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          domain_name?: string | null
          expiration_date?: string | null
          health_score?: number | null
          id?: string | null
          price?: number | null
          status?: string | null
          title?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "admin"
        | "investor"
        | "expert"
        | "reseller"
        | "franchise"
        | "buyer"
      transaction_type: "deposit" | "withdrawal" | "purchase" | "sale"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "admin",
        "investor",
        "expert",
        "reseller",
        "franchise",
        "buyer",
      ],
      transaction_type: ["deposit", "withdrawal", "purchase", "sale"],
    },
  },
} as const
