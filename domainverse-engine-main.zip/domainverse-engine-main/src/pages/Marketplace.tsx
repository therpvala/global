import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Globe, ShoppingCart, Wallet, Filter, Search, ArrowUpDown, Heart, ChevronLeft, ChevronRight, User, Clock, X, GitCompare, Check, ShieldCheck, AlertTriangle } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import DomainCompareDialog from "@/components/DomainCompareDialog";

const DOMAIN_CATEGORIES = [
  { value: "all", label: "All Categories" },
  { value: "tech", label: "Tech" },
  { value: "business", label: "Business" },
  { value: "premium", label: "Premium" },
  { value: "crypto", label: "Crypto" },
  { value: "ai", label: "AI & ML" },
  { value: "ecommerce", label: "E-commerce" },
  { value: "other", label: "Other" },
];

const SORT_OPTIONS = [
  { value: "newest", label: "Newest First" },
  { value: "oldest", label: "Oldest First" },
  { value: "price_low", label: "Price: Low to High" },
  { value: "price_high", label: "Price: High to Low" },
];

const ITEMS_PER_PAGE = 12;

interface Domain {
  id: string;
  title: string;
  domain_name: string;
  description: string | null;
  price: number;
  status: string;
  created_at: string;
  user_id: string;
  category: string;
  expiration_date: string | null;
}

const Marketplace = () => {
  const { user } = useAuth();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [loading, setLoading] = useState(true);
  const [balance, setBalance] = useState<number>(0);
  const [selectedDomain, setSelectedDomain] = useState<Domain | null>(null);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("newest");
  const [watchedDomains, setWatchedDomains] = useState<Set<string>>(new Set());
  const [togglingWatch, setTogglingWatch] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [showMyDomainsOnly, setShowMyDomainsOnly] = useState(false);
  const { recentlyViewed, clearRecentlyViewed } = useRecentlyViewed();
  const [compareList, setCompareList] = useState<Domain[]>([]);
  const [showCompareDialog, setShowCompareDialog] = useState(false);

  const MAX_COMPARE_ITEMS = 4;

  const toggleCompare = (domain: Domain, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (compareList.some(d => d.id === domain.id)) {
      setCompareList(prev => prev.filter(d => d.id !== domain.id));
    } else {
      if (compareList.length >= MAX_COMPARE_ITEMS) {
        toast.error(`You can compare up to ${MAX_COMPARE_ITEMS} domains at a time`);
        return;
      }
      setCompareList(prev => [...prev, domain]);
    }
  };

  const removeFromCompare = (id: string) => {
    setCompareList(prev => prev.filter(d => d.id !== id));
  };

  const clearCompare = () => {
    setCompareList([]);
  };

  useEffect(() => {
    fetchDomains();
    if (user) {
      fetchWalletBalance();
      fetchWatchlist();
    }
  }, [user, categoryFilter, searchQuery, sortOption, currentPage, showMyDomainsOnly]);

  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [categoryFilter, searchQuery, sortOption, showMyDomainsOnly]);

  const fetchDomains = async () => {
    setLoading(true);
    
    // First get total count for pagination
    let countQuery = supabase
      .from("domains")
      .select("*", { count: "exact", head: true })
      .eq("status", "active");

    if (categoryFilter !== "all") {
      countQuery = countQuery.eq("category", categoryFilter);
    }

    if (searchQuery.trim()) {
      countQuery = countQuery.or(`title.ilike.%${searchQuery}%,domain_name.ilike.%${searchQuery}%`);
    }

    if (showMyDomainsOnly && user) {
      countQuery = countQuery.eq("user_id", user.id);
    }

    const { count } = await countQuery;
    setTotalCount(count || 0);

    // Then fetch paginated data
    const from = (currentPage - 1) * ITEMS_PER_PAGE;
    const to = from + ITEMS_PER_PAGE - 1;

    let query = supabase
      .from("domains")
      .select("*")
      .eq("status", "active")
      .range(from, to);

    // Apply sorting
    switch (sortOption) {
      case "oldest":
        query = query.order("created_at", { ascending: true });
        break;
      case "price_low":
        query = query.order("price", { ascending: true });
        break;
      case "price_high":
        query = query.order("price", { ascending: false });
        break;
      case "newest":
      default:
        query = query.order("created_at", { ascending: false });
        break;
    }

    if (categoryFilter !== "all") {
      query = query.eq("category", categoryFilter);
    }

    if (searchQuery.trim()) {
      query = query.or(`title.ilike.%${searchQuery}%,domain_name.ilike.%${searchQuery}%`);
    }

    if (showMyDomainsOnly && user) {
      query = query.eq("user_id", user.id);
    }

    const { data, error } = await query;

    if (!error && data) {
      setDomains(data as Domain[]);
    }
    setLoading(false);
  };

  const fetchWalletBalance = async () => {
    if (!user) return;

    const { data: wallet } = await supabase
      .from("wallets")
      .select("balance")
      .eq("user_id", user.id)
      .maybeSingle();

    if (wallet) {
      setBalance(Number(wallet.balance));
    }
  };

  const fetchWatchlist = async () => {
    if (!user) return;

    const { data } = await supabase
      .from("domain_watchlist")
      .select("domain_id")
      .eq("user_id", user.id);

    if (data) {
      setWatchedDomains(new Set(data.map(item => item.domain_id)));
    }
  };

  const toggleWatch = async (domainId: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!user) {
      toast.error("Please sign in to save domains");
      return;
    }

    setTogglingWatch(domainId);
    const isCurrentlyWatched = watchedDomains.has(domainId);

    try {
      if (isCurrentlyWatched) {
        const { error } = await supabase
          .from("domain_watchlist")
          .delete()
          .eq("user_id", user.id)
          .eq("domain_id", domainId);

        if (error) throw error;
        setWatchedDomains(prev => {
          const next = new Set(prev);
          next.delete(domainId);
          return next;
        });
        toast.success("Removed from watchlist");
      } else {
        const { error } = await supabase
          .from("domain_watchlist")
          .insert({ user_id: user.id, domain_id: domainId });

        if (error) throw error;
        setWatchedDomains(prev => new Set(prev).add(domainId));
        toast.success("Added to watchlist");
      }
    } catch (error: any) {
      toast.error("Failed to update watchlist");
      console.error(error);
    } finally {
      setTogglingWatch(null);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const isExpiringSoon = (expirationDate: string | null) => {
    if (!expirationDate) return false;
    const expiry = new Date(expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
  };

  const getDaysUntilExpiry = (expirationDate: string) => {
    const expiry = new Date(expirationDate);
    const now = new Date();
    return Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  const handlePurchaseClick = (domain: Domain) => {
    if (!user) {
      toast.error("Please sign in to purchase domains");
      return;
    }
    if (domain.user_id === user.id) {
      toast.error("You cannot purchase your own domain");
      return;
    }
    setSelectedDomain(domain);
    setShowPurchaseDialog(true);
  };

  const handlePurchase = async () => {
    if (!selectedDomain || !user) return;

    if (balance < selectedDomain.price) {
      toast.error("Insufficient wallet balance");
      setShowPurchaseDialog(false);
      return;
    }

    setIsPurchasing(true);
    try {
      const sellerId = selectedDomain.user_id;
      const price = selectedDomain.price;

      // Deduct from buyer's wallet
      const { error: buyerWalletError } = await supabase
        .from("wallets")
        .update({ balance: balance - price })
        .eq("user_id", user.id);

      if (buyerWalletError) throw buyerWalletError;

      // Create purchase transaction for buyer
      const { error: buyerTxnError } = await supabase
        .from("transactions")
        .insert({
          user_id: user.id,
          type: "purchase",
          amount: price,
          description: `Purchased domain: ${selectedDomain.domain_name}`,
        });

      if (buyerTxnError) throw buyerTxnError;

      // Add to seller's wallet
      const { data: sellerWallet } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", sellerId)
        .maybeSingle();

      if (sellerWallet) {
        await supabase
          .from("wallets")
          .update({ balance: Number(sellerWallet.balance) + price })
          .eq("user_id", sellerId);
      } else {
        await supabase
          .from("wallets")
          .insert({ user_id: sellerId, balance: price });
      }

      // Create sale transaction for seller
      await supabase
        .from("transactions")
        .insert({
          user_id: sellerId,
          type: "sale",
          amount: price,
          description: `Sold domain: ${selectedDomain.domain_name}`,
        });

      // Update domain ownership and status
      const { error: domainError } = await supabase
        .from("domains")
        .update({ user_id: user.id, status: "sold" })
        .eq("id", selectedDomain.id);

      if (domainError) throw domainError;

      toast.success(`Successfully purchased ${selectedDomain.domain_name}!`);
      setShowPurchaseDialog(false);
      setSelectedDomain(null);
      fetchDomains();
      fetchWalletBalance();
    } catch (error: any) {
      toast.error("Failed to complete purchase");
      console.error(error);
    } finally {
      setIsPurchasing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container mx-auto py-12 px-4">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Domain Marketplace</h1>
            <p className="text-muted-foreground mt-2">
              Browse and purchase premium domains
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search domains..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-[200px] lg:w-[280px]"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {DOMAIN_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <ArrowUpDown className="h-4 w-4 text-muted-foreground" />
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            {user && (
              <div className="flex items-center gap-2 px-3 py-2 bg-muted rounded-lg">
                <User className="h-4 w-4 text-muted-foreground" />
                <Switch
                  id="my-domains"
                  checked={showMyDomainsOnly}
                  onCheckedChange={setShowMyDomainsOnly}
                />
                <Label htmlFor="my-domains" className="text-sm font-medium cursor-pointer">
                  My Domains
                </Label>
              </div>
            )}
            {user && (
              <>
                <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
                  <Wallet className="h-4 w-4 text-primary" />
                  <span className="font-medium">{formatPrice(balance)}</span>
                </div>
                <Button asChild>
                  <Link to="/add-domain">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Domain
                  </Link>
                </Button>
              </>
            )}
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-1/2 mb-2" />
                  <Skeleton className="h-20 w-full" />
                </CardContent>
                <CardFooter>
                  <Skeleton className="h-8 w-24" />
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : domains.length === 0 ? (
          <div className="text-center py-16">
            <Globe className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">No domains listed yet</h2>
            <p className="text-muted-foreground mb-4">
              Be the first to list your domain on the marketplace
            </p>
            {user && (
              <Button asChild>
                <Link to="/add-domain">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Your Domain
                </Link>
              </Button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {domains.map((domain) => (
              <Card key={domain.id} className={`flex flex-col hover:border-primary/50 transition-colors relative ${compareList.some(d => d.id === domain.id) ? 'ring-2 ring-primary' : ''}`}>
                <div className="absolute top-2 left-2 z-10">
                  <button
                    onClick={(e) => toggleCompare(domain, e)}
                    className={`flex items-center justify-center h-6 w-6 rounded border-2 transition-colors ${
                      compareList.some(d => d.id === domain.id)
                        ? 'bg-primary border-primary text-primary-foreground'
                        : 'bg-background border-muted-foreground/30 hover:border-primary'
                    }`}
                  >
                    {compareList.some(d => d.id === domain.id) && (
                      <Check className="h-4 w-4" />
                    )}
                  </button>
                </div>
                {user && user.id !== domain.user_id && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 h-8 w-8"
                    onClick={(e) => toggleWatch(domain.id, e)}
                    disabled={togglingWatch === domain.id}
                  >
                    <Heart 
                      className={`h-4 w-4 transition-colors ${
                        watchedDomains.has(domain.id) 
                          ? "fill-red-500 text-red-500" 
                          : "text-muted-foreground hover:text-red-500"
                      }`} 
                    />
                  </Button>
                )}
                <CardHeader className="pr-12">
                  <div className="flex items-start justify-between gap-2">
                    <Link to={`/domain/${domain.id}`} className="hover:text-primary transition-colors flex-1 min-w-0">
                      <CardTitle className="text-lg line-clamp-1 flex items-center gap-1.5">
                        {domain.title}
                        {domain.expiration_date && (
                          <ShieldCheck className="h-4 w-4 text-green-500 flex-shrink-0" />
                        )}
                      </CardTitle>
                    </Link>
                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {isExpiringSoon(domain.expiration_date) && (
                        <Badge variant="outline" className="text-orange-600 border-orange-200 bg-orange-50 gap-1 text-xs">
                          <AlertTriangle className="h-3 w-3" />
                          {getDaysUntilExpiry(domain.expiration_date!)}d
                        </Badge>
                      )}
                      <Badge variant="secondary" className="capitalize">{domain.category}</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex-1">
                  <Link to={`/domain/${domain.id}`} className="hover:underline">
                    <p className="text-primary font-semibold text-lg mb-2">
                      {domain.domain_name}
                    </p>
                  </Link>
                  {domain.description && (
                    <p className="text-muted-foreground text-sm line-clamp-3">
                      {domain.description}
                    </p>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-primary">
                    {formatPrice(domain.price)}
                  </span>
                  <div className="flex gap-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      asChild
                    >
                      <Link to={`/domain/${domain.id}`}>View</Link>
                    </Button>
                    <Button 
                      size="sm" 
                      onClick={() => handlePurchaseClick(domain)}
                      disabled={user?.id === domain.user_id}
                    >
                      <ShoppingCart className="mr-2 h-4 w-4" />
                      {user?.id === domain.user_id ? "Yours" : "Buy"}
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {!loading && totalCount > ITEMS_PER_PAGE && (
          <div className="flex items-center justify-center gap-4 mt-8">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Previous
            </Button>
            <span className="text-sm text-muted-foreground">
              Page {currentPage} of {Math.ceil(totalCount / ITEMS_PER_PAGE)}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(p => Math.min(Math.ceil(totalCount / ITEMS_PER_PAGE), p + 1))}
              disabled={currentPage >= Math.ceil(totalCount / ITEMS_PER_PAGE)}
            >
              Next
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        )}

        {/* Recently Viewed Section */}
        {recentlyViewed.length > 0 && (
          <div className="mt-12">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <h2 className="text-xl font-semibold">Recently Viewed</h2>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearRecentlyViewed}
                className="text-muted-foreground hover:text-destructive"
              >
                <X className="h-4 w-4 mr-1" />
                Clear
              </Button>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {recentlyViewed.slice(0, 5).map((domain) => (
                <Link
                  key={domain.id}
                  to={`/domain/${domain.id}`}
                  className="block p-4 rounded-lg border bg-card hover:border-primary transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Globe className="h-4 w-4 text-primary" />
                    <span className="text-xs text-muted-foreground capitalize">{domain.category}</span>
                    {domain.expiration_date && (
                      <ShieldCheck className="h-3.5 w-3.5 text-green-500 ml-auto" />
                    )}
                    {isExpiringSoon(domain.expiration_date) && (
                      <AlertTriangle className="h-3.5 w-3.5 text-orange-500" />
                    )}
                  </div>
                  <p className="font-medium text-sm truncate flex items-center gap-1">
                    {domain.title}
                  </p>
                  <p className="text-primary text-xs truncate">{domain.domain_name}</p>
                  <p className="text-sm font-semibold mt-2">{formatPrice(domain.price)}</p>
                  {domain.expiration_date && (
                    <p className={`text-xs mt-1 ${isExpiringSoon(domain.expiration_date) ? 'text-orange-600 font-medium' : 'text-muted-foreground'}`}>
                      Expires: {new Date(domain.expiration_date).toLocaleDateString()}
                      {isExpiringSoon(domain.expiration_date) && ` (${getDaysUntilExpiry(domain.expiration_date)}d)`}
                    </p>
                  )}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Purchase Confirmation Dialog */}
      <Dialog open={showPurchaseDialog} onOpenChange={setShowPurchaseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Purchase</DialogTitle>
            <DialogDescription>
              You are about to purchase this domain using your wallet balance.
            </DialogDescription>
          </DialogHeader>
          {selectedDomain && (
            <div className="space-y-4 py-4">
              <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
                <div>
                  <p className="font-semibold">{selectedDomain.title}</p>
                  <p className="text-primary">{selectedDomain.domain_name}</p>
                </div>
                <span className="text-2xl font-bold text-primary">
                  {formatPrice(selectedDomain.price)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Your wallet balance:</span>
                <span className={balance < selectedDomain.price ? "text-destructive" : "text-green-500"}>
                  {formatPrice(balance)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">After purchase:</span>
                <span className={balance - selectedDomain.price < 0 ? "text-destructive" : ""}>
                  {formatPrice(balance - selectedDomain.price)}
                </span>
              </div>
              {balance < selectedDomain.price && (
                <p className="text-destructive text-sm">
                  Insufficient balance. Please deposit more funds to your wallet.
                </p>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPurchaseDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handlePurchase} 
              disabled={isPurchasing || (selectedDomain && balance < selectedDomain.price)}
            >
              {isPurchasing ? "Processing..." : "Confirm Purchase"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Domain Compare Dialog */}
      <DomainCompareDialog
        open={showCompareDialog}
        onOpenChange={setShowCompareDialog}
        domains={compareList}
        onRemove={removeFromCompare}
        onPurchase={(domain) => {
          setShowCompareDialog(false);
          handlePurchaseClick(domain);
        }}
        currentUserId={user?.id}
      />

      {/* Floating Compare Bar */}
      {compareList.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 animate-fade-in">
          <div className="flex items-center gap-3 px-4 py-3 bg-card border rounded-full shadow-lg">
            <div className="flex items-center gap-2">
              <GitCompare className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">
                {compareList.length} domain{compareList.length > 1 ? 's' : ''} selected
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => setShowCompareDialog(true)}
                disabled={compareList.length < 2}
              >
                Compare
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={clearCompare}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marketplace;
