import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Gavel } from "lucide-react";
import { toast } from "sonner";

interface Domain {
  id: string;
  domain_name: string;
  title: string;
  price: number;
}

const CreateAuction = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [selectedDomain, setSelectedDomain] = useState("");
  const [startingPrice, setStartingPrice] = useState("");
  const [minIncrement, setMinIncrement] = useState("10");
  const [duration, setDuration] = useState("24");
  const [loading, setLoading] = useState(false);
  const [fetchingDomains, setFetchingDomains] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }

    const fetchDomains = async () => {
      try {
        // Fetch user's domains that are not already in an active auction
        const { data: userDomains, error } = await supabase
          .from("domains")
          .select("id, domain_name, title, price")
          .eq("user_id", user.id)
          .eq("status", "active");

        if (error) throw error;

        // Filter out domains already in active auctions
        const { data: activeAuctions } = await supabase
          .from("auctions")
          .select("domain_id")
          .eq("status", "active");

        const auctionedDomainIds = new Set(activeAuctions?.map(a => a.domain_id) || []);
        const availableDomains = (userDomains || []).filter(d => !auctionedDomainIds.has(d.id));

        setDomains(availableDomains);
      } catch (error: any) {
        toast.error("Failed to load domains");
        console.error(error);
      } finally {
        setFetchingDomains(false);
      }
    };

    fetchDomains();
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedDomain) {
      toast.error("Please select a domain");
      return;
    }

    const price = parseFloat(startingPrice);
    if (isNaN(price) || price <= 0) {
      toast.error("Please enter a valid starting price");
      return;
    }

    const increment = parseFloat(minIncrement);
    if (isNaN(increment) || increment <= 0) {
      toast.error("Please enter a valid minimum increment");
      return;
    }

    const durationHours = parseInt(duration);
    const endTime = new Date();
    endTime.setHours(endTime.getHours() + durationHours);

    setLoading(true);

    try {
      const { error } = await supabase.from("auctions").insert({
        domain_id: selectedDomain,
        seller_id: user!.id,
        starting_price: price,
        min_bid_increment: increment,
        end_time: endTime.toISOString(),
      });

      if (error) throw error;

      toast.success("Auction created successfully!");
      navigate("/auctions");
    } catch (error: any) {
      toast.error(error.message || "Failed to create auction");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const selectedDomainData = domains.find(d => d.id === selectedDomain);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-2xl">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6 gap-2"
            onClick={() => navigate("/auctions")}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Auctions
          </Button>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Gavel className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle className="font-display text-2xl">Create Auction</CardTitle>
                  <CardDescription>List your domain for bidding</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {fetchingDomains ? (
                <div className="animate-pulse space-y-4">
                  <div className="h-10 bg-muted rounded" />
                  <div className="h-10 bg-muted rounded" />
                  <div className="h-10 bg-muted rounded" />
                </div>
              ) : domains.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-muted-foreground mb-4">
                    You don't have any domains available for auction.
                  </p>
                  <Button onClick={() => navigate("/add-domain")}>
                    Add a Domain First
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Domain Selection */}
                  <div className="space-y-2">
                    <Label htmlFor="domain">Select Domain</Label>
                    <Select value={selectedDomain} onValueChange={setSelectedDomain}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose a domain to auction" />
                      </SelectTrigger>
                      <SelectContent>
                        {domains.map((domain) => (
                          <SelectItem key={domain.id} value={domain.id}>
                            {domain.domain_name} - {domain.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedDomainData && (
                    <div className="p-4 rounded-lg bg-muted/50 border">
                      <p className="text-sm text-muted-foreground">Listed Price</p>
                      <p className="font-display text-xl font-bold">
                        ${selectedDomainData.price.toLocaleString()}
                      </p>
                    </div>
                  )}

                  {/* Starting Price */}
                  <div className="space-y-2">
                    <Label htmlFor="startingPrice">Starting Price ($)</Label>
                    <Input
                      id="startingPrice"
                      type="number"
                      placeholder="1000"
                      value={startingPrice}
                      onChange={(e) => setStartingPrice(e.target.value)}
                      min="1"
                      step="1"
                      required
                    />
                  </div>

                  {/* Minimum Increment */}
                  <div className="space-y-2">
                    <Label htmlFor="minIncrement">Minimum Bid Increment ($)</Label>
                    <Input
                      id="minIncrement"
                      type="number"
                      placeholder="10"
                      value={minIncrement}
                      onChange={(e) => setMinIncrement(e.target.value)}
                      min="1"
                      step="1"
                      required
                    />
                  </div>

                  {/* Duration */}
                  <div className="space-y-2">
                    <Label htmlFor="duration">Auction Duration</Label>
                    <Select value={duration} onValueChange={setDuration}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Hour</SelectItem>
                        <SelectItem value="6">6 Hours</SelectItem>
                        <SelectItem value="12">12 Hours</SelectItem>
                        <SelectItem value="24">24 Hours</SelectItem>
                        <SelectItem value="48">2 Days</SelectItem>
                        <SelectItem value="72">3 Days</SelectItem>
                        <SelectItem value="168">7 Days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Submit Button */}
                  <Button type="submit" className="w-full" size="lg" disabled={loading}>
                    {loading ? "Creating Auction..." : "Create Auction"}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default CreateAuction;
