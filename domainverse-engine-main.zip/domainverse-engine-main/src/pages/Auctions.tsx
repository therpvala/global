import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, TrendingUp, Users, Flame, Gavel, Plus, ShieldCheck, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

interface Auction {
  id: string;
  domain_id: string;
  seller_id: string;
  starting_price: number;
  current_bid: number;
  current_bidder_id: string | null;
  min_bid_increment: number;
  start_time: string;
  end_time: string;
  status: string;
  domain: {
    domain_name: string;
    title: string;
    description: string | null;
    expiration_date: string | null;
  };
  bid_count: number;
}

const Auctions = () => {
  const { user } = useAuth();
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAuctions = async () => {
    try {
      const { data: auctionsData, error: auctionsError } = await supabase
        .from("auctions")
        .select(`
          *,
          domain:domains(domain_name, title, description, expiration_date)
        `)
        .eq("status", "active")
        .order("end_time", { ascending: true });

      if (auctionsError) throw auctionsError;

      // Get bid counts for each auction
      const auctionsWithCounts = await Promise.all(
        (auctionsData || []).map(async (auction) => {
          const { count } = await supabase
            .from("bids")
            .select("*", { count: "exact", head: true })
            .eq("auction_id", auction.id);
          
          return {
            ...auction,
            bid_count: count || 0,
          };
        })
      );

      setAuctions(auctionsWithCounts);
    } catch (error: any) {
      toast.error("Failed to load auctions");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuctions();

    // Subscribe to real-time auction updates
    const channel = supabase
      .channel("auctions-realtime")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "auctions",
        },
        () => {
          fetchAuctions();
        }
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "bids",
        },
        () => {
          fetchAuctions();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getTimeLeft = (endTime: string) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end.getTime() - now.getTime();

    if (diff <= 0) return "Ended";

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

    if (days > 0) return `${days}d ${hours}h`;
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const isHot = (bidCount: number, currentBid: number, startingPrice: number) => {
    return bidCount >= 5 || currentBid >= startingPrice * 2;
  };

  const isExpiringSoon = (expirationDate: string | null) => {
    if (!expirationDate) return false;
    const expiry = new Date(expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
  };

  const getDaysUntilExpiry = (expirationDate: string) => {
    const expiry = new Date(expirationDate);
    const now = new Date();
    return Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
                Live Auctions
              </h1>
              <p className="text-muted-foreground">
                Bid on premium domains in real-time
              </p>
            </div>
            {user && (
              <Link to="/create-auction">
                <Button variant="default" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Create Auction
                </Button>
              </Link>
            )}
          </div>

          {/* Auctions Grid */}
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-6 bg-muted rounded w-1/3 mb-4" />
                    <div className="h-8 bg-muted rounded w-2/3 mb-6" />
                    <div className="space-y-3">
                      <div className="h-4 bg-muted rounded" />
                      <div className="h-4 bg-muted rounded" />
                      <div className="h-4 bg-muted rounded" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : auctions.length === 0 ? (
            <Card className="text-center py-16">
              <CardContent>
                <Gavel className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  No Active Auctions
                </h3>
                <p className="text-muted-foreground mb-6">
                  Be the first to create an auction!
                </p>
                {user && (
                  <Link to="/create-auction">
                    <Button>Create Auction</Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {auctions.map((auction) => (
                <Link key={auction.id} to={`/auction/${auction.id}`}>
                  <Card className="group hover:shadow-elevated transition-all duration-300 hover:-translate-y-1 overflow-hidden relative">
                    {/* Hot Badge */}
                    {isHot(auction.bid_count, auction.current_bid, auction.starting_price) && (
                      <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 rounded-full bg-destructive/10 text-destructive text-xs font-medium z-10">
                        <Flame className="h-3 w-3" />
                        Hot
                      </div>
                    )}

                    <CardHeader className="pb-2">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <Badge variant="secondary" className="w-fit">
                          Auction
                        </Badge>
                        {auction.domain?.expiration_date && (
                          <Badge variant="outline" className="w-fit gap-1 text-green-600 border-green-200 bg-green-50">
                            <ShieldCheck className="h-3 w-3" />
                            Verified
                          </Badge>
                        )}
                        {isExpiringSoon(auction.domain?.expiration_date) && (
                          <Badge variant="outline" className="w-fit gap-1 text-orange-600 border-orange-200 bg-orange-50">
                            <AlertTriangle className="h-3 w-3" />
                            {getDaysUntilExpiry(auction.domain!.expiration_date!)}d left
                          </Badge>
                        )}
                      </div>
                      <CardTitle className="font-display text-xl group-hover:text-primary transition-colors">
                        {auction.domain?.domain_name}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {auction.domain?.title}
                      </p>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      {/* Stats */}
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Current Bid</span>
                          <span className="flex items-center gap-1 font-display text-lg font-bold text-foreground">
                            <TrendingUp className="h-4 w-4 text-accent" />
                            ${auction.current_bid > 0 ? auction.current_bid.toLocaleString() : auction.starting_price.toLocaleString()}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Bidders</span>
                          <span className="flex items-center gap-1 text-sm font-medium text-foreground">
                            <Users className="h-4 w-4 text-primary" />
                            {auction.bid_count}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground">Time Left</span>
                          <span className="flex items-center gap-1 text-sm font-medium text-destructive">
                            <Clock className="h-4 w-4" />
                            {getTimeLeft(auction.end_time)}
                          </span>
                        </div>
                      </div>

                      {/* Bid Button */}
                      <Button variant="default" className="w-full">
                        Place Bid
                      </Button>
                    </CardContent>

                    {/* Animated Border */}
                    <div className="absolute inset-0 rounded-lg border-2 border-transparent group-hover:border-primary/30 transition-colors duration-300 pointer-events-none" />
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Auctions;
