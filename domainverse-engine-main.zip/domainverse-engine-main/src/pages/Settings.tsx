import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole, getRoleLabel } from "@/hooks/useUserRole";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import Logo from "@/components/Logo";
import { toast } from "sonner";
import {
  ArrowLeft,
  Bell,
  Shield,
  Eye,
  Mail,
  Loader2,
  Settings as SettingsIcon,
  User,
  Globe,
} from "lucide-react";

const Settings = () => {
  const { user, signOut } = useAuth();
  const { roles, loading: rolesLoading } = useUserRole();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Notification preferences (stored locally for now)
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [bidAlerts, setBidAlerts] = useState(true);
  const [watchlistAlerts, setWatchlistAlerts] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);

  useEffect(() => {
    // Load saved preferences from localStorage
    const prefs = localStorage.getItem("notification_prefs");
    if (prefs) {
      const parsed = JSON.parse(prefs);
      setEmailNotifications(parsed.emailNotifications ?? true);
      setBidAlerts(parsed.bidAlerts ?? true);
      setWatchlistAlerts(parsed.watchlistAlerts ?? true);
      setMarketingEmails(parsed.marketingEmails ?? false);
    }
    setLoading(false);
  }, []);

  const handleSavePreferences = () => {
    setSaving(true);
    const prefs = { emailNotifications, bidAlerts, watchlistAlerts, marketingEmails };
    localStorage.setItem("notification_prefs", JSON.stringify(prefs));
    setTimeout(() => {
      setSaving(false);
      toast.success("Preferences saved successfully");
    }, 300);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-hero flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-hero">
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>
            <Button variant="ghost" onClick={() => signOut()}>
              Sign Out
            </Button>
          </div>
        </div>
      </nav>

      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto max-w-2xl">
          <Link
            to="/dashboard"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Link>

          <div className="flex items-center gap-3 mb-8">
            <SettingsIcon className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-3xl font-bold font-display text-foreground">Settings</h1>
              <p className="text-muted-foreground">Manage your account preferences</p>
            </div>
          </div>

          {/* Account Info */}
          <Card className="glass border-border mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                Account
              </CardTitle>
              <CardDescription>Your account details and roles</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-muted-foreground">Email</Label>
                  <p className="font-medium text-foreground">{user?.email}</p>
                </div>
                <Mail className="h-5 w-5 text-muted-foreground" />
              </div>
              <Separator />
              <div>
                <Label className="text-muted-foreground">Your Roles</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {!rolesLoading && roles.map((role) => (
                    <Badge key={role} variant="secondary">
                      {getRoleLabel(role)}
                    </Badge>
                  ))}
                  {!rolesLoading && roles.length === 0 && (
                    <p className="text-sm text-muted-foreground">No roles assigned</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notification Preferences */}
          <Card className="glass border-border mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5 text-primary" />
                Notifications
              </CardTitle>
              <CardDescription>Choose what notifications you receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-muted-foreground">Receive email for important updates</p>
                </div>
                <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Bid Alerts</Label>
                  <p className="text-sm text-muted-foreground">Get notified when outbid or auction ends</p>
                </div>
                <Switch checked={bidAlerts} onCheckedChange={setBidAlerts} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Watchlist Alerts</Label>
                  <p className="text-sm text-muted-foreground">Notify when watched domains go on auction</p>
                </div>
                <Switch checked={watchlistAlerts} onCheckedChange={setWatchlistAlerts} />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Marketing Emails</Label>
                  <p className="text-sm text-muted-foreground">Receive tips and platform updates</p>
                </div>
                <Switch checked={marketingEmails} onCheckedChange={setMarketingEmails} />
              </div>
            </CardContent>
          </Card>

          {/* Privacy & Security */}
          <Card className="glass border-border mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Privacy & Security
              </CardTitle>
              <CardDescription>Manage your security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Password</Label>
                  <p className="text-sm text-muted-foreground">Last changed: Unknown</p>
                </div>
                <Button variant="outline" size="sm" disabled>
                  Change Password
                </Button>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Two-Factor Authentication</Label>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
                </div>
                <Badge variant="secondary">Coming Soon</Badge>
              </div>
            </CardContent>
          </Card>

          <Button
            onClick={handleSavePreferences}
            variant="hero"
            className="w-full h-12"
            disabled={saving}
          >
            {saving ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              "Save Preferences"
            )}
          </Button>
        </div>
      </main>
    </div>
  );
};

export default Settings;
