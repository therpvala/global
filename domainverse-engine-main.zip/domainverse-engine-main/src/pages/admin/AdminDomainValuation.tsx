import AdminLayout from "@/components/admin/AdminLayout";
import DomainValuationTool from "@/components/DomainValuationTool";

const AdminDomainValuation = () => {
  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Domain Valuation</h1>
        <p className="text-sm text-muted-foreground">
          AI-powered domain valuation based on keywords, length, and market data
        </p>
      </div>
      
      <div className="max-w-3xl">
        <DomainValuationTool />
      </div>
    </AdminLayout>
  );
};

export default AdminDomainValuation;
