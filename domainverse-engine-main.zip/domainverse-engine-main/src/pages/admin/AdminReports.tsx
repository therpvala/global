import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import RevenueChart from "@/components/admin/RevenueChart";
import UserGrowthChart from "@/components/admin/UserGrowthChart";
import DomainCategoriesChart from "@/components/admin/DomainCategoriesChart";
import AuctionPerformanceChart from "@/components/admin/AuctionPerformanceChart";
import {
  DollarSign,
  Users,
  Globe,
  Gavel,
} from "lucide-react";

interface ReportStats {
  monthlyRevenue: number;
  newUsers: number;
  domainsListed: number;
  auctionsCompleted: number;
}

const AdminReports = () => {
  const [stats, setStats] = useState<ReportStats>({
    monthlyRevenue: 0,
    newUsers: 0,
    domainsListed: 0,
    auctionsCompleted: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();

      const [
        { data: transactions },
        { count: newUsersCount },
        { count: domainsCount },
        { count: auctionsCount },
      ] = await Promise.all([
        supabase
          .from("transactions")
          .select("amount, type")
          .gte("created_at", thirtyDaysAgo)
          .in("type", ["sale", "purchase"]),
        supabase
          .from("profiles")
          .select("*", { count: "exact", head: true })
          .gte("created_at", thirtyDaysAgo),
        supabase
          .from("domains")
          .select("*", { count: "exact", head: true })
          .gte("created_at", thirtyDaysAgo),
        supabase
          .from("auctions")
          .select("*", { count: "exact", head: true })
          .eq("status", "completed")
          .gte("created_at", thirtyDaysAgo),
      ]);

      const revenue = transactions?.reduce((sum, t) => sum + Number(t.amount) * 0.05, 0) || 0;

      setStats({
        monthlyRevenue: Math.round(revenue),
        newUsers: newUsersCount || 0,
        domainsListed: domainsCount || 0,
        auctionsCompleted: auctionsCount || 0,
      });
      setLoading(false);
    };

    fetchStats();
  }, []);

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Reports</h1>
        <p className="text-sm text-muted-foreground">
          Analytics and performance reports
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatsCard
          label="Monthly Revenue"
          value={loading ? "..." : `$${stats.monthlyRevenue.toLocaleString()}`}
          icon={DollarSign}
          trend={{ value: 18, isPositive: true }}
        />
        <StatsCard
          label="New Users"
          value={loading ? "..." : stats.newUsers}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          label="Domains Listed"
          value={loading ? "..." : stats.domainsListed}
          icon={Globe}
          trend={{ value: 8, isPositive: true }}
        />
        <StatsCard
          label="Auctions Completed"
          value={loading ? "..." : stats.auctionsCompleted}
          icon={Gavel}
          trend={{ value: 24, isPositive: true }}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <RevenueChart />
        <UserGrowthChart />
        <DomainCategoriesChart />
        <AuctionPerformanceChart />
      </div>
    </AdminLayout>
  );
};

export default AdminReports;
