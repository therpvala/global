import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import LiveActivityFeed from "@/components/admin/LiveActivityFeed";
import ActionRequiredCard from "@/components/admin/ActionRequiredCard";
import { Button } from "@/components/ui/button";
import {
  Users,
  Globe,
  Gavel,
  DollarSign,
  TrendingUp,
  Briefcase,
  Star,
  ParkingSquare,
  ArrowRight,
} from "lucide-react";

interface DashboardStats {
  totalUsers: number;
  totalDomains: number;
  activeAuctions: number;
  totalRevenue: number;
  activeInvestors: number;
  totalExperts: number;
  parkedDomains: number;
  pendingVerifications: number;
  pendingPayouts: number;
  fraudAlerts: number;
}

const AdminDashboardNew = () => {
  const [stats, setStats] = useState<DashboardStats>({
    totalUsers: 0,
    totalDomains: 0,
    activeAuctions: 0,
    totalRevenue: 0,
    activeInvestors: 0,
    totalExperts: 0,
    parkedDomains: 0,
    pendingVerifications: 0,
    pendingPayouts: 0,
    fraudAlerts: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [
          { count: usersCount },
          { count: domainsCount },
          { count: auctionsCount },
          { data: transactions },
          { count: investorsCount },
          { count: expertsCount },
          { count: parkedCount },
          { count: pendingVerifications },
          { count: pendingPayouts },
          { count: fraudCount },
        ] = await Promise.all([
          supabase.from("user_roles").select("*", { count: "exact", head: true }),
          supabase.from("domains").select("*", { count: "exact", head: true }),
          supabase.from("auctions").select("*", { count: "exact", head: true }).eq("status", "active"),
          supabase.from("transactions").select("amount, type"),
          supabase.from("user_roles").select("*", { count: "exact", head: true }).eq("role", "investor"),
          supabase.from("experts").select("*", { count: "exact", head: true }),
          supabase.from("parked_domains").select("*", { count: "exact", head: true }).eq("status", "active"),
          supabase.from("ownership_verification").select("*", { count: "exact", head: true }).eq("verified", false),
          supabase.from("payouts").select("*", { count: "exact", head: true }).eq("status", "pending"),
          supabase.from("fraud_alerts").select("*", { count: "exact", head: true }).eq("status", "pending"),
        ]);

        const revenue = transactions?.reduce((sum, t) => {
          if (t.type === "sale" || t.type === "purchase") {
            return sum + (Number(t.amount) * 0.05);
          }
          return sum;
        }, 0) || 0;

        setStats({
          totalUsers: usersCount || 0,
          totalDomains: domainsCount || 0,
          activeAuctions: auctionsCount || 0,
          totalRevenue: revenue,
          activeInvestors: investorsCount || 0,
          totalExperts: expertsCount || 0,
          parkedDomains: parkedCount || 0,
          pendingVerifications: pendingVerifications || 0,
          pendingPayouts: pendingPayouts || 0,
          fraudAlerts: fraudCount || 0,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const actionItems = [
    ...(stats.pendingVerifications > 0
      ? [{
          id: "verifications",
          title: "Pending Verifications",
          description: "Domain ownership verifications awaiting review",
          type: "warning" as const,
          link: "/admin/domains/pending",
          count: stats.pendingVerifications,
        }]
      : []),
    ...(stats.pendingPayouts > 0
      ? [{
          id: "payouts",
          title: "Pending Payouts",
          description: "Payout requests awaiting approval",
          type: "urgent" as const,
          link: "/admin/payments/auto-payout",
          count: stats.pendingPayouts,
        }]
      : []),
    ...(stats.fraudAlerts > 0
      ? [{
          id: "fraud",
          title: "Fraud Alerts",
          description: "Suspicious bids detected",
          type: "urgent" as const,
          link: "/admin/auctions/fraud",
          count: stats.fraudAlerts,
        }]
      : []),
  ];

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Platform overview and key metrics
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-6">
        <StatsCard
          label="Total Users"
          value={stats.totalUsers}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          label="Domains"
          value={stats.totalDomains}
          icon={Globe}
          trend={{ value: 8, isPositive: true }}
        />
        <StatsCard
          label="Active Auctions"
          value={stats.activeAuctions}
          icon={Gavel}
        />
        <StatsCard
          label="Revenue"
          value={`$${stats.totalRevenue.toLocaleString()}`}
          icon={DollarSign}
          trend={{ value: 24, isPositive: true }}
        />
        <StatsCard
          label="Investors"
          value={stats.activeInvestors}
          icon={Briefcase}
        />
        <StatsCard
          label="Experts"
          value={stats.totalExperts}
          icon={Star}
        />
        <StatsCard
          label="Parked"
          value={stats.parkedDomains}
          icon={ParkingSquare}
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Activity Feed */}
        <div className="lg:col-span-2">
          <LiveActivityFeed />
        </div>

        {/* Right Column - Action Required */}
        <div className="space-y-6">
          <ActionRequiredCard items={actionItems} />

          {/* Quick Links */}
          <div className="bg-card border border-border rounded-lg p-4">
            <h3 className="text-sm font-semibold text-foreground mb-3">Quick Actions</h3>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-between" asChild>
                <Link to="/admin/users">
                  Manage Users
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-between" asChild>
                <Link to="/admin/domains">
                  View All Domains
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-between" asChild>
                <Link to="/admin/auctions">
                  Manage Auctions
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button variant="outline" className="w-full justify-between" asChild>
                <Link to="/admin/reports">
                  View Reports
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default AdminDashboardNew;
