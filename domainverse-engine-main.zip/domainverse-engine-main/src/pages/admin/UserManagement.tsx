import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  Users,
  Shield,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  Search,
  Plus,
  Trash2,
  ArrowLeft,
  CheckCircle,
  UserPlus,
  Filter,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AppRole, getRoleLabel, getRoleColor } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { format } from "date-fns";

interface UserWithRoles {
  user_id: string;
  email: string | null;
  full_name: string | null;
  created_at: string;
  roles: { id: string; role: AppRole; created_at: string }[];
}

const allRoles: AppRole[] = ["admin", "investor", "expert", "reseller", "franchise", "buyer"];

const UserManagement = () => {
  const { user, signOut } = useAuth();
  const [users, setUsers] = useState<UserWithRoles[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<AppRole | "all">("all");
  const [selectedUser, setSelectedUser] = useState<UserWithRoles | null>(null);
  const [addRoleDialogOpen, setAddRoleDialogOpen] = useState(false);
  const [newRole, setNewRole] = useState<AppRole>("buyer");

  const fetchUsers = async () => {
    try {
      // Fetch all user roles
      const { data: rolesData, error: rolesError } = await supabase
        .from("user_roles")
        .select("id, user_id, role, created_at")
        .order("created_at", { ascending: false });

      if (rolesError) throw rolesError;

      // Fetch all profiles
      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("user_id, email, full_name, created_at");

      if (profilesError) throw profilesError;

      // Group roles by user_id
      const userMap = new Map<string, UserWithRoles>();

      rolesData?.forEach((roleEntry) => {
        const profile = profilesData?.find((p) => p.user_id === roleEntry.user_id);
        
        if (!userMap.has(roleEntry.user_id)) {
          userMap.set(roleEntry.user_id, {
            user_id: roleEntry.user_id,
            email: profile?.email || null,
            full_name: profile?.full_name || null,
            created_at: profile?.created_at || roleEntry.created_at,
            roles: [],
          });
        }
        
        userMap.get(roleEntry.user_id)?.roles.push({
          id: roleEntry.id,
          role: roleEntry.role as AppRole,
          created_at: roleEntry.created_at,
        });
      });

      setUsers(Array.from(userMap.values()));
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleAddRole = async () => {
    if (!selectedUser) return;

    // Check if user already has this role
    if (selectedUser.roles.some((r) => r.role === newRole)) {
      toast.error("User already has this role");
      return;
    }

    try {
      const { error } = await supabase.from("user_roles").insert({
        user_id: selectedUser.user_id,
        role: newRole,
      });

      if (error) throw error;

      toast.success(`Added ${getRoleLabel(newRole)} role to ${selectedUser.full_name || selectedUser.email}`);
      setAddRoleDialogOpen(false);
      fetchUsers();
    } catch (error) {
      console.error("Error adding role:", error);
      toast.error("Failed to add role");
    }
  };

  const handleRemoveRole = async (userId: string, roleId: string, role: AppRole) => {
    // Prevent removing the last role
    const userToUpdate = users.find((u) => u.user_id === userId);
    if (userToUpdate && userToUpdate.roles.length <= 1) {
      toast.error("Cannot remove the last role. Users must have at least one role.");
      return;
    }

    try {
      const { error } = await supabase
        .from("user_roles")
        .delete()
        .eq("id", roleId);

      if (error) throw error;

      toast.success(`Removed ${getRoleLabel(role)} role`);
      fetchUsers();
    } catch (error) {
      console.error("Error removing role:", error);
      toast.error("Failed to remove role");
    }
  };

  const handleChangeRole = async (userId: string, roleId: string, currentRole: AppRole, newRole: AppRole) => {
    try {
      const { error } = await supabase
        .from("user_roles")
        .update({ role: newRole })
        .eq("id", roleId);

      if (error) throw error;

      toast.success(`Changed role from ${getRoleLabel(currentRole)} to ${getRoleLabel(newRole)}`);
      fetchUsers();
    } catch (error) {
      console.error("Error changing role:", error);
      toast.error("Failed to change role");
    }
  };

  // Filter users based on search and role filter
  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      !searchQuery ||
      u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.full_name?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole =
      filterRole === "all" || u.roles.some((r) => r.role === filterRole);

    return matchesSearch && matchesRole;
  });

  const displayName = user?.email?.split("@")[0] || "Admin";

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge variant="destructive" className="gap-1">
                <Shield className="h-3 w-3" />
                Admin
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-destructive flex items-center justify-center">
                      <Shield className="h-4 w-4 text-destructive-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      User Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          {/* Back Link */}
          <Link
            to="/admin"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Admin Dashboard
          </Link>

          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              User <span className="text-gradient-primary">Management</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              View all users, assign roles, and manage permissions
            </p>
          </div>

          {/* Filters */}
          <Card className="glass border-border mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or email..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select
                  value={filterRole}
                  onValueChange={(value) => setFilterRole(value as AppRole | "all")}
                >
                  <SelectTrigger className="w-full sm:w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {allRoles.map((role) => (
                      <SelectItem key={role} value={role}>
                        {getRoleLabel(role)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Users Table */}
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Users ({filteredUsers.length})
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-3">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : filteredUsers.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No users found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Roles</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredUsers.map((u) => (
                        <TableRow key={u.user_id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center flex-shrink-0">
                                <span className="text-sm font-semibold text-primary-foreground">
                                  {(u.full_name || u.email || "U").charAt(0).toUpperCase()}
                                </span>
                              </div>
                              <div>
                                <p className="font-medium text-foreground">
                                  {u.full_name || "No name"}
                                </p>
                                <p className="text-sm text-muted-foreground">{u.email}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-2">
                              {u.roles.map((roleEntry) => (
                                <DropdownMenu key={roleEntry.id}>
                                  <DropdownMenuTrigger asChild>
                                    <Badge
                                      className={`${getRoleColor(roleEntry.role)} cursor-pointer hover:opacity-80 transition-opacity`}
                                    >
                                      {getRoleLabel(roleEntry.role)}
                                      <ChevronDown className="h-3 w-3 ml-1" />
                                    </Badge>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent>
                                    {allRoles.map((role) => (
                                      <DropdownMenuItem
                                        key={role}
                                        onClick={() =>
                                          handleChangeRole(u.user_id, roleEntry.id, roleEntry.role, role)
                                        }
                                        disabled={role === roleEntry.role}
                                      >
                                        <Badge className={`${getRoleColor(role)} mr-2`}>
                                          {getRoleLabel(role)}
                                        </Badge>
                                        {role === roleEntry.role && (
                                          <CheckCircle className="h-4 w-4 ml-auto" />
                                        )}
                                      </DropdownMenuItem>
                                    ))}
                                    <DropdownMenuSeparator />
                                    <DropdownMenuItem
                                      onClick={() =>
                                        handleRemoveRole(u.user_id, roleEntry.id, roleEntry.role)
                                      }
                                      className="text-destructive"
                                      disabled={u.roles.length <= 1}
                                    >
                                      <Trash2 className="h-4 w-4 mr-2" />
                                      Remove Role
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className="text-sm text-muted-foreground">
                              {format(new Date(u.created_at), "MMM d, yyyy")}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <Dialog
                              open={addRoleDialogOpen && selectedUser?.user_id === u.user_id}
                              onOpenChange={(open) => {
                                setAddRoleDialogOpen(open);
                                if (open) setSelectedUser(u);
                              }}
                            >
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm" className="gap-2">
                                  <UserPlus className="h-4 w-4" />
                                  Add Role
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Add Role</DialogTitle>
                                  <DialogDescription>
                                    Add a new role to {u.full_name || u.email}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="py-4">
                                  <Select
                                    value={newRole}
                                    onValueChange={(value) => setNewRole(value as AppRole)}
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select a role" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {allRoles
                                        .filter((role) => !u.roles.some((r) => r.role === role))
                                        .map((role) => (
                                          <SelectItem key={role} value={role}>
                                            <div className="flex items-center gap-2">
                                              <Badge className={getRoleColor(role)}>
                                                {getRoleLabel(role)}
                                              </Badge>
                                            </div>
                                          </SelectItem>
                                        ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <DialogFooter>
                                  <Button variant="outline" onClick={() => setAddRoleDialogOpen(false)}>
                                    Cancel
                                  </Button>
                                  <Button onClick={handleAddRole}>Add Role</Button>
                                </DialogFooter>
                              </DialogContent>
                            </Dialog>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default UserManagement;
