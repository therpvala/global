import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Shield,
  Search,
  CheckCircle,
  Clock,
  XCircle,
  ExternalLink,
  RefreshCw,
} from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

interface Verification {
  id: string;
  domain_id: string;
  method: string;
  token: string;
  verified: boolean;
  verified_at: string | null;
  expires_at: string;
  created_at: string;
  domains?: {
    domain_name: string;
    title: string;
  };
}

const AdminDomainOwnership = () => {
  const [verifications, setVerifications] = useState<Verification[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  const fetchVerifications = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("ownership_verification")
      .select("*, domains(domain_name, title)")
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Error fetching verifications:", error);
    } else {
      setVerifications(data || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchVerifications();
  }, []);

  const handleApprove = async (id: string) => {
    const { error } = await supabase
      .from("ownership_verification")
      .update({ verified: true, verified_at: new Date().toISOString() })
      .eq("id", id);

    if (error) {
      toast.error("Failed to approve verification");
    } else {
      toast.success("Verification approved");
      fetchVerifications();
    }
  };

  const handleReject = async (id: string) => {
    const { error } = await supabase
      .from("ownership_verification")
      .delete()
      .eq("id", id);

    if (error) {
      toast.error("Failed to reject verification");
    } else {
      toast.success("Verification rejected");
      fetchVerifications();
    }
  };

  const filteredVerifications = verifications.filter(
    (v) =>
      !searchQuery ||
      v.domains?.domain_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const pendingCount = verifications.filter((v) => !v.verified).length;
  const verifiedCount = verifications.filter((v) => v.verified).length;

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Domain Ownership</h1>
        <p className="text-sm text-muted-foreground">
          Verify and manage domain ownership claims
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="text-2xl font-bold text-foreground">{verifications.length}</div>
          <div className="text-sm text-muted-foreground">Total Requests</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="text-2xl font-bold text-yellow-600">{pendingCount}</div>
          <div className="text-sm text-muted-foreground">Pending</div>
        </div>
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="text-2xl font-bold text-green-600">{verifiedCount}</div>
          <div className="text-sm text-muted-foreground">Verified</div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search verifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" onClick={fetchVerifications}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>Method</TableHead>
              <TableHead>Token</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Expires</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={7}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredVerifications.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <Shield className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No verifications found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredVerifications.map((verification) => (
                <TableRow key={verification.id} className="hover:bg-muted/30">
                  <TableCell>
                    <span className="font-medium">
                      {verification.domains?.domain_name || "Unknown"}
                    </span>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="uppercase">
                      {verification.method}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <code className="text-xs bg-muted px-2 py-1 rounded">
                      {verification.token.slice(0, 12)}...
                    </code>
                  </TableCell>
                  <TableCell>
                    {verification.verified ? (
                      <Badge className="bg-green-500/10 text-green-600">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    ) : new Date(verification.expires_at) < new Date() ? (
                      <Badge className="bg-red-500/10 text-red-600">
                        <XCircle className="h-3 w-3 mr-1" />
                        Expired
                      </Badge>
                    ) : (
                      <Badge className="bg-yellow-500/10 text-yellow-600">
                        <Clock className="h-3 w-3 mr-1" />
                        Pending
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(verification.expires_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(verification.created_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    {!verification.verified && (
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleApprove(verification.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleReject(verification.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminDomainOwnership;
