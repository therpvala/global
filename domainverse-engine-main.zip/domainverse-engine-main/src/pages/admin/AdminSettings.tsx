import { useState } from "react";
import AdminLayout from "@/components/admin/AdminLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Settings,
  Globe,
  DollarSign,
  Mail,
  Shield,
  Save,
} from "lucide-react";
import { toast } from "sonner";

const AdminSettings = () => {
  const [generalSettings, setGeneralSettings] = useState({
    siteName: "Domain Vala",
    siteUrl: "https://domainvala.com",
    supportEmail: "support@domainvala.com",
    maintenanceMode: false,
  });

  const [paymentSettings, setPaymentSettings] = useState({
    platformFee: "5",
    minWithdrawal: "100",
    escrowDays: "7",
    autoPayoutEnabled: true,
  });

  const [auctionSettings, setAuctionSettings] = useState({
    minBidIncrement: "10",
    defaultDuration: "7",
    extensionMinutes: "5",
    antiSnipingEnabled: true,
  });

  const handleSave = () => {
    toast.success("Settings saved successfully");
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Configure platform settings
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="general" className="gap-2">
            <Globe className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="payments" className="gap-2">
            <DollarSign className="h-4 w-4" />
            Payments
          </TabsTrigger>
          <TabsTrigger value="auctions" className="gap-2">
            <Settings className="h-4 w-4" />
            Auctions
          </TabsTrigger>
          <TabsTrigger value="email" className="gap-2">
            <Mail className="h-4 w-4" />
            Email
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <Card className="border border-border">
            <CardHeader>
              <CardTitle className="text-base font-semibold">General Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Site Name</Label>
                  <Input
                    value={generalSettings.siteName}
                    onChange={(e) =>
                      setGeneralSettings({ ...generalSettings, siteName: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Site URL</Label>
                  <Input
                    value={generalSettings.siteUrl}
                    onChange={(e) =>
                      setGeneralSettings({ ...generalSettings, siteUrl: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Support Email</Label>
                  <Input
                    value={generalSettings.supportEmail}
                    onChange={(e) =>
                      setGeneralSettings({ ...generalSettings, supportEmail: e.target.value })
                    }
                  />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Maintenance Mode</Label>
                  <p className="text-xs text-muted-foreground">Take the site offline for maintenance</p>
                </div>
                <Switch
                  checked={generalSettings.maintenanceMode}
                  onCheckedChange={(checked) =>
                    setGeneralSettings({ ...generalSettings, maintenanceMode: checked })
                  }
                />
              </div>
              <Button onClick={handleSave} className="gap-2">
                <Save className="h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card className="border border-border">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Payment Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Platform Fee (%)</Label>
                  <Input
                    type="number"
                    value={paymentSettings.platformFee}
                    onChange={(e) =>
                      setPaymentSettings({ ...paymentSettings, platformFee: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Minimum Withdrawal ($)</Label>
                  <Input
                    type="number"
                    value={paymentSettings.minWithdrawal}
                    onChange={(e) =>
                      setPaymentSettings({ ...paymentSettings, minWithdrawal: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Escrow Hold Days</Label>
                  <Input
                    type="number"
                    value={paymentSettings.escrowDays}
                    onChange={(e) =>
                      setPaymentSettings({ ...paymentSettings, escrowDays: e.target.value })
                    }
                  />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Auto Payout</Label>
                  <p className="text-xs text-muted-foreground">Automatically process payouts</p>
                </div>
                <Switch
                  checked={paymentSettings.autoPayoutEnabled}
                  onCheckedChange={(checked) =>
                    setPaymentSettings({ ...paymentSettings, autoPayoutEnabled: checked })
                  }
                />
              </div>
              <Button onClick={handleSave} className="gap-2">
                <Save className="h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="auctions">
          <Card className="border border-border">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Auction Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Minimum Bid Increment ($)</Label>
                  <Input
                    type="number"
                    value={auctionSettings.minBidIncrement}
                    onChange={(e) =>
                      setAuctionSettings({ ...auctionSettings, minBidIncrement: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Default Duration (days)</Label>
                  <Input
                    type="number"
                    value={auctionSettings.defaultDuration}
                    onChange={(e) =>
                      setAuctionSettings({ ...auctionSettings, defaultDuration: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Extension Minutes</Label>
                  <Input
                    type="number"
                    value={auctionSettings.extensionMinutes}
                    onChange={(e) =>
                      setAuctionSettings({ ...auctionSettings, extensionMinutes: e.target.value })
                    }
                  />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="space-y-0.5">
                  <Label className="text-sm font-medium">Anti-Sniping</Label>
                  <p className="text-xs text-muted-foreground">Extend auctions on last-minute bids</p>
                </div>
                <Switch
                  checked={auctionSettings.antiSnipingEnabled}
                  onCheckedChange={(checked) =>
                    setAuctionSettings({ ...auctionSettings, antiSnipingEnabled: checked })
                  }
                />
              </div>
              <Button onClick={handleSave} className="gap-2">
                <Save className="h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="email">
          <Card className="border border-border">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Email Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12 text-muted-foreground">
                <Mail className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Email configuration coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
};

export default AdminSettings;
