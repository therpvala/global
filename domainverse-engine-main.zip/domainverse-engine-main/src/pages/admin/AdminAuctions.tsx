import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import FraudAlertsList from "@/components/admin/FraudAlertsList";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Gavel,
  Search,
  Filter,
  ExternalLink,
  Clock,
  Activity,
  CheckCircle,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";

interface Auction {
  id: string;
  domain_id: string;
  seller_id: string;
  starting_price: number;
  current_bid: number;
  buy_now_price: number | null;
  status: string;
  start_time: string;
  end_time: string;
  created_at: string;
  domains?: {
    domain_name: string;
    title: string;
  };
}

const AdminAuctions = () => {
  const { filter } = useParams<{ filter?: string }>();
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>(filter || "all");

  useEffect(() => {
    const fetchAuctions = async () => {
      setLoading(true);
      let query = supabase
        .from("auctions")
        .select("*, domains(domain_name, title)")
        .order("created_at", { ascending: false });

      if (filter === "active") {
        query = query.eq("status", "active");
      } else if (filter === "upcoming") {
        query = query.gt("start_time", new Date().toISOString());
      } else if (filter === "ended") {
        query = query.in("status", ["completed", "ended"]);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Error fetching auctions:", error);
      } else {
        setAuctions(data || []);
      }
      setLoading(false);
    };

    fetchAuctions();
  }, [filter]);

  const filteredAuctions = auctions.filter((a) => {
    const matchesSearch =
      !searchQuery ||
      a.domains?.domain_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.domains?.title?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || a.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getPageTitle = () => {
    switch (filter) {
      case "active":
        return "Active Auctions";
      case "upcoming":
        return "Upcoming Auctions";
      case "ended":
        return "Ended Auctions";
      case "bids":
        return "Live Bids";
      case "fraud":
        return "Fraud Detection";
      default:
        return "All Auctions";
    }
  };

  const getStatusBadge = (status: string, endTime: string) => {
    const isEnded = new Date(endTime) < new Date();
    if (isEnded || status === "completed" || status === "ended") {
      return <Badge className="bg-gray-500/10 text-gray-600">Ended</Badge>;
    }
    if (status === "active") {
      return (
        <Badge className="bg-green-500/10 text-green-600">
          <Activity className="h-3 w-3 mr-1" />
          Active
        </Badge>
      );
    }
    return <Badge variant="outline">{status}</Badge>;
  };

  // Show fraud detection page
  if (filter === "fraud") {
    return (
      <AdminLayout>
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground">Fraud Detection</h1>
          <p className="text-sm text-muted-foreground">
            AI-powered analysis of bidding patterns to detect suspicious activity
          </p>
        </div>
        <FraudAlertsList />
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">{getPageTitle()}</h1>
        <p className="text-sm text-muted-foreground">
          Monitor and manage auction listings
        </p>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search auctions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="ended">Ended</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Auctions Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>Starting Price</TableHead>
              <TableHead>Current Bid</TableHead>
              <TableHead>Buy Now</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Time Left</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={7}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredAuctions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <Gavel className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No auctions found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredAuctions.map((auction) => (
                <TableRow key={auction.id} className="hover:bg-muted/30">
                  <TableCell>
                    <div>
                      <p className="font-medium text-foreground">
                        {auction.domains?.domain_name || "Unknown"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {auction.domains?.title || ""}
                      </p>
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    ${auction.starting_price.toLocaleString()}
                  </TableCell>
                  <TableCell className="font-medium text-foreground">
                    ${auction.current_bid.toLocaleString()}
                  </TableCell>
                  <TableCell>
                    {auction.buy_now_price ? (
                      <span className="font-medium">${auction.buy_now_price.toLocaleString()}</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>{getStatusBadge(auction.status, auction.end_time)}</TableCell>
                  <TableCell>
                    {new Date(auction.end_time) > new Date() ? (
                      <div className="flex items-center gap-1 text-sm">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        {formatDistanceToNow(new Date(auction.end_time))}
                      </div>
                    ) : (
                      <span className="text-muted-foreground text-sm">Ended</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" asChild>
                      <Link to={`/auction/${auction.id}`}>
                        <ExternalLink className="h-4 w-4" />
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminAuctions;
