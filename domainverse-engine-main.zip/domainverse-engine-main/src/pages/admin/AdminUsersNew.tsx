import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Users,
  Search,
  Filter,
  ChevronDown,
  UserPlus,
  Trash2,
  CheckCircle,
} from "lucide-react";
import { AppRole, getRoleLabel, getRoleColor } from "@/hooks/useUserRole";
import { toast } from "sonner";
import { format } from "date-fns";

interface UserWithRoles {
  user_id: string;
  email: string | null;
  full_name: string | null;
  created_at: string;
  roles: { id: string; role: AppRole; created_at: string }[];
}

const allRoles: AppRole[] = ["admin", "investor", "expert", "reseller", "franchise", "buyer"];

const AdminUsersNew = () => {
  const [users, setUsers] = useState<UserWithRoles[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterRole, setFilterRole] = useState<AppRole | "all">("all");
  const [selectedUser, setSelectedUser] = useState<UserWithRoles | null>(null);
  const [addRoleDialogOpen, setAddRoleDialogOpen] = useState(false);
  const [newRole, setNewRole] = useState<AppRole>("buyer");

  const fetchUsers = async () => {
    try {
      const { data: rolesData, error: rolesError } = await supabase
        .from("user_roles")
        .select("id, user_id, role, created_at")
        .order("created_at", { ascending: false });

      if (rolesError) throw rolesError;

      const { data: profilesData, error: profilesError } = await supabase
        .from("profiles")
        .select("user_id, email, full_name, created_at");

      if (profilesError) throw profilesError;

      const userMap = new Map<string, UserWithRoles>();

      rolesData?.forEach((roleEntry) => {
        const profile = profilesData?.find((p) => p.user_id === roleEntry.user_id);
        
        if (!userMap.has(roleEntry.user_id)) {
          userMap.set(roleEntry.user_id, {
            user_id: roleEntry.user_id,
            email: profile?.email || null,
            full_name: profile?.full_name || null,
            created_at: profile?.created_at || roleEntry.created_at,
            roles: [],
          });
        }
        
        userMap.get(roleEntry.user_id)?.roles.push({
          id: roleEntry.id,
          role: roleEntry.role as AppRole,
          created_at: roleEntry.created_at,
        });
      });

      setUsers(Array.from(userMap.values()));
    } catch (error) {
      console.error("Error fetching users:", error);
      toast.error("Failed to load users");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleAddRole = async () => {
    if (!selectedUser) return;

    if (selectedUser.roles.some((r) => r.role === newRole)) {
      toast.error("User already has this role");
      return;
    }

    try {
      const { error } = await supabase.from("user_roles").insert({
        user_id: selectedUser.user_id,
        role: newRole,
      });

      if (error) throw error;

      toast.success(`Added ${getRoleLabel(newRole)} role`);
      setAddRoleDialogOpen(false);
      fetchUsers();
    } catch (error) {
      console.error("Error adding role:", error);
      toast.error("Failed to add role");
    }
  };

  const handleRemoveRole = async (userId: string, roleId: string, role: AppRole) => {
    const userToUpdate = users.find((u) => u.user_id === userId);
    if (userToUpdate && userToUpdate.roles.length <= 1) {
      toast.error("Cannot remove the last role");
      return;
    }

    try {
      const { error } = await supabase.from("user_roles").delete().eq("id", roleId);
      if (error) throw error;
      toast.success(`Removed ${getRoleLabel(role)} role`);
      fetchUsers();
    } catch (error) {
      console.error("Error removing role:", error);
      toast.error("Failed to remove role");
    }
  };

  const handleChangeRole = async (userId: string, roleId: string, currentRole: AppRole, newRole: AppRole) => {
    try {
      const { error } = await supabase.from("user_roles").update({ role: newRole }).eq("id", roleId);
      if (error) throw error;
      toast.success(`Changed role to ${getRoleLabel(newRole)}`);
      fetchUsers();
    } catch (error) {
      console.error("Error changing role:", error);
      toast.error("Failed to change role");
    }
  };

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      !searchQuery ||
      u.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.full_name?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole =
      filterRole === "all" || u.roles.some((r) => r.role === filterRole);

    return matchesSearch && matchesRole;
  });

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Users & Roles</h1>
        <p className="text-sm text-muted-foreground">
          Manage user accounts and role assignments
        </p>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select
            value={filterRole}
            onValueChange={(value) => setFilterRole(value as AppRole | "all")}
          >
            <SelectTrigger className="w-full sm:w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filter by role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              {allRoles.map((role) => (
                <SelectItem key={role} value={role}>
                  {getRoleLabel(role)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>User</TableHead>
              <TableHead>Roles</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={4}>
                    <div className="h-14 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredUsers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-12">
                  <Users className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No users found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredUsers.map((u) => (
                <TableRow key={u.user_id} className="hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-semibold text-primary">
                          {(u.full_name || u.email || "U").charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground text-sm">
                          {u.full_name || "No name"}
                        </p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-wrap gap-1.5">
                      {u.roles.map((roleEntry) => (
                        <DropdownMenu key={roleEntry.id}>
                          <DropdownMenuTrigger asChild>
                            <Badge
                              className={`${getRoleColor(roleEntry.role)} cursor-pointer text-xs`}
                            >
                              {getRoleLabel(roleEntry.role)}
                              <ChevronDown className="h-3 w-3 ml-1" />
                            </Badge>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent>
                            {allRoles.map((role) => (
                              <DropdownMenuItem
                                key={role}
                                onClick={() =>
                                  handleChangeRole(u.user_id, roleEntry.id, roleEntry.role, role)
                                }
                                disabled={role === roleEntry.role}
                              >
                                <Badge className={`${getRoleColor(role)} mr-2 text-xs`}>
                                  {getRoleLabel(role)}
                                </Badge>
                                {role === roleEntry.role && (
                                  <CheckCircle className="h-3 w-3 ml-auto" />
                                )}
                              </DropdownMenuItem>
                            ))}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() =>
                                handleRemoveRole(u.user_id, roleEntry.id, roleEntry.role)
                              }
                              className="text-destructive text-xs"
                              disabled={u.roles.length <= 1}
                            >
                              <Trash2 className="h-3 w-3 mr-2" />
                              Remove Role
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      ))}
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(u.created_at), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <Dialog
                      open={addRoleDialogOpen && selectedUser?.user_id === u.user_id}
                      onOpenChange={(open) => {
                        setAddRoleDialogOpen(open);
                        if (open) setSelectedUser(u);
                      }}
                    >
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-1.5">
                          <UserPlus className="h-3.5 w-3.5" />
                          Add Role
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Add Role</DialogTitle>
                          <DialogDescription>
                            Add a new role to {u.full_name || u.email}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="py-4">
                          <Select
                            value={newRole}
                            onValueChange={(value) => setNewRole(value as AppRole)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                            <SelectContent>
                              {allRoles.map((role) => (
                                <SelectItem
                                  key={role}
                                  value={role}
                                  disabled={u.roles.some((r) => r.role === role)}
                                >
                                  {getRoleLabel(role)}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setAddRoleDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={handleAddRole}>Add Role</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminUsersNew;
