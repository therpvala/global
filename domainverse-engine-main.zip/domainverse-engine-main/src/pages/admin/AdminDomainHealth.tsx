import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Activity,
  Search,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { format } from "date-fns";

interface DomainHealth {
  id: string;
  domain_id: string;
  dns_status: string;
  ssl_status: string;
  blacklist_status: string;
  last_check_at: string;
  domains?: {
    domain_name: string;
    title: string;
  };
}

const getStatusIcon = (status: string) => {
  switch (status) {
    case "ok":
    case "valid":
    case "active":
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    case "error":
    case "invalid":
    case "failed":
      return <XCircle className="h-4 w-4 text-red-600" />;
    case "warning":
      return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    default:
      return <Activity className="h-4 w-4 text-muted-foreground" />;
  }
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case "ok":
    case "valid":
    case "active":
      return "bg-green-500/10 text-green-600";
    case "error":
    case "invalid":
    case "failed":
      return "bg-red-500/10 text-red-600";
    case "warning":
      return "bg-yellow-500/10 text-yellow-600";
    default:
      return "bg-gray-500/10 text-gray-600";
  }
};

const AdminDomainHealth = () => {
  const [healthData, setHealthData] = useState<DomainHealth[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchHealthData = async () => {
      setLoading(true);
      
      const { data, error } = await supabase
        .from("domain_health")
        .select("*, domains(domain_name, title)")
        .order("last_check_at", { ascending: false });

      if (error) {
        console.error("Error fetching health data:", error);
      } else {
        setHealthData(data || []);
      }
      setLoading(false);
    };

    fetchHealthData();
  }, []);

  const filteredData = healthData.filter((h) =>
    !searchQuery ||
    h.domains?.domain_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Domain Health Check</h1>
        <p className="text-sm text-muted-foreground">
          Monitor DNS, SSL, and blacklist status
        </p>
      </div>

      {/* Search & Actions */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search domains..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="gap-2">
            <RefreshCw className="h-4 w-4" />
            Run Health Check
          </Button>
        </div>
      </div>

      {/* Health Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>DNS Status</TableHead>
              <TableHead>SSL Status</TableHead>
              <TableHead>Blacklist</TableHead>
              <TableHead>Last Check</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={5}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredData.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-12">
                  <Activity className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No health data found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredData.map((health) => (
                <TableRow key={health.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium">
                    {health.domains?.domain_name || "Unknown"}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(health.dns_status)}
                      <Badge className={getStatusBadge(health.dns_status)}>
                        {health.dns_status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(health.ssl_status)}
                      <Badge className={getStatusBadge(health.ssl_status)}>
                        {health.ssl_status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(health.blacklist_status)}
                      <Badge className={getStatusBadge(health.blacklist_status)}>
                        {health.blacklist_status}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {health.last_check_at
                      ? format(new Date(health.last_check_at), "MMM d, HH:mm")
                      : "Never"}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminDomainHealth;
