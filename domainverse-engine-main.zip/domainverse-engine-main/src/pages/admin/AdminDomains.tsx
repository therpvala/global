import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Globe,
  Search,
  Filter,
  ExternalLink,
  CheckCircle,
  Clock,
  AlertTriangle,
  XCircle,
} from "lucide-react";
import { format } from "date-fns";

interface Domain {
  id: string;
  domain_name: string;
  title: string;
  price: number;
  status: string;
  category: string;
  health_score: number;
  created_at: string;
  user_id: string;
}

const statusConfig = {
  active: { label: "Active", icon: CheckCircle, class: "bg-green-500/10 text-green-600" },
  pending: { label: "Pending", icon: Clock, class: "bg-yellow-500/10 text-yellow-600" },
  expired: { label: "Expired", icon: AlertTriangle, class: "bg-red-500/10 text-red-600" },
  sold: { label: "Sold", icon: CheckCircle, class: "bg-blue-500/10 text-blue-600" },
};

const AdminDomains = () => {
  const { filter } = useParams<{ filter?: string }>();
  const [domains, setDomains] = useState<Domain[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>(filter || "all");

  useEffect(() => {
    const fetchDomains = async () => {
      setLoading(true);
      let query = supabase.from("domains").select("*").order("created_at", { ascending: false });

      if (filter && filter !== "all") {
        query = query.eq("status", filter);
      }

      const { data, error } = await query;

      if (error) {
        console.error("Error fetching domains:", error);
      } else {
        setDomains(data || []);
      }
      setLoading(false);
    };

    fetchDomains();
  }, [filter]);

  const filteredDomains = domains.filter((d) => {
    const matchesSearch =
      !searchQuery ||
      d.domain_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.title.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === "all" || d.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getPageTitle = () => {
    switch (filter) {
      case "active":
        return "Active Domains";
      case "pending":
        return "Pending Verification";
      case "expired":
        return "Expired Domains";
      case "sold":
        return "Sold Domains";
      default:
        return "All Domains";
    }
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">{getPageTitle()}</h1>
        <p className="text-sm text-muted-foreground">
          Manage and monitor domain listings
        </p>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search domains..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="expired">Expired</SelectItem>
              <SelectItem value="sold">Sold</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Domains Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Health</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={7}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredDomains.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <Globe className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No domains found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredDomains.map((domain) => {
                const status = statusConfig[domain.status as keyof typeof statusConfig] || statusConfig.active;
                const StatusIcon = status.icon;
                return (
                  <TableRow key={domain.id} className="hover:bg-muted/30">
                    <TableCell>
                      <div>
                        <p className="font-medium text-foreground">{domain.domain_name}</p>
                        <p className="text-xs text-muted-foreground">{domain.title}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{domain.category}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">
                      ${domain.price.toLocaleString()}
                    </TableCell>
                    <TableCell>
                      <Badge className={status.class}>
                        <StatusIcon className="h-3 w-3 mr-1" />
                        {status.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${domain.health_score || 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {domain.health_score || 0}%
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(domain.created_at), "MMM d, yyyy")}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" asChild>
                        <Link to={`/domain/${domain.id}`}>
                          <ExternalLink className="h-4 w-4" />
                        </Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminDomains;
