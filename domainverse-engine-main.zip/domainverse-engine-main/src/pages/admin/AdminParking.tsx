import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ParkingSquare,
  Search,
  DollarSign,
  MousePointer,
  Eye,
  TrendingUp,
} from "lucide-react";
import { format } from "date-fns";

interface ParkedDomain {
  id: string;
  domain_id: string;
  user_id: string;
  monthly_earnings: number;
  total_earnings: number;
  clicks: number;
  impressions: number;
  status: string;
  parked_at: string;
  domains?: {
    domain_name: string;
    title: string;
  };
}

interface ParkingStats {
  totalParked: number;
  totalEarnings: number;
  totalClicks: number;
  totalImpressions: number;
}

const AdminParking = () => {
  const [parkedDomains, setParkedDomains] = useState<ParkedDomain[]>([]);
  const [stats, setStats] = useState<ParkingStats>({
    totalParked: 0,
    totalEarnings: 0,
    totalClicks: 0,
    totalImpressions: 0,
  });
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      const { data: parkedData } = await supabase
        .from("parked_domains")
        .select("*, domains(domain_name, title)")
        .order("total_earnings", { ascending: false });

      if (parkedData) {
        setParkedDomains(parkedData);
        const totalEarnings = parkedData.reduce((sum, p) => sum + Number(p.total_earnings), 0);
        const totalClicks = parkedData.reduce((sum, p) => sum + p.clicks, 0);
        const totalImpressions = parkedData.reduce((sum, p) => sum + p.impressions, 0);
        setStats({
          totalParked: parkedData.length,
          totalEarnings,
          totalClicks,
          totalImpressions,
        });
      }
      
      setLoading(false);
    };

    fetchData();
  }, []);

  const filteredDomains = parkedDomains.filter((p) =>
    !searchQuery ||
    p.domains?.domain_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Domain Parking</h1>
        <p className="text-sm text-muted-foreground">
          Monitor parked domains and earnings
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatsCard label="Parked Domains" value={stats.totalParked} icon={ParkingSquare} />
        <StatsCard label="Total Earnings" value={`$${stats.totalEarnings.toLocaleString()}`} icon={DollarSign} />
        <StatsCard label="Total Clicks" value={stats.totalClicks.toLocaleString()} icon={MousePointer} />
        <StatsCard label="Impressions" value={stats.totalImpressions.toLocaleString()} icon={Eye} />
      </div>

      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search parked domains..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Parked Domains Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>Monthly</TableHead>
              <TableHead>Total Earnings</TableHead>
              <TableHead>Clicks</TableHead>
              <TableHead>Impressions</TableHead>
              <TableHead>CTR</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Parked At</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={8}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredDomains.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-12">
                  <ParkingSquare className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No parked domains found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredDomains.map((parked) => {
                const ctr = parked.impressions > 0 
                  ? ((parked.clicks / parked.impressions) * 100).toFixed(2)
                  : "0.00";
                return (
                  <TableRow key={parked.id} className="hover:bg-muted/30">
                    <TableCell>
                      <span className="font-medium">{parked.domains?.domain_name || "Unknown"}</span>
                    </TableCell>
                    <TableCell className="text-green-600 font-medium">
                      ${Number(parked.monthly_earnings).toFixed(2)}
                    </TableCell>
                    <TableCell className="font-medium">
                      ${Number(parked.total_earnings).toFixed(2)}
                    </TableCell>
                    <TableCell>{parked.clicks.toLocaleString()}</TableCell>
                    <TableCell>{parked.impressions.toLocaleString()}</TableCell>
                    <TableCell>{ctr}%</TableCell>
                    <TableCell>
                      <Badge
                        className={
                          parked.status === "active"
                            ? "bg-green-500/10 text-green-600"
                            : "bg-gray-500/10 text-gray-600"
                        }
                      >
                        {parked.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {format(new Date(parked.parked_at), "MMM d, yyyy")}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminParking;
