import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Star,
  Search,
  Users,
  BarChart3,
  DollarSign,
  FileText,
} from "lucide-react";
import { format } from "date-fns";

interface Expert {
  id: string;
  user_id: string;
  rating: number;
  success_rate: number;
  total_suggestions: number;
  approved_suggestions: number;
  commission_rate: number;
  status: string;
  created_at: string;
}

interface ExpertStats {
  totalExperts: number;
  totalSuggestions: number;
  avgSuccessRate: number;
  totalCommissions: number;
}

const AdminExperts = () => {
  const [experts, setExperts] = useState<Expert[]>([]);
  const [stats, setStats] = useState<ExpertStats>({
    totalExperts: 0,
    totalSuggestions: 0,
    avgSuccessRate: 0,
    totalCommissions: 0,
  });
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      const { data: expertsData } = await supabase
        .from("experts")
        .select("*")
        .order("rating", { ascending: false });

      if (expertsData) {
        setExperts(expertsData);
        const totalSuggestions = expertsData.reduce((sum, exp) => sum + exp.total_suggestions, 0);
        const avgSuccess = expertsData.length > 0
          ? expertsData.reduce((sum, exp) => sum + Number(exp.success_rate), 0) / expertsData.length
          : 0;
        setStats({
          totalExperts: expertsData.length,
          totalSuggestions,
          avgSuccessRate: Math.round(avgSuccess * 10) / 10,
          totalCommissions: 5240, // Simulated
        });
      }
      
      setLoading(false);
    };

    fetchData();
  }, []);

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Domain Experts</h1>
        <p className="text-sm text-muted-foreground">
          Manage expert accounts and performance
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatsCard label="Total Experts" value={stats.totalExperts} icon={Users} />
        <StatsCard label="Suggestions" value={stats.totalSuggestions} icon={FileText} />
        <StatsCard label="Avg Success Rate" value={`${stats.avgSuccessRate}%`} icon={BarChart3} />
        <StatsCard label="Commissions" value={`$${stats.totalCommissions.toLocaleString()}`} icon={DollarSign} />
      </div>

      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search experts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Experts Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Expert ID</TableHead>
              <TableHead>Rating</TableHead>
              <TableHead>Success Rate</TableHead>
              <TableHead>Suggestions</TableHead>
              <TableHead>Approved</TableHead>
              <TableHead>Commission %</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={7}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : experts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12">
                  <Star className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No experts found</p>
                </TableCell>
              </TableRow>
            ) : (
              experts.map((expert) => (
                <TableRow key={expert.id} className="hover:bg-muted/30">
                  <TableCell className="font-mono text-sm">
                    {expert.id.slice(0, 8)}...
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                      <span className="font-medium">{Number(expert.rating).toFixed(1)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500"
                          style={{ width: `${expert.success_rate}%` }}
                        />
                      </div>
                      <span className="text-sm">{Number(expert.success_rate).toFixed(0)}%</span>
                    </div>
                  </TableCell>
                  <TableCell>{expert.total_suggestions}</TableCell>
                  <TableCell>{expert.approved_suggestions}</TableCell>
                  <TableCell>{expert.commission_rate}%</TableCell>
                  <TableCell>
                    <Badge
                      className={
                        expert.status === "active"
                          ? "bg-green-500/10 text-green-600"
                          : "bg-gray-500/10 text-gray-600"
                      }
                    >
                      {expert.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminExperts;
