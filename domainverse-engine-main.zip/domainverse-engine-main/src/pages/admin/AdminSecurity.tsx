import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import SecurityEventsList from "@/components/admin/SecurityEventsList";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Shield,
  Lock,
  Key,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Eye,
  Users,
} from "lucide-react";

const AdminSecurity = () => {
  const [settings, setSettings] = useState({
    twoFactorRequired: false,
    domainTransferLock: true,
    auditLogging: true,
    rateLimiting: true,
    adminApprovalRequired: true,
  });

  const handleToggle = (key: keyof typeof settings) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const securityChecks = [
    { name: "SSL Certificate", status: "active", lastCheck: "2 hours ago" },
    { name: "Database Encryption", status: "active", lastCheck: "1 hour ago" },
    { name: "Firewall Rules", status: "active", lastCheck: "30 minutes ago" },
    { name: "Backup Status", status: "active", lastCheck: "6 hours ago" },
    { name: "API Rate Limits", status: "active", lastCheck: "15 minutes ago" },
  ];

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Security</h1>
        <p className="text-sm text-muted-foreground">
          Security settings and monitoring
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Security Status */}
        <Card className="border border-border">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              Security Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {securityChecks.map((check) => (
              <div
                key={check.name}
                className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{check.name}</p>
                    <p className="text-xs text-muted-foreground">Last check: {check.lastCheck}</p>
                  </div>
                </div>
                <Badge className="bg-green-500/10 text-green-600">{check.status}</Badge>
              </div>
            ))}
            <Button variant="outline" className="w-full gap-2">
              <RefreshCw className="h-4 w-4" />
              Run Security Scan
            </Button>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card className="border border-border">
          <CardHeader>
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <Lock className="h-4 w-4 text-primary" />
              Security Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Two-Factor Authentication Required</Label>
                <p className="text-xs text-muted-foreground">Require 2FA for all admin users</p>
              </div>
              <Switch
                checked={settings.twoFactorRequired}
                onCheckedChange={() => handleToggle("twoFactorRequired")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Domain Transfer Lock</Label>
                <p className="text-xs text-muted-foreground">Lock domains from unauthorized transfers</p>
              </div>
              <Switch
                checked={settings.domainTransferLock}
                onCheckedChange={() => handleToggle("domainTransferLock")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Audit Logging</Label>
                <p className="text-xs text-muted-foreground">Log all admin actions</p>
              </div>
              <Switch
                checked={settings.auditLogging}
                onCheckedChange={() => handleToggle("auditLogging")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">API Rate Limiting</Label>
                <p className="text-xs text-muted-foreground">Limit API requests per user</p>
              </div>
              <Switch
                checked={settings.rateLimiting}
                onCheckedChange={() => handleToggle("rateLimiting")}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Admin Approval Required</Label>
                <p className="text-xs text-muted-foreground">Require approval for sales, payouts, auctions</p>
              </div>
              <Switch
                checked={settings.adminApprovalRequired}
                onCheckedChange={() => handleToggle("adminApprovalRequired")}
              />
            </div>
          </CardContent>
        </Card>

        {/* Recent Security Events - Now using real data */}
        <SecurityEventsList />
      </div>
    </AdminLayout>
  );
};

export default AdminSecurity;
