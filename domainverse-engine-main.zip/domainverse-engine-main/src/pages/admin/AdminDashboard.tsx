import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  Users,
  Globe,
  Gavel,
  TrendingUp,
  Shield,
  Settings,
  LogOut,
  BarChart3,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  ChevronDown,
  LayoutDashboard,
  User,
  UserCog,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { AppRole, getRoleLabel, getRoleColor } from "@/hooks/useUserRole";

interface UserStats {
  totalUsers: number;
  totalDomains: number;
  activeAuctions: number;
  totalTransactions: number;
  revenue: number;
}

interface UserWithRole {
  id: string;
  user_id: string;
  email: string | null;
  full_name: string | null;
  created_at: string;
  role: AppRole;
}

const AdminDashboard = () => {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<UserStats>({
    totalUsers: 0,
    totalDomains: 0,
    activeAuctions: 0,
    totalTransactions: 0,
    revenue: 0,
  });
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch users with roles
        const { data: rolesData } = await supabase
          .from("user_roles")
          .select("id, user_id, role, created_at");

        // Fetch profiles
        const { data: profilesData } = await supabase
          .from("profiles")
          .select("user_id, email, full_name");

        // Merge data
        const mergedUsers = rolesData?.map((roleEntry) => {
          const profile = profilesData?.find((p) => p.user_id === roleEntry.user_id);
          return {
            id: roleEntry.id,
            user_id: roleEntry.user_id,
            email: profile?.email || null,
            full_name: profile?.full_name || null,
            created_at: roleEntry.created_at,
            role: roleEntry.role as AppRole,
          };
        }) || [];

        setUsers(mergedUsers);

        // Fetch stats
        const { count: domainsCount } = await supabase
          .from("domains")
          .select("*", { count: "exact", head: true });

        const { count: auctionsCount } = await supabase
          .from("auctions")
          .select("*", { count: "exact", head: true })
          .eq("status", "active");

        const { data: transactionsData } = await supabase
          .from("transactions")
          .select("amount, type");

        const totalRevenue = transactionsData?.reduce((sum, t) => {
          if (t.type === "sale" || t.type === "purchase") {
            return sum + (t.amount * 0.05); // 5% platform fee
          }
          return sum;
        }, 0) || 0;

        setStats({
          totalUsers: new Set(rolesData?.map((r) => r.user_id)).size,
          totalDomains: domainsCount || 0,
          activeAuctions: auctionsCount || 0,
          totalTransactions: transactionsData?.length || 0,
          revenue: totalRevenue,
        });
      } catch (error) {
        console.error("Error fetching admin data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleRoleChange = async (userId: string, currentRole: AppRole, newRole: AppRole) => {
    try {
      const { error } = await supabase
        .from("user_roles")
        .update({ role: newRole })
        .eq("user_id", userId)
        .eq("role", currentRole);

      if (error) throw error;

      setUsers((prev) =>
        prev.map((u) =>
          u.user_id === userId && u.role === currentRole ? { ...u, role: newRole } : u
        )
      );
    } catch (error) {
      console.error("Error updating role:", error);
    }
  };

  const statsCards = [
    { label: "Total Users", value: stats.totalUsers, icon: Users, color: "text-primary" },
    { label: "Total Domains", value: stats.totalDomains, icon: Globe, color: "text-accent" },
    { label: "Active Auctions", value: stats.activeAuctions, icon: Gavel, color: "text-primary" },
    { label: "Transactions", value: stats.totalTransactions, icon: TrendingUp, color: "text-accent" },
    { label: "Platform Revenue", value: `$${stats.revenue.toLocaleString()}`, icon: DollarSign, color: "text-primary" },
  ];

  const displayName = user?.email?.split("@")[0] || "Admin";

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge variant="destructive" className="gap-1">
                <Shield className="h-3 w-3" />
                Admin
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-destructive flex items-center justify-center">
                      <Shield className="h-4 w-4 text-destructive-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      User Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Admin <span className="text-gradient-primary">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage users, monitor platform activity, and oversee operations
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat, index) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Admin Actions
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/admin/users">
                  <UserCog className="h-6 w-6 text-primary" />
                  <span>Manage Users</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Globe className="h-6 w-6 text-primary" />
                  <span>View Domains</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/auctions">
                  <Gavel className="h-6 w-6 text-primary" />
                  <span>View Auctions</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/dashboard">
                  <LayoutDashboard className="h-6 w-6 text-primary" />
                  <span>User Dashboard</span>
                </Link>
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="users" className="space-y-6">
            <TabsList className="glass">
              <TabsTrigger value="users" className="gap-2">
                <UserCog className="h-4 w-4" />
                User Overview
              </TabsTrigger>
              <TabsTrigger value="analytics" className="gap-2">
                <BarChart3 className="h-4 w-4" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="reports" className="gap-2">
                <AlertTriangle className="h-4 w-4" />
                Reports
              </TabsTrigger>
            </TabsList>

            <TabsContent value="users">
              <Card className="glass border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    All Users ({users.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="space-y-3">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {users.map((u) => (
                        <div
                          key={u.id}
                          className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
                              <span className="text-sm font-semibold text-primary-foreground">
                                {(u.full_name || u.email || "U").charAt(0).toUpperCase()}
                              </span>
                            </div>
                            <div>
                              <p className="font-medium text-foreground">
                                {u.full_name || "No name"}
                              </p>
                              <p className="text-sm text-muted-foreground">{u.email}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="outline" size="sm" className="gap-2">
                                  <Badge className={getRoleColor(u.role)}>
                                    {getRoleLabel(u.role)}
                                  </Badge>
                                  <ChevronDown className="h-3 w-3" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                {(["admin", "investor", "expert", "reseller", "franchise", "buyer"] as AppRole[]).map(
                                  (role) => (
                                    <DropdownMenuItem
                                      key={role}
                                      onClick={() => handleRoleChange(u.user_id, u.role, role)}
                                      disabled={role === u.role}
                                    >
                                      <Badge className={`${getRoleColor(role)} mr-2`}>
                                        {getRoleLabel(role)}
                                      </Badge>
                                      {role === u.role && <CheckCircle className="h-4 w-4 ml-auto" />}
                                    </DropdownMenuItem>
                                  )
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics">
              <Card className="glass border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-primary" />
                    Platform Analytics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-6 rounded-lg bg-muted/30 text-center">
                      <TrendingUp className="h-10 w-10 text-primary mx-auto mb-3" />
                      <div className="text-3xl font-bold text-foreground">+24%</div>
                      <div className="text-sm text-muted-foreground">User Growth</div>
                    </div>
                    <div className="p-6 rounded-lg bg-muted/30 text-center">
                      <DollarSign className="h-10 w-10 text-accent mx-auto mb-3" />
                      <div className="text-3xl font-bold text-foreground">+18%</div>
                      <div className="text-sm text-muted-foreground">Revenue Growth</div>
                    </div>
                    <div className="p-6 rounded-lg bg-muted/30 text-center">
                      <Gavel className="h-10 w-10 text-primary mx-auto mb-3" />
                      <div className="text-3xl font-bold text-foreground">+32%</div>
                      <div className="text-sm text-muted-foreground">Auction Activity</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reports">
              <Card className="glass border-border">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-primary" />
                    System Reports
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-foreground mb-2">All Systems Operational</h3>
                    <p className="text-muted-foreground">No issues reported in the last 24 hours</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
