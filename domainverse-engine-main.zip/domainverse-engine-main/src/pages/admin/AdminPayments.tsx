import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Wallet,
  Search,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  Lock,
  CheckCircle,
  Clock,
  AlertTriangle,
} from "lucide-react";
import { format } from "date-fns";

interface Transaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
}

interface PaymentStats {
  totalWalletBalance: number;
  pendingEscrow: number;
  totalTransactions: number;
  pendingPayouts: number;
}

const AdminPayments = () => {
  const { section } = useParams<{ section?: string }>();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<PaymentStats>({
    totalWalletBalance: 0,
    pendingEscrow: 0,
    totalTransactions: 0,
    pendingPayouts: 0,
  });
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      const [
        { data: transactionsData },
        { data: walletsData },
        { data: escrowData },
        { count: payoutsCount },
      ] = await Promise.all([
        supabase.from("transactions").select("*").order("created_at", { ascending: false }).limit(100),
        supabase.from("wallets").select("balance"),
        supabase.from("escrow").select("amount").eq("status", "pending"),
        supabase.from("payouts").select("*", { count: "exact", head: true }).eq("status", "pending"),
      ]);

      if (transactionsData) {
        setTransactions(transactionsData);
      }

      const totalBalance = walletsData?.reduce((sum, w) => sum + Number(w.balance), 0) || 0;
      const pendingEscrow = escrowData?.reduce((sum, e) => sum + Number(e.amount), 0) || 0;

      setStats({
        totalWalletBalance: totalBalance,
        pendingEscrow,
        totalTransactions: transactionsData?.length || 0,
        pendingPayouts: payoutsCount || 0,
      });
      
      setLoading(false);
    };

    fetchData();
  }, [section]);

  const getPageTitle = () => {
    switch (section) {
      case "wallets":
        return "Wallets";
      case "escrow":
        return "Escrow";
      case "transactions":
        return "Transactions";
      case "auto-payout":
        return "Auto Payout";
      case "failed":
        return "Failed Payments";
      default:
        return "Payments & Escrow";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownRight className="h-4 w-4 text-green-600" />;
      case "withdrawal":
        return <ArrowUpRight className="h-4 w-4 text-red-600" />;
      case "purchase":
        return <ArrowUpRight className="h-4 w-4 text-blue-600" />;
      case "sale":
        return <ArrowDownRight className="h-4 w-4 text-green-600" />;
      default:
        return <DollarSign className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      deposit: "bg-green-500/10 text-green-600",
      withdrawal: "bg-red-500/10 text-red-600",
      purchase: "bg-blue-500/10 text-blue-600",
      sale: "bg-purple-500/10 text-purple-600",
    };
    return colors[type] || "bg-gray-500/10 text-gray-600";
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">{getPageTitle()}</h1>
        <p className="text-sm text-muted-foreground">
          Manage payments, escrow, and transactions
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatsCard label="Total Balance" value={`$${stats.totalWalletBalance.toLocaleString()}`} icon={Wallet} />
        <StatsCard label="Pending Escrow" value={`$${stats.pendingEscrow.toLocaleString()}`} icon={Lock} />
        <StatsCard label="Transactions" value={stats.totalTransactions} icon={DollarSign} />
        <StatsCard label="Pending Payouts" value={stats.pendingPayouts} icon={Clock} />
      </div>

      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search transactions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Transactions Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={4}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : transactions.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} className="text-center py-12">
                  <Wallet className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No transactions found</p>
                </TableCell>
              </TableRow>
            ) : (
              transactions.map((transaction) => (
                <TableRow key={transaction.id} className="hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getTypeIcon(transaction.type)}
                      <Badge className={getTypeBadge(transaction.type)}>
                        {transaction.type}
                      </Badge>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">
                    ${Number(transaction.amount).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {transaction.description || "—"}
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(transaction.created_at), "MMM d, yyyy HH:mm")}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminPayments;
