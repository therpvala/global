import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import AdminLayout from "@/components/admin/AdminLayout";
import StatsCard from "@/components/admin/StatsCard";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Briefcase,
  Search,
  TrendingUp,
  DollarSign,
  Globe,
  Users,
} from "lucide-react";
import { format } from "date-fns";

interface Investment {
  id: string;
  investor_id: string;
  domain_id: string;
  amount: number;
  share_percentage: number;
  status: string;
  created_at: string;
  domains?: {
    domain_name: string;
    title: string;
    price: number;
  };
}

interface InvestorStats {
  totalInvestors: number;
  totalInvestments: number;
  totalAmount: number;
  avgROI: number;
}

const AdminInvestors = () => {
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [stats, setStats] = useState<InvestorStats>({
    totalInvestors: 0,
    totalInvestments: 0,
    totalAmount: 0,
    avgROI: 0,
  });
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
      const [{ data: investmentsData }, { count: investorsCount }] = await Promise.all([
        supabase.from("investments").select("*, domains(domain_name, title, price)").order("created_at", { ascending: false }),
        supabase.from("user_roles").select("*", { count: "exact", head: true }).eq("role", "investor"),
      ]);

      if (investmentsData) {
        setInvestments(investmentsData);
        const totalAmount = investmentsData.reduce((sum, inv) => sum + Number(inv.amount), 0);
        setStats({
          totalInvestors: investorsCount || 0,
          totalInvestments: investmentsData.length,
          totalAmount,
          avgROI: 15.5, // Simulated
        });
      }
      
      setLoading(false);
    };

    fetchData();
  }, []);

  const filteredInvestments = investments.filter((inv) =>
    !searchQuery ||
    inv.domains?.domain_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground">Investors</h1>
        <p className="text-sm text-muted-foreground">
          Manage investor accounts and investments
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatsCard label="Total Investors" value={stats.totalInvestors} icon={Users} />
        <StatsCard label="Investments" value={stats.totalInvestments} icon={Briefcase} />
        <StatsCard label="Total Invested" value={`$${stats.totalAmount.toLocaleString()}`} icon={DollarSign} />
        <StatsCard label="Avg ROI" value={`${stats.avgROI}%`} icon={TrendingUp} />
      </div>

      {/* Search */}
      <div className="bg-card border border-border rounded-lg p-4 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search investments..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Investments Table */}
      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Domain</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Share %</TableHead>
              <TableHead>Domain Value</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={6}>
                    <div className="h-12 bg-muted/50 rounded animate-pulse" />
                  </TableCell>
                </TableRow>
              ))
            ) : filteredInvestments.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-12">
                  <Briefcase className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">No investments found</p>
                </TableCell>
              </TableRow>
            ) : (
              filteredInvestments.map((investment) => (
                <TableRow key={investment.id} className="hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{investment.domains?.domain_name || "Unknown"}</span>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">
                    ${Number(investment.amount).toLocaleString()}
                  </TableCell>
                  <TableCell>{investment.share_percentage}%</TableCell>
                  <TableCell className="text-muted-foreground">
                    ${investment.domains?.price?.toLocaleString() || "—"}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={
                        investment.status === "active"
                          ? "bg-green-500/10 text-green-600"
                          : "bg-gray-500/10 text-gray-600"
                      }
                    >
                      {investment.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground text-sm">
                    {format(new Date(investment.created_at), "MMM d, yyyy")}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </AdminLayout>
  );
};

export default AdminInvestors;
