import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft } from "lucide-react";
import { DomainVerification, WhoisResult } from "@/components/DomainVerification";
import { z } from "zod";

const DOMAIN_CATEGORIES = [
  { value: "tech", label: "Tech" },
  { value: "business", label: "Business" },
  { value: "premium", label: "Premium" },
  { value: "crypto", label: "Crypto" },
  { value: "ai", label: "AI & ML" },
  { value: "ecommerce", label: "E-commerce" },
  { value: "other", label: "Other" },
];

const domainSchema = z.object({
  title: z.string().trim().min(1, "Title is required").max(100, "Title must be less than 100 characters"),
  domain_name: z.string().trim().min(1, "Domain name is required").max(255, "Domain name must be less than 255 characters"),
  description: z.string().trim().max(1000, "Description must be less than 1000 characters").optional(),
  price: z.number().positive("Price must be greater than 0").max(999999999.99, "Price is too high"),
  category: z.string().min(1, "Category is required"),
});

const AddDomain = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [domainVerified, setDomainVerified] = useState(false);
  const [expirationDate, setExpirationDate] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    domain_name: "",
    description: "",
    price: "",
    category: "other",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to add a domain",
        variant: "destructive",
      });
      return;
    }

    const validationResult = domainSchema.safeParse({
      ...formData,
      price: parseFloat(formData.price) || 0,
      category: formData.category,
    });

    if (!validationResult.success) {
      toast({
        title: "Validation Error",
        description: validationResult.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    const { error } = await supabase.from("domains").insert({
      user_id: user.id,
      title: formData.title.trim(),
      domain_name: formData.domain_name.trim(),
      description: formData.description.trim() || null,
      price: parseFloat(formData.price),
      category: formData.category,
      expiration_date: expirationDate,
    });

    setLoading(false);

    if (error) {
      toast({
        title: "Error",
        description: "Failed to add domain. Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Success",
      description: "Domain added to marketplace!",
    });
    navigate("/marketplace");
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="container max-w-2xl mx-auto">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Add Domain to Marketplace</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Premium Tech Domain"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="domain_name">Domain Name</Label>
                <Input
                  id="domain_name"
                  placeholder="e.g., example.com"
                  value={formData.domain_name}
                  onChange={(e) => {
                    setFormData({ ...formData, domain_name: e.target.value });
                    setDomainVerified(false);
                    setExpirationDate(null);
                  }}
                  required
                />
                <DomainVerification 
                  domain={formData.domain_name} 
                  onVerified={(result: WhoisResult) => {
                    setDomainVerified(!result.available);
                    setExpirationDate(result.expiresDate || null);
                  }}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Price ($)</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  min="0.01"
                  placeholder="e.g., 999.99"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: e.target.value })
                  }
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) =>
                    setFormData({ ...formData, category: value })
                  }
                >
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {DOMAIN_CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description (optional)</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your domain..."
                  rows={4}
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                />
              </div>

              <Button type="submit" className="w-full" disabled={loading || !domainVerified}>
                {loading ? "Adding..." : "Add Domain"}
              </Button>
              {!domainVerified && (
                <p className="text-sm text-muted-foreground text-center">
                  Please verify domain ownership before listing
                </p>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AddDomain;
