import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { Wallet as WalletIcon, ArrowUpCircle, ArrowDownCircle, History } from "lucide-react";
import Navbar from "@/components/Navbar";

interface Transaction {
  id: string;
  type: "deposit" | "withdrawal" | "purchase" | "sale";
  amount: number;
  description: string | null;
  created_at: string;
}

const Wallet = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [amount, setAmount] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [walletLoading, setWalletLoading] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/auth");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user) {
      fetchWalletData();
    }
  }, [user]);

  const fetchWalletData = async () => {
    if (!user) return;

    setWalletLoading(true);
    try {
      // Fetch or create wallet
      let { data: wallet, error: walletError } = await supabase
        .from("wallets")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle();

      if (walletError) throw walletError;

      if (!wallet) {
        const { data: newWallet, error: createError } = await supabase
          .from("wallets")
          .insert({ user_id: user.id, balance: 0 })
          .select()
          .single();

        if (createError) throw createError;
        wallet = newWallet;
      }

      setBalance(Number(wallet.balance));

      // Fetch transactions
      const { data: txns, error: txnError } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (txnError) throw txnError;
      setTransactions(txns as Transaction[]);
    } catch (error: any) {
      toast.error("Failed to load wallet data");
      console.error(error);
    } finally {
      setWalletLoading(false);
    }
  };

  const handleDeposit = async () => {
    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    setIsLoading(true);
    try {
      // Update wallet balance
      const { error: walletError } = await supabase
        .from("wallets")
        .update({ balance: balance + depositAmount })
        .eq("user_id", user!.id);

      if (walletError) throw walletError;

      // Create transaction record
      const { error: txnError } = await supabase
        .from("transactions")
        .insert({
          user_id: user!.id,
          type: "deposit",
          amount: depositAmount,
          description: "Wallet deposit",
        });

      if (txnError) throw txnError;

      toast.success(`Successfully deposited $${depositAmount.toFixed(2)}`);
      setAmount("");
      fetchWalletData();
    } catch (error: any) {
      toast.error("Failed to deposit funds");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (withdrawAmount > balance) {
      toast.error("Insufficient balance");
      return;
    }

    setIsLoading(true);
    try {
      // Update wallet balance
      const { error: walletError } = await supabase
        .from("wallets")
        .update({ balance: balance - withdrawAmount })
        .eq("user_id", user!.id);

      if (walletError) throw walletError;

      // Create transaction record
      const { error: txnError } = await supabase
        .from("transactions")
        .insert({
          user_id: user!.id,
          type: "withdrawal",
          amount: withdrawAmount,
          description: "Wallet withdrawal",
        });

      if (txnError) throw txnError;

      toast.success(`Successfully withdrew $${withdrawAmount.toFixed(2)}`);
      setAmount("");
      fetchWalletData();
    } catch (error: any) {
      toast.error("Failed to withdraw funds");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case "deposit":
      case "sale":
        return <ArrowDownCircle className="h-4 w-4 text-green-500" />;
      case "withdrawal":
      case "purchase":
        return <ArrowUpCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  const getTransactionColor = (type: string) => {
    switch (type) {
      case "deposit":
      case "sale":
        return "text-green-500";
      case "withdrawal":
      case "purchase":
        return "text-red-500";
      default:
        return "";
    }
  };

  if (loading || walletLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center min-h-[60vh]">
          <p className="text-muted-foreground">Loading wallet...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center gap-3 mb-8">
          <WalletIcon className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">My Wallet</h1>
        </div>

        {/* Balance Card */}
        <Card className="mb-8 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardHeader>
            <CardDescription>Available Balance</CardDescription>
            <CardTitle className="text-4xl font-bold text-primary">
              ${balance.toFixed(2)}
            </CardTitle>
          </CardHeader>
        </Card>

        {/* Deposit/Withdraw Tabs */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Manage Funds</CardTitle>
            <CardDescription>Deposit or withdraw funds from your wallet</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="deposit">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="deposit">Deposit</TabsTrigger>
                <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
              </TabsList>
              <TabsContent value="deposit" className="space-y-4">
                <div className="flex gap-4 mt-4">
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min="0"
                    step="0.01"
                    className="flex-1"
                  />
                  <Button onClick={handleDeposit} disabled={isLoading}>
                    {isLoading ? "Processing..." : "Deposit"}
                  </Button>
                </div>
              </TabsContent>
              <TabsContent value="withdraw" className="space-y-4">
                <div className="flex gap-4 mt-4">
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    min="0"
                    step="0.01"
                    className="flex-1"
                  />
                  <Button onClick={handleWithdraw} disabled={isLoading}>
                    {isLoading ? "Processing..." : "Withdraw"}
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <History className="h-5 w-5" />
              <CardTitle>Transaction History</CardTitle>
            </div>
            <CardDescription>Your recent transactions</CardDescription>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">
                No transactions yet
              </p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((txn) => (
                    <TableRow key={txn.id}>
                      <TableCell className="flex items-center gap-2 capitalize">
                        {getTransactionIcon(txn.type)}
                        {txn.type}
                      </TableCell>
                      <TableCell>{txn.description || "-"}</TableCell>
                      <TableCell className={getTransactionColor(txn.type)}>
                        {txn.type === "deposit" || txn.type === "sale" ? "+" : "-"}
                        ${Number(txn.amount).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        {new Date(txn.created_at).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Wallet;
