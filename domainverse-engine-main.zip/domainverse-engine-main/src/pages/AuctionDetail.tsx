import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Clock, TrendingUp, Users, Gavel, ArrowLeft, User, AlertTriangle, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow, format } from "date-fns";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface Auction {
  id: string;
  domain_id: string;
  seller_id: string;
  starting_price: number;
  current_bid: number;
  current_bidder_id: string | null;
  min_bid_increment: number;
  start_time: string;
  end_time: string;
  status: string;
  domain: {
    domain_name: string;
    title: string;
    description: string | null;
    expiration_date: string | null;
  };
}

interface Bid {
  id: string;
  user_id: string;
  amount: number;
  created_at: string;
}

const AuctionDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [auction, setAuction] = useState<Auction | null>(null);
  const [bids, setBids] = useState<Bid[]>([]);
  const [bidAmount, setBidAmount] = useState("");
  const [loading, setLoading] = useState(true);
  const [bidding, setBidding] = useState(false);
  const [walletBalance, setWalletBalance] = useState(0);
  const [timeLeft, setTimeLeft] = useState("");

  const fetchAuction = async () => {
    if (!id) return;

    try {
      const { data: auctionData, error: auctionError } = await supabase
        .from("auctions")
        .select(`
          *,
          domain:domains(domain_name, title, description, expiration_date)
        `)
        .eq("id", id)
        .maybeSingle();

      if (auctionError) throw auctionError;
      if (!auctionData) {
        toast.error("Auction not found");
        navigate("/auctions");
        return;
      }

      setAuction(auctionData);

      // Fetch bids
      const { data: bidsData, error: bidsError } = await supabase
        .from("bids")
        .select("*")
        .eq("auction_id", id)
        .order("amount", { ascending: false });

      if (bidsError) throw bidsError;
      setBids(bidsData || []);
    } catch (error: any) {
      toast.error("Failed to load auction");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchWallet = async () => {
    if (!user) return;

    const { data } = await supabase
      .from("wallets")
      .select("balance")
      .eq("user_id", user.id)
      .maybeSingle();

    if (data) {
      setWalletBalance(data.balance);
    }
  };

  useEffect(() => {
    fetchAuction();
    fetchWallet();

    // Subscribe to real-time updates
    const channel = supabase
      .channel(`auction-${id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "auctions",
          filter: `id=eq.${id}`,
        },
        (payload) => {
          if (payload.new && typeof payload.new === 'object' && 'id' in payload.new) {
            setAuction((prev) => prev ? { ...prev, ...payload.new } : null);
          }
        }
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "bids",
          filter: `auction_id=eq.${id}`,
        },
        (payload) => {
          if (payload.new && typeof payload.new === 'object') {
            setBids((prev) => [payload.new as Bid, ...prev]);
            toast.info("New bid placed!");
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id, user]);

  // Update time left every second
  useEffect(() => {
    if (!auction) return;

    const updateTimeLeft = () => {
      const now = new Date();
      const end = new Date(auction.end_time);
      const diff = end.getTime() - now.getTime();

      if (diff <= 0) {
        setTimeLeft("Ended");
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      if (days > 0) {
        setTimeLeft(`${days}d ${hours}h ${minutes}m`);
      } else if (hours > 0) {
        setTimeLeft(`${hours}h ${minutes}m ${seconds}s`);
      } else {
        setTimeLeft(`${minutes}m ${seconds}s`);
      }
    };

    updateTimeLeft();
    const interval = setInterval(updateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [auction]);

  const handlePlaceBid = async () => {
    if (!user) {
      toast.error("Please sign in to place a bid");
      navigate("/auth");
      return;
    }

    if (!auction) return;

    const amount = parseFloat(bidAmount);
    const minBid = auction.current_bid > 0 
      ? auction.current_bid + auction.min_bid_increment 
      : auction.starting_price;

    if (isNaN(amount) || amount < minBid) {
      toast.error(`Minimum bid is $${minBid.toLocaleString()}`);
      return;
    }

    if (amount > walletBalance) {
      toast.error("Insufficient wallet balance");
      return;
    }

    if (auction.seller_id === user.id) {
      toast.error("You cannot bid on your own auction");
      return;
    }

    if (timeLeft === "Ended") {
      toast.error("This auction has ended");
      return;
    }

    setBidding(true);

    try {
      // Store previous bidder info before placing new bid
      const previousBidderId = auction.current_bidder_id;

      // Insert bid
      const { error: bidError } = await supabase.from("bids").insert({
        auction_id: auction.id,
        user_id: user.id,
        amount,
      });

      if (bidError) throw bidError;

      // Update auction current bid
      const { error: updateError } = await supabase
        .from("auctions")
        .update({
          current_bid: amount,
          current_bidder_id: user.id,
        })
        .eq("id", auction.id);

      // Send outbid notifications to previous bidders
      if (previousBidderId && previousBidderId !== user.id) {
        supabase.functions.invoke("create-outbid-notification", {
          body: {
            auction_id: auction.id,
            new_bidder_id: user.id,
            new_bid_amount: amount,
            domain_name: auction.domain?.domain_name || "domain",
          },
        }).catch((err) => console.error("Failed to send notifications:", err));
      }

      toast.success("Bid placed successfully!");
      setBidAmount("");
      fetchAuction();
    } catch (error: any) {
      toast.error(error.message || "Failed to place bid");
      console.error(error);
    } finally {
      setBidding(false);
    }
  };

  const getMinBid = () => {
    if (!auction) return 0;
    return auction.current_bid > 0 
      ? auction.current_bid + auction.min_bid_increment 
      : auction.starting_price;
  };

  const isExpiringSoon = (expirationDate: string | null) => {
    if (!expirationDate) return false;
    const expiry = new Date(expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
  };

  const getDaysUntilExpiry = (expirationDate: string | null) => {
    if (!expirationDate) return null;
    const expiry = new Date(expirationDate);
    const now = new Date();
    return Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4">
            <div className="animate-pulse space-y-6">
              <div className="h-8 bg-muted rounded w-1/3" />
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 h-96 bg-muted rounded" />
                <div className="h-96 bg-muted rounded" />
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!auction) {
    return null;
  }

  const isEnded = timeLeft === "Ended";
  const isSeller = user?.id === auction.seller_id;
  const isWinning = user?.id === auction.current_bidder_id;
  const expiringSoon = isExpiringSoon(auction.domain?.expiration_date);
  const daysLeft = getDaysUntilExpiry(auction.domain?.expiration_date);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6 gap-2"
            onClick={() => navigate("/auctions")}
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Auctions
          </Button>

          {/* Expiration Warning Banner */}
          {expiringSoon && daysLeft !== null && (
            <Alert variant="destructive" className="mb-6 border-destructive/50 bg-destructive/10">
              <AlertTriangle className="h-5 w-5" />
              <AlertTitle className="text-lg font-semibold">
                Domain Expiring Soon!
              </AlertTitle>
              <AlertDescription className="mt-2">
                <p className="text-base">
                  This domain expires in <strong>{daysLeft} day{daysLeft !== 1 ? 's' : ''}</strong>
                  {auction.domain?.expiration_date && (
                    <span> (on {format(new Date(auction.domain.expiration_date), "MMMM d, yyyy")})</span>
                  )}. 
                  Place your bid quickly to secure this domain before it becomes unavailable.
                </p>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Auction Details */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <Badge variant={isEnded ? "secondary" : "default"}>
                      {isEnded ? "Ended" : "Live Auction"}
                    </Badge>
                    {isWinning && !isEnded && (
                      <Badge variant="outline" className="text-green-500 border-green-500">
                        You're Winning!
                      </Badge>
                    )}
                    {auction.domain?.expiration_date && (
                      <Badge variant="outline" className="gap-1 text-green-600 border-green-600/50 bg-green-500/10">
                        <ShieldCheck className="h-3 w-3" />
                        Verified
                      </Badge>
                    )}
                    {expiringSoon && daysLeft !== null && (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        {daysLeft}d left
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="font-display text-3xl">
                    {auction.domain?.domain_name}
                  </CardTitle>
                  <p className="text-muted-foreground">
                    {auction.domain?.title}
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  {auction.domain?.description && (
                    <p className="text-foreground">
                      {auction.domain.description}
                    </p>
                  )}

                  {/* Stats Grid */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">Current Bid</p>
                      <p className="font-display text-2xl font-bold text-foreground">
                        ${(auction.current_bid > 0 ? auction.current_bid : auction.starting_price).toLocaleString()}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">Starting Price</p>
                      <p className="font-display text-2xl font-bold text-foreground">
                        ${auction.starting_price.toLocaleString()}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">Total Bids</p>
                      <p className="font-display text-2xl font-bold text-foreground">
                        {bids.length}
                      </p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/50">
                      <p className="text-sm text-muted-foreground mb-1">Time Left</p>
                      <p className={`font-display text-2xl font-bold ${isEnded ? "text-muted-foreground" : "text-destructive"}`}>
                        {timeLeft}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Bid History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Gavel className="h-5 w-5" />
                    Bid History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {bids.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">
                      No bids yet. Be the first to bid!
                    </p>
                  ) : (
                    <ScrollArea className="h-[300px]">
                      <div className="space-y-3">
                        {bids.map((bid, index) => (
                          <div
                            key={bid.id}
                            className={`flex items-center justify-between p-3 rounded-lg ${
                              index === 0 ? "bg-primary/10 border border-primary/20" : "bg-muted/50"
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                                <User className="h-4 w-4" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">
                                  {bid.user_id === user?.id ? "You" : `Bidder ${bid.user_id.slice(0, 8)}`}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  {formatDistanceToNow(new Date(bid.created_at), { addSuffix: true })}
                                </p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {index === 0 && (
                                <Badge variant="default" className="text-xs">
                                  Highest
                                </Badge>
                              )}
                              <span className="font-display font-bold">
                                ${bid.amount.toLocaleString()}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Bid Panel */}
            <div className="space-y-6">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Place Your Bid
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {user ? (
                    <>
                      <div className="p-3 rounded-lg bg-muted/50">
                        <p className="text-sm text-muted-foreground">Your Wallet Balance</p>
                        <p className="font-display text-xl font-bold">
                          ${walletBalance.toLocaleString()}
                        </p>
                      </div>

                      <div className="p-3 rounded-lg bg-primary/10 border border-primary/20">
                        <p className="text-sm text-muted-foreground">Minimum Bid</p>
                        <p className="font-display text-xl font-bold text-primary">
                          ${getMinBid().toLocaleString()}
                        </p>
                      </div>

                      {!isEnded && !isSeller && (
                        <>
                          <div className="space-y-2">
                            <label className="text-sm font-medium">Your Bid Amount</label>
                            <div className="relative">
                              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                                $
                              </span>
                              <Input
                                type="number"
                                placeholder={getMinBid().toString()}
                                value={bidAmount}
                                onChange={(e) => setBidAmount(e.target.value)}
                                className="pl-7"
                                min={getMinBid()}
                                step={auction.min_bid_increment}
                              />
                            </div>
                          </div>

                          <Button
                            className="w-full"
                            size="lg"
                            onClick={handlePlaceBid}
                            disabled={bidding}
                          >
                            {bidding ? "Placing Bid..." : "Place Bid"}
                          </Button>
                        </>
                      )}

                      {isSeller && (
                        <p className="text-center text-muted-foreground text-sm">
                          You cannot bid on your own auction
                        </p>
                      )}

                      {isEnded && (
                        <p className="text-center text-muted-foreground text-sm">
                          This auction has ended
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-4">
                      <p className="text-muted-foreground mb-4">
                        Sign in to place a bid
                      </p>
                      <Button onClick={() => navigate("/auth")} className="w-full">
                        Sign In
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Clock className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Ends At</p>
                        <p className="font-medium">
                          {new Date(auction.end_time).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Users className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm text-muted-foreground">Total Bidders</p>
                        <p className="font-medium">
                          {new Set(bids.map(b => b.user_id)).size}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default AuctionDetail;
