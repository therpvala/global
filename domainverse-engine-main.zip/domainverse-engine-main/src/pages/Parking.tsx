import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link, useNavigate } from "react-router-dom";
import { ParkingSquare, DollarSign, Globe, TrendingUp, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

interface EarningsEstimate {
  monthly: number;
  yearly: number;
  category: string;
}

const categoryMultipliers: Record<string, number> = {
  tech: 1.5,
  finance: 1.8,
  health: 1.3,
  business: 1.4,
  crypto: 2.0,
  ai: 2.2,
  ecommerce: 1.6,
  other: 1.0,
};

const detectCategory = (domain: string): string => {
  const lowerDomain = domain.toLowerCase();
  if (lowerDomain.includes("ai") || lowerDomain.includes("ml") || lowerDomain.includes("bot")) return "ai";
  if (lowerDomain.includes("crypto") || lowerDomain.includes("coin") || lowerDomain.includes("nft")) return "crypto";
  if (lowerDomain.includes("tech") || lowerDomain.includes("dev") || lowerDomain.includes("code")) return "tech";
  if (lowerDomain.includes("bank") || lowerDomain.includes("pay") || lowerDomain.includes("money")) return "finance";
  if (lowerDomain.includes("health") || lowerDomain.includes("med") || lowerDomain.includes("care")) return "health";
  if (lowerDomain.includes("shop") || lowerDomain.includes("store") || lowerDomain.includes("buy")) return "ecommerce";
  if (lowerDomain.includes("biz") || lowerDomain.includes("corp") || lowerDomain.includes("inc")) return "business";
  return "other";
};

const estimateEarnings = (domain: string): EarningsEstimate => {
  const category = detectCategory(domain);
  const multiplier = categoryMultipliers[category] || 1.0;
  
  // Base earnings calculation based on domain length and TLD
  const parts = domain.split(".");
  const name = parts[0] || "";
  const tld = parts[parts.length - 1] || "";
  
  let baseMonthly = 15; // Base $15/month
  
  // Shorter domains are more valuable
  if (name.length <= 4) baseMonthly += 50;
  else if (name.length <= 6) baseMonthly += 30;
  else if (name.length <= 8) baseMonthly += 15;
  
  // Premium TLDs
  if (tld === "com") baseMonthly += 25;
  else if (tld === "io" || tld === "ai") baseMonthly += 20;
  else if (tld === "net" || tld === "org") baseMonthly += 10;
  
  const monthly = Math.round(baseMonthly * multiplier);
  const yearly = monthly * 12;
  
  return { monthly, yearly, category };
};

const Parking = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [domain, setDomain] = useState("");
  const [estimate, setEstimate] = useState<EarningsEstimate | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleEstimate = () => {
    if (!domain.trim()) {
      toast.error("Please enter a domain name");
      return;
    }
    
    const cleanDomain = domain.trim().toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, "");
    setEstimate(estimateEarnings(cleanDomain));
  };

  const handleSubmitParking = async () => {
    if (!user) {
      toast.error("Please sign in to park your domain");
      navigate("/auth");
      return;
    }

    if (!domain.trim()) {
      toast.error("Please enter a domain name");
      return;
    }

    setSubmitting(true);
    const cleanDomain = domain.trim().toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, "");

    try {
      // First, create or find the domain
      let domainId: string;

      // Check if domain already exists for this user
      const { data: existingDomain } = await supabase
        .from("domains")
        .select("id, status")
        .eq("user_id", user.id)
        .eq("domain_name", cleanDomain)
        .maybeSingle();

      if (existingDomain) {
        // Check if already parked
        const { data: existingParked } = await supabase
          .from("parked_domains")
          .select("id")
          .eq("domain_id", existingDomain.id)
          .maybeSingle();

        if (existingParked) {
          toast.error("This domain is already parked");
          setSubmitting(false);
          return;
        }

        domainId = existingDomain.id;
        
        // Update domain status to parked
        await supabase
          .from("domains")
          .update({ status: "parked" })
          .eq("id", domainId);
      } else {
        // Create new domain
        const { data: newDomain, error: domainError } = await supabase
          .from("domains")
          .insert({
            user_id: user.id,
            domain_name: cleanDomain,
            title: `${cleanDomain} - Parked Domain`,
            price: 0,
            status: "parked",
            category: estimate?.category || "other",
            description: "This domain is parked and earning passive income.",
          })
          .select()
          .single();

        if (domainError) throw domainError;
        domainId = newDomain.id;
      }

      // Create parked domain entry with estimated earnings
      const monthlyEarnings = estimate?.monthly || 15;
      const { error: parkError } = await supabase.from("parked_domains").insert({
        domain_id: domainId,
        user_id: user.id,
        monthly_earnings: monthlyEarnings,
        total_earnings: 0,
        clicks: 0,
        impressions: 0,
        status: "active",
      });

      if (parkError) throw parkError;

      toast.success("Domain parked successfully! View it in your dashboard.");
      setDomain("");
      setEstimate(null);
      navigate("/dashboard");
    } catch (error: any) {
      console.error("Error parking domain:", error);
      toast.error(error.message || "Failed to park domain");
    } finally {
      setSubmitting(false);
    }
  };

  const benefits = [
    { icon: DollarSign, title: "Earn Passive Income", description: "Monetize unused domains with optimized ads" },
    { icon: Globe, title: "Global Traffic", description: "Capture type-in traffic from worldwide visitors" },
    { icon: TrendingUp, title: "AI Optimization", description: "Smart landing pages maximize your revenue" },
  ];

  return (
    <>
      <Helmet>
        <title>Domain Parking - Earn Passive Income | DomainVala</title>
        <meta name="description" content="Park your unused domains and earn passive monthly income. AI-optimized landing pages maximize your revenue." />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar />
        
        <main className="pt-20">
          {/* Hero */}
          <section className="py-16 bg-white">
            <div className="container mx-auto px-4">
              <div className="max-w-2xl mx-auto text-center">
                <div className="inline-flex p-3 rounded-full bg-primary/10 mb-4">
                  <ParkingSquare className="h-8 w-8 text-primary" />
                </div>
                <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Park Your Domain & Earn
                </h1>
                <p className="text-muted-foreground mb-8">
                  Turn unused domains into monthly income. Get an instant earnings estimate.
                </p>
              </div>
            </div>
          </section>

          {/* Earnings Calculator */}
          <section className="py-12 bg-muted/30">
            <div className="container mx-auto px-4">
              <Card className="max-w-xl mx-auto">
                <CardHeader>
                  <CardTitle>Estimate Your Earnings</CardTitle>
                  <CardDescription>Enter your domain to see potential monthly income</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="domain">Domain Name</Label>
                    <div className="flex gap-2">
                      <Input
                        id="domain"
                        placeholder="example.com"
                        value={domain}
                        onChange={(e) => setDomain(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleEstimate()}
                      />
                      <Button onClick={handleEstimate}>Estimate</Button>
                    </div>
                  </div>

                  {estimate && (
                    <div className="p-6 bg-primary/5 rounded-lg border border-primary/20">
                      <div className="text-center mb-4">
                        <p className="text-sm text-muted-foreground mb-1">Estimated Monthly Earnings</p>
                        <p className="font-display text-4xl font-bold text-primary">
                          ${estimate.monthly}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">
                          ${estimate.yearly}/year • Category: {estimate.category}
                        </p>
                      </div>
                      <Button
                        className="w-full bg-primary hover:bg-primary/90"
                        onClick={handleSubmitParking}
                        disabled={submitting}
                      >
                        {submitting ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          <>
                            <ParkingSquare className="h-4 w-4 mr-2" />
                            Start Parking This Domain
                          </>
                        )}
                      </Button>
                      {!user && (
                        <p className="text-xs text-center text-muted-foreground mt-3">
                          You'll need to{" "}
                          <Link to="/auth" className="text-primary hover:underline">
                            sign in
                          </Link>{" "}
                          to park your domain
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </section>

          {/* Benefits */}
          <section className="py-16 bg-white">
            <div className="container mx-auto px-4">
              <h2 className="font-display text-2xl font-bold text-center text-foreground mb-10">
                Why Park With Us
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
                {benefits.map((benefit) => (
                  <div
                    key={benefit.title}
                    className="text-center p-6 border border-border rounded-lg"
                  >
                    <div className="inline-flex p-3 rounded-full bg-primary/10 mb-4">
                      <benefit.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                    <p className="text-sm text-muted-foreground">{benefit.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* How It Works */}
          <section className="py-16 bg-muted/30">
            <div className="container mx-auto px-4">
              <h2 className="font-display text-2xl font-bold text-center text-foreground mb-10">
                How Parking Works
              </h2>
              <div className="max-w-2xl mx-auto space-y-4">
                {[
                  "Submit your domain for parking",
                  "We verify ownership via DNS",
                  "AI creates optimized landing page",
                  "Earn from ad impressions and clicks",
                  "Get paid monthly to your wallet",
                ].map((step, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 bg-white rounded-lg border border-border">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                      <Check className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <p className="text-foreground">{step}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA */}
          <section className="py-16 bg-primary">
            <div className="container mx-auto px-4 text-center">
              <h2 className="font-display text-2xl md:text-3xl font-bold text-primary-foreground mb-4">
                Start Earning Today
              </h2>
              <p className="text-primary-foreground/80 mb-6">
                Join thousands of domain owners earning passive income
              </p>
              <Button
                size="lg"
                variant="outline"
                className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
                onClick={() => document.getElementById("domain")?.focus()}
              >
                Park Your First Domain
              </Button>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Parking;
