import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  ShoppingBag,
  Globe,
  Wallet,
  Eye,
  Search,
  Gavel,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  Clock,
  Heart,
  ExternalLink,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface BuyerStats {
  purchasedDomains: number;
  walletBalance: number;
  watchlistCount: number;
  activeBids: number;
}

interface WatchlistItem {
  id: string;
  domain: {
    id: string;
    domain_name: string;
    title: string;
    price: number;
  };
}

const BuyerDashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<BuyerStats>({
    purchasedDomains: 0,
    walletBalance: 0,
    watchlistCount: 0,
    activeBids: 0,
  });
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [recentAuctions, setRecentAuctions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Fetch owned domains (purchased)
        const { data: domains } = await supabase
          .from("domains")
          .select("id")
          .eq("user_id", user.id);

        // Fetch wallet
        const { data: wallet } = await supabase
          .from("wallets")
          .select("balance")
          .eq("user_id", user.id)
          .maybeSingle();

        // Fetch watchlist
        const { data: watchlistData } = await supabase
          .from("domain_watchlist")
          .select(`
            id,
            domain:domains(id, domain_name, title, price)
          `)
          .eq("user_id", user.id);

        // Fetch active bids
        const { data: bids } = await supabase
          .from("bids")
          .select("id, auction:auctions(status)")
          .eq("user_id", user.id);

        const activeBids = bids?.filter((b) => b.auction?.status === "active") || [];

        // Fetch recent auctions
        const { data: auctions } = await supabase
          .from("auctions")
          .select(`
            id,
            current_bid,
            starting_price,
            end_time,
            domain:domains(domain_name, title)
          `)
          .eq("status", "active")
          .order("created_at", { ascending: false })
          .limit(5);

        setStats({
          purchasedDomains: domains?.length || 0,
          walletBalance: wallet?.balance || 0,
          watchlistCount: watchlistData?.length || 0,
          activeBids: activeBids.length,
        });

        setWatchlist(watchlistData as WatchlistItem[] || []);
        setRecentAuctions(auctions || []);
      } catch (error) {
        console.error("Error fetching buyer data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const getTimeLeft = (endTime: string) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end.getTime() - now.getTime();

    if (diff <= 0) return "Ended";

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

    if (days > 0) return `${days}d ${hours}h`;
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const displayName = user?.email?.split("@")[0] || "Buyer";

  const statsCards = [
    { label: "Purchased Domains", value: stats.purchasedDomains.toString(), icon: Globe, color: "text-primary" },
    { label: "Wallet Balance", value: `$${stats.walletBalance.toLocaleString()}`, icon: Wallet, color: "text-accent" },
    { label: "Watchlist", value: stats.watchlistCount.toString(), icon: Heart, color: "text-pink-500" },
    { label: "Active Bids", value: stats.activeBids.toString(), icon: Gavel, color: "text-primary" },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge className="gap-1 bg-card text-card-foreground border">
                <ShoppingBag className="h-3 w-3" />
                Buyer
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-card border flex items-center justify-center">
                      <ShoppingBag className="h-4 w-4 text-card-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      General Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Buyer <span className="text-gradient-primary">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Discover and purchase premium domains
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Quick Actions
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Search className="h-6 w-6 text-primary" />
                  <span>Browse Domains</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/auctions">
                  <Gavel className="h-6 w-6 text-primary" />
                  <span>Live Auctions</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/watchlist">
                  <Eye className="h-6 w-6 text-primary" />
                  <span>Watchlist</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/wallet">
                  <Wallet className="h-6 w-6 text-primary" />
                  <span>Add Funds</span>
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Watchlist */}
            <Card className="glass border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-pink-500" />
                  Your Watchlist
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/watchlist">View All</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : watchlist.length === 0 ? (
                  <div className="text-center py-8">
                    <Heart className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground text-sm">No domains in watchlist</p>
                    <Button variant="outline" size="sm" className="mt-4" asChild>
                      <Link to="/marketplace">Browse Domains</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {watchlist.slice(0, 4).map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                        onClick={() => navigate(`/domain/${item.domain.id}`)}
                      >
                        <div>
                          <p className="font-medium text-foreground">{item.domain.domain_name}</p>
                          <p className="text-sm text-muted-foreground truncate">{item.domain.title}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-foreground">
                            ${item.domain.price.toLocaleString()}
                          </span>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Auctions */}
            <Card className="glass border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Gavel className="h-5 w-5 text-primary" />
                  Hot Auctions
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/auctions">View All</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : recentAuctions.length === 0 ? (
                  <div className="text-center py-8">
                    <Gavel className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground text-sm">No active auctions</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentAuctions.map((auction) => (
                      <div
                        key={auction.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                        onClick={() => navigate(`/auction/${auction.id}`)}
                      >
                        <div>
                          <p className="font-medium text-foreground">{auction.domain?.domain_name}</p>
                          <p className="text-sm text-muted-foreground truncate">{auction.domain?.title}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-foreground">
                            ${(auction.current_bid || auction.starting_price).toLocaleString()}
                          </p>
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {getTimeLeft(auction.end_time)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default BuyerDashboard;
