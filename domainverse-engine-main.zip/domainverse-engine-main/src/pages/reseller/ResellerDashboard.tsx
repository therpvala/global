import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  Repeat,
  ShoppingCart,
  TrendingUp,
  Package,
  DollarSign,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  Globe,
  Gavel,
  Plus,
  Tag,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ResellerStats {
  inventory: number;
  salesThisMonth: number;
  profit: number;
  pendingOrders: number;
}

const ResellerDashboard = () => {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<ResellerStats>({
    inventory: 0,
    salesThisMonth: 0,
    profit: 0,
    pendingOrders: 0,
  });
  const [domains, setDomains] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Fetch domains for sale
        const { data: domainsData } = await supabase
          .from("domains")
          .select("*")
          .eq("user_id", user.id)
          .eq("status", "active");

        // Fetch sales transactions
        const { data: sales } = await supabase
          .from("transactions")
          .select("*")
          .eq("user_id", user.id)
          .eq("type", "sale");

        const profit = sales?.reduce((sum, s) => sum + s.amount, 0) || 0;

        setDomains(domainsData || []);
        setStats({
          inventory: domainsData?.length || 0,
          salesThisMonth: sales?.length || 0,
          profit,
          pendingOrders: 2, // Simulated
        });
      } catch (error) {
        console.error("Error fetching reseller data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const displayName = user?.email?.split("@")[0] || "Reseller";

  const statsCards = [
    { label: "Inventory", value: stats.inventory.toString(), icon: Package, color: "text-primary" },
    { label: "Sales This Month", value: stats.salesThisMonth.toString(), icon: ShoppingCart, color: "text-accent" },
    { label: "Total Profit", value: `$${stats.profit.toLocaleString()}`, icon: DollarSign, color: "text-green-500" },
    { label: "Pending Orders", value: stats.pendingOrders.toString(), icon: Repeat, color: "text-primary" },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge className="gap-1 bg-secondary text-secondary-foreground">
                <Repeat className="h-3 w-3" />
                Reseller
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                      <Repeat className="h-4 w-4 text-secondary-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      General Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Reseller <span className="text-gradient-primary">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage your domain inventory and track sales performance
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Reseller Tools
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/add-domain">
                  <Plus className="h-6 w-6 text-primary" />
                  <span>Add to Inventory</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <ShoppingCart className="h-6 w-6 text-primary" />
                  <span>Buy Domains</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/create-auction">
                  <Gavel className="h-6 w-6 text-primary" />
                  <span>Create Auction</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2">
                <Tag className="h-6 w-6 text-primary" />
                <span>Bulk Pricing</span>
              </Button>
            </div>
          </div>

          {/* Inventory */}
          <Card className="glass border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5 text-primary" />
                Inventory
              </CardTitle>
              <Button size="sm" asChild>
                <Link to="/add-domain">Add Domain</Link>
              </Button>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : domains.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No domains in inventory</p>
                  <Button variant="outline" size="sm" className="mt-4" asChild>
                    <Link to="/add-domain">Add Your First Domain</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  {domains.slice(0, 5).map((domain) => (
                    <div
                      key={domain.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Globe className="h-5 w-5 text-primary" />
                        <div>
                          <p className="font-medium text-foreground">{domain.domain_name}</p>
                          <p className="text-sm text-muted-foreground">{domain.title}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-semibold text-foreground">
                          ${domain.price.toLocaleString()}
                        </span>
                        <Badge variant="secondary">{domain.status}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default ResellerDashboard;
