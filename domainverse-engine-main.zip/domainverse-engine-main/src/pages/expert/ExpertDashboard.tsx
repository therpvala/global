import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  Award,
  Search,
  FileText,
  Star,
  MessageSquare,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  Globe,
  CheckCircle,
  Clock,
  Zap,
  Loader2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface ExpertStats {
  valuationsCompleted: number;
  pendingRequests: number;
  averageRating: number;
  totalEarnings: number;
}

interface Suggestion {
  id: string;
  suggestion_type: string;
  suggested_price: number | null;
  status: string;
  notes: string | null;
  created_at: string;
  domain: {
    domain_name: string;
    title: string;
  } | null;
}

const ExpertDashboard = () => {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<ExpertStats>({
    valuationsCompleted: 0,
    pendingRequests: 0,
    averageRating: 0,
    totalEarnings: 0,
  });
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Find expert profile for this user
        const { data: expertProfile } = await supabase
          .from("experts")
          .select("*")
          .eq("user_id", user.id)
          .maybeSingle();

        if (expertProfile) {
          // Fetch suggestions for this expert
          const { data: suggestionsData } = await supabase
            .from("expert_suggestions")
            .select(`
              id, suggestion_type, suggested_price, status, notes, created_at,
              domain:domains(domain_name, title)
            `)
            .eq("expert_id", expertProfile.id)
            .order("created_at", { ascending: false })
            .limit(10);

          const completed = suggestionsData?.filter(s => s.status === "approved" || s.status === "rejected") || [];
          const pending = suggestionsData?.filter(s => s.status === "pending") || [];

          // Estimate earnings: $50 per approved suggestion
          const approvedCount = suggestionsData?.filter(s => s.status === "approved").length || 0;

          setStats({
            valuationsCompleted: expertProfile.approved_suggestions || completed.length,
            pendingRequests: pending.length,
            averageRating: expertProfile.rating || 0,
            totalEarnings: approvedCount * 50 + (expertProfile.approved_suggestions * 50),
          });

          setSuggestions(suggestionsData as Suggestion[] || []);
        } else {
          // No expert profile yet - show zero stats
          setStats({
            valuationsCompleted: 0,
            pendingRequests: 0,
            averageRating: 0,
            totalEarnings: 0,
          });
        }
      } catch (error) {
        console.error("Error fetching expert data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const displayName = user?.email?.split("@")[0] || "Expert";

  const statsCards = [
    { label: "Valuations Done", value: stats.valuationsCompleted.toString(), icon: CheckCircle, color: "text-primary" },
    { label: "Pending Requests", value: stats.pendingRequests.toString(), icon: Clock, color: "text-accent" },
    { label: "Average Rating", value: stats.averageRating > 0 ? `${stats.averageRating}/5` : "N/A", icon: Star, color: "text-yellow-500" },
    { label: "Total Earnings", value: `$${stats.totalEarnings.toLocaleString()}`, icon: Award, color: "text-primary" },
  ];

  const pendingSuggestions = suggestions.filter(s => s.status === "pending");

  return (
    <div className="min-h-screen bg-gradient-hero">
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge className="gap-1 bg-accent text-accent-foreground">
                <Award className="h-3 w-3" />
                Expert
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center">
                      <Award className="h-4 w-4 text-accent-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      General Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Expert <span className="text-gradient-primary">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage valuation requests and provide domain expertise
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Expert Tools
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Search className="h-6 w-6 text-primary" />
                  <span>Research Domains</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/dashboard">
                  <FileText className="h-6 w-6 text-primary" />
                  <span>Valuation Reports</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/auctions">
                  <MessageSquare className="h-6 w-6 text-primary" />
                  <span>Active Auctions</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Zap className="h-6 w-6 text-primary" />
                  <span>Quick Valuate</span>
                </Link>
              </Button>
            </div>
          </div>

          {/* Pending Valuations */}
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                Pending Valuation Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : pendingSuggestions.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="h-10 w-10 text-primary mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No pending requests</p>
                  <p className="text-muted-foreground text-xs mt-1">
                    New valuation requests will appear here
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingSuggestions.map((val) => (
                    <div
                      key={val.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center">
                          <Globe className="h-5 w-5 text-primary-foreground" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">
                            {val.domain?.domain_name || "Unknown Domain"}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {val.suggestion_type} · {new Date(val.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge variant="default">pending</Badge>
                        {val.suggested_price && (
                          <span className="text-sm font-semibold text-foreground">
                            ${val.suggested_price.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent Completed Valuations */}
          {suggestions.filter(s => s.status !== "pending").length > 0 && (
            <Card className="glass border-border mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-primary" />
                  Recent Completed Valuations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {suggestions.filter(s => s.status !== "pending").slice(0, 5).map((val) => (
                    <div
                      key={val.id}
                      className="flex items-center justify-between p-3 rounded-lg bg-muted/20"
                    >
                      <div>
                        <p className="font-medium text-foreground text-sm">
                          {val.domain?.domain_name || "Unknown Domain"}
                        </p>
                        <p className="text-xs text-muted-foreground">{val.suggestion_type}</p>
                      </div>
                      <Badge variant={val.status === "approved" ? "default" : "secondary"}>
                        {val.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
};

export default ExpertDashboard;
