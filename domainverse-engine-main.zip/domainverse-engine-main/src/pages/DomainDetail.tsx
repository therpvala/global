import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useRecentlyViewed } from "@/hooks/useRecentlyViewed";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import MakeOfferDialog from "@/components/MakeOfferDialog";
import DomainHealthScore from "@/components/DomainHealthScore";
import OffersManager from "@/components/OffersManager";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  ArrowLeft, 
  Globe, 
  Calendar, 
  DollarSign, 
  Gavel, 
  ShoppingCart,
  User,
  Clock,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Tag,
  Save,
  X,
  MessageSquare,
  AlertTriangle,
  ShieldCheck
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { toast } from "sonner";
import { format } from "date-fns";
import { z } from "zod";

const DOMAIN_CATEGORIES = [
  { value: "tech", label: "Tech" },
  { value: "business", label: "Business" },
  { value: "premium", label: "Premium" },
  { value: "crypto", label: "Crypto" },
  { value: "ai", label: "AI & ML" },
  { value: "ecommerce", label: "E-commerce" },
  { value: "other", label: "Other" },
];

const editDomainSchema = z.object({
  title: z.string().trim().min(1, "Title is required").max(100, "Title must be less than 100 characters"),
  description: z.string().trim().max(1000, "Description must be less than 1000 characters").optional(),
  price: z.number().positive("Price must be greater than 0").max(999999999.99, "Price is too high"),
  category: z.string().min(1, "Category is required"),
});

interface Domain {
  id: string;
  title: string;
  domain_name: string;
  description: string | null;
  price: number;
  status: string;
  category: string;
  created_at: string;
  updated_at: string;
  user_id: string;
  expiration_date: string | null;
}

interface ActiveAuction {
  id: string;
  current_bid: number;
  starting_price: number;
  end_time: string;
  status: string;
}

const DomainDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToRecentlyViewed } = useRecentlyViewed();
  
  const [domain, setDomain] = useState<Domain | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeAuction, setActiveAuction] = useState<ActiveAuction | null>(null);
  const [balance, setBalance] = useState<number>(0);
  const [showPurchaseDialog, setShowPurchaseDialog] = useState(false);
  const [showAuctionDialog, setShowAuctionDialog] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [isCreatingAuction, setIsCreatingAuction] = useState(false);
  const [isWatching, setIsWatching] = useState(false);
  const [isTogglingWatch, setIsTogglingWatch] = useState(false);
  
  // Auction form state
  const [startingPrice, setStartingPrice] = useState("");
  const [minIncrement, setMinIncrement] = useState("10");
  const [duration, setDuration] = useState("24");

  // Edit form state
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [editForm, setEditForm] = useState({
    title: "",
    description: "",
    price: "",
    category: "other",
  });

  useEffect(() => {
    if (id) {
      fetchDomain();
    }
  }, [id]);

  useEffect(() => {
    if (user) {
      fetchWalletBalance();
      if (id) {
        checkWatchStatus();
      }
    }
  }, [user, id]);

  const fetchDomain = async () => {
    if (!id) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from("domains")
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) throw error;
      
      if (!data) {
        toast.error("Domain not found");
        navigate("/marketplace");
        return;
      }
      
      setDomain(data);

      // Track recently viewed
      addToRecentlyViewed({
        id: data.id,
        title: data.title,
        domain_name: data.domain_name,
        price: data.price,
        category: data.category,
        expiration_date: data.expiration_date,
      });
      
      // Check for active auction
      const { data: auctionData } = await supabase
        .from("auctions")
        .select("id, current_bid, starting_price, end_time, status")
        .eq("domain_id", id)
        .eq("status", "active")
        .maybeSingle();
      
      setActiveAuction(auctionData);
    } catch (error: any) {
      toast.error("Failed to load domain");
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const fetchWalletBalance = async () => {
    if (!user) return;

    const { data: wallet } = await supabase
      .from("wallets")
      .select("balance")
      .eq("user_id", user.id)
      .maybeSingle();

    if (wallet) {
      setBalance(Number(wallet.balance));
    }
  };

  const checkWatchStatus = async () => {
    if (!user || !id) return;

    const { data } = await supabase
      .from("domain_watchlist")
      .select("id")
      .eq("user_id", user.id)
      .eq("domain_id", id)
      .maybeSingle();

    setIsWatching(!!data);
  };

  const toggleWatch = async () => {
    if (!user || !id) {
      toast.error("Please sign in to watch domains");
      return;
    }

    setIsTogglingWatch(true);
    try {
      if (isWatching) {
        const { error } = await supabase
          .from("domain_watchlist")
          .delete()
          .eq("user_id", user.id)
          .eq("domain_id", id);

        if (error) throw error;
        setIsWatching(false);
        toast.success("Removed from watchlist");
      } else {
        const { error } = await supabase
          .from("domain_watchlist")
          .insert({ user_id: user.id, domain_id: id });

        if (error) throw error;
        setIsWatching(true);
        toast.success("Added to watchlist - you'll be notified when this domain goes on auction");
      }
    } catch (error: any) {
      toast.error("Failed to update watchlist");
      console.error(error);
    } finally {
      setIsTogglingWatch(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(price);
  };

  const isExpiringSoon = (expirationDate: string | null) => {
    if (!expirationDate) return false;
    const expiry = new Date(expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
  };

  const getDaysUntilExpiry = (expirationDate: string | null) => {
    if (!expirationDate) return null;
    const expiry = new Date(expirationDate);
    const now = new Date();
    return Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  };

  const isOwner = user && domain && user.id === domain.user_id;
  const daysLeft = domain ? getDaysUntilExpiry(domain.expiration_date) : null;
  const expiringSoon = domain ? isExpiringSoon(domain.expiration_date) : false;

  const handlePurchase = async () => {
    if (!domain || !user) return;

    if (balance < domain.price) {
      toast.error("Insufficient wallet balance");
      setShowPurchaseDialog(false);
      return;
    }

    setIsPurchasing(true);
    try {
      const sellerId = domain.user_id;
      const price = domain.price;

      // Deduct from buyer's wallet
      const { error: buyerWalletError } = await supabase
        .from("wallets")
        .update({ balance: balance - price })
        .eq("user_id", user.id);

      if (buyerWalletError) throw buyerWalletError;

      // Create purchase transaction for buyer
      await supabase.from("transactions").insert({
        user_id: user.id,
        type: "purchase",
        amount: price,
        description: `Purchased domain: ${domain.domain_name}`,
      });

      // Add to seller's wallet
      const { data: sellerWallet } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", sellerId)
        .maybeSingle();

      if (sellerWallet) {
        await supabase
          .from("wallets")
          .update({ balance: Number(sellerWallet.balance) + price })
          .eq("user_id", sellerId);
      } else {
        await supabase
          .from("wallets")
          .insert({ user_id: sellerId, balance: price });
      }

      // Create sale transaction for seller
      await supabase.from("transactions").insert({
        user_id: sellerId,
        type: "sale",
        amount: price,
        description: `Sold domain: ${domain.domain_name}`,
      });

      // Update domain ownership
      await supabase
        .from("domains")
        .update({ user_id: user.id, status: "sold" })
        .eq("id", domain.id);

      toast.success(`Successfully purchased ${domain.domain_name}!`);
      setShowPurchaseDialog(false);
      navigate("/dashboard");
    } catch (error: any) {
      toast.error("Failed to complete purchase");
      console.error(error);
    } finally {
      setIsPurchasing(false);
    }
  };

  const handleCreateAuction = async () => {
    if (!domain || !user) return;

    const price = parseFloat(startingPrice);
    if (isNaN(price) || price <= 0) {
      toast.error("Please enter a valid starting price");
      return;
    }

    const increment = parseFloat(minIncrement);
    if (isNaN(increment) || increment <= 0) {
      toast.error("Please enter a valid minimum increment");
      return;
    }

    const durationHours = parseInt(duration);
    const endTime = new Date();
    endTime.setHours(endTime.getHours() + durationHours);

    setIsCreatingAuction(true);
    try {
      const { data: auction, error } = await supabase
        .from("auctions")
        .insert({
          domain_id: domain.id,
          seller_id: user.id,
          starting_price: price,
          min_bid_increment: increment,
          end_time: endTime.toISOString(),
        })
        .select()
        .single();

      if (error) throw error;

      // Notify watchers about the new auction
      try {
        await supabase.functions.invoke('notify-watchers', {
          body: {
            domain_id: domain.id,
            domain_name: domain.domain_name,
            auction_id: auction.id,
            starting_price: price,
          },
        });
      } catch (notifyError) {
        console.error('Failed to notify watchers:', notifyError);
        // Don't fail the auction creation if notifications fail
      }

      toast.success("Auction created successfully!");
      setShowAuctionDialog(false);
      navigate(`/auction/${auction.id}`);
    } catch (error: any) {
      toast.error(error.message || "Failed to create auction");
      console.error(error);
    } finally {
      setIsCreatingAuction(false);
    }
  };

  const openEditDialog = () => {
    if (!domain) return;
    setEditForm({
      title: domain.title,
      description: domain.description || "",
      price: domain.price.toString(),
      category: domain.category || "other",
    });
    setShowEditDialog(true);
  };

  const handleUpdateDomain = async () => {
    if (!domain || !user) return;

    const price = parseFloat(editForm.price);
    const validationResult = editDomainSchema.safeParse({
      title: editForm.title,
      description: editForm.description || undefined,
      price: price,
      category: editForm.category,
    });

    if (!validationResult.success) {
      toast.error(validationResult.error.errors[0].message);
      return;
    }

    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from("domains")
        .update({
          title: editForm.title.trim(),
          description: editForm.description.trim() || null,
          price: price,
          category: editForm.category,
        })
        .eq("id", domain.id)
        .eq("user_id", user.id);

      if (error) throw error;

      setDomain({
        ...domain,
        title: editForm.title.trim(),
        description: editForm.description.trim() || null,
        price: price,
        category: editForm.category,
      });

      toast.success("Domain updated successfully!");
      setShowEditDialog(false);
    } catch (error: any) {
      toast.error("Failed to update domain");
      console.error(error);
    } finally {
      setIsUpdating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4 max-w-4xl">
            <Skeleton className="h-8 w-32 mb-6" />
            <Card>
              <CardHeader>
                <Skeleton className="h-8 w-3/4" />
              </CardHeader>
              <CardContent className="space-y-6">
                <Skeleton className="h-24 w-full" />
                <Skeleton className="h-16 w-full" />
              </CardContent>
            </Card>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!domain) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4 text-center">
            <Globe className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <h1 className="text-2xl font-bold mb-2">Domain not found</h1>
            <Button onClick={() => navigate("/marketplace")}>
              Back to Marketplace
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-4xl">
          {/* Back Button */}
          <Button
            variant="ghost"
            className="mb-6 gap-2"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>

          {/* Expiration Warning Banner */}
          {expiringSoon && daysLeft !== null && (
            <Alert variant="destructive" className="mb-6 border-destructive/50 bg-destructive/10">
              <AlertTriangle className="h-5 w-5" />
              <AlertTitle className="text-lg font-semibold">
                Domain Expiring Soon!
              </AlertTitle>
              <AlertDescription className="mt-2">
                <p className="text-base">
                  This domain expires in <strong>{daysLeft} day{daysLeft !== 1 ? 's' : ''}</strong> 
                  {domain.expiration_date && (
                    <span> (on {format(new Date(domain.expiration_date), "MMMM d, yyyy")})</span>
                  )}. 
                  Act quickly to secure this domain before it becomes unavailable.
                </p>
              </AlertDescription>
            </Alert>
          )}

          <div className="grid gap-6 md:grid-cols-3">
            {/* Main Info Card */}
            <Card className="md:col-span-2">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-3 rounded-xl bg-primary/10">
                      <Globe className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="font-display text-2xl">{domain.title}</CardTitle>
                      <p className="text-primary font-semibold text-lg">{domain.domain_name}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {domain.expiration_date && (
                      <Badge variant="outline" className="gap-1 text-green-600 border-green-600/50 bg-green-500/10">
                        <ShieldCheck className="h-3 w-3" />
                        Verified
                      </Badge>
                    )}
                    {expiringSoon && daysLeft !== null && (
                      <Badge variant="destructive" className="gap-1">
                        <AlertTriangle className="h-3 w-3" />
                        {daysLeft}d left
                      </Badge>
                    )}
                    <Badge variant={domain.status === "active" ? "default" : "secondary"}>
                      {domain.status}
                    </Badge>
                    <Badge variant="outline" className="capitalize">
                      {domain.category}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Description */}
                {domain.description && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Description</h3>
                    <p className="text-foreground">{domain.description}</p>
                  </div>
                )}

                {/* Details Grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 rounded-lg bg-muted/50 border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <DollarSign className="h-4 w-4" />
                      <span className="text-sm">Listed Price</span>
                    </div>
                    <p className="font-display text-2xl font-bold text-primary">
                      {formatPrice(domain.price)}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50 border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Tag className="h-4 w-4" />
                      <span className="text-sm">Category</span>
                    </div>
                    <p className="font-semibold capitalize">
                      {domain.category}
                    </p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted/50 border">
                    <div className="flex items-center gap-2 text-muted-foreground mb-1">
                      <Calendar className="h-4 w-4" />
                      <span className="text-sm">Listed On</span>
                    </div>
                    <p className="font-semibold">
                      {format(new Date(domain.created_at), "MMM d, yyyy")}
                    </p>
                  </div>
                  {domain.expiration_date && (
                    <div className="p-4 rounded-lg bg-muted/50 border">
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <Clock className="h-4 w-4" />
                        <span className="text-sm">Domain Expires</span>
                      </div>
                      <p className="font-semibold">
                        {format(new Date(domain.expiration_date), "MMM d, yyyy")}
                      </p>
                    </div>
                  )}
                </div>

                {/* Domain Health Score */}
                <DomainHealthScore expirationDate={domain.expiration_date} />

                {/* Active Auction Notice */}
                {activeAuction && (
                  <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <div className="flex items-center gap-2 text-amber-600 mb-2">
                      <Gavel className="h-5 w-5" />
                      <span className="font-semibold">Active Auction</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      This domain is currently being auctioned. Current bid: {formatPrice(Number(activeAuction.current_bid) || Number(activeAuction.starting_price))}
                    </p>
                    <Button asChild size="sm">
                      <Link to={`/auction/${activeAuction.id}`}>
                        View Auction
                      </Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Actions Sidebar */}
            <div className="space-y-4">
              {isOwner ? (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <User className="h-5 w-5" />
                        Your Domain
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Button 
                        variant="outline" 
                        className="w-full" 
                        onClick={openEditDialog}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit Details
                      </Button>
                      {!activeAuction && domain.status === "active" && (
                        <Button 
                          className="w-full" 
                          onClick={() => setShowAuctionDialog(true)}
                        >
                          <Gavel className="mr-2 h-4 w-4" />
                          Create Auction
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                  
                  {/* Offers received on this domain */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <MessageSquare className="h-5 w-5" />
                        Offers Received
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <OffersManager domainId={domain.id} view="received" />
                    </CardContent>
                  </Card>
                </>
              ) : (
                <>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Purchase Domain</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="text-center py-4">
                        <p className="text-3xl font-display font-bold text-primary">
                          {formatPrice(domain.price)}
                        </p>
                        <p className="text-sm text-muted-foreground">Buy Now Price</p>
                      </div>
                      
                      {user ? (
                        <>
                          <div className="flex justify-between text-sm py-2 border-t">
                            <span className="text-muted-foreground">Your Balance</span>
                            <span className={balance < domain.price ? "text-destructive" : "text-green-500"}>
                              {formatPrice(balance)}
                            </span>
                          </div>
                          {activeAuction ? (
                            <Button className="w-full" asChild>
                              <Link to={`/auction/${activeAuction.id}`}>
                                <Gavel className="mr-2 h-4 w-4" />
                                Bid in Auction
                              </Link>
                            </Button>
                          ) : (
                            <Button 
                              className="w-full" 
                              onClick={() => setShowPurchaseDialog(true)}
                              disabled={balance < domain.price}
                            >
                              <ShoppingCart className="mr-2 h-4 w-4" />
                              Buy Now
                            </Button>
                          )}
                          {!activeAuction && domain.status === "active" && (
                            <MakeOfferDialog
                              domainId={domain.id}
                              domainName={domain.domain_name}
                              sellerId={domain.user_id}
                              listingPrice={domain.price}
                            />
                          )}
                          {balance < domain.price && (
                            <Button variant="outline" className="w-full" asChild>
                              <Link to="/wallet">Add Funds</Link>
                            </Button>
                          )}
                        </>
                      ) : (
                        <Button className="w-full" asChild>
                          <Link to="/auth">Sign in to Purchase</Link>
                        </Button>
                      )}
                    </CardContent>
                  </Card>

                  {/* Watch Card */}
                  <Card>
                    <CardContent className="pt-6">
                      <Button
                        variant={isWatching ? "secondary" : "outline"}
                        className="w-full"
                        onClick={toggleWatch}
                        disabled={isTogglingWatch || !user}
                      >
                        {isWatching ? (
                          <>
                            <EyeOff className="mr-2 h-4 w-4" />
                            Unwatch
                          </>
                        ) : (
                          <>
                            <Eye className="mr-2 h-4 w-4" />
                            Watch Domain
                          </>
                        )}
                      </Button>
                      <p className="text-xs text-muted-foreground text-center mt-2">
                        {user 
                          ? "Get notified when this domain goes on auction"
                          : "Sign in to watch this domain"
                        }
                      </p>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />

      {/* Purchase Confirmation Dialog */}
      <Dialog open={showPurchaseDialog} onOpenChange={setShowPurchaseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Purchase</DialogTitle>
            <DialogDescription>
              You are about to purchase this domain using your wallet balance.
            </DialogDescription>
          </DialogHeader>
          {domain && (
            <div className="space-y-4 py-4">
              <div className="flex justify-between items-center p-4 bg-muted rounded-lg">
                <div>
                  <p className="font-semibold">{domain.title}</p>
                  <p className="text-primary">{domain.domain_name}</p>
                </div>
                <span className="text-2xl font-bold text-primary">
                  {formatPrice(domain.price)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Your wallet balance:</span>
                <span className={balance < domain.price ? "text-destructive" : "text-green-500"}>
                  {formatPrice(balance)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">After purchase:</span>
                <span>{formatPrice(balance - domain.price)}</span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPurchaseDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handlePurchase} disabled={isPurchasing}>
              {isPurchasing ? "Processing..." : "Confirm Purchase"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Auction Dialog */}
      <Dialog open={showAuctionDialog} onOpenChange={setShowAuctionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Auction</DialogTitle>
            <DialogDescription>
              List {domain?.domain_name} for bidding
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <p className="text-sm text-muted-foreground">Listed Price</p>
              <p className="font-display text-xl font-bold">
                {domain && formatPrice(domain.price)}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="startingPrice">Starting Price ($)</Label>
              <Input
                id="startingPrice"
                type="number"
                placeholder="1000"
                value={startingPrice}
                onChange={(e) => setStartingPrice(e.target.value)}
                min="1"
                step="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="minIncrement">Minimum Bid Increment ($)</Label>
              <Input
                id="minIncrement"
                type="number"
                placeholder="10"
                value={minIncrement}
                onChange={(e) => setMinIncrement(e.target.value)}
                min="1"
                step="1"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Auction Duration</Label>
              <Select value={duration} onValueChange={setDuration}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 Hour</SelectItem>
                  <SelectItem value="6">6 Hours</SelectItem>
                  <SelectItem value="12">12 Hours</SelectItem>
                  <SelectItem value="24">24 Hours</SelectItem>
                  <SelectItem value="48">2 Days</SelectItem>
                  <SelectItem value="72">3 Days</SelectItem>
                  <SelectItem value="168">7 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAuctionDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateAuction} disabled={isCreatingAuction}>
              {isCreatingAuction ? "Creating..." : "Create Auction"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Domain Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Domain Details</DialogTitle>
            <DialogDescription>
              Update the details for {domain?.domain_name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="editTitle">Title</Label>
              <Input
                id="editTitle"
                placeholder="Premium Tech Domain"
                value={editForm.title}
                onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                maxLength={100}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="editPrice">Price ($)</Label>
              <Input
                id="editPrice"
                type="number"
                placeholder="999.99"
                value={editForm.price}
                onChange={(e) => setEditForm({ ...editForm, price: e.target.value })}
                min="0.01"
                step="0.01"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="editCategory">Category</Label>
              <Select
                value={editForm.category}
                onValueChange={(value) => setEditForm({ ...editForm, category: value })}
              >
                <SelectTrigger id="editCategory">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {DOMAIN_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="editDescription">Description (optional)</Label>
              <Textarea
                id="editDescription"
                placeholder="Describe your domain..."
                rows={4}
                value={editForm.description}
                onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                maxLength={1000}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              <X className="mr-2 h-4 w-4" />
              Cancel
            </Button>
            <Button onClick={handleUpdateDomain} disabled={isUpdating}>
              <Save className="mr-2 h-4 w-4" />
              {isUpdating ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DomainDetail;
