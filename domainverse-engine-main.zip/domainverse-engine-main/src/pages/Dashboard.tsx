import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole, getRoleLabel, AppRole } from "@/hooks/useUserRole";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import ParkedDomainsSection from "@/components/ParkedDomainsSection";
import {
  Globe,
  Wallet,
  TrendingUp,
  Gavel,
  Plus,
  Search,
  Settings,
  LogOut,
  Eye,
  ChevronDown,
  LayoutDashboard,
  User,
  Clock,
  ExternalLink,
  Shield,
  Briefcase,
  Award,
  Store,
  Building2,
  ShoppingCart,
  ParkingCircle,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Profile {
  full_name: string | null;
  email: string | null;
  avatar_url: string | null;
}

interface Domain {
  id: string;
  domain_name: string;
  title: string;
  price: number;
  status: string;
  created_at: string;
}

interface Auction {
  id: string;
  current_bid: number;
  starting_price: number;
  end_time: string;
  status: string;
  domain: {
    domain_name: string;
    title: string;
  };
}

const roleConfig: Record<AppRole, { icon: typeof Shield; path: string; gradient: string }> = {
  admin: { icon: Shield, path: "/admin", gradient: "from-destructive to-destructive/80" },
  investor: { icon: Briefcase, path: "/investor", gradient: "from-primary to-primary/80" },
  expert: { icon: Award, path: "/expert", gradient: "from-accent to-accent/80" },
  reseller: { icon: Store, path: "/reseller", gradient: "from-secondary to-secondary/80" },
  franchise: { icon: Building2, path: "/franchise", gradient: "from-muted to-muted/80" },
  buyer: { icon: ShoppingCart, path: "/buyer", gradient: "from-primary to-accent" },
};

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const { roles, loading: rolesLoading } = useUserRole();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [domains, setDomains] = useState<Domain[]>([]);
  const [auctions, setAuctions] = useState<Auction[]>([]);
  const [walletBalance, setWalletBalance] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Fetch profile
        const { data: profileData } = await supabase
          .from("profiles")
          .select("full_name, email, avatar_url")
          .eq("user_id", user.id)
          .maybeSingle();
        setProfile(profileData);

        // Fetch owned domains
        const { data: domainsData } = await supabase
          .from("domains")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });
        setDomains(domainsData || []);

        // Fetch user's active auctions (as seller)
        const { data: sellerAuctions } = await supabase
          .from("auctions")
          .select(`
            id,
            current_bid,
            starting_price,
            end_time,
            status,
            domain:domains(domain_name, title)
          `)
          .eq("seller_id", user.id)
          .eq("status", "active")
          .order("end_time", { ascending: true });

        // Fetch auctions user is bidding on
        const { data: biddingAuctions } = await supabase
          .from("auctions")
          .select(`
            id,
            current_bid,
            starting_price,
            end_time,
            status,
            current_bidder_id,
            domain:domains(domain_name, title)
          `)
          .eq("status", "active")
          .eq("current_bidder_id", user.id);

        // Combine and dedupe auctions
        const allAuctions = [...(sellerAuctions || []), ...(biddingAuctions || [])];
        const uniqueAuctions = allAuctions.filter(
          (auction, index, self) => index === self.findIndex((a) => a.id === auction.id)
        );
        setAuctions(uniqueAuctions);

        // Fetch wallet balance
        const { data: walletData } = await supabase
          .from("wallets")
          .select("balance")
          .eq("user_id", user.id)
          .maybeSingle();
        setWalletBalance(walletData?.balance || 0);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
  };

  const getTimeLeft = (endTime: string) => {
    const now = new Date();
    const end = new Date(endTime);
    const diff = end.getTime() - now.getTime();

    if (diff <= 0) return "Ended";

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

    if (days > 0) return `${days}d ${hours}h`;
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const portfolioValue = domains.reduce((sum, d) => sum + d.price, 0);

  const stats = [
    { label: "Total Domains", value: domains.length.toString(), icon: Globe, color: "text-primary" },
    { label: "Wallet Balance", value: `$${walletBalance.toLocaleString()}`, icon: Wallet, color: "text-accent" },
    { label: "Active Auctions", value: auctions.length.toString(), icon: Gavel, color: "text-primary" },
    { label: "Portfolio Value", value: `$${portfolioValue.toLocaleString()}`, icon: TrendingUp, color: "text-accent" },
  ];

  const displayName = profile?.full_name || user?.email?.split("@")[0] || "User";

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="hidden lg:flex items-center gap-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search domains..."
                  className="pl-10 pr-4 py-2 rounded-lg bg-muted/50 border border-border text-sm w-64 focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center">
                      <span className="text-sm font-semibold text-primary-foreground">
                        {displayName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/settings" className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          {/* Welcome Section */}
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Welcome back, <span className="text-gradient-primary">{displayName}</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Here's an overview of your domain portfolio
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {stats.map((stat, index) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 lg:p-6 hover:shadow-glow transition-all duration-300"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Role Dashboards */}
          {!rolesLoading && roles.length > 0 && (
            <div className="glass rounded-xl p-6 lg:p-8 mb-8">
              <h2 className="text-xl font-bold font-display text-foreground mb-2">
                Your Dashboards
              </h2>
              <p className="text-muted-foreground text-sm mb-6">
                Access your role-specific dashboard for specialized tools and features
              </p>
              <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                {roles.map((role) => {
                  const config = roleConfig[role];
                  const IconComponent = config.icon;
                  return (
                    <Button
                      key={role}
                      variant="outline"
                      className={`h-auto py-5 flex-col gap-3 group hover:border-primary/50 transition-all duration-300`}
                      asChild
                    >
                      <Link to={config.path}>
                        <div className={`p-2.5 rounded-lg bg-gradient-to-br ${config.gradient} group-hover:scale-110 transition-transform`}>
                          <IconComponent className="h-5 w-5 text-white" />
                        </div>
                        <span className="text-sm font-medium">{getRoleLabel(role)}</span>
                      </Link>
                    </Button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Quick Actions
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/add-domain">
                  <Plus className="h-6 w-6 text-primary" />
                  <span>Add Domain</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/parking">
                  <ParkingCircle className="h-6 w-6 text-primary" />
                  <span>Park Domain</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Search className="h-6 w-6 text-primary" />
                  <span>Search Market</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/auctions">
                  <Gavel className="h-6 w-6 text-primary" />
                  <span>View Auctions</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/watchlist">
                  <Eye className="h-6 w-6 text-primary" />
                  <span>Watchlist</span>
                </Link>
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Active Auctions */}
            <Card className="glass border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Gavel className="h-5 w-5 text-primary" />
                  Active Auctions
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/auctions">View All</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : auctions.length === 0 ? (
                  <div className="text-center py-8">
                    <Gavel className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground text-sm">No active auctions</p>
                    <Button variant="outline" size="sm" className="mt-4" asChild>
                      <Link to="/create-auction">Create Auction</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {auctions.slice(0, 5).map((auction) => (
                      <div
                        key={auction.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors cursor-pointer"
                        onClick={() => navigate(`/auction/${auction.id}`)}
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">
                            {auction.domain?.domain_name}
                          </p>
                          <p className="text-sm text-muted-foreground truncate">
                            {auction.domain?.title}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 ml-4">
                          <div className="text-right">
                            <p className="font-semibold text-foreground">
                              ${(auction.current_bid || auction.starting_price).toLocaleString()}
                            </p>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3" />
                              {getTimeLeft(auction.end_time)}
                            </div>
                          </div>
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Owned Domains */}
            <Card className="glass border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  Your Domains
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link to="/add-domain">Add New</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="space-y-3">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
                    ))}
                  </div>
                ) : domains.length === 0 ? (
                  <div className="text-center py-8">
                    <Globe className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground text-sm">No domains yet</p>
                    <Button variant="outline" size="sm" className="mt-4" asChild>
                      <Link to="/add-domain">Add Domain</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {domains.slice(0, 5).map((domain) => (
                      <div
                        key={domain.id}
                        className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">
                            {domain.domain_name}
                          </p>
                          <p className="text-sm text-muted-foreground truncate">
                            {domain.title}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 ml-4">
                          <div className="text-right">
                            <p className="font-semibold text-foreground">
                              ${domain.price.toLocaleString()}
                            </p>
                            <Badge
                              variant={domain.status === "active" ? "default" : "secondary"}
                              className="text-xs"
                            >
                              {domain.status}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Parked Domains Section */}
          <div className="mt-8">
            <ParkedDomainsSection />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
