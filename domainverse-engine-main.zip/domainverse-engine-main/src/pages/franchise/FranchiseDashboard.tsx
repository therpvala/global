import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  Building2,
  Users,
  Globe,
  DollarSign,
  TrendingUp,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  MapPin,
  BarChart3,
  Settings,
  Megaphone,
  Loader2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";

interface FranchiseStats {
  totalDomains: number;
  walletBalance: number;
  totalSales: number;
  parkedDomains: number;
}

const FranchiseDashboard = () => {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<FranchiseStats>({
    totalDomains: 0,
    walletBalance: 0,
    totalSales: 0,
    parkedDomains: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        const [
          { data: domains },
          { data: wallet },
          { data: sales },
          { count: parkedCount },
        ] = await Promise.all([
          supabase.from("domains").select("id").eq("user_id", user.id),
          supabase.from("wallets").select("balance").eq("user_id", user.id).maybeSingle(),
          supabase.from("transactions").select("amount").eq("user_id", user.id).eq("type", "sale"),
          supabase.from("parked_domains").select("*", { count: "exact", head: true }).eq("user_id", user.id).eq("status", "active"),
        ]);

        const totalSalesAmount = sales?.reduce((sum, s) => sum + Number(s.amount), 0) || 0;

        setStats({
          totalDomains: domains?.length || 0,
          walletBalance: wallet?.balance || 0,
          totalSales: totalSalesAmount,
          parkedDomains: parkedCount || 0,
        });
      } catch (error) {
        console.error("Error fetching franchise data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const displayName = user?.email?.split("@")[0] || "Franchise Partner";

  const statsCards = [
    { label: "Total Domains", value: stats.totalDomains.toString(), icon: Globe, color: "text-primary" },
    { label: "Wallet Balance", value: `$${stats.walletBalance.toLocaleString()}`, icon: DollarSign, color: "text-accent" },
    { label: "Total Sales", value: `$${stats.totalSales.toLocaleString()}`, icon: TrendingUp, color: "text-green-500" },
    { label: "Parked Domains", value: stats.parkedDomains.toString(), icon: MapPin, color: "text-primary" },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge className="gap-1 bg-muted text-muted-foreground border">
                <Building2 className="h-3 w-3" />
                Franchise
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                      <Building2 className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      General Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Franchise <span className="text-gradient-primary">Dashboard</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Manage your franchise operations and domain portfolio
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {loading ? <Loader2 className="h-6 w-6 animate-spin" /> : stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Franchise Tools
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/add-domain">
                  <Globe className="h-6 w-6 text-primary" />
                  <span>Add Domain</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  <span>Marketplace</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/parking">
                  <Megaphone className="h-6 w-6 text-primary" />
                  <span>Domain Parking</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/settings">
                  <Settings className="h-6 w-6 text-primary" />
                  <span>Settings</span>
                </Link>
              </Button>
            </div>
          </div>

          {/* Portfolio Overview */}
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-primary" />
                Franchise Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-muted/30">
                      <p className="text-sm text-muted-foreground">Portfolio Health</p>
                      <div className="mt-2">
                        <Progress value={75} className="h-2" />
                        <p className="text-xs text-muted-foreground mt-1">75% domains active</p>
                      </div>
                    </div>
                    <div className="p-4 rounded-lg bg-muted/30">
                      <p className="text-sm text-muted-foreground">Revenue Target</p>
                      <div className="mt-2">
                        <Progress value={stats.totalSales > 0 ? Math.min((stats.totalSales / 50000) * 100, 100) : 0} className="h-2" />
                        <p className="text-xs text-muted-foreground mt-1">
                          ${stats.totalSales.toLocaleString()} / $50,000
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="text-center py-4">
                    <Button variant="outline" asChild>
                      <Link to="/dashboard">View Full Dashboard</Link>
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default FranchiseDashboard;
