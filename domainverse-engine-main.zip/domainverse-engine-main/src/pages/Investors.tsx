import { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp,
  Shield,
  DollarSign,
  Globe,
  BarChart3,
  CheckCircle,
  ArrowRight,
  Briefcase,
} from "lucide-react";

const investmentTiers = [
  {
    name: "Starter",
    minInvestment: 1000,
    maxShare: 5,
    expectedROI: "8-12%",
    features: ["Access to marketplace domains", "Monthly reports", "Email support"],
  },
  {
    name: "Growth",
    minInvestment: 10000,
    maxShare: 15,
    expectedROI: "12-18%",
    features: ["Premium domain access", "Weekly reports", "Priority support", "Portfolio diversification"],
    popular: true,
  },
  {
    name: "Premium",
    minInvestment: 50000,
    maxShare: 30,
    expectedROI: "15-25%",
    features: ["Exclusive domains", "Daily insights", "Dedicated manager", "Custom portfolio", "Early access"],
  },
];

const stats = [
  { label: "Total Invested", value: "$2.4M+", icon: DollarSign },
  { label: "Active Investors", value: "340+", icon: Briefcase },
  { label: "Avg. Annual ROI", value: "18.5%", icon: TrendingUp },
  { label: "Domains Funded", value: "1,200+", icon: Globe },
];

const Investors = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            Domain Investment Platform
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Invest in Premium Domains
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Diversify your portfolio with high-value domain investments. 
            Earn passive income from domain sales and parking revenue.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gap-2" asChild>
              <Link to="/auth">
                Start Investing
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/marketplace">Browse Domains</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="h-8 w-8 text-primary mx-auto mb-2" />
                <div className="text-2xl md:text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Investment Tiers */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-foreground mb-4">
            Investment Tiers
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Choose an investment tier that matches your goals. All tiers include full platform access and secure escrow protection.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {investmentTiers.map((tier) => (
              <Card 
                key={tier.name} 
                className={`relative border ${tier.popular ? "border-primary shadow-lg" : "border-border"}`}
              >
                {tier.popular && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-4">
                  <CardTitle className="text-xl">{tier.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-3xl font-bold text-foreground">
                      ${tier.minInvestment.toLocaleString()}
                    </span>
                    <span className="text-muted-foreground"> min</span>
                  </div>
                  <div className="flex items-center justify-center gap-2 mt-2">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    <span className="text-primary font-medium">{tier.expectedROI} ROI</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    {tier.features.map((feature) => (
                      <div key={feature} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                        <span className="text-sm text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <div className="text-sm text-muted-foreground text-center mb-4">
                    Up to {tier.maxShare}% share per domain
                  </div>
                  <Button 
                    className="w-full" 
                    variant={tier.popular ? "default" : "outline"}
                    asChild
                  >
                    <Link to="/auth">Get Started</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Invest */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-foreground mb-12">
            Why Invest in Domains?
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Appreciation Potential</h3>
              <p className="text-muted-foreground text-sm">
                Premium domains consistently appreciate in value, often outperforming traditional investments.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <DollarSign className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Passive Income</h3>
              <p className="text-muted-foreground text-sm">
                Earn from domain parking revenue while waiting for the right buyer.
              </p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">Secure Escrow</h3>
              <p className="text-muted-foreground text-sm">
                All investments are protected through our secure escrow system with full transparency.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Ready to Start Investing?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            Join hundreds of investors earning from premium domain investments.
          </p>
          <Button size="lg" className="gap-2" asChild>
            <Link to="/auth">
              Create Account
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Investors;
