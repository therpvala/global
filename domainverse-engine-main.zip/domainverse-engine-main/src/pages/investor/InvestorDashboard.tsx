import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Logo from "@/components/Logo";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import {
  TrendingUp,
  Wallet,
  PieChart,
  Globe,
  Target,
  BarChart3,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  User,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Progress } from "@/components/ui/progress";

interface PortfolioStats {
  totalValue: number;
  totalDomains: number;
  walletBalance: number;
  roi: number;
}

interface Investment {
  id: string;
  domain_name: string;
  title: string;
  price: number;
  purchasePrice: number;
  change: number;
}

const InvestorDashboard = () => {
  const { user, signOut } = useAuth();
  const [stats, setStats] = useState<PortfolioStats>({
    totalValue: 0,
    totalDomains: 0,
    walletBalance: 0,
    roi: 0,
  });
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      try {
        // Fetch owned domains
        const { data: domains } = await supabase
          .from("domains")
          .select("*")
          .eq("user_id", user.id);

        // Fetch wallet
        const { data: wallet } = await supabase
          .from("wallets")
          .select("balance")
          .eq("user_id", user.id)
          .maybeSingle();

        // Fetch purchase transactions
        const { data: purchases } = await supabase
          .from("transactions")
          .select("*")
          .eq("user_id", user.id)
          .eq("type", "purchase");

        const totalValue = domains?.reduce((sum, d) => sum + d.price, 0) || 0;
        const totalPurchaseValue = purchases?.reduce((sum, p) => sum + p.amount, 0) || 0;
        const roi = totalPurchaseValue > 0 ? ((totalValue - totalPurchaseValue) / totalPurchaseValue) * 100 : 0;

        setStats({
          totalValue,
          totalDomains: domains?.length || 0,
          walletBalance: wallet?.balance || 0,
          roi,
        });

        // Create mock investment data with price changes
        const investmentData: Investment[] = domains?.map((d) => ({
          id: d.id,
          domain_name: d.domain_name,
          title: d.title,
          price: d.price,
          purchasePrice: d.price * 0.85, // Simulated
          change: Math.random() * 30 - 10, // Random change between -10% and +20%
        })) || [];

        setInvestments(investmentData);
      } catch (error) {
        console.error("Error fetching investor data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user]);

  const displayName = user?.email?.split("@")[0] || "Investor";

  const statsCards = [
    { label: "Portfolio Value", value: `$${stats.totalValue.toLocaleString()}`, icon: PieChart, color: "text-primary" },
    { label: "Total Domains", value: stats.totalDomains.toString(), icon: Globe, color: "text-accent" },
    { label: "Wallet Balance", value: `$${stats.walletBalance.toLocaleString()}`, icon: Wallet, color: "text-primary" },
    { label: "ROI", value: `${stats.roi.toFixed(1)}%`, icon: TrendingUp, color: stats.roi >= 0 ? "text-green-500" : "text-destructive" },
  ];

  return (
    <div className="min-h-screen bg-gradient-hero">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 lg:h-20">
            <Link to="/" className="flex-shrink-0">
              <Logo size="md" />
            </Link>

            <div className="flex items-center gap-2">
              <Badge className="gap-1 bg-primary text-primary-foreground">
                <TrendingUp className="h-3 w-3" />
                Investor
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              <NotificationsDropdown />

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2">
                    <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-primary-foreground" />
                    </div>
                    <span className="hidden lg:inline font-medium">{displayName}</span>
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem asChild>
                    <Link to="/profile" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/dashboard" className="flex items-center gap-2">
                      <LayoutDashboard className="h-4 w-4" />
                      General Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={signOut} className="text-destructive">
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 lg:pt-28 pb-12 px-4">
        <div className="container mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl lg:text-4xl font-bold font-display text-foreground">
              Investor <span className="text-gradient-primary">Portfolio</span>
            </h1>
            <p className="text-muted-foreground mt-2">
              Track your domain investments and portfolio performance
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
            {statsCards.map((stat) => (
              <div
                key={stat.label}
                className="glass rounded-xl p-5 hover:shadow-glow transition-all duration-300"
              >
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <div className="text-2xl lg:text-3xl font-bold font-display text-foreground">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="glass rounded-xl p-6 lg:p-8 mb-8">
            <h2 className="text-xl font-bold font-display text-foreground mb-6">
              Investment Actions
            </h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/marketplace">
                  <Target className="h-6 w-6 text-primary" />
                  <span>Find Opportunities</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/auctions">
                  <BarChart3 className="h-6 w-6 text-primary" />
                  <span>Live Auctions</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/wallet">
                  <DollarSign className="h-6 w-6 text-primary" />
                  <span>Add Funds</span>
                </Link>
              </Button>
              <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
                <Link to="/watchlist">
                  <PieChart className="h-6 w-6 text-primary" />
                  <span>Watchlist</span>
                </Link>
              </Button>
            </div>
          </div>

          {/* Portfolio Holdings */}
          <Card className="glass border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                Portfolio Holdings
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="space-y-3">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="h-20 bg-muted/50 rounded-lg animate-pulse" />
                  ))}
                </div>
              ) : investments.length === 0 ? (
                <div className="text-center py-8">
                  <Globe className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground text-sm">No investments yet</p>
                  <Button variant="outline" size="sm" className="mt-4" asChild>
                    <Link to="/marketplace">Start Investing</Link>
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {investments.map((inv) => (
                    <div
                      key={inv.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{inv.domain_name}</p>
                        <p className="text-sm text-muted-foreground">{inv.title}</p>
                        <div className="mt-2">
                          <Progress value={Math.min(Math.max(inv.change + 50, 0), 100)} className="h-2" />
                        </div>
                      </div>
                      <div className="text-right ml-4">
                        <p className="font-semibold text-foreground">${inv.price.toLocaleString()}</p>
                        <div className={`flex items-center gap-1 text-sm ${inv.change >= 0 ? "text-green-500" : "text-destructive"}`}>
                          {inv.change >= 0 ? (
                            <ArrowUpRight className="h-4 w-4" />
                          ) : (
                            <ArrowDownRight className="h-4 w-4" />
                          )}
                          {Math.abs(inv.change).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default InvestorDashboard;
