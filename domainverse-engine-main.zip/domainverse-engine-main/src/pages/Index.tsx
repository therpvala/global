import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import TrustSignals from "@/components/TrustSignals";
import FeaturesSection from "@/components/FeaturesSection";
import HowItWorks from "@/components/HowItWorks";
import LiveStatsBar from "@/components/LiveStatsBar";
import InvestorTeaser from "@/components/InvestorTeaser";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>DomainVala - Sell, Park & Auction Premium Domains</title>
        <meta 
          name="description" 
          content="The fastest way to monetize your domains. Sell, park, or auction with secure escrow, AI valuations, and global buyers. Start in minutes." 
        />
        <meta name="keywords" content="sell domains, domain parking, domain auctions, domain marketplace, domain valuation" />
        <link rel="canonical" href="https://domainvala.com" />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <HeroSection />
          <TrustSignals />
          <FeaturesSection />
          <HowItWorks />
          <LiveStatsBar />
          <InvestorTeaser />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
