import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "recently_viewed_domains";
const MAX_ITEMS = 10;

export interface RecentlyViewedDomain {
  id: string;
  title: string;
  domain_name: string;
  price: number;
  category: string;
  expiration_date: string | null;
  viewed_at: number;
}

export const useRecentlyViewed = () => {
  const [recentlyViewed, setRecentlyViewed] = useState<RecentlyViewedDomain[]>([]);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as RecentlyViewedDomain[];
        setRecentlyViewed(parsed);
      }
    } catch (error) {
      console.error("Error loading recently viewed:", error);
    }
  }, []);

  const addToRecentlyViewed = useCallback((domain: Omit<RecentlyViewedDomain, "viewed_at">) => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      let items: RecentlyViewedDomain[] = stored ? JSON.parse(stored) : [];
      
      // Remove if already exists
      items = items.filter(item => item.id !== domain.id);
      
      // Add to beginning with timestamp
      const newItem: RecentlyViewedDomain = {
        ...domain,
        viewed_at: Date.now(),
      };
      items.unshift(newItem);
      
      // Keep only MAX_ITEMS
      items = items.slice(0, MAX_ITEMS);
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
      setRecentlyViewed(items);
    } catch (error) {
      console.error("Error saving recently viewed:", error);
    }
  }, []);

  const clearRecentlyViewed = useCallback(() => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      setRecentlyViewed([]);
    } catch (error) {
      console.error("Error clearing recently viewed:", error);
    }
  }, []);

  return {
    recentlyViewed,
    addToRecentlyViewed,
    clearRecentlyViewed,
  };
};
