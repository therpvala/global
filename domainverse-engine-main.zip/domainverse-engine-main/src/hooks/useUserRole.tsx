import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";

export type AppRole = "admin" | "investor" | "expert" | "reseller" | "franchise" | "buyer";

interface UserRoleData {
  role: AppRole | null;
  roles: AppRole[];
  loading: boolean;
  isAdmin: boolean;
  isInvestor: boolean;
  isExpert: boolean;
  isReseller: boolean;
  isFranchise: boolean;
  isBuyer: boolean;
  hasRole: (role: AppRole) => boolean;
  refetch: () => Promise<void>;
}

export const useUserRole = (): UserRoleData => {
  const { user } = useAuth();
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRoles = async () => {
    if (!user) {
      setRoles([]);
      setLoading(false);
      return;
    }
    setLoading(true);

    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);

      if (error) throw error;

      const userRoles = (data?.map((r) => r.role) || []) as AppRole[];
      setRoles(userRoles);
    } catch (error) {
      console.error("Error fetching user roles:", error);
      setRoles([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      setLoading(true);
    }
    fetchRoles();
  }, [user]);

  // Get primary role (highest priority)
  const getPrimaryRole = (): AppRole | null => {
    const priority: AppRole[] = ["admin", "investor", "expert", "reseller", "franchise", "buyer"];
    for (const role of priority) {
      if (roles.includes(role)) return role;
    }
    return null;
  };

  const hasRole = (role: AppRole) => roles.includes(role);

  return {
    role: getPrimaryRole(),
    roles,
    loading,
    isAdmin: hasRole("admin"),
    isInvestor: hasRole("investor"),
    isExpert: hasRole("expert"),
    isReseller: hasRole("reseller"),
    isFranchise: hasRole("franchise"),
    isBuyer: hasRole("buyer"),
    hasRole,
    refetch: fetchRoles,
  };
};

export const getRoleLabel = (role: AppRole): string => {
  const labels: Record<AppRole, string> = {
    admin: "Administrator",
    investor: "Investor",
    expert: "Domain Expert",
    reseller: "Reseller",
    franchise: "Franchise Partner",
    buyer: "Buyer",
  };
  return labels[role];
};

export const getRoleColor = (role: AppRole): string => {
  const colors: Record<AppRole, string> = {
    admin: "bg-destructive text-destructive-foreground",
    investor: "bg-primary text-primary-foreground",
    expert: "bg-accent text-accent-foreground",
    reseller: "bg-secondary text-secondary-foreground",
    franchise: "bg-muted text-muted-foreground",
    buyer: "bg-card text-card-foreground border",
  };
  return colors[role];
};
