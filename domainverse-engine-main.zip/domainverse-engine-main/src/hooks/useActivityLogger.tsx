import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface LogActivityParams {
  action: string;
  entityType: string;
  entityId?: string;
  entityName?: string;
  metadata?: Record<string, unknown>;
}

export const useActivityLogger = () => {
  const { user } = useAuth();

  const logActivity = async ({
    action,
    entityType,
    entityId,
    entityName,
    metadata = {},
  }: LogActivityParams) => {
    try {
      const { error } = await supabase.functions.invoke("log-activity", {
        body: {
          user_id: user?.id,
          action,
          entity_type: entityType,
          entity_id: entityId,
          entity_name: entityName,
          metadata,
        },
      });

      if (error) {
        console.error("Failed to log activity:", error);
      }
    } catch (err) {
      console.error("Error logging activity:", err);
    }
  };

  return { logActivity };
};

// Standalone function for use outside of React components
export const logActivity = async ({
  userId,
  action,
  entityType,
  entityId,
  entityName,
  metadata = {},
}: LogActivityParams & { userId?: string }) => {
  try {
    const { error } = await supabase.functions.invoke("log-activity", {
      body: {
        user_id: userId,
        action,
        entity_type: entityType,
        entity_id: entityId,
        entity_name: entityName,
        metadata,
      },
    });

    if (error) {
      console.error("Failed to log activity:", error);
    }
  } catch (err) {
    console.error("Error logging activity:", err);
  }
};
