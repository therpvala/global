import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  ParkingCircle,
  TrendingUp,
  DollarSign,
  Eye,
  MousePointer,
  ArrowDownCircle,
  RefreshCw,
  ExternalLink,
} from "lucide-react";

interface ParkedDomain {
  id: string;
  domain_id: string;
  monthly_earnings: number;
  total_earnings: number;
  clicks: number;
  impressions: number;
  status: string;
  parked_at: string;
  last_earning_date: string | null;
  domain: {
    domain_name: string;
    title: string;
  };
}

const ParkedDomainsSection = () => {
  const { user } = useAuth();
  const [parkedDomains, setParkedDomains] = useState<ParkedDomain[]>([]);
  const [loading, setLoading] = useState(true);
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [totalAvailableEarnings, setTotalAvailableEarnings] = useState(0);

  useEffect(() => {
    if (user) {
      fetchParkedDomains();
      setupRealtimeSubscription();
    }
  }, [user]);

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel("parked-domains-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "parked_domains",
        },
        () => {
          fetchParkedDomains();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const fetchParkedDomains = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("parked_domains")
        .select(`
          *,
          domain:domains(domain_name, title)
        `)
        .eq("user_id", user.id)
        .order("parked_at", { ascending: false });

      if (error) throw error;

      setParkedDomains(data as ParkedDomain[]);
      
      // Calculate total available earnings
      const total = (data || []).reduce(
        (sum, d) => sum + Number(d.total_earnings),
        0
      );
      setTotalAvailableEarnings(total);
    } catch (error) {
      console.error("Error fetching parked domains:", error);
      toast.error("Failed to load parked domains");
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    if (amount > totalAvailableEarnings) {
      toast.error("Insufficient parking earnings");
      return;
    }

    setIsWithdrawing(true);
    try {
      // Get or create wallet
      let { data: wallet, error: walletError } = await supabase
        .from("wallets")
        .select("*")
        .eq("user_id", user!.id)
        .maybeSingle();

      if (walletError) throw walletError;

      if (!wallet) {
        const { data: newWallet, error: createError } = await supabase
          .from("wallets")
          .insert({ user_id: user!.id, balance: 0 })
          .select()
          .single();

        if (createError) throw createError;
        wallet = newWallet;
      }

      // Update wallet balance
      const { error: updateWalletError } = await supabase
        .from("wallets")
        .update({ balance: Number(wallet.balance) + amount })
        .eq("user_id", user!.id);

      if (updateWalletError) throw updateWalletError;

      // Create transaction record
      const { error: txnError } = await supabase.from("transactions").insert({
        user_id: user!.id,
        type: "deposit" as const,
        amount: amount,
        description: "Parking earnings withdrawal",
      });

      if (txnError) throw txnError;

      // Deduct from parked domains earnings (proportionally)
      let remainingToDeduct = amount;
      for (const domain of parkedDomains) {
        if (remainingToDeduct <= 0) break;
        const domainEarnings = Number(domain.total_earnings);
        if (domainEarnings > 0) {
          const deduction = Math.min(domainEarnings, remainingToDeduct);
          await supabase
            .from("parked_domains")
            .update({ total_earnings: domainEarnings - deduction })
            .eq("id", domain.id);
          remainingToDeduct -= deduction;
        }
      }

      toast.success(`Successfully withdrew $${amount.toFixed(2)} to wallet`);
      setWithdrawDialogOpen(false);
      setWithdrawAmount("");
      fetchParkedDomains();
    } catch (error) {
      console.error("Error withdrawing:", error);
      toast.error("Failed to withdraw earnings");
    } finally {
      setIsWithdrawing(false);
    }
  };

  const handleUnpark = async (parkedDomainId: string) => {
    try {
      const { error } = await supabase
        .from("parked_domains")
        .delete()
        .eq("id", parkedDomainId);

      if (error) throw error;

      toast.success("Domain unparked successfully");
      fetchParkedDomains();
    } catch (error) {
      console.error("Error unparking domain:", error);
      toast.error("Failed to unpark domain");
    }
  };

  const stats = [
    {
      label: "Parked Domains",
      value: parkedDomains.length.toString(),
      icon: ParkingCircle,
      color: "text-primary",
    },
    {
      label: "Total Earnings",
      value: `$${totalAvailableEarnings.toFixed(2)}`,
      icon: DollarSign,
      color: "text-accent",
    },
    {
      label: "Total Clicks",
      value: parkedDomains.reduce((sum, d) => sum + d.clicks, 0).toString(),
      icon: MousePointer,
      color: "text-primary",
    },
    {
      label: "Total Impressions",
      value: parkedDomains.reduce((sum, d) => sum + d.impressions, 0).toString(),
      icon: Eye,
      color: "text-accent",
    },
  ];

  if (loading) {
    return (
      <Card className="glass border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ParkingCircle className="h-5 w-5 text-primary" />
            Parked Domains
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-muted/50 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass border-border">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <ParkingCircle className="h-5 w-5 text-primary" />
          Parked Domains
        </CardTitle>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={fetchParkedDomains}
            className="gap-1"
          >
            <RefreshCw className="h-3 w-3" />
            Refresh
          </Button>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/parking">Park More</Link>
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="p-4 rounded-lg bg-muted/30 border border-border"
            >
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
                <span className="text-xs text-muted-foreground">{stat.label}</span>
              </div>
              <p className="text-xl font-bold text-foreground">{stat.value}</p>
            </div>
          ))}
        </div>

        {/* Withdraw Button */}
        {totalAvailableEarnings > 0 && (
          <div className="flex items-center justify-between p-4 rounded-lg bg-accent/10 border border-accent/20">
            <div>
              <p className="font-medium text-foreground">Available for Withdrawal</p>
              <p className="text-2xl font-bold text-accent">
                ${totalAvailableEarnings.toFixed(2)}
              </p>
            </div>
            <Button
              onClick={() => setWithdrawDialogOpen(true)}
              className="gap-2"
            >
              <ArrowDownCircle className="h-4 w-4" />
              Withdraw to Wallet
            </Button>
          </div>
        )}

        {/* Parked Domains Table */}
        {parkedDomains.length === 0 ? (
          <div className="text-center py-8">
            <ParkingCircle className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground text-sm">No parked domains yet</p>
            <Button variant="outline" size="sm" className="mt-4" asChild>
              <Link to="/parking">Park a Domain</Link>
            </Button>
          </div>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead>Domain</TableHead>
                  <TableHead className="text-right">Monthly</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                  <TableHead className="text-right">Clicks</TableHead>
                  <TableHead className="text-right">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {parkedDomains.map((parked) => (
                  <TableRow key={parked.id} className="hover:bg-muted/20">
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div>
                          <p className="font-medium text-foreground">
                            {parked.domain?.domain_name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            Parked {new Date(parked.parked_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="text-accent font-medium">
                        ${Number(parked.monthly_earnings).toFixed(2)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className="font-semibold text-foreground">
                        ${Number(parked.total_earnings).toFixed(2)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {parked.clicks.toLocaleString()}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge
                        variant={parked.status === "active" ? "default" : "secondary"}
                        className={parked.status === "active" ? "bg-accent text-accent-foreground" : ""}
                      >
                        {parked.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                        >
                          <Link to={`/domain/${parked.domain_id}`}>
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUnpark(parked.id)}
                        >
                          Unpark
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Monthly Trend */}
        {parkedDomains.length > 0 && (
          <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/20 border border-border">
            <TrendingUp className="h-5 w-5 text-accent" />
            <div>
              <p className="text-sm text-muted-foreground">
                Estimated Monthly Income
              </p>
              <p className="text-lg font-bold text-foreground">
                $
                {parkedDomains
                  .reduce((sum, d) => sum + Number(d.monthly_earnings), 0)
                  .toFixed(2)}
                <span className="text-sm font-normal text-muted-foreground">
                  {" "}/ month
                </span>
              </p>
            </div>
          </div>
        )}
      </CardContent>

      {/* Withdraw Dialog */}
      <Dialog open={withdrawDialogOpen} onOpenChange={setWithdrawDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Withdraw Parking Earnings</DialogTitle>
            <DialogDescription>
              Transfer your parking earnings to your wallet balance.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 rounded-lg bg-muted/50">
              <p className="text-sm text-muted-foreground">Available Balance</p>
              <p className="text-2xl font-bold text-foreground">
                ${totalAvailableEarnings.toFixed(2)}
              </p>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Withdrawal Amount</label>
              <Input
                type="number"
                placeholder="Enter amount"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                min="0"
                max={totalAvailableEarnings}
                step="0.01"
              />
              <Button
                variant="ghost"
                size="sm"
                className="text-xs"
                onClick={() => setWithdrawAmount(totalAvailableEarnings.toString())}
              >
                Withdraw All
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setWithdrawDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleWithdraw} disabled={isWithdrawing}>
              {isWithdrawing ? "Processing..." : "Withdraw to Wallet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default ParkedDomainsSection;
