import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Globe,
  Gavel,
  Users,
  UserCog,
  Wallet,
  ParkingSquare,
  BarChart3,
  Shield,
  Settings,
  ScrollText,
  ChevronDown,
  ChevronRight,
  Activity,
  CheckCircle,
  AlertTriangle,
  Clock,
  DollarSign,
  TrendingUp,
  Briefcase,
  Star,
  FileText,
  Lock,
  Banknote,
  Sparkles,
} from "lucide-react";

interface SidebarItem {
  label: string;
  icon: React.ElementType;
  href?: string;
  children?: { label: string; href: string; icon?: React.ElementType }[];
}

const sidebarItems: SidebarItem[] = [
  {
    label: "Dashboard",
    icon: LayoutDashboard,
    href: "/admin",
  },
  {
    label: "Domains",
    icon: Globe,
    children: [
      { label: "All Domains", href: "/admin/domains", icon: Globe },
      { label: "Active", href: "/admin/domains/active", icon: CheckCircle },
      { label: "Pending Verification", href: "/admin/domains/pending", icon: Clock },
      { label: "Expired", href: "/admin/domains/expired", icon: AlertTriangle },
      { label: "Sold", href: "/admin/domains/sold", icon: DollarSign },
      { label: "Health Check", href: "/admin/domains/health", icon: Activity },
      { label: "Ownership", href: "/admin/domains/ownership", icon: Shield },
      { label: "AI Valuation", href: "/admin/domains/valuation", icon: Sparkles },
    ],
  },
  {
    label: "Auctions",
    icon: Gavel,
    children: [
      { label: "All Auctions", href: "/admin/auctions", icon: Gavel },
      { label: "Active", href: "/admin/auctions/active", icon: Activity },
      { label: "Upcoming", href: "/admin/auctions/upcoming", icon: Clock },
      { label: "Ended", href: "/admin/auctions/ended", icon: CheckCircle },
      { label: "Live Bids", href: "/admin/auctions/bids", icon: TrendingUp },
      { label: "Fraud Detection", href: "/admin/auctions/fraud", icon: AlertTriangle },
    ],
  },
  {
    label: "Investors",
    icon: Briefcase,
    children: [
      { label: "Investor List", href: "/admin/investors", icon: Users },
      { label: "Active Investments", href: "/admin/investors/active", icon: TrendingUp },
      { label: "Domain Mapping", href: "/admin/investors/mapping", icon: Globe },
      { label: "ROI Reports", href: "/admin/investors/roi", icon: BarChart3 },
      { label: "Payouts", href: "/admin/investors/payouts", icon: Banknote },
    ],
  },
  {
    label: "Domain Experts",
    icon: Star,
    children: [
      { label: "Expert List", href: "/admin/experts", icon: Users },
      { label: "Assigned Domains", href: "/admin/experts/assigned", icon: Globe },
      { label: "Suggestions", href: "/admin/experts/suggestions", icon: FileText },
      { label: "Performance", href: "/admin/experts/performance", icon: BarChart3 },
      { label: "Commission", href: "/admin/experts/commission", icon: DollarSign },
    ],
  },
  {
    label: "Users & Roles",
    icon: UserCog,
    href: "/admin/users",
  },
  {
    label: "Payments & Escrow",
    icon: Wallet,
    children: [
      { label: "Wallets", href: "/admin/payments/wallets", icon: Wallet },
      { label: "Escrow", href: "/admin/payments/escrow", icon: Lock },
      { label: "Transactions", href: "/admin/payments/transactions", icon: ScrollText },
      { label: "Auto Payout", href: "/admin/payments/auto-payout", icon: Banknote },
      { label: "Failed Payments", href: "/admin/payments/failed", icon: AlertTriangle },
    ],
  },
  {
    label: "Parking",
    icon: ParkingSquare,
    href: "/admin/parking",
  },
  {
    label: "Reports",
    icon: BarChart3,
    href: "/admin/reports",
  },
  {
    label: "Security",
    icon: Shield,
    href: "/admin/security",
  },
  {
    label: "Settings",
    icon: Settings,
    href: "/admin/settings",
  },
  {
    label: "Logs",
    icon: ScrollText,
    href: "/admin/logs",
  },
];

const AdminSidebar = () => {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState<string[]>(["Domains", "Auctions"]);

  const toggleExpand = (label: string) => {
    setExpandedItems((prev) =>
      prev.includes(label) ? prev.filter((l) => l !== label) : [...prev, label]
    );
  };

  const isActive = (href?: string) => {
    if (!href) return false;
    if (href === "/admin") return location.pathname === "/admin";
    return location.pathname.startsWith(href);
  };

  const isChildActive = (children?: { href: string }[]) => {
    if (!children) return false;
    return children.some((child) => location.pathname === child.href);
  };

  return (
    <aside className="fixed left-0 top-16 bottom-0 w-64 bg-card border-r border-border overflow-y-auto z-40">
      <nav className="p-4 space-y-1">
        {sidebarItems.map((item) => (
          <div key={item.label}>
            {item.href ? (
              <Link
                to={item.href}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isActive(item.href)
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <item.icon className="h-4 w-4 flex-shrink-0" />
                <span>{item.label}</span>
              </Link>
            ) : (
              <>
                <button
                  onClick={() => toggleExpand(item.label)}
                  className={cn(
                    "w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    isChildActive(item.children)
                      ? "text-primary bg-primary/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="h-4 w-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {expandedItems.includes(item.label) ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </button>
                {expandedItems.includes(item.label) && item.children && (
                  <div className="ml-4 mt-1 space-y-1 border-l border-border pl-3">
                    {item.children.map((child) => (
                      <Link
                        key={child.href}
                        to={child.href}
                        className={cn(
                          "flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors",
                          location.pathname === child.href
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground hover:bg-muted"
                        )}
                      >
                        {child.icon && <child.icon className="h-3.5 w-3.5 flex-shrink-0" />}
                        <span>{child.label}</span>
                      </Link>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default AdminSidebar;
