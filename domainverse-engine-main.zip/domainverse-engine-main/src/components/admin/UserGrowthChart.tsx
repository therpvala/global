import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users } from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { format, subDays } from "date-fns";

interface GrowthData {
  date: string;
  users: number;
  cumulative: number;
}

const UserGrowthChart = () => {
  const [data, setData] = useState<GrowthData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserGrowth = async () => {
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();

      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("created_at")
        .gte("created_at", thirtyDaysAgo)
        .order("created_at", { ascending: true });

      if (error) {
        console.error("Error fetching user growth:", error);
        setLoading(false);
        return;
      }

      // Group by day
      const dailyData: Record<string, number> = {};

      // Initialize last 30 days
      for (let i = 29; i >= 0; i--) {
        const date = format(subDays(new Date(), i), "MMM d");
        dailyData[date] = 0;
      }

      // Count new users per day
      profiles?.forEach((p) => {
        const date = format(new Date(p.created_at), "MMM d");
        if (dailyData[date] !== undefined) {
          dailyData[date] += 1;
        }
      });

      // Calculate cumulative
      let cumulative = 0;
      const chartData = Object.entries(dailyData).map(([date, users]) => {
        cumulative += users;
        return {
          date,
          users,
          cumulative,
        };
      });

      setData(chartData);
      setLoading(false);
    };

    fetchUserGrowth();
  }, []);

  const totalNewUsers = data.reduce((sum, d) => sum + d.users, 0);

  return (
    <Card className="border border-border">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center justify-between">
          <span className="flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            User Growth
          </span>
          <span className="text-lg font-bold text-primary">
            +{totalNewUsers} new
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : (
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 10 }}
                  className="text-muted-foreground"
                  tickLine={false}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tick={{ fontSize: 10 }}
                  className="text-muted-foreground"
                  tickLine={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="cumulative"
                  stroke="hsl(var(--primary))"
                  fill="hsl(var(--primary) / 0.2)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default UserGrowthChart;
