import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Globe } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
} from "recharts";

interface CategoryData {
  name: string;
  count: number;
  percent: number;
}

const COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--primary) / 0.8)",
  "hsl(var(--primary) / 0.6)",
  "hsl(var(--primary) / 0.4)",
  "hsl(var(--muted-foreground))",
];

const DomainCategoriesChart = () => {
  const [data, setData] = useState<CategoryData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data: domains, error } = await supabase
        .from("domains")
        .select("category");

      if (error) {
        console.error("Error fetching categories:", error);
        setLoading(false);
        return;
      }

      // Count by category
      const categoryCounts: Record<string, number> = {};
      domains?.forEach((d) => {
        const cat = d.category || "other";
        categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
      });

      const total = domains?.length || 1;
      const chartData = Object.entries(categoryCounts)
        .map(([name, count]) => ({
          name: name.charAt(0).toUpperCase() + name.slice(1),
          count,
          percent: Math.round((count / total) * 100),
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      setData(chartData);
      setLoading(false);
    };

    fetchCategories();
  }, []);

  return (
    <Card className="border border-border">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Globe className="h-4 w-4 text-primary" />
          Domain Categories
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : data.length === 0 ? (
          <div className="h-48 flex items-center justify-center text-muted-foreground">
            No domains found
          </div>
        ) : (
          <div className="space-y-3">
            {data.map((cat, index) => (
              <div key={cat.name}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-foreground">{cat.name}</span>
                  <span className="text-muted-foreground">{cat.count}</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full transition-all duration-500"
                    style={{
                      width: `${cat.percent}%`,
                      backgroundColor: COLORS[index % COLORS.length],
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DomainCategoriesChart;
