import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Activity,
  Globe,
  Gavel,
  DollarSign,
  CheckCircle,
  User,
  Star,
  Clock,
} from "lucide-react";
import { format } from "date-fns";

import type { Json } from "@/integrations/supabase/types";

interface ActivityLog {
  id: string;
  user_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  entity_name: string | null;
  metadata: Json;
  created_at: string;
}

const getActionIcon = (entityType: string) => {
  switch (entityType) {
    case "domain":
      return Globe;
    case "auction":
      return Gavel;
    case "bid":
      return DollarSign;
    case "user":
      return User;
    case "expert":
      return Star;
    case "verification":
      return CheckCircle;
    default:
      return Activity;
  }
};

const getActionColor = (action: string) => {
  if (action.includes("created") || action.includes("added")) return "bg-green-500/10 text-green-600 border-green-500/20";
  if (action.includes("verified") || action.includes("approved")) return "bg-blue-500/10 text-blue-600 border-blue-500/20";
  if (action.includes("sold") || action.includes("purchased")) return "bg-purple-500/10 text-purple-600 border-purple-500/20";
  if (action.includes("bid")) return "bg-orange-500/10 text-orange-600 border-orange-500/20";
  if (action.includes("started")) return "bg-yellow-500/10 text-yellow-600 border-yellow-500/20";
  return "bg-muted text-muted-foreground border-border";
};

const LiveActivityFeed = () => {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch initial activities
    const fetchActivities = async () => {
      const { data, error } = await supabase
        .from("activity_logs")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);

      if (error) {
        console.error("Error fetching activities:", error);
      } else {
        setActivities(data || []);
      }
      setLoading(false);
    };

    fetchActivities();

    // Subscribe to realtime updates
    const channel = supabase
      .channel("activity-logs")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "activity_logs",
        },
        (payload) => {
          setActivities((prev) => [payload.new as ActivityLog, ...prev].slice(0, 50));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <Card className="border border-border">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base font-semibold">
          <Activity className="h-4 w-4 text-primary" />
          Live Activity
          <Badge variant="outline" className="ml-auto text-xs">
            <span className="w-2 h-2 rounded-full bg-green-500 mr-1.5 animate-pulse" />
            Live
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          {loading ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-12 bg-muted/50 rounded animate-pulse" />
              ))}
            </div>
          ) : activities.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No recent activity</p>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {activities.map((activity) => {
                const Icon = getActionIcon(activity.entity_type);
                return (
                  <div
                    key={activity.id}
                    className="px-4 py-3 hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <div className="mt-0.5 p-1.5 rounded bg-muted">
                        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Badge
                            variant="outline"
                            className={`text-xs ${getActionColor(activity.action)}`}
                          >
                            {activity.action}
                          </Badge>
                          {activity.entity_name && (
                            <span className="text-sm font-medium text-foreground truncate">
                              {activity.entity_name}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(activity.created_at), "MMM d, HH:mm:ss")}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default LiveActivityFeed;
