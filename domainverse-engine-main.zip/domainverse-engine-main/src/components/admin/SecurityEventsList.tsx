import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertTriangle, Eye, Shield, Clock } from "lucide-react";
import { format } from "date-fns";
import type { Json } from "@/integrations/supabase/types";

interface SecurityEvent {
  id: string;
  action: string;
  entity_type: string;
  entity_name: string | null;
  created_at: string;
  metadata: Json;
}

const SecurityEventsList = () => {
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSecurityEvents = async () => {
      // Fetch recent activity that might be security-relevant
      const { data, error } = await supabase
        .from("activity_logs")
        .select("*")
        .or("action.ilike.%failed%,action.ilike.%login%,action.ilike.%password%,action.ilike.%role%,action.ilike.%suspicious%,action.ilike.%fraud%")
        .order("created_at", { ascending: false })
        .limit(20);

      if (error) {
        console.error("Error fetching security events:", error);
      } else {
        setEvents(data || []);
      }
      setLoading(false);
    };

    fetchSecurityEvents();

    // Subscribe to realtime security events
    const channel = supabase
      .channel("security-events")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "activity_logs",
        },
        (payload) => {
          const newEvent = payload.new as SecurityEvent;
          // Check if it's security-related
          const securityKeywords = ["failed", "login", "password", "role", "suspicious", "fraud"];
          if (securityKeywords.some((k) => newEvent.action.toLowerCase().includes(k))) {
            setEvents((prev) => [newEvent, ...prev].slice(0, 20));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getEventIcon = (action: string) => {
    if (action.toLowerCase().includes("failed")) return AlertTriangle;
    if (action.toLowerCase().includes("fraud") || action.toLowerCase().includes("suspicious")) return Shield;
    return Eye;
  };

  const getEventColor = (action: string) => {
    if (action.toLowerCase().includes("failed") || action.toLowerCase().includes("fraud")) {
      return "text-yellow-600";
    }
    return "text-blue-600";
  };

  return (
    <Card className="border border-border lg:col-span-2">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-primary" />
          Recent Security Events
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-12 bg-muted/50 rounded animate-pulse" />
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Shield className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No security events detected</p>
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-3">
              {events.map((event) => {
                const Icon = getEventIcon(event.action);
                const colorClass = getEventColor(event.action);
                return (
                  <div
                    key={event.id}
                    className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`h-4 w-4 ${colorClass}`} />
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {event.action}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {event.entity_name || event.entity_type}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(event.created_at), "MMM d, HH:mm")}
                    </span>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};

export default SecurityEventsList;
