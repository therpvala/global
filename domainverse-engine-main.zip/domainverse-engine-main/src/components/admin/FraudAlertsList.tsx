import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  AlertTriangle,
  Shield,
  ShieldAlert,
  ShieldCheck,
  RefreshCw,
  Eye,
  CheckCircle,
  XCircle,
  Sparkles,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

interface FraudAlert {
  id: string;
  auction_id: string | null;
  bid_id: string | null;
  user_id: string | null;
  alert_type: string;
  severity: string;
  confidence_score: number;
  description: string;
  patterns_detected: string[];
  status: string;
  created_at: string;
}

export default function FraudAlertsList() {
  const [alerts, setAlerts] = useState<FraudAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<FraudAlert | null>(null);
  const { toast } = useToast();

  const fetchAlerts = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("fraud_alerts")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) {
      console.error("Error fetching fraud alerts:", error);
    } else {
      setAlerts((data as FraudAlert[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchAlerts();

    // Subscribe to realtime updates
    const channel = supabase
      .channel("fraud_alerts_realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "fraud_alerts" },
        () => fetchAlerts()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const runFraudScan = async () => {
    setScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke("fraud-detection", {
        body: { analyzeAll: false },
      });

      if (error) throw error;

      toast({
        title: "Fraud Scan Complete",
        description: data.summary || `Found ${data.alertsCount || 0} suspicious patterns.`,
      });

      await fetchAlerts();
    } catch (error: any) {
      console.error("Fraud scan error:", error);
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to run fraud detection scan.",
        variant: "destructive",
      });
    } finally {
      setScanning(false);
    }
  };

  const updateAlertStatus = async (alertId: string, status: string) => {
    const { error } = await supabase
      .from("fraud_alerts")
      .update({ status, reviewed_at: new Date().toISOString() })
      .eq("id", alertId);

    if (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update alert status.",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Alert Updated",
        description: `Alert marked as ${status}.`,
      });
      setSelectedAlert(null);
      fetchAlerts();
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <ShieldAlert className="h-4 w-4 text-red-600" />;
      case "high":
        return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      case "medium":
        return <Shield className="h-4 w-4 text-yellow-500" />;
      default:
        return <ShieldCheck className="h-4 w-4 text-blue-500" />;
    }
  };

  const getSeverityBadge = (severity: string) => {
    const colors: Record<string, string> = {
      critical: "bg-red-100 text-red-800 border-red-200",
      high: "bg-orange-100 text-orange-800 border-orange-200",
      medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
      low: "bg-blue-100 text-blue-800 border-blue-200",
    };
    return colors[severity] || colors.low;
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      pending: "bg-gray-100 text-gray-800",
      investigating: "bg-blue-100 text-blue-800",
      confirmed: "bg-red-100 text-red-800",
      dismissed: "bg-green-100 text-green-800",
    };
    return colors[status] || colors.pending;
  };

  const formatAlertType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const pendingCount = alerts.filter((a) => a.status === "pending").length;
  const criticalCount = alerts.filter((a) => a.severity === "critical" && a.status === "pending").length;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Fraud Detection</h2>
          <p className="text-sm text-muted-foreground">
            {pendingCount} pending alerts
            {criticalCount > 0 && ` • ${criticalCount} critical`}
          </p>
        </div>
        <Button onClick={runFraudScan} disabled={scanning} size="sm">
          {scanning ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Scanning...
            </>
          ) : (
            <>
              <Sparkles className="mr-2 h-4 w-4" />
              Run AI Scan
            </>
          )}
        </Button>
      </div>

      {/* Alerts List */}
      {loading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </div>
      ) : alerts.length === 0 ? (
        <Card className="border-border">
          <CardContent className="py-8 text-center">
            <ShieldCheck className="h-12 w-12 text-green-500 mx-auto mb-3" />
            <p className="text-muted-foreground">No fraud alerts detected</p>
            <p className="text-sm text-muted-foreground mt-1">
              Run an AI scan to analyze recent bidding patterns
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {alerts.map((alert) => (
            <Card
              key={alert.id}
              className={`border-border cursor-pointer hover:bg-muted/50 transition-colors ${
                alert.severity === "critical" && alert.status === "pending"
                  ? "border-l-4 border-l-red-500"
                  : ""
              }`}
              onClick={() => setSelectedAlert(alert)}
            >
              <CardContent className="py-3 px-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3">
                    {getSeverityIcon(alert.severity)}
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">
                          {formatAlertType(alert.alert_type)}
                        </span>
                        <Badge className={getSeverityBadge(alert.severity)} variant="outline">
                          {alert.severity}
                        </Badge>
                        <Badge className={getStatusBadge(alert.status)} variant="secondary">
                          {alert.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">
                        {alert.description}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Confidence: {alert.confidence_score}% •{" "}
                        {new Date(alert.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Eye className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Alert Detail Dialog */}
      <Dialog open={!!selectedAlert} onOpenChange={() => setSelectedAlert(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedAlert && getSeverityIcon(selectedAlert.severity)}
              {selectedAlert && formatAlertType(selectedAlert.alert_type)}
            </DialogTitle>
            <DialogDescription>
              Detected {new Date(selectedAlert?.created_at || "").toLocaleString()}
            </DialogDescription>
          </DialogHeader>

          {selectedAlert && (
            <div className="space-y-4">
              <div className="flex gap-2">
                <Badge className={getSeverityBadge(selectedAlert.severity)} variant="outline">
                  {selectedAlert.severity} severity
                </Badge>
                <Badge variant="secondary">
                  {selectedAlert.confidence_score}% confidence
                </Badge>
                <Badge className={getStatusBadge(selectedAlert.status)} variant="secondary">
                  {selectedAlert.status}
                </Badge>
              </div>

              <div>
                <h4 className="text-sm font-medium mb-1">Description</h4>
                <p className="text-sm text-muted-foreground">{selectedAlert.description}</p>
              </div>

              {selectedAlert.patterns_detected?.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2">Patterns Detected</h4>
                  <ul className="space-y-1">
                    {selectedAlert.patterns_detected.map((pattern, i) => (
                      <li key={i} className="text-sm flex items-start gap-2">
                        <AlertTriangle className="h-3.5 w-3.5 mt-0.5 text-yellow-500 flex-shrink-0" />
                        {pattern}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {selectedAlert.auction_id && (
                <div className="text-sm">
                  <span className="text-muted-foreground">Auction ID:</span>{" "}
                  <code className="bg-muted px-1 rounded">{selectedAlert.auction_id}</code>
                </div>
              )}

              {selectedAlert.status === "pending" && (
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    className="flex-1"
                    onClick={() => updateAlertStatus(selectedAlert.id, "confirmed")}
                  >
                    <XCircle className="mr-2 h-4 w-4" />
                    Confirm Fraud
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="flex-1"
                    onClick={() => updateAlertStatus(selectedAlert.id, "dismissed")}
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Dismiss
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
