import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gavel } from "lucide-react";

interface AuctionStats {
  successRate: number;
  avgSalePrice: number;
  avgBidsPerAuction: number;
  avgDuration: number;
}

const AuctionPerformanceChart = () => {
  const [stats, setStats] = useState<AuctionStats>({
    successRate: 0,
    avgSalePrice: 0,
    avgBidsPerAuction: 0,
    avgDuration: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAuctionStats = async () => {
      const [{ data: auctions }, { data: bids }] = await Promise.all([
        supabase.from("auctions").select("id, status, current_bid, start_time, end_time"),
        supabase.from("bids").select("auction_id"),
      ]);

      if (!auctions) {
        setLoading(false);
        return;
      }

      const completedAuctions = auctions.filter((a) => a.status === "completed");
      const totalAuctions = auctions.length;
      
      const successRate = totalAuctions > 0
        ? Math.round((completedAuctions.length / totalAuctions) * 100)
        : 0;

      const avgSalePrice = completedAuctions.length > 0
        ? Math.round(
            completedAuctions.reduce((sum, a) => sum + Number(a.current_bid), 0) /
              completedAuctions.length
          )
        : 0;

      // Count bids per auction
      const bidCounts: Record<string, number> = {};
      bids?.forEach((b) => {
        bidCounts[b.auction_id] = (bidCounts[b.auction_id] || 0) + 1;
      });

      const avgBidsPerAuction = totalAuctions > 0
        ? Math.round(
            Object.values(bidCounts).reduce((sum, c) => sum + c, 0) / totalAuctions
          )
        : 0;

      // Calculate average duration in days
      const durations = auctions
        .filter((a) => a.start_time && a.end_time)
        .map((a) => {
          const start = new Date(a.start_time).getTime();
          const end = new Date(a.end_time).getTime();
          return (end - start) / (1000 * 60 * 60 * 24);
        });

      const avgDuration = durations.length > 0
        ? Math.round(durations.reduce((sum, d) => sum + d, 0) / durations.length * 10) / 10
        : 0;

      setStats({
        successRate,
        avgSalePrice,
        avgBidsPerAuction,
        avgDuration,
      });
      setLoading(false);
    };

    fetchAuctionStats();
  }, []);

  return (
    <Card className="border border-border">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <Gavel className="h-4 w-4 text-primary" />
          Auction Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-32 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-foreground">
                {stats.successRate}%
              </div>
              <div className="text-xs text-muted-foreground">Success Rate</div>
            </div>
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-foreground">
                ${stats.avgSalePrice.toLocaleString()}
              </div>
              <div className="text-xs text-muted-foreground">Avg Sale Price</div>
            </div>
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-foreground">
                {stats.avgBidsPerAuction}
              </div>
              <div className="text-xs text-muted-foreground">Avg Bids/Auction</div>
            </div>
            <div className="text-center p-4 bg-muted/30 rounded-lg">
              <div className="text-2xl font-bold text-foreground">
                {stats.avgDuration} days
              </div>
              <div className="text-xs text-muted-foreground">Avg Duration</div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AuctionPerformanceChart;
