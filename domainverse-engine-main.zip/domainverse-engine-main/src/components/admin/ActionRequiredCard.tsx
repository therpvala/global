import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  AlertTriangle,
  Clock,
  Shield,
  DollarSign,
  ArrowRight,
} from "lucide-react";

interface ActionItem {
  id: string;
  title: string;
  description: string;
  type: "urgent" | "warning" | "info";
  link: string;
  count?: number;
}

interface ActionRequiredCardProps {
  items: ActionItem[];
}

const getTypeStyles = (type: ActionItem["type"]) => {
  switch (type) {
    case "urgent":
      return {
        badge: "bg-red-500/10 text-red-600 border-red-500/20",
        icon: AlertTriangle,
      };
    case "warning":
      return {
        badge: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20",
        icon: Clock,
      };
    case "info":
      return {
        badge: "bg-blue-500/10 text-blue-600 border-blue-500/20",
        icon: Shield,
      };
  }
};

const ActionRequiredCard = ({ items }: ActionRequiredCardProps) => {
  if (items.length === 0) {
    return (
      <Card className="border border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-base font-semibold flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            Action Required
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground">
            <Shield className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No pending actions</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-base font-semibold flex items-center gap-2">
          <AlertTriangle className="h-4 w-4 text-primary" />
          Action Required
          <Badge variant="secondary" className="ml-auto">
            {items.length}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {items.map((item) => {
          const styles = getTypeStyles(item.type);
          const Icon = styles.icon;
          return (
            <div
              key={item.id}
              className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="p-2 rounded bg-muted">
                <Icon className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm text-foreground">
                    {item.title}
                  </span>
                  {item.count && (
                    <Badge variant="outline" className={styles.badge}>
                      {item.count}
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground truncate">
                  {item.description}
                </p>
              </div>
              <Button variant="ghost" size="sm" asChild>
                <Link to={item.link}>
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
};

export default ActionRequiredCard;
