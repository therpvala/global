import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { format, subDays, startOfDay, endOfDay } from "date-fns";

interface RevenueData {
  date: string;
  revenue: number;
  transactions: number;
}

const RevenueChart = () => {
  const [data, setData] = useState<RevenueData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRevenue = async () => {
      // Get transactions from the last 30 days
      const thirtyDaysAgo = subDays(new Date(), 30).toISOString();

      const { data: transactions, error } = await supabase
        .from("transactions")
        .select("amount, type, created_at")
        .gte("created_at", thirtyDaysAgo)
        .in("type", ["sale", "purchase"]);

      if (error) {
        console.error("Error fetching revenue:", error);
        setLoading(false);
        return;
      }

      // Group by day
      const dailyData: Record<string, { revenue: number; transactions: number }> = {};

      // Initialize last 30 days
      for (let i = 29; i >= 0; i--) {
        const date = format(subDays(new Date(), i), "MMM d");
        dailyData[date] = { revenue: 0, transactions: 0 };
      }

      // Aggregate transactions
      transactions?.forEach((t) => {
        const date = format(new Date(t.created_at), "MMM d");
        if (dailyData[date]) {
          // Platform takes 5% commission
          dailyData[date].revenue += Number(t.amount) * 0.05;
          dailyData[date].transactions += 1;
        }
      });

      const chartData = Object.entries(dailyData).map(([date, values]) => ({
        date,
        revenue: Math.round(values.revenue),
        transactions: values.transactions,
      }));

      setData(chartData);
      setLoading(false);
    };

    fetchRevenue();
  }, []);

  const totalRevenue = data.reduce((sum, d) => sum + d.revenue, 0);

  return (
    <Card className="border border-border">
      <CardHeader>
        <CardTitle className="text-base font-semibold flex items-center justify-between">
          <span className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            Revenue Overview
          </span>
          <span className="text-lg font-bold text-primary">
            ${totalRevenue.toLocaleString()}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-48 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        ) : (
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  tick={{ fontSize: 10 }}
                  className="text-muted-foreground"
                  tickLine={false}
                  interval="preserveStartEnd"
                />
                <YAxis
                  tick={{ fontSize: 10 }}
                  className="text-muted-foreground"
                  tickLine={false}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                  formatter={(value: number) => [`$${value}`, "Revenue"]}
                />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default RevenueChart;
