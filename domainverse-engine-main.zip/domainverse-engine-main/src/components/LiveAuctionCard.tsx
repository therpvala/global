import { Clock, TrendingUp, Users, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface AuctionCardProps {
  domain: string;
  currentBid: number;
  bidders: number;
  timeLeft?: string;
  endTime?: string;
  category: string;
  isHot?: boolean;
}

const LiveAuctionCard = ({
  domain,
  currentBid,
  bidders,
  timeLeft,
  endTime,
  category,
  isHot = false,
}: AuctionCardProps) => {
  const [countdown, setCountdown] = useState<string>(timeLeft || '');

  useEffect(() => {
    if (!endTime) {
      setCountdown(timeLeft || '');
      return;
    }

    const calculateTimeLeft = () => {
      const end = new Date(endTime);
      const now = new Date();
      const diff = end.getTime() - now.getTime();

      if (diff <= 0) return 'Ended';

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      if (days > 0) return `${days}d ${hours}h ${minutes}m`;
      if (hours > 0) return `${hours}h ${minutes}m ${seconds}s`;
      return `${minutes}m ${seconds}s`;
    };

    setCountdown(calculateTimeLeft());

    const interval = setInterval(() => {
      setCountdown(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(interval);
  }, [endTime, timeLeft]);

  const isEnding = endTime && new Date(endTime).getTime() - new Date().getTime() < 1000 * 60 * 60; // Less than 1 hour

  return (
    <div className="group relative glass rounded-2xl p-6 hover:shadow-elevated transition-all duration-300 hover:-translate-y-1 overflow-hidden">
      {/* Hot Badge */}
      {isHot && (
        <div className="absolute top-4 right-4 flex items-center gap-1 px-2 py-1 rounded-full bg-destructive/10 text-destructive text-xs font-medium">
          <Flame className="h-3 w-3" />
          Hot
        </div>
      )}

      {/* Category Badge */}
      <span className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-4">
        {category}
      </span>

      {/* Domain Name */}
      <h3 className="font-display text-xl md:text-2xl font-bold text-foreground mb-4 group-hover:text-primary transition-colors">
        {domain}
      </h3>

      {/* Stats */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Current Bid</span>
          <span className="flex items-center gap-1 font-display text-lg font-bold text-foreground">
            <TrendingUp className="h-4 w-4 text-accent" />
            ${currentBid.toLocaleString()}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Bidders</span>
          <span className="flex items-center gap-1 text-sm font-medium text-foreground">
            <Users className="h-4 w-4 text-primary" />
            {bidders}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Time Left</span>
          <span className={`flex items-center gap-1 text-sm font-medium ${isEnding ? 'text-destructive animate-pulse' : 'text-destructive'}`}>
            <Clock className={`h-4 w-4 ${isEnding ? 'animate-pulse' : ''}`} />
            {countdown}
          </span>
        </div>
      </div>

      {/* Bid Button */}
      <Button variant="hero" className="w-full">
        Place Bid
      </Button>

      {/* Animated Border on Hover */}
      <div className="absolute inset-0 rounded-2xl border-2 border-transparent group-hover:border-primary/30 transition-colors duration-300 pointer-events-none" />
    </div>
  );
};

export default LiveAuctionCard;
