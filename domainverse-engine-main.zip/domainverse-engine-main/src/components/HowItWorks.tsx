import { Plus, MousePointer, Banknote } from "lucide-react";

const steps = [
  {
    icon: Plus,
    step: "1",
    title: "Add Domain",
    description: "Enter your domain name",
  },
  {
    icon: MousePointer,
    step: "2",
    title: "Choose Action",
    description: "Sell, Park, or Auction",
  },
  {
    icon: Banknote,
    step: "3",
    title: "Get Paid",
    description: "Automatic payouts",
  },
];

const HowItWorks = () => {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="font-display text-2xl md:text-3xl font-bold text-center text-foreground mb-12">
          How It Works
        </h2>
        <div className="flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16 max-w-3xl mx-auto">
          {steps.map((item, index) => (
            <div key={item.step} className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center">
                  <item.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <span className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-foreground text-background text-sm font-bold flex items-center justify-center">
                  {item.step}
                </span>
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-1">
                {item.title}
              </h3>
              <p className="text-sm text-muted-foreground">{item.description}</p>
              
              {/* Connector line for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute">
                  {/* Line handled by flex gap */}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
