import { Link } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Globe, X, ShoppingCart, Calendar, DollarSign, Tag, FileText, ShieldCheck, AlertTriangle, Clock, Activity } from "lucide-react";
import { format } from "date-fns";
import DomainHealthScore from "@/components/DomainHealthScore";

interface Domain {
  id: string;
  title: string;
  domain_name: string;
  description: string | null;
  price: number;
  status: string;
  created_at: string;
  user_id: string;
  category: string;
  expiration_date: string | null;
}

interface DomainCompareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  domains: Domain[];
  onRemove: (id: string) => void;
  onPurchase: (domain: Domain) => void;
  currentUserId?: string;
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(price);
};

const isExpiringSoon = (expirationDate: string | null) => {
  if (!expirationDate) return false;
  const expiry = new Date(expirationDate);
  const now = new Date();
  const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  return daysUntilExpiry <= 30 && daysUntilExpiry > 0;
};

const getDaysUntilExpiry = (expirationDate: string | null) => {
  if (!expirationDate) return null;
  const expiry = new Date(expirationDate);
  const now = new Date();
  return Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
};

const DomainCompareDialog = ({
  open,
  onOpenChange,
  domains,
  onRemove,
  onPurchase,
  currentUserId,
}: DomainCompareDialogProps) => {
  if (domains.length === 0) return null;

  const comparisonRows = [
    {
      label: "Domain Name",
      icon: <Globe className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <Link to={`/domain/${d.id}`} className="text-primary hover:underline font-semibold">
          {d.domain_name}
        </Link>
      ),
    },
    {
      label: "Verification",
      icon: <ShieldCheck className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <div className="flex flex-wrap gap-1">
          {d.expiration_date ? (
            <Badge variant="outline" className="gap-1 text-green-600 border-green-600/50 bg-green-500/10">
              <ShieldCheck className="h-3 w-3" />
              Verified
            </Badge>
          ) : (
            <span className="text-sm text-muted-foreground">Not verified</span>
          )}
          {isExpiringSoon(d.expiration_date) && (
            <Badge variant="destructive" className="gap-1">
              <AlertTriangle className="h-3 w-3" />
              {getDaysUntilExpiry(d.expiration_date)}d left
            </Badge>
          )}
        </div>
      ),
    },
    {
      label: "Price",
      icon: <DollarSign className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <span className="text-xl font-bold text-primary">{formatPrice(d.price)}</span>
      ),
    },
    {
      label: "Expires",
      icon: <Clock className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <span className={`text-sm ${isExpiringSoon(d.expiration_date) ? "text-destructive font-medium" : "text-muted-foreground"}`}>
          {d.expiration_date 
            ? format(new Date(d.expiration_date), "MMM d, yyyy")
            : "Unknown"}
        </span>
      ),
    },
    {
      label: "Health Score",
      icon: <Activity className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <DomainHealthScore expirationDate={d.expiration_date} variant="compact" className="w-full max-w-[120px]" />
      ),
    },
    {
      label: "Category",
      icon: <Tag className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <Badge variant="secondary" className="capitalize">
          {d.category}
        </Badge>
      ),
    },
    {
      label: "Description",
      icon: <FileText className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <p className="text-sm text-muted-foreground line-clamp-4">
          {d.description || "No description provided"}
        </p>
      ),
    },
    {
      label: "Listed",
      icon: <Calendar className="h-4 w-4" />,
      getValue: (d: Domain) => (
        <span className="text-sm text-muted-foreground">
          {format(new Date(d.created_at), "MMM d, yyyy")}
        </span>
      ),
    },
  ];

  // Find the lowest and highest price for highlighting
  const prices = domains.map((d) => d.price);
  const lowestPrice = Math.min(...prices);
  const highestPrice = Math.max(...prices);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Compare Domains ({domains.length})
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="w-full">
          <div className="min-w-max">
            {/* Header Row with Domain Titles */}
            <div className="grid gap-4" style={{ gridTemplateColumns: `180px repeat(${domains.length}, minmax(200px, 1fr))` }}>
              <div className="p-4 font-semibold text-muted-foreground">Domain</div>
              {domains.map((domain) => (
                <div
                  key={domain.id}
                  className="p-4 bg-muted/50 rounded-lg relative"
                >
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-1 right-1 h-6 w-6"
                    onClick={() => onRemove(domain.id)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                  <h3 className="font-semibold pr-6 line-clamp-2">{domain.title}</h3>
                  {domain.price === lowestPrice && domains.length > 1 && (
                    <Badge className="mt-2 bg-green-500/10 text-green-600 hover:bg-green-500/20">
                      Lowest Price
                    </Badge>
                  )}
                  {domain.price === highestPrice && domains.length > 1 && lowestPrice !== highestPrice && (
                    <Badge className="mt-2 bg-orange-500/10 text-orange-600 hover:bg-orange-500/20">
                      Highest Price
                    </Badge>
                  )}
                </div>
              ))}
            </div>

            {/* Comparison Rows */}
            {comparisonRows.map((row, index) => (
              <div
                key={row.label}
                className="grid gap-4 border-t"
                style={{ gridTemplateColumns: `180px repeat(${domains.length}, minmax(200px, 1fr))` }}
              >
                <div className="p-4 flex items-center gap-2 text-muted-foreground">
                  {row.icon}
                  <span className="font-medium">{row.label}</span>
                </div>
                {domains.map((domain) => (
                  <div key={domain.id} className="p-4 flex items-center">
                    {row.getValue(domain)}
                  </div>
                ))}
              </div>
            ))}

            {/* Action Row */}
            <div
              className="grid gap-4 border-t pt-4"
              style={{ gridTemplateColumns: `180px repeat(${domains.length}, minmax(200px, 1fr))` }}
            >
              <div className="p-4 flex items-center text-muted-foreground font-medium">
                Actions
              </div>
              {domains.map((domain) => (
                <div key={domain.id} className="p-4 flex flex-col gap-2">
                  <Button variant="outline" size="sm" asChild>
                    <Link to={`/domain/${domain.id}`}>View Details</Link>
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => onPurchase(domain)}
                    disabled={currentUserId === domain.user_id}
                  >
                    <ShoppingCart className="mr-2 h-4 w-4" />
                    {currentUserId === domain.user_id ? "Your Domain" : "Buy Now"}
                  </Button>
                </div>
              ))}
            </div>
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};

export default DomainCompareDialog;
