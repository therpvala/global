import { ShieldCheck, Lock, Bot, Globe } from "lucide-react";

const signals = [
  {
    icon: ShieldCheck,
    label: "Verified Ownership",
  },
  {
    icon: Lock,
    label: "Secure Escrow",
  },
  {
    icon: Bot,
    label: "AI Valuation",
  },
  {
    icon: Globe,
    label: "Global Buyers",
  },
];

const TrustSignals = () => {
  return (
    <section className="py-8 border-t border-b border-border bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
          {signals.map((signal) => (
            <div
              key={signal.label}
              className="flex items-center gap-2 text-muted-foreground"
            >
              <signal.icon className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">{signal.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSignals;
