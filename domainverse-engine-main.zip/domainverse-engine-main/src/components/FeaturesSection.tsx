import { Link } from "react-router-dom";
import { DollarSign, ParkingSquare, Gavel, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  {
    icon: DollarSign,
    title: "Domain Reselling",
    description: "Fast sale to global buyers",
    href: "/add-domain",
    cta: "Start Selling",
  },
  {
    icon: ParkingSquare,
    title: "Domain Parking",
    description: "Earn passive income monthly",
    href: "/parking",
    cta: "Start Parking",
  },
  {
    icon: Gavel,
    title: "Domain Auctions",
    description: "Get maximum value",
    href: "/auctions",
    cta: "Start Auction",
  },
];

const FeaturesSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="border border-border rounded-lg p-6 text-center hover:border-primary transition-colors"
            >
              <div className="inline-flex p-3 rounded-full bg-primary/10 mb-4">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {feature.description}
              </p>
              <Button variant="outline" size="sm" asChild>
                <Link to={feature.href}>
                  {feature.cta}
                  <ArrowRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
