import logoImage from "@/assets/softwarevala-logo.jpg";

interface LogoProps {
  className?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg";
}

const Logo = ({ className = "", showText = true, size = "md" }: LogoProps) => {
  const sizeClasses = {
    sm: "h-[40px] w-[40px]",
    md: "h-[48px] w-[48px]",
    lg: "h-[52px] w-[52px]",
  };

  return (
    <div className={`flex items-center gap-2 p-2 ${className}`}>
      <img 
        src={logoImage} 
        alt="DomainVala by Software Vala" 
        className={`${sizeClasses[size]} object-cover rounded-full`}
      />
      {showText && (
        <div className="flex flex-col justify-center">
          <span className="font-semibold text-base text-foreground leading-tight">
            Domain<span className="text-primary">Vala</span>
          </span>
          <span className="text-[10px] text-muted-foreground/65 font-medium leading-tight">
            Powered by Software Vala
          </span>
        </div>
      )}
    </div>
  );
};

export default Logo;
