import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MessageSquare, DollarSign } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";

interface MakeOfferDialogProps {
  domainId: string;
  domainName: string;
  sellerId: string;
  listingPrice: number;
  onOfferSent?: () => void;
}

const MakeOfferDialog = ({ domainId, domainName, sellerId, listingPrice, onOfferSent }: MakeOfferDialogProps) => {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error("Please login to make an offer");
      return;
    }

    if (user.id === sellerId) {
      toast.error("You cannot make an offer on your own domain");
      return;
    }

    const offerAmount = parseFloat(amount);
    if (isNaN(offerAmount) || offerAmount <= 0) {
      toast.error("Please enter a valid offer amount");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from('offers').insert({
        domain_id: domainId,
        buyer_id: user.id,
        seller_id: sellerId,
        amount: offerAmount,
        message: message.trim() || null,
      });

      if (error) throw error;

      toast.success("Offer sent successfully!");
      setOpen(false);
      setAmount("");
      setMessage("");
      onOfferSent?.();
    } catch (error: any) {
      console.error("Error sending offer:", error);
      toast.error(error.message || "Failed to send offer");
    } finally {
      setLoading(false);
    }
  };

  if (!user || user.id === sellerId) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <MessageSquare className="h-4 w-4" />
          Make Offer
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Make an Offer</DialogTitle>
          <DialogDescription>
            Send a negotiation offer for <span className="font-semibold text-foreground">{domainName}</span>
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Listing Price</Label>
            <p className="text-2xl font-bold text-primary">${listingPrice.toLocaleString()}</p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="amount">Your Offer</Label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="amount"
                type="number"
                placeholder="Enter your offer amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="pl-9"
                min="1"
                step="0.01"
                required
              />
            </div>
            {amount && parseFloat(amount) < listingPrice && (
              <p className="text-xs text-muted-foreground">
                {Math.round((1 - parseFloat(amount) / listingPrice) * 100)}% below listing price
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message (Optional)</Label>
            <Textarea
              id="message"
              placeholder="Add a message to the seller..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={500}
              rows={3}
            />
            <p className="text-xs text-muted-foreground text-right">{message.length}/500</p>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Sending..." : "Send Offer"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default MakeOfferDialog;
