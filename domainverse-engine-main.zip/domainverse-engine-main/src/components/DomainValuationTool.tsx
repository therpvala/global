import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Sparkles,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Target,
  Star,
  Lightbulb,
  Search,
} from "lucide-react";

interface ValuationResult {
  estimatedValue: {
    low: number;
    mid: number;
    high: number;
  };
  positiveFactors: string[];
  negativeFactors: string[];
  targetIndustries: string[];
  brandabilityScore: number;
  investmentPotential: "low" | "medium" | "high";
  sellingStrategy: string;
  summary: string;
}

export default function DomainValuationTool() {
  const [domainName, setDomainName] = useState("");
  const [loading, setLoading] = useState(false);
  const [valuation, setValuation] = useState<ValuationResult | null>(null);
  const { toast } = useToast();

  const handleValuate = async () => {
    if (!domainName.trim()) {
      toast({
        title: "Domain Required",
        description: "Please enter a domain name to valuate.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setValuation(null);

    try {
      const { data, error } = await supabase.functions.invoke("domain-valuation", {
        body: { domainName: domainName.trim().toLowerCase() },
      });

      if (error) throw error;

      if (data?.valuation) {
        setValuation(data.valuation);
        toast({
          title: "Valuation Complete",
          description: `AI analysis for ${domainName} is ready.`,
        });
      }
    } catch (error: any) {
      console.error("Valuation error:", error);
      toast({
        title: "Valuation Failed",
        description: error.message || "Failed to valuate domain. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getInvestmentColor = (potential: string) => {
    switch (potential) {
      case "high":
        return "bg-green-100 text-green-800 border-green-200";
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <div className="space-y-6">
      {/* Search Input */}
      <Card className="border-border">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-5 w-5 text-primary" />
            AI Domain Valuation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Enter domain name (e.g., techstartup.com)"
                value={domainName}
                onChange={(e) => setDomainName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleValuate()}
                className="pl-10"
              />
            </div>
            <Button onClick={handleValuate} disabled={loading}>
              {loading ? "Analyzing..." : "Valuate"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {loading && (
        <Card className="border-border">
          <CardContent className="pt-6 space-y-4">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-24 w-full" />
            <div className="grid grid-cols-3 gap-4">
              <Skeleton className="h-20" />
              <Skeleton className="h-20" />
              <Skeleton className="h-20" />
            </div>
            <Skeleton className="h-32 w-full" />
          </CardContent>
        </Card>
      )}

      {/* Results */}
      {valuation && !loading && (
        <div className="space-y-4">
          {/* Value Estimate */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <DollarSign className="h-4 w-4" />
                Estimated Value
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Low</p>
                  <p className="text-lg font-semibold">{formatCurrency(valuation.estimatedValue.low)}</p>
                </div>
                <div className="text-center p-3 bg-primary/10 rounded-lg border-2 border-primary/20">
                  <p className="text-xs text-muted-foreground mb-1">Mid (Recommended)</p>
                  <p className="text-xl font-bold text-primary">{formatCurrency(valuation.estimatedValue.mid)}</p>
                </div>
                <div className="text-center p-3 bg-muted/50 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">High</p>
                  <p className="text-lg font-semibold">{formatCurrency(valuation.estimatedValue.high)}</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{valuation.summary}</p>
            </CardContent>
          </Card>

          {/* Scores Row */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="border-border">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Star className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm font-medium">Brandability</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-2xl font-bold">{valuation.brandabilityScore}</span>
                    <span className="text-sm text-muted-foreground">/10</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-border">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    <span className="text-sm font-medium">Investment</span>
                  </div>
                  <Badge className={getInvestmentColor(valuation.investmentPotential)}>
                    {valuation.investmentPotential.toUpperCase()}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Factors */}
          <div className="grid grid-cols-2 gap-4">
            <Card className="border-border">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm text-green-700">
                  <TrendingUp className="h-4 w-4" />
                  Positive Factors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {valuation.positiveFactors.map((factor, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-green-500 mt-0.5">+</span>
                      {factor}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
            <Card className="border-border">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-sm text-red-700">
                  <TrendingDown className="h-4 w-4" />
                  Negative Factors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-1">
                  {valuation.negativeFactors.map((factor, i) => (
                    <li key={i} className="text-sm flex items-start gap-2">
                      <span className="text-red-500 mt-0.5">−</span>
                      {factor}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Target Industries */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Target className="h-4 w-4" />
                Target Industries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {valuation.targetIndustries.map((industry, i) => (
                  <Badge key={i} variant="secondary">
                    {industry}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Selling Strategy */}
          <Card className="border-border">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Lightbulb className="h-4 w-4 text-yellow-500" />
                Recommended Selling Strategy
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">{valuation.sellingStrategy}</p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
