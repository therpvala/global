import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, CheckCircle, XCircle, Globe, Calendar, Building } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface WhoisResult {
  available: boolean;
  domainName: string;
  registrar?: string;
  createdDate?: string;
  expiresDate?: string;
  registrant?: {
    organization?: string;
    country?: string;
  };
  error?: string;
}

interface DomainVerificationProps {
  domain: string;
  onVerified?: (result: WhoisResult) => void;
}

export const DomainVerification = ({ domain, onVerified }: DomainVerificationProps) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WhoisResult | null>(null);

  const handleVerify = async () => {
    if (!domain.trim()) {
      toast.error("Please enter a domain name first");
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('whois-lookup', {
        body: { domain: domain.trim().toLowerCase() }
      });

      if (error) {
        toast.error("Failed to verify domain");
        console.error('WHOIS lookup error:', error);
        return;
      }

      if (data.error) {
        toast.error(data.error);
        return;
      }

      setResult(data);
      onVerified?.(data);
      
      if (data.available) {
        toast.warning("This domain appears to be available for registration, not owned");
      } else {
        toast.success("Domain ownership verified");
      }
    } catch (err) {
      toast.error("An error occurred during verification");
      console.error('WHOIS lookup error:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Button 
          type="button" 
          variant="outline" 
          onClick={handleVerify} 
          disabled={loading || !domain.trim()}
          className="gap-2"
        >
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Search className="h-4 w-4" />
          )}
          Verify Ownership
        </Button>
        {result && (
          result.available ? (
            <Badge variant="destructive" className="gap-1">
              <XCircle className="h-3 w-3" />
              Not Registered
            </Badge>
          ) : (
            <Badge className="bg-green-500 hover:bg-green-600 gap-1">
              <CheckCircle className="h-3 w-3" />
              Registered
            </Badge>
          )
        )}
      </div>

      {result && !result.available && (
        <div className="rounded-lg border bg-muted/50 p-3 space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <Globe className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{result.domainName}</span>
          </div>
          <div className="grid gap-2 text-sm md:grid-cols-2">
            {result.registrar && (
              <div className="flex items-center gap-2">
                <Building className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">{result.registrar}</span>
              </div>
            )}
            {result.expiresDate && (
              <div className="flex items-center gap-2">
                <Calendar className="h-3 w-3 text-muted-foreground" />
                <span className="text-muted-foreground">Expires: {formatDate(result.expiresDate)}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {result?.available && (
        <p className="text-sm text-amber-600">
          ⚠️ This domain appears unregistered. You should only list domains you own.
        </p>
      )}
    </div>
  );
};
