import { Link } from "react-router-dom";

const footerLinks = [
  { name: "About", href: "/about" },
  { name: "Support", href: "/support" },
  { name: "Legal", href: "/legal" },
  { name: "API", href: "/api" },
  { name: "Contact", href: "/contact" },
];

const Footer = () => {
  return (
    <footer className="bg-muted py-10 border-t border-border">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-foreground">
              Domain<span className="text-primary">Vala</span>
            </span>
          </div>

          {/* Links */}
          <nav className="flex flex-wrap justify-center gap-6">
            {footerLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} DomainVala
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
