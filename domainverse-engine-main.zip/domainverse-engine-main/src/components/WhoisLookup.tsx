import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Search, CheckCircle, XCircle, Globe, Calendar, Server, Building } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface WhoisResult {
  available: boolean;
  domainName: string;
  registrar?: string;
  createdDate?: string;
  expiresDate?: string;
  updatedDate?: string;
  registrant?: {
    organization?: string;
    country?: string;
  };
  nameServers?: string[];
  status?: string[];
  error?: string;
}

export const WhoisLookup = () => {
  const [domain, setDomain] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WhoisResult | null>(null);

  const handleLookup = async () => {
    if (!domain.trim()) {
      toast.error("Please enter a domain name");
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke('whois-lookup', {
        body: { domain: domain.trim().toLowerCase() }
      });

      if (error) {
        toast.error("Failed to lookup domain");
        console.error('WHOIS lookup error:', error);
        return;
      }

      if (data.error) {
        toast.error(data.error);
        return;
      }

      setResult(data);
    } catch (err) {
      toast.error("An error occurred during lookup");
      console.error('WHOIS lookup error:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return "N/A";
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch {
      return dateString;
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="h-5 w-5" />
          Domain WHOIS Lookup
        </CardTitle>
        <CardDescription>
          Check domain availability and registration details
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex gap-2">
          <Input
            placeholder="Enter domain name (e.g., example.com)"
            value={domain}
            onChange={(e) => setDomain(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleLookup()}
            disabled={loading}
          />
          <Button onClick={handleLookup} disabled={loading}>
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Search className="h-4 w-4" />
            )}
            <span className="ml-2">Lookup</span>
          </Button>
        </div>

        {result && (
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-semibold">{result.domainName}</h3>
              {result.available ? (
                <Badge className="bg-green-500 hover:bg-green-600">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Available
                </Badge>
              ) : (
                <Badge variant="destructive">
                  <XCircle className="h-3 w-3 mr-1" />
                  Registered
                </Badge>
              )}
            </div>

            {!result.available && (
              <div className="grid gap-4 md:grid-cols-2">
                {result.registrar && (
                  <div className="flex items-start gap-2">
                    <Building className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Registrar</p>
                      <p className="text-sm text-muted-foreground">{result.registrar}</p>
                    </div>
                  </div>
                )}

                {result.createdDate && (
                  <div className="flex items-start gap-2">
                    <Calendar className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Created</p>
                      <p className="text-sm text-muted-foreground">{formatDate(result.createdDate)}</p>
                    </div>
                  </div>
                )}

                {result.expiresDate && (
                  <div className="flex items-start gap-2">
                    <Calendar className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Expires</p>
                      <p className="text-sm text-muted-foreground">{formatDate(result.expiresDate)}</p>
                    </div>
                  </div>
                )}

                {result.registrant?.organization && (
                  <div className="flex items-start gap-2">
                    <Building className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Organization</p>
                      <p className="text-sm text-muted-foreground">
                        {result.registrant.organization}
                        {result.registrant.country && ` (${result.registrant.country})`}
                      </p>
                    </div>
                  </div>
                )}

                {result.nameServers && result.nameServers.length > 0 && (
                  <div className="flex items-start gap-2 md:col-span-2">
                    <Server className="h-4 w-4 mt-1 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Name Servers</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {result.nameServers.slice(0, 4).map((ns, i) => (
                          <Badge key={i} variant="secondary" className="text-xs">
                            {ns}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {result.available && (
              <p className="text-sm text-muted-foreground">
                This domain appears to be available for registration!
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
