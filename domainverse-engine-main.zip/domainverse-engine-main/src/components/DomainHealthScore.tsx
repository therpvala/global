import { ShieldCheck, ShieldX, Clock, AlertTriangle, CheckCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface DomainHealthScoreProps {
  expirationDate: string | null;
  variant?: "full" | "compact" | "badge";
  className?: string;
}

interface HealthScoreResult {
  score: number;
  label: string;
  color: string;
  bgColor: string;
  factors: {
    name: string;
    points: number;
    maxPoints: number;
    status: "good" | "warning" | "danger" | "neutral";
  }[];
}

const calculateHealthScore = (expirationDate: string | null): HealthScoreResult => {
  const factors: HealthScoreResult["factors"] = [];
  let totalScore = 0;

  // Verification status (50 points max)
  if (expirationDate) {
    factors.push({
      name: "WHOIS Verified",
      points: 50,
      maxPoints: 50,
      status: "good",
    });
    totalScore += 50;
  } else {
    factors.push({
      name: "Not Verified",
      points: 0,
      maxPoints: 50,
      status: "neutral",
    });
  }

  // Expiration date health (50 points max)
  if (expirationDate) {
    const expiry = new Date(expirationDate);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntilExpiry > 365) {
      factors.push({
        name: "Expires in 1+ year",
        points: 50,
        maxPoints: 50,
        status: "good",
      });
      totalScore += 50;
    } else if (daysUntilExpiry > 180) {
      factors.push({
        name: "Expires in 6-12 months",
        points: 35,
        maxPoints: 50,
        status: "good",
      });
      totalScore += 35;
    } else if (daysUntilExpiry > 30) {
      factors.push({
        name: "Expires in 1-6 months",
        points: 20,
        maxPoints: 50,
        status: "warning",
      });
      totalScore += 20;
    } else if (daysUntilExpiry > 0) {
      factors.push({
        name: `Expires in ${daysUntilExpiry} days`,
        points: 5,
        maxPoints: 50,
        status: "danger",
      });
      totalScore += 5;
    } else {
      factors.push({
        name: "Domain expired",
        points: 0,
        maxPoints: 50,
        status: "danger",
      });
    }
  } else {
    factors.push({
      name: "Expiration unknown",
      points: 0,
      maxPoints: 50,
      status: "neutral",
    });
  }

  // Determine label and colors based on score
  let label: string;
  let color: string;
  let bgColor: string;

  if (totalScore >= 80) {
    label = "Excellent";
    color = "text-green-600";
    bgColor = "bg-green-500";
  } else if (totalScore >= 60) {
    label = "Good";
    color = "text-emerald-600";
    bgColor = "bg-emerald-500";
  } else if (totalScore >= 40) {
    label = "Fair";
    color = "text-amber-600";
    bgColor = "bg-amber-500";
  } else if (totalScore >= 20) {
    label = "Poor";
    color = "text-orange-600";
    bgColor = "bg-orange-500";
  } else {
    label = "Unknown";
    color = "text-muted-foreground";
    bgColor = "bg-muted";
  }

  return { score: totalScore, label, color, bgColor, factors };
};

const DomainHealthScore = ({ expirationDate, variant = "full", className }: DomainHealthScoreProps) => {
  const { score, label, color, bgColor, factors } = calculateHealthScore(expirationDate);

  if (variant === "badge") {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={cn("inline-flex items-center gap-1.5 px-2 py-1 rounded-full text-xs font-medium border", className, {
              "bg-green-500/10 text-green-600 border-green-500/30": score >= 80,
              "bg-emerald-500/10 text-emerald-600 border-emerald-500/30": score >= 60 && score < 80,
              "bg-amber-500/10 text-amber-600 border-amber-500/30": score >= 40 && score < 60,
              "bg-orange-500/10 text-orange-600 border-orange-500/30": score >= 20 && score < 40,
              "bg-muted text-muted-foreground border-border": score < 20,
            })}>
              {score >= 60 ? (
                <CheckCircle className="h-3 w-3" />
              ) : score >= 40 ? (
                <AlertTriangle className="h-3 w-3" />
              ) : (
                <ShieldX className="h-3 w-3" />
              )}
              {score}/100
            </div>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs">
            <div className="space-y-2">
              <p className="font-semibold">Domain Health: {label}</p>
              {factors.map((factor, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs gap-4">
                  <span>{factor.name}</span>
                  <span className="font-mono">{factor.points}/{factor.maxPoints}</span>
                </div>
              ))}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  if (variant === "compact") {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={cn("flex items-center gap-2", className)}>
              <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={cn("h-full rounded-full transition-all", bgColor)}
                  style={{ width: `${score}%` }}
                />
              </div>
              <span className={cn("text-sm font-semibold tabular-nums", color)}>{score}</span>
            </div>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs">
            <div className="space-y-2">
              <p className="font-semibold">Domain Health: {label}</p>
              {factors.map((factor, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs gap-4">
                  <span>{factor.name}</span>
                  <span className="font-mono">{factor.points}/{factor.maxPoints}</span>
                </div>
              ))}
            </div>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  // Full variant
  return (
    <div className={cn("p-4 rounded-lg border bg-card", className)}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {score >= 60 ? (
            <ShieldCheck className="h-5 w-5 text-green-600" />
          ) : score >= 40 ? (
            <AlertTriangle className="h-5 w-5 text-amber-600" />
          ) : (
            <ShieldX className="h-5 w-5 text-muted-foreground" />
          )}
          <span className="font-semibold">Domain Health</span>
        </div>
        <div className={cn("text-2xl font-bold tabular-nums", color)}>
          {score}<span className="text-sm text-muted-foreground">/100</span>
        </div>
      </div>

      <Progress value={score} className="h-2 mb-3" />

      <p className={cn("text-sm font-medium mb-4", color)}>{label}</p>

      <div className="space-y-2">
        {factors.map((factor, idx) => (
          <div key={idx} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              {factor.status === "good" && <CheckCircle className="h-4 w-4 text-green-600" />}
              {factor.status === "warning" && <AlertTriangle className="h-4 w-4 text-amber-600" />}
              {factor.status === "danger" && <AlertTriangle className="h-4 w-4 text-destructive" />}
              {factor.status === "neutral" && <Clock className="h-4 w-4 text-muted-foreground" />}
              <span className="text-muted-foreground">{factor.name}</span>
            </div>
            <span className="font-mono text-xs">
              +{factor.points}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DomainHealthScore;