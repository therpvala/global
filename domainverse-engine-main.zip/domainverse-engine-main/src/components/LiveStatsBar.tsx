import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Stats {
  domainsSold: number;
  activeAuctions: number;
  totalInvestors: number;
  payoutsCompleted: number;
}

const LiveStatsBar = () => {
  const [stats, setStats] = useState<Stats>({
    domainsSold: 0,
    activeAuctions: 0,
    totalInvestors: 0,
    payoutsCompleted: 0,
  });

  useEffect(() => {
    const fetchStats = async () => {
      try {
        // Fetch domains sold (status = sold)
        const { count: soldCount } = await supabase
          .from("domains")
          .select("*", { count: "exact", head: true })
          .eq("status", "sold");

        // Fetch active auctions
        const { count: auctionsCount } = await supabase
          .from("auctions")
          .select("*", { count: "exact", head: true })
          .eq("status", "active");

        // Fetch total investors (users with investor role)
        const { count: investorsCount } = await supabase
          .from("user_roles")
          .select("*", { count: "exact", head: true })
          .eq("role", "investor");

        // Fetch completed transactions (payouts)
        const { count: payoutsCount } = await supabase
          .from("transactions")
          .select("*", { count: "exact", head: true })
          .eq("type", "sale");

        setStats({
          domainsSold: soldCount || 0,
          activeAuctions: auctionsCount || 0,
          totalInvestors: investorsCount || 0,
          payoutsCompleted: payoutsCount || 0,
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
    };

    fetchStats();
  }, []);

  const statItems = [
    { label: "Domains Sold", value: stats.domainsSold },
    { label: "Active Auctions", value: stats.activeAuctions },
    { label: "Total Investors", value: stats.totalInvestors },
    { label: "Payouts Completed", value: stats.payoutsCompleted },
  ];

  return (
    <section className="py-10 bg-primary">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {statItems.map((item) => (
            <div key={item.label} className="text-center">
              <div className="font-display text-3xl md:text-4xl font-bold text-primary-foreground mb-1">
                {item.value.toLocaleString()}
              </div>
              <div className="text-sm text-primary-foreground/80">
                {item.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LiveStatsBar;
