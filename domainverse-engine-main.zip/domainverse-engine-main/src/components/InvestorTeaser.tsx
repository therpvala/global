import { Link } from "react-router-dom";
import { TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const InvestorTeaser = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-flex p-3 rounded-full bg-primary/10 mb-4">
            <TrendingUp className="h-6 w-6 text-primary" />
          </div>
          <h2 className="font-display text-2xl md:text-3xl font-bold text-foreground mb-3">
            Invest in Premium Domains
          </h2>
          <p className="text-muted-foreground mb-6">
            Join our investor network and access exclusive domain opportunities.
          </p>
          <Button size="lg" className="bg-primary hover:bg-primary/90" asChild>
            <Link to="/auth?role=investor">
              Become an Investor
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default InvestorTeaser;
