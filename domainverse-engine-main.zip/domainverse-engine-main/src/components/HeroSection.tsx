import { useState } from "react";
import { Link } from "react-router-dom";
import { Search, DollarSign, ParkingSquare, Gavel, Calculator, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const HeroSection = () => {
  const [searchDomain, setSearchDomain] = useState("");

  const handleSearch = () => {
    if (searchDomain.trim()) {
      // Navigate to marketplace with search query
      window.location.href = `/marketplace?search=${encodeURIComponent(searchDomain.trim())}`;
    }
  };

  return (
    <section className="bg-white pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Main Heading */}
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-4 leading-tight">
            Sell, Park, or Auction
            <br />
            <span className="text-primary">Your Domain in Minutes</span>
          </h1>

          {/* Subheading */}
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
            The fastest way to monetize your domains. Secure escrow. Global buyers. Instant payouts.
          </p>

          {/* Domain Search Bar */}
          <div className="flex flex-col sm:flex-row gap-3 max-w-xl mx-auto mb-10">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                placeholder="Search domains..."
                value={searchDomain}
                onChange={(e) => setSearchDomain(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="pl-10 h-12 text-base"
              />
            </div>
            <Button 
              onClick={handleSearch}
              className="h-12 px-8 bg-primary hover:bg-primary/90"
            >
              Search
            </Button>
          </div>

          {/* Primary Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto mb-8">
            <Button
              size="lg"
              className="h-14 text-base bg-primary hover:bg-primary/90"
              asChild
            >
              <Link to="/add-domain">
                <DollarSign className="h-5 w-5 mr-2" />
                Sell Your Domain
              </Link>
            </Button>
            <Button
              size="lg"
              className="h-14 text-base bg-primary hover:bg-primary/90"
              asChild
            >
              <Link to="/parking">
                <ParkingSquare className="h-5 w-5 mr-2" />
                Park Your Domain
              </Link>
            </Button>
            <Button
              size="lg"
              className="h-14 text-base bg-primary hover:bg-primary/90"
              asChild
            >
              <Link to="/create-auction">
                <Gavel className="h-5 w-5 mr-2" />
                Start Auction
              </Link>
            </Button>
          </div>

          {/* Secondary Actions */}
          <div className="flex flex-wrap justify-center gap-4">
            <Button variant="outline" asChild>
              <Link to="/valuation">
                <Calculator className="h-4 w-4 mr-2" />
                Get Valuation
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link to="/expert">
                <MessageCircle className="h-4 w-4 mr-2" />
                Expert Advice
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
