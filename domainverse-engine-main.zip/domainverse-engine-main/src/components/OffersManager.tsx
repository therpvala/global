import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Check, X, MessageSquare, DollarSign, Clock, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

interface Offer {
  id: string;
  domain_id: string;
  buyer_id: string;
  seller_id: string;
  amount: number;
  message: string | null;
  status: string;
  counter_amount: number | null;
  counter_message: string | null;
  expires_at: string;
  created_at: string;
  domain_name?: string;
  buyer_email?: string;
  seller_email?: string;
}

interface OffersManagerProps {
  domainId?: string;
  view: 'received' | 'sent';
}

const OffersManager = ({ domainId, view }: OffersManagerProps) => {
  const { user } = useAuth();
  const [offers, setOffers] = useState<Offer[]>([]);
  const [loading, setLoading] = useState(true);
  const [counterDialogOpen, setCounterDialogOpen] = useState(false);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [counterAmount, setCounterAmount] = useState("");
  const [counterMessage, setCounterMessage] = useState("");
  const [actionLoading, setActionLoading] = useState(false);

  const fetchOffers = async () => {
    if (!user) return;

    try {
      let query = supabase
        .from('offers')
        .select('*')
        .order('created_at', { ascending: false });

      if (domainId) {
        query = query.eq('domain_id', domainId);
      }

      if (view === 'received') {
        query = query.eq('seller_id', user.id);
      } else {
        query = query.eq('buyer_id', user.id);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Fetch domain names and profiles
      const enrichedOffers = await Promise.all(
        (data || []).map(async (offer) => {
          const { data: domain } = await supabase
            .from('domains')
            .select('domain_name')
            .eq('id', offer.domain_id)
            .single();

          const { data: buyerProfile } = await supabase
            .from('profiles')
            .select('email')
            .eq('user_id', offer.buyer_id)
            .single();

          const { data: sellerProfile } = await supabase
            .from('profiles')
            .select('email')
            .eq('user_id', offer.seller_id)
            .single();

          return {
            ...offer,
            domain_name: domain?.domain_name || 'Unknown',
            buyer_email: buyerProfile?.email || 'Unknown',
            seller_email: sellerProfile?.email || 'Unknown',
          };
        })
      );

      setOffers(enrichedOffers);
    } catch (error) {
      console.error("Error fetching offers:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOffers();

    const channel = supabase
      .channel('offers-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'offers' }, fetchOffers)
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, domainId, view]);

  const handleAccept = async (offer: Offer) => {
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('offers')
        .update({ status: 'accepted' })
        .eq('id', offer.id);

      if (error) throw error;
      toast.success("Offer accepted! Contact the buyer to finalize the transaction.");
      fetchOffers();
    } catch (error: any) {
      toast.error(error.message || "Failed to accept offer");
    } finally {
      setActionLoading(false);
    }
  };

  const handleReject = async (offer: Offer) => {
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('offers')
        .update({ status: 'rejected' })
        .eq('id', offer.id);

      if (error) throw error;
      toast.success("Offer rejected");
      fetchOffers();
    } catch (error: any) {
      toast.error(error.message || "Failed to reject offer");
    } finally {
      setActionLoading(false);
    }
  };

  const handleCounter = async () => {
    if (!selectedOffer) return;
    
    const amount = parseFloat(counterAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error("Please enter a valid counter amount");
      return;
    }

    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('offers')
        .update({
          status: 'countered',
          counter_amount: amount,
          counter_message: counterMessage.trim() || null,
        })
        .eq('id', selectedOffer.id);

      if (error) throw error;
      toast.success("Counter offer sent!");
      setCounterDialogOpen(false);
      setCounterAmount("");
      setCounterMessage("");
      setSelectedOffer(null);
      fetchOffers();
    } catch (error: any) {
      toast.error(error.message || "Failed to send counter offer");
    } finally {
      setActionLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
      pending: { variant: "secondary", label: "Pending" },
      accepted: { variant: "default", label: "Accepted" },
      rejected: { variant: "destructive", label: "Rejected" },
      countered: { variant: "outline", label: "Countered" },
      expired: { variant: "destructive", label: "Expired" },
    };
    const config = variants[status] || variants.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground text-center">Loading offers...</p>
        </CardContent>
      </Card>
    );
  }

  if (offers.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground text-center">
            {view === 'received' ? "No offers received yet" : "You haven't made any offers yet"}
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        {offers.map((offer) => (
          <Card key={offer.id}>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold">{offer.domain_name}</h4>
                    {getStatusBadge(offer.status)}
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      ${offer.amount.toLocaleString()}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {formatDistanceToNow(new Date(offer.created_at), { addSuffix: true })}
                    </span>
                  </div>
                  {offer.message && (
                    <p className="text-sm text-muted-foreground flex items-start gap-1 mt-2">
                      <MessageSquare className="h-3 w-3 mt-0.5 flex-shrink-0" />
                      {offer.message}
                    </p>
                  )}
                  {offer.status === 'countered' && offer.counter_amount && (
                    <div className="mt-2 p-2 bg-muted/50 rounded-lg">
                      <p className="text-sm font-medium flex items-center gap-1">
                        <ArrowRight className="h-3 w-3" />
                        Counter: ${offer.counter_amount.toLocaleString()}
                      </p>
                      {offer.counter_message && (
                        <p className="text-sm text-muted-foreground mt-1">{offer.counter_message}</p>
                      )}
                    </div>
                  )}
                </div>

                {view === 'received' && offer.status === 'pending' && (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSelectedOffer(offer);
                        setCounterDialogOpen(true);
                      }}
                      disabled={actionLoading}
                    >
                      Counter
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleReject(offer)}
                      disabled={actionLoading}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleAccept(offer)}
                      disabled={actionLoading}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={counterDialogOpen} onOpenChange={setCounterDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Counter Offer</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-muted-foreground">Original offer:</p>
              <p className="text-xl font-bold">${selectedOffer?.amount.toLocaleString()}</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="counter-amount">Your Counter Amount</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="counter-amount"
                  type="number"
                  placeholder="Enter counter amount"
                  value={counterAmount}
                  onChange={(e) => setCounterAmount(e.target.value)}
                  className="pl-9"
                  min="1"
                  step="0.01"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="counter-message">Message (Optional)</Label>
              <Textarea
                id="counter-message"
                placeholder="Add a message..."
                value={counterMessage}
                onChange={(e) => setCounterMessage(e.target.value)}
                maxLength={500}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCounterDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCounter} disabled={actionLoading}>
              {actionLoading ? "Sending..." : "Send Counter"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default OffersManager;
