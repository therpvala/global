import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    const { domain_id, domain_name, auction_id, starting_price } = await req.json()

    console.log('Notifying watchers for domain:', domain_id, domain_name)

    // Find all users watching this domain
    const { data: watchers, error: watchersError } = await supabase
      .from('domain_watchlist')
      .select('user_id')
      .eq('domain_id', domain_id)

    if (watchersError) {
      console.error('Error fetching watchers:', watchersError)
      throw watchersError
    }

    const watcherIds = watchers?.map(w => w.user_id) || []

    console.log(`Found ${watcherIds.length} watchers to notify`)

    if (watcherIds.length === 0) {
      return new Response(
        JSON.stringify({ success: true, notified: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create notifications for all watchers
    const notifications = watcherIds.map(userId => ({
      user_id: userId,
      title: 'Watched domain is now on auction!',
      message: `${domain_name} is now available for bidding! Starting price: $${starting_price.toLocaleString()}`,
      type: 'auction_started',
      auction_id: auction_id,
    }))

    const { error: insertError } = await supabase
      .from('notifications')
      .insert(notifications)

    if (insertError) {
      console.error('Error inserting notifications:', insertError)
      throw insertError
    }

    console.log(`Successfully notified ${watcherIds.length} watchers`)

    return new Response(
      JSON.stringify({ success: true, notified: watcherIds.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error notifying watchers:', error)
    return new Response(
      JSON.stringify({ success: false, error: String(error) }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
