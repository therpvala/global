import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    const { auction_id, new_bidder_id, new_bid_amount, domain_name } = await req.json()

    console.log('Creating outbid notifications for auction:', auction_id)

    // Find all previous bidders on this auction (excluding the new bidder)
    const { data: previousBids, error: bidsError } = await supabase
      .from('bids')
      .select('user_id')
      .eq('auction_id', auction_id)
      .neq('user_id', new_bidder_id)

    if (bidsError) {
      console.error('Error fetching previous bids:', bidsError)
      throw bidsError
    }

    // Get unique user IDs
    const uniqueUserIds = [...new Set(previousBids?.map(b => b.user_id) || [])]

    console.log(`Found ${uniqueUserIds.length} users to notify`)

    if (uniqueUserIds.length === 0) {
      return new Response(
        JSON.stringify({ success: true, notified: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create notifications for all previous bidders
    const notifications = uniqueUserIds.map(userId => ({
      user_id: userId,
      title: 'You\'ve been outbid!',
      message: `Someone placed a bid of $${new_bid_amount.toLocaleString()} on ${domain_name}. Place a higher bid to stay in the running!`,
      type: 'outbid',
      auction_id: auction_id,
    }))

    const { error: insertError } = await supabase
      .from('notifications')
      .insert(notifications)

    if (insertError) {
      console.error('Error inserting notifications:', insertError)
      throw insertError
    }

    console.log(`Successfully notified ${uniqueUserIds.length} users`)

    return new Response(
      JSON.stringify({ success: true, notified: uniqueUserIds.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error creating outbid notifications:', error)
    return new Response(
      JSON.stringify({ success: false, error: String(error) }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
