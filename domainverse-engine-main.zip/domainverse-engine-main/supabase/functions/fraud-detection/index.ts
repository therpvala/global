import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const systemPrompt = `You are an expert fraud detection analyst specializing in online auction fraud. Analyze bidding patterns and identify suspicious activity.

Common fraud patterns to detect:
1. **Shill Bidding**: Fake bids to artificially inflate prices
2. **Bid Sniping Abuse**: Last-second bids to prevent fair competition
3. **Collusion**: Multiple accounts working together
4. **Velocity Anomalies**: Unusually rapid sequential bids
5. **Amount Anomalies**: Suspicious bid increments (too high or suspicious patterns)
6. **New Account Abuse**: High-value bids from newly created accounts
7. **Retraction Patterns**: Users who frequently retract bids

Provide a confidence score (0-100) for each detected pattern. Flag as:
- "critical" (80-100 confidence, immediate action needed)
- "high" (60-79 confidence, investigation required)
- "medium" (40-59 confidence, monitor closely)
- "low" (20-39 confidence, note for reference)`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { auctionId, analyzeAll } = await req.json();

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Fetch bids to analyze
    let bidsQuery = supabase
      .from('bids')
      .select(`
        id,
        auction_id,
        user_id,
        amount,
        is_auto,
        created_at,
        auctions!inner (
          id,
          domain_id,
          seller_id,
          starting_price,
          current_bid,
          start_time,
          end_time,
          status
        )
      `)
      .order('created_at', { ascending: false });

    if (auctionId) {
      bidsQuery = bidsQuery.eq('auction_id', auctionId);
    } else if (!analyzeAll) {
      // Only analyze recent bids (last 24 hours)
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      bidsQuery = bidsQuery.gte('created_at', yesterday);
    }

    const { data: bids, error: bidsError } = await bidsQuery.limit(100);

    if (bidsError) {
      console.error('Error fetching bids:', bidsError);
      throw new Error('Failed to fetch bids for analysis');
    }

    if (!bids || bids.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: 'No bids to analyze', alerts: [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Analyzing ${bids.length} bids for fraud patterns`);

    // Group bids by auction for pattern analysis
    const bidsByAuction: Record<string, any[]> = {};
    for (const bid of bids) {
      if (!bidsByAuction[bid.auction_id]) {
        bidsByAuction[bid.auction_id] = [];
      }
      bidsByAuction[bid.auction_id].push(bid);
    }

    // Prepare analysis data
    const analysisData = Object.entries(bidsByAuction).map(([auctionId, auctionBids]) => {
      const auction = auctionBids[0]?.auctions;
      return {
        auctionId,
        sellerId: auction?.seller_id,
        startingPrice: auction?.starting_price,
        currentBid: auction?.current_bid,
        startTime: auction?.start_time,
        endTime: auction?.end_time,
        bids: auctionBids.map(b => ({
          bidId: b.id,
          userId: b.user_id,
          amount: b.amount,
          isAuto: b.is_auto,
          createdAt: b.created_at
        }))
      };
    });

    // Call AI for fraud analysis
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: `Analyze the following auction bidding data for fraud patterns. Return structured alerts for any suspicious activity detected.

Auction Data:
${JSON.stringify(analysisData, null, 2)}

For each suspicious pattern found, provide:
1. The auction ID and bid ID involved
2. The type of fraud pattern detected
3. A confidence score (0-100)
4. Severity level (critical/high/medium/low)
5. A clear description of why this is suspicious
6. The specific patterns that triggered this alert`
          }
        ],
        tools: [
          {
            type: 'function',
            function: {
              name: 'report_fraud_alerts',
              description: 'Report detected fraud alerts from bid analysis',
              parameters: {
                type: 'object',
                properties: {
                  alerts: {
                    type: 'array',
                    items: {
                      type: 'object',
                      properties: {
                        auctionId: { type: 'string' },
                        bidId: { type: 'string' },
                        userId: { type: 'string' },
                        alertType: {
                          type: 'string',
                          enum: ['shill_bidding', 'bid_sniping', 'collusion', 'velocity_anomaly', 'amount_anomaly', 'new_account_abuse', 'retraction_pattern', 'other']
                        },
                        severity: {
                          type: 'string',
                          enum: ['critical', 'high', 'medium', 'low']
                        },
                        confidenceScore: { type: 'number' },
                        description: { type: 'string' },
                        patternsDetected: {
                          type: 'array',
                          items: { type: 'string' }
                        }
                      },
                      required: ['auctionId', 'alertType', 'severity', 'confidenceScore', 'description', 'patternsDetected']
                    }
                  },
                  summary: { type: 'string' }
                },
                required: ['alerts', 'summary']
              }
            }
          }
        ],
        tool_choice: { type: 'function', function: { name: 'report_fraud_alerts' } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits depleted. Please add credits to continue.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];

    if (!toolCall) {
      return new Response(
        JSON.stringify({ success: true, message: 'Analysis complete, no suspicious patterns detected', alerts: [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const result = JSON.parse(toolCall.function.arguments);
    const { alerts, summary } = result;

    // Store alerts in database
    if (alerts && alerts.length > 0) {
      const alertRecords = alerts.map((alert: any) => ({
        auction_id: alert.auctionId || null,
        bid_id: alert.bidId || null,
        user_id: alert.userId || null,
        alert_type: alert.alertType,
        severity: alert.severity,
        confidence_score: alert.confidenceScore,
        description: alert.description,
        patterns_detected: alert.patternsDetected,
        status: 'pending'
      }));

      const { error: insertError } = await supabase
        .from('fraud_alerts')
        .insert(alertRecords);

      if (insertError) {
        console.error('Error storing fraud alerts:', insertError);
      } else {
        console.log(`Stored ${alertRecords.length} fraud alerts`);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        summary,
        alertsCount: alerts?.length || 0,
        alerts: alerts || []
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Fraud detection error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
