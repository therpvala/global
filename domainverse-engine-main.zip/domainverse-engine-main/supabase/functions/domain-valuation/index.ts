import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const systemPrompt = `You are an expert domain name valuator with deep knowledge of the domain aftermarket industry. Analyze domain names and provide accurate valuations based on:

1. **Keywords**: Industry relevance, search volume, commercial intent, brandability
2. **Length**: Shorter domains (1-6 chars) are premium, 7-12 is good, 13+ is less valuable
3. **TLD**: .com is most valuable, then .io, .co, .net, .org, country codes vary
4. **Brandability**: Easy to spell, pronounce, remember, no hyphens or numbers preferred
5. **Market Trends**: Current industry demand, emerging sectors, tech trends
6. **Comparable Sales**: Reference similar domain sales when applicable

Provide realistic valuations based on actual market conditions. Be specific about factors that increase or decrease value.`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { domainName } = await req.json();
    
    if (!domainName) {
      return new Response(
        JSON.stringify({ error: 'Domain name is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    console.log(`Valuating domain: ${domainName}`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-3-flash-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { 
            role: 'user', 
            content: `Analyze and valuate this domain name: "${domainName}"
            
Provide a comprehensive valuation including:
1. Estimated value range (low, mid, high in USD)
2. Key value factors (positive and negative)
3. Target industries/buyers
4. Brandability score (1-10)
5. Investment potential (low/medium/high)
6. Recommended selling strategy` 
          }
        ],
        tools: [
          {
            type: 'function',
            function: {
              name: 'domain_valuation',
              description: 'Return a structured domain valuation analysis',
              parameters: {
                type: 'object',
                properties: {
                  estimatedValue: {
                    type: 'object',
                    properties: {
                      low: { type: 'number', description: 'Low estimate in USD' },
                      mid: { type: 'number', description: 'Mid estimate in USD' },
                      high: { type: 'number', description: 'High estimate in USD' }
                    },
                    required: ['low', 'mid', 'high']
                  },
                  positiveFactors: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'Factors that increase domain value'
                  },
                  negativeFactors: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'Factors that decrease domain value'
                  },
                  targetIndustries: {
                    type: 'array',
                    items: { type: 'string' },
                    description: 'Industries that would benefit from this domain'
                  },
                  brandabilityScore: {
                    type: 'number',
                    description: 'Score from 1-10 on how brandable the domain is'
                  },
                  investmentPotential: {
                    type: 'string',
                    enum: ['low', 'medium', 'high'],
                    description: 'Investment potential rating'
                  },
                  sellingStrategy: {
                    type: 'string',
                    description: 'Recommended approach to sell this domain'
                  },
                  summary: {
                    type: 'string',
                    description: 'Brief overall summary of the domain valuation'
                  }
                },
                required: ['estimatedValue', 'positiveFactors', 'negativeFactors', 'targetIndustries', 'brandabilityScore', 'investmentPotential', 'sellingStrategy', 'summary'],
                additionalProperties: false
              }
            }
          }
        ],
        tool_choice: { type: 'function', function: { name: 'domain_valuation' } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits depleted. Please add credits to continue.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log('AI response received');

    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      throw new Error('No tool call in response');
    }

    const valuation = JSON.parse(toolCall.function.arguments);

    return new Response(
      JSON.stringify({ 
        success: true, 
        domainName,
        valuation 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Domain valuation error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
