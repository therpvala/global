import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    console.log('Checking for ended auctions to settle...')

    // Find all active auctions that have ended
    const { data: endedAuctions, error: fetchError } = await supabase
      .from('auctions')
      .select(`
        id,
        domain_id,
        seller_id,
        current_bid,
        current_bidder_id,
        status
      `)
      .eq('status', 'active')
      .lt('end_time', new Date().toISOString())

    if (fetchError) {
      console.error('Error fetching ended auctions:', fetchError)
      throw fetchError
    }

    console.log(`Found ${endedAuctions?.length || 0} ended auctions to settle`)

    const results = []

    for (const auction of endedAuctions || []) {
      console.log(`Processing auction ${auction.id}...`)

      try {
        // If no bidder, just mark as expired
        if (!auction.current_bidder_id || auction.current_bid <= 0) {
          const { error: updateError } = await supabase
            .from('auctions')
            .update({ status: 'expired' })
            .eq('id', auction.id)

          if (updateError) throw updateError

          console.log(`Auction ${auction.id} expired (no bids)`)
          results.push({ auction_id: auction.id, status: 'expired', message: 'No bids placed' })
          continue
        }

        // Check winner's wallet balance
        const { data: winnerWallet, error: walletError } = await supabase
          .from('wallets')
          .select('id, balance')
          .eq('user_id', auction.current_bidder_id)
          .single()

        if (walletError || !winnerWallet) {
          console.error(`Winner wallet not found for auction ${auction.id}`)
          results.push({ auction_id: auction.id, status: 'failed', message: 'Winner wallet not found' })
          continue
        }

        if (winnerWallet.balance < auction.current_bid) {
          console.error(`Insufficient funds for auction ${auction.id}`)
          
          // Mark auction as failed due to insufficient funds
          await supabase
            .from('auctions')
            .update({ status: 'failed' })
            .eq('id', auction.id)

          results.push({ auction_id: auction.id, status: 'failed', message: 'Insufficient funds' })
          continue
        }

        // Get or create seller's wallet
        const { data: existingSellerWallet, error: sellerWalletError } = await supabase
          .from('wallets')
          .select('id, balance')
          .eq('user_id', auction.seller_id)
          .maybeSingle()

        let sellerWalletId: string
        let sellerWalletBalance: number

        if (sellerWalletError) throw sellerWalletError

        if (!existingSellerWallet) {
          // Create wallet for seller if doesn't exist
          const { data: newWallet, error: createError } = await supabase
            .from('wallets')
            .insert({ user_id: auction.seller_id, balance: 0 })
            .select()
            .single()

          if (createError || !newWallet) throw createError || new Error('Failed to create seller wallet')
          sellerWalletId = newWallet.id
          sellerWalletBalance = newWallet.balance
        } else {
          sellerWalletId = existingSellerWallet.id
          sellerWalletBalance = existingSellerWallet.balance
        }

        // Deduct from winner's wallet
        const { error: deductError } = await supabase
          .from('wallets')
          .update({ balance: winnerWallet.balance - auction.current_bid })
          .eq('id', winnerWallet.id)

        if (deductError) throw deductError

        // Add to seller's wallet
        const { error: addError } = await supabase
          .from('wallets')
          .update({ balance: sellerWalletBalance + auction.current_bid })
          .eq('id', sellerWalletId)

        if (addError) throw addError

        // Create transaction records
        const { error: txnError } = await supabase
          .from('transactions')
          .insert([
            {
              user_id: auction.current_bidder_id,
              amount: auction.current_bid,
              type: 'purchase',
              description: `Won auction for domain`
            },
            {
              user_id: auction.seller_id,
              amount: auction.current_bid,
              type: 'sale',
              description: `Sold domain via auction`
            }
          ])

        if (txnError) throw txnError

        // Transfer domain ownership
        const { error: domainError } = await supabase
          .from('domains')
          .update({ 
            user_id: auction.current_bidder_id,
            status: 'active'
          })
          .eq('id', auction.domain_id)

        if (domainError) throw domainError

        // Mark auction as completed
        const { error: completeError } = await supabase
          .from('auctions')
          .update({ status: 'completed' })
          .eq('id', auction.id)

        if (completeError) throw completeError

        console.log(`Auction ${auction.id} settled successfully`)
        results.push({ 
          auction_id: auction.id, 
          status: 'completed', 
          winner_id: auction.current_bidder_id,
          amount: auction.current_bid
        })

      } catch (auctionError) {
        console.error(`Error settling auction ${auction.id}:`, auctionError)
        results.push({ auction_id: auction.id, status: 'error', message: String(auctionError) })
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        settled: results.length,
        results 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    )

  } catch (error) {
    console.error('Settlement error:', error)
    return new Response(
      JSON.stringify({ success: false, error: String(error) }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    )
  }
})
