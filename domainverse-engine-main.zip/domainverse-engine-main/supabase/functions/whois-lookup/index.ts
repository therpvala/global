import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WhoisResponse {
  available: boolean;
  domainName: string;
  registrar?: string;
  createdDate?: string;
  expiresDate?: string;
  updatedDate?: string;
  registrant?: {
    organization?: string;
    country?: string;
  };
  nameServers?: string[];
  status?: string[];
  error?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { domain } = await req.json();
    
    if (!domain || typeof domain !== 'string') {
      return new Response(
        JSON.stringify({ error: 'Domain name is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate domain format
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$/;
    if (!domainRegex.test(domain)) {
      return new Response(
        JSON.stringify({ error: 'Invalid domain format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const apiKey = Deno.env.get('WHOIS_API_KEY');
    if (!apiKey) {
      console.error('WHOIS_API_KEY not configured');
      return new Response(
        JSON.stringify({ error: 'WHOIS API not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Looking up WHOIS data for domain: ${domain}`);

    const whoisUrl = `https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=${apiKey}&domainName=${encodeURIComponent(domain)}&outputFormat=JSON`;
    
    const response = await fetch(whoisUrl);
    
    if (!response.ok) {
      console.error(`WhoisXML API error: ${response.status}`);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch WHOIS data' }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();
    console.log('WHOIS API response received');

    // Check if domain exists (registered)
    const whoisRecord = data.WhoisRecord;
    
    if (!whoisRecord || whoisRecord.dataError) {
      // Domain might be available
      const result: WhoisResponse = {
        available: true,
        domainName: domain,
      };
      return new Response(
        JSON.stringify(result),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Parse registered domain info
    const result: WhoisResponse = {
      available: false,
      domainName: whoisRecord.domainName || domain,
      registrar: whoisRecord.registrarName || whoisRecord.registryData?.registrarName,
      createdDate: whoisRecord.createdDate || whoisRecord.registryData?.createdDate,
      expiresDate: whoisRecord.expiresDate || whoisRecord.registryData?.expiresDate,
      updatedDate: whoisRecord.updatedDate || whoisRecord.registryData?.updatedDate,
      registrant: {
        organization: whoisRecord.registrant?.organization,
        country: whoisRecord.registrant?.country,
      },
      nameServers: whoisRecord.nameServers?.hostNames || [],
      status: whoisRecord.status ? [whoisRecord.status] : (whoisRecord.registryData?.status || []),
    };

    return new Response(
      JSON.stringify(result),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in whois-lookup function:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
