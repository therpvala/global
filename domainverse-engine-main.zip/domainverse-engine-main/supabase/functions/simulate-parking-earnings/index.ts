import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ParkedDomain {
  id: string;
  domain_id: string;
  user_id: string;
  monthly_earnings: number;
  total_earnings: number;
  clicks: number;
  impressions: number;
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log("Starting parking earnings simulation...");

    // Fetch all active parked domains
    const { data: parkedDomains, error: fetchError } = await supabase
      .from("parked_domains")
      .select("*")
      .eq("status", "active");

    if (fetchError) {
      console.error("Error fetching parked domains:", fetchError);
      throw fetchError;
    }

    if (!parkedDomains || parkedDomains.length === 0) {
      console.log("No active parked domains found");
      return new Response(
        JSON.stringify({ message: "No active parked domains", updated: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Found ${parkedDomains.length} active parked domains`);

    let updatedCount = 0;

    for (const domain of parkedDomains as ParkedDomain[]) {
      // Calculate daily earnings (monthly / 30 with some variance)
      const baseDaily = domain.monthly_earnings / 30;
      // Add random variance between -20% and +30% for realism
      const variance = 0.8 + Math.random() * 0.5;
      const dailyEarning = Math.round(baseDaily * variance * 100) / 100;

      // Simulate clicks and impressions
      const newClicks = Math.floor(Math.random() * 5) + 1; // 1-5 clicks
      const newImpressions = newClicks * (Math.floor(Math.random() * 20) + 10); // 10-30x clicks

      // Update the parked domain
      const { error: updateError } = await supabase
        .from("parked_domains")
        .update({
          total_earnings: Number(domain.total_earnings) + dailyEarning,
          clicks: domain.clicks + newClicks,
          impressions: domain.impressions + newImpressions,
          last_earning_date: new Date().toISOString(),
        })
        .eq("id", domain.id);

      if (updateError) {
        console.error(`Error updating domain ${domain.id}:`, updateError);
      } else {
        console.log(
          `Updated domain ${domain.id}: +$${dailyEarning.toFixed(2)}, +${newClicks} clicks, +${newImpressions} impressions`
        );
        updatedCount++;
      }
    }

    console.log(`Successfully updated ${updatedCount} parked domains`);

    return new Response(
      JSON.stringify({
        message: "Parking earnings simulation completed",
        updated: updatedCount,
        timestamp: new Date().toISOString(),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error in simulate-parking-earnings:", errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
