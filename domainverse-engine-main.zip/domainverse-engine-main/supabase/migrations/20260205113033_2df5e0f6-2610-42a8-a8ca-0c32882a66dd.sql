-- Security enhancement: Restrict activity_logs to admins only (users can't view others' logs)
DROP POLICY IF EXISTS "Block unauthenticated reads on activity_logs" ON public.activity_logs;

-- Only admins can view activity logs
CREATE POLICY "Only admins can view activity_logs" 
ON public.activity_logs 
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Profiles: Users can only see their own profile (fix authenticated user data exposure)
-- First drop the blocking policy that was too broad
DROP POLICY IF EXISTS "Block unauthenticated access to profiles" ON public.profiles;

-- Ensure profiles are truly protected by user_id check
CREATE POLICY "Authenticated users can only view their own profile data" 
ON public.profiles 
FOR SELECT
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));