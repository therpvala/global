-- Create domains table for marketplace listings
CREATE TABLE public.domains (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  domain_name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.domains ENABLE ROW LEVEL SECURITY;

-- Anyone can view active domains
CREATE POLICY "Anyone can view active domains"
ON public.domains
FOR SELECT
USING (status = 'active');

-- Users can view their own domains regardless of status
CREATE POLICY "Users can view their own domains"
ON public.domains
FOR SELECT
USING (auth.uid() = user_id);

-- Users can create their own domains
CREATE POLICY "Users can create their own domains"
ON public.domains
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Users can update their own domains
CREATE POLICY "Users can update their own domains"
ON public.domains
FOR UPDATE
USING (auth.uid() = user_id);

-- Users can delete their own domains
CREATE POLICY "Users can delete their own domains"
ON public.domains
FOR DELETE
USING (auth.uid() = user_id);

-- Add trigger for updated_at
CREATE TRIGGER update_domains_updated_at
BEFORE UPDATE ON public.domains
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();