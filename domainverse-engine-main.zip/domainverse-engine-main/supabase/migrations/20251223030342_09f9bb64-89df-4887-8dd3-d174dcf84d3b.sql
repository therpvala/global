-- Create auctions table
CREATE TABLE public.auctions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  domain_id UUID REFERENCES public.domains(id) ON DELETE CASCADE NOT NULL,
  seller_id UUID NOT NULL,
  starting_price NUMERIC NOT NULL DEFAULT 0,
  current_bid NUMERIC NOT NULL DEFAULT 0,
  current_bidder_id UUID,
  min_bid_increment NUMERIC NOT NULL DEFAULT 10,
  start_time TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  end_time TIMESTAMP WITH TIME ZONE NOT NULL,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create bids table
CREATE TABLE public.bids (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  auction_id UUID REFERENCES public.auctions(id) ON DELETE CASCADE NOT NULL,
  user_id UUID NOT NULL,
  amount NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.auctions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bids ENABLE ROW LEVEL SECURITY;

-- Auctions policies
CREATE POLICY "Anyone can view active auctions"
ON public.auctions FOR SELECT
USING (status = 'active');

CREATE POLICY "Users can view their own auctions"
ON public.auctions FOR SELECT
USING (auth.uid() = seller_id);

CREATE POLICY "Users can create auctions for their domains"
ON public.auctions FOR INSERT
WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Sellers can update their own auctions"
ON public.auctions FOR UPDATE
USING (auth.uid() = seller_id);

-- Bids policies
CREATE POLICY "Anyone can view bids on active auctions"
ON public.bids FOR SELECT
USING (EXISTS (
  SELECT 1 FROM public.auctions 
  WHERE auctions.id = bids.auction_id
));

CREATE POLICY "Authenticated users can place bids"
ON public.bids FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Triggers for updated_at
CREATE TRIGGER update_auctions_updated_at
BEFORE UPDATE ON public.auctions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for auctions and bids
ALTER PUBLICATION supabase_realtime ADD TABLE public.auctions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bids;