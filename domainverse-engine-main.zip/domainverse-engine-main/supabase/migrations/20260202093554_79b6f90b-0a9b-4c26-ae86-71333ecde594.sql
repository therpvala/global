-- Add buy_now price and is_auto_bid flag to existing tables
ALTER TABLE public.auctions ADD COLUMN IF NOT EXISTS buy_now_price numeric DEFAULT NULL;

ALTER TABLE public.bids ADD COLUMN IF NOT EXISTS is_auto boolean DEFAULT false;

-- Create domain_health table for DNS/SSL/Blacklist status
CREATE TABLE public.domain_health (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id uuid NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
    dns_status text NOT NULL DEFAULT 'pending',
    ssl_status text NOT NULL DEFAULT 'pending',
    blacklist_status text NOT NULL DEFAULT 'pending',
    last_check_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    UNIQUE(domain_id)
);

ALTER TABLE public.domain_health ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all domain health" ON public.domain_health
FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update domain health" ON public.domain_health
FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert domain health" ON public.domain_health
FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can view their domain health" ON public.domain_health
FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.domains WHERE domains.id = domain_health.domain_id AND domains.user_id = auth.uid())
);

-- Create ownership_verification table
CREATE TABLE public.ownership_verification (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id uuid NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
    method text NOT NULL DEFAULT 'dns',
    token text NOT NULL,
    verified boolean NOT NULL DEFAULT false,
    verified_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL DEFAULT (now() + interval '24 hours'),
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.ownership_verification ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own verification" ON public.ownership_verification
FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.domains WHERE domains.id = ownership_verification.domain_id AND domains.user_id = auth.uid())
);

CREATE POLICY "Users can create verification for their domains" ON public.ownership_verification
FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.domains WHERE domains.id = ownership_verification.domain_id AND domains.user_id = auth.uid())
);

CREATE POLICY "Admins can view all verifications" ON public.ownership_verification
FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update verifications" ON public.ownership_verification
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create investments table
CREATE TABLE public.investments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    investor_id uuid NOT NULL,
    domain_id uuid NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
    amount numeric NOT NULL,
    share_percentage numeric NOT NULL DEFAULT 0,
    status text NOT NULL DEFAULT 'active',
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.investments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Investors can view their own investments" ON public.investments
FOR SELECT USING (auth.uid() = investor_id);

CREATE POLICY "Investors can create investments" ON public.investments
FOR INSERT WITH CHECK (auth.uid() = investor_id);

CREATE POLICY "Admins can view all investments" ON public.investments
FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage investments" ON public.investments
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create escrow table
CREATE TABLE public.escrow (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    domain_id uuid NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
    buyer_id uuid NOT NULL,
    seller_id uuid NOT NULL,
    amount numeric NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    released_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.escrow ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Buyers can view their escrow" ON public.escrow
FOR SELECT USING (auth.uid() = buyer_id);

CREATE POLICY "Sellers can view their escrow" ON public.escrow
FOR SELECT USING (auth.uid() = seller_id);

CREATE POLICY "Admins can manage escrow" ON public.escrow
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create payouts table
CREATE TABLE public.payouts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    amount numeric NOT NULL,
    method text NOT NULL DEFAULT 'bank',
    status text NOT NULL DEFAULT 'pending',
    processed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.payouts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their payouts" ON public.payouts
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can request payouts" ON public.payouts
FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can manage payouts" ON public.payouts
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create experts table
CREATE TABLE public.experts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL UNIQUE,
    rating numeric NOT NULL DEFAULT 0,
    success_rate numeric NOT NULL DEFAULT 0,
    total_suggestions integer NOT NULL DEFAULT 0,
    approved_suggestions integer NOT NULL DEFAULT 0,
    commission_rate numeric NOT NULL DEFAULT 5,
    status text NOT NULL DEFAULT 'active',
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.experts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Experts can view their own profile" ON public.experts
FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Experts can update their profile" ON public.experts
FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage experts" ON public.experts
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can view experts" ON public.experts
FOR SELECT USING (true);

-- Create expert_suggestions table
CREATE TABLE public.expert_suggestions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    expert_id uuid NOT NULL REFERENCES public.experts(id) ON DELETE CASCADE,
    domain_id uuid NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
    suggestion_type text NOT NULL DEFAULT 'pricing',
    notes text,
    suggested_price numeric,
    status text NOT NULL DEFAULT 'pending',
    reviewed_at timestamp with time zone,
    reviewed_by uuid,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.expert_suggestions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Experts can view their suggestions" ON public.expert_suggestions
FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.experts WHERE experts.id = expert_suggestions.expert_id AND experts.user_id = auth.uid())
);

CREATE POLICY "Experts can create suggestions" ON public.expert_suggestions
FOR INSERT WITH CHECK (
    EXISTS (SELECT 1 FROM public.experts WHERE experts.id = expert_suggestions.expert_id AND experts.user_id = auth.uid())
);

CREATE POLICY "Admins can manage suggestions" ON public.expert_suggestions
FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- Create activity_logs table for real-time feed
CREATE TABLE public.activity_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id uuid,
    entity_name text,
    metadata jsonb DEFAULT '{}',
    ip_address text,
    created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all activity logs" ON public.activity_logs
FOR SELECT USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "System can insert activity logs" ON public.activity_logs
FOR INSERT WITH CHECK (true);

-- Enable realtime for activity_logs
ALTER PUBLICATION supabase_realtime ADD TABLE public.activity_logs;

-- Add health_score to domains
ALTER TABLE public.domains ADD COLUMN IF NOT EXISTS health_score integer DEFAULT 0;

-- Create triggers for updated_at
CREATE TRIGGER update_domain_health_updated_at
    BEFORE UPDATE ON public.domain_health
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_ownership_verification_updated_at
    BEFORE UPDATE ON public.ownership_verification
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_investments_updated_at
    BEFORE UPDATE ON public.investments
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_escrow_updated_at
    BEFORE UPDATE ON public.escrow
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payouts_updated_at
    BEFORE UPDATE ON public.payouts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_experts_updated_at
    BEFORE UPDATE ON public.experts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_expert_suggestions_updated_at
    BEFORE UPDATE ON public.expert_suggestions
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();