-- Create parked_domains table to track parking status and earnings
CREATE TABLE public.parked_domains (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  domain_id UUID NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  monthly_earnings NUMERIC NOT NULL DEFAULT 0,
  total_earnings NUMERIC NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  parked_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_earning_date TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(domain_id)
);

-- Enable Row Level Security
ALTER TABLE public.parked_domains ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own parked domains" 
ON public.parked_domains 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can park their own domains" 
ON public.parked_domains 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own parked domains" 
ON public.parked_domains 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can unpark their own domains" 
ON public.parked_domains 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_parked_domains_updated_at
BEFORE UPDATE ON public.parked_domains
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for parked_domains table
ALTER PUBLICATION supabase_realtime ADD TABLE public.parked_domains;