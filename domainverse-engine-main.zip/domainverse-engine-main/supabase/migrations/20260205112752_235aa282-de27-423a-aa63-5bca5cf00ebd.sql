-- ================================================
-- SECURITY HARDENING MIGRATION
-- Fix critical security issues by adding explicit deny policies for unauthenticated users
-- ================================================

-- 1. Add explicit deny policies for tables that need them

-- Profiles: Block unauthenticated access explicitly
CREATE POLICY "Block unauthenticated access to profiles" 
ON public.profiles 
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Wallets: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to wallets"
ON public.wallets
FOR ALL
USING (auth.uid() IS NOT NULL);

-- Transactions: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to transactions"
ON public.transactions
FOR ALL
USING (auth.uid() IS NOT NULL);

-- Escrow: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to escrow"
ON public.escrow
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Offers: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to offers"
ON public.offers
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Investments: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to investments"
ON public.investments
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Parked Domains: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to parked_domains"
ON public.parked_domains
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Payouts: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to payouts"
ON public.payouts
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Fraud Alerts: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to fraud_alerts"
ON public.fraud_alerts
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Activity Logs: Explicit deny for unauthenticated reads
CREATE POLICY "Block unauthenticated reads on activity_logs"
ON public.activity_logs
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Domain Watchlist: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to domain_watchlist"
ON public.domain_watchlist
FOR ALL
USING (auth.uid() IS NOT NULL);

-- Expert Suggestions: Explicit deny for unauthenticated
CREATE POLICY "Block unauthenticated access to expert_suggestions"
ON public.expert_suggestions
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- 2. Create secure views for public data that masks user_ids

-- Secure domains view for public listing (masks user_id)
CREATE OR REPLACE VIEW public.public_domains AS
SELECT 
  id,
  title,
  domain_name,
  description,
  price,
  category,
  status,
  health_score,
  expiration_date,
  created_at
FROM public.domains
WHERE status = 'active';

-- Secure auctions view for public listing (masks seller_id)
CREATE OR REPLACE VIEW public.public_auctions AS
SELECT 
  a.id,
  a.domain_id,
  a.starting_price,
  a.current_bid,
  a.min_bid_increment,
  a.buy_now_price,
  a.start_time,
  a.end_time,
  a.status,
  a.created_at,
  d.domain_name,
  d.title
FROM public.auctions a
JOIN public.domains d ON a.domain_id = d.id
WHERE a.status = 'active';

-- Secure bids view for public display (masks user_id for non-owners)
CREATE OR REPLACE VIEW public.public_bids AS
SELECT 
  b.id,
  b.auction_id,
  b.amount,
  b.is_auto,
  b.created_at,
  CASE 
    WHEN b.user_id = auth.uid() THEN b.user_id
    ELSE NULL
  END as user_id
FROM public.bids b;

-- Grant access to views
GRANT SELECT ON public.public_domains TO anon, authenticated;
GRANT SELECT ON public.public_auctions TO anon, authenticated;
GRANT SELECT ON public.public_bids TO authenticated;

-- 3. Add index for common queries
CREATE INDEX IF NOT EXISTS idx_domains_status ON public.domains(status);
CREATE INDEX IF NOT EXISTS idx_auctions_status ON public.auctions(status);
CREATE INDEX IF NOT EXISTS idx_bids_auction_id ON public.bids(auction_id);
CREATE INDEX IF NOT EXISTS idx_fraud_alerts_status ON public.fraud_alerts(status);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON public.activity_logs(created_at DESC);