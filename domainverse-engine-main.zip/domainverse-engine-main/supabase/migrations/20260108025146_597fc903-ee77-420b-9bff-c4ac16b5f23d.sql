-- Add expiration_date column to domains table
ALTER TABLE public.domains 
ADD COLUMN expiration_date timestamp with time zone;