-- Fix overly permissive RLS policies for system inserts
-- Replace WITH CHECK (true) with service role checks

-- Drop and recreate activity_logs INSERT policy
DROP POLICY IF EXISTS "System can insert activity logs" ON public.activity_logs;
CREATE POLICY "Service role can insert activity logs"
ON public.activity_logs
FOR INSERT
WITH CHECK (
  current_setting('request.jwt.claims', true)::json->>'role' = 'service_role'
  OR auth.uid() IS NOT NULL
);

-- Drop and recreate domain_health INSERT policy
DROP POLICY IF EXISTS "System can insert domain health" ON public.domain_health;
CREATE POLICY "Service role can insert domain health"
ON public.domain_health
FOR INSERT
WITH CHECK (
  current_setting('request.jwt.claims', true)::json->>'role' = 'service_role'
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- Drop and recreate notifications INSERT policy
DROP POLICY IF EXISTS "System can insert notifications" ON public.notifications;
CREATE POLICY "Service role can insert notifications"
ON public.notifications
FOR INSERT
WITH CHECK (
  current_setting('request.jwt.claims', true)::json->>'role' = 'service_role'
  OR auth.uid() = user_id
);

-- Drop and recreate fraud_alerts INSERT policy
DROP POLICY IF EXISTS "System can insert fraud alerts" ON public.fraud_alerts;
CREATE POLICY "Service role can insert fraud alerts"
ON public.fraud_alerts
FOR INSERT
WITH CHECK (
  current_setting('request.jwt.claims', true)::json->>'role' = 'service_role'
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- Add admin policies for domains (drop first to avoid conflicts)
DROP POLICY IF EXISTS "Admins can view all domains" ON public.domains;
CREATE POLICY "Admins can view all domains"
ON public.domains
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can manage all domains" ON public.domains;
CREATE POLICY "Admins can manage all domains"
ON public.domains
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for auctions
DROP POLICY IF EXISTS "Admins can view all auctions" ON public.auctions;
CREATE POLICY "Admins can view all auctions"
ON public.auctions
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can manage all auctions" ON public.auctions;
CREATE POLICY "Admins can manage all auctions"
ON public.auctions
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for bids
DROP POLICY IF EXISTS "Admins can view all bids" ON public.bids;
CREATE POLICY "Admins can view all bids"
ON public.bids
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for transactions
DROP POLICY IF EXISTS "Admins can view all transactions" ON public.transactions;
CREATE POLICY "Admins can view all transactions"
ON public.transactions
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for wallets
DROP POLICY IF EXISTS "Admins can view all wallets" ON public.wallets;
CREATE POLICY "Admins can view all wallets"
ON public.wallets
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for parked_domains
DROP POLICY IF EXISTS "Admins can view all parked domains" ON public.parked_domains;
CREATE POLICY "Admins can view all parked domains"
ON public.parked_domains
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for notifications
DROP POLICY IF EXISTS "Admins can view all notifications" ON public.notifications;
CREATE POLICY "Admins can view all notifications"
ON public.notifications
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Add admin policies for offers
DROP POLICY IF EXISTS "Admins can view all offers" ON public.offers;
CREATE POLICY "Admins can view all offers"
ON public.offers
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

DROP POLICY IF EXISTS "Admins can manage all offers" ON public.offers;
CREATE POLICY "Admins can manage all offers"
ON public.offers
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));