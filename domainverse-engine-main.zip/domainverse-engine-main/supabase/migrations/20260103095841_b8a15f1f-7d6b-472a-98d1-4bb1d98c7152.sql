-- Create offers table for price negotiations
CREATE TABLE public.offers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  domain_id UUID NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
  buyer_id UUID NOT NULL,
  seller_id UUID NOT NULL,
  amount NUMERIC NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'countered', 'expired')),
  counter_amount NUMERIC,
  counter_message TEXT,
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (now() + interval '7 days'),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;

-- Buyers can view their own offers
CREATE POLICY "Buyers can view their own offers"
ON public.offers
FOR SELECT
USING (auth.uid() = buyer_id);

-- Sellers can view offers on their domains
CREATE POLICY "Sellers can view offers on their domains"
ON public.offers
FOR SELECT
USING (auth.uid() = seller_id);

-- Authenticated users can create offers
CREATE POLICY "Users can create offers"
ON public.offers
FOR INSERT
WITH CHECK (auth.uid() = buyer_id);

-- Sellers can update offers (accept/reject/counter)
CREATE POLICY "Sellers can update offers on their domains"
ON public.offers
FOR UPDATE
USING (auth.uid() = seller_id);

-- Buyers can update their own offers (withdraw)
CREATE POLICY "Buyers can update their own offers"
ON public.offers
FOR UPDATE
USING (auth.uid() = buyer_id);

-- Create trigger for updated_at
CREATE TRIGGER update_offers_updated_at
BEFORE UPDATE ON public.offers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime for offers
ALTER PUBLICATION supabase_realtime ADD TABLE public.offers;