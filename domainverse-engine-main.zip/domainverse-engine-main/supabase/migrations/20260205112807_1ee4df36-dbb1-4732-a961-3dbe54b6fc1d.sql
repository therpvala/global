-- Fix Security Definer View issues by using SECURITY INVOKER

-- Drop existing views
DROP VIEW IF EXISTS public.public_domains;
DROP VIEW IF EXISTS public.public_auctions;
DROP VIEW IF EXISTS public.public_bids;

-- Recreate with SECURITY INVOKER (uses caller's permissions)
CREATE VIEW public.public_domains
WITH (security_invoker = on)
AS
SELECT 
  id,
  title,
  domain_name,
  description,
  price,
  category,
  status,
  health_score,
  expiration_date,
  created_at
FROM public.domains
WHERE status = 'active';

CREATE VIEW public.public_auctions
WITH (security_invoker = on)
AS
SELECT 
  a.id,
  a.domain_id,
  a.starting_price,
  a.current_bid,
  a.min_bid_increment,
  a.buy_now_price,
  a.start_time,
  a.end_time,
  a.status,
  a.created_at,
  d.domain_name,
  d.title
FROM public.auctions a
JOIN public.domains d ON a.domain_id = d.id
WHERE a.status = 'active';

CREATE VIEW public.public_bids
WITH (security_invoker = on)
AS
SELECT 
  b.id,
  b.auction_id,
  b.amount,
  b.is_auto,
  b.created_at,
  b.user_id
FROM public.bids b;

-- Grant access
GRANT SELECT ON public.public_domains TO anon, authenticated;
GRANT SELECT ON public.public_auctions TO anon, authenticated;
GRANT SELECT ON public.public_bids TO authenticated;