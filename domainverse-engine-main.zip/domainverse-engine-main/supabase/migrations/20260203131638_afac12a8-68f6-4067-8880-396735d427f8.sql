-- Create fraud_alerts table to store detected suspicious activity
CREATE TABLE public.fraud_alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  auction_id UUID REFERENCES public.auctions(id),
  bid_id UUID REFERENCES public.bids(id),
  user_id UUID,
  alert_type TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'medium',
  confidence_score NUMERIC NOT NULL DEFAULT 0,
  description TEXT NOT NULL,
  patterns_detected JSONB DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.fraud_alerts ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can view all fraud alerts"
  ON public.fraud_alerts FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage fraud alerts"
  ON public.fraud_alerts FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "System can insert fraud alerts"
  ON public.fraud_alerts FOR INSERT
  WITH CHECK (true);

-- Enable realtime for fraud alerts
ALTER PUBLICATION supabase_realtime ADD TABLE public.fraud_alerts;

-- Create trigger for updated_at
CREATE TRIGGER update_fraud_alerts_updated_at
  BEFORE UPDATE ON public.fraud_alerts
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();