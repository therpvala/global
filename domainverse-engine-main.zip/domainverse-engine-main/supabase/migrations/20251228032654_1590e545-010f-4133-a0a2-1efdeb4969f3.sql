-- Add category column to domains table
ALTER TABLE public.domains 
ADD COLUMN category text NOT NULL DEFAULT 'other';

-- Add an index for filtering by category
CREATE INDEX idx_domains_category ON public.domains(category);