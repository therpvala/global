-- Create a table for domain watchlist
CREATE TABLE public.domain_watchlist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  domain_id UUID NOT NULL REFERENCES public.domains(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, domain_id)
);

-- Enable Row Level Security
ALTER TABLE public.domain_watchlist ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own watchlist"
ON public.domain_watchlist
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can add to their own watchlist"
ON public.domain_watchlist
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can remove from their own watchlist"
ON public.domain_watchlist
FOR DELETE
USING (auth.uid() = user_id);

-- Enable realtime for watchlist updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.domain_watchlist;