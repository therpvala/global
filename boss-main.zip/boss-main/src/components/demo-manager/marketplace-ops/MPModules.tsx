// @ts-nocheck
import { useEffect, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Layers, Package, FolderOpen, ShoppingBag, MessageSquare,
  KeySquare, BarChart3,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface ModuleDef {
  id: string;
  label: string;
  description: string;
  icon: any;
  color: string;
  table?: string;
  badge: string;
}

const DEFAULT_MODULES: ModuleDef[] = [
  { id: "products",   label: "Product Management",  description: "Catalog, pricing, assets, demos",         icon: Package,        color: "from-indigo-500 to-indigo-600", table: "products",            badge: "CORE" },
  { id: "categories", label: "Catalog System",      description: "Categories, subcategories, tags",         icon: FolderOpen,     color: "from-purple-500 to-purple-600", table: "business_categories", badge: "STRUCTURE" },
  { id: "orders",     label: "Orders & Payments",   description: "Orders list, payment status, refunds",     icon: ShoppingBag,    color: "from-emerald-500 to-emerald-600", table: undefined,           badge: "LIVE" },
  { id: "reviews",    label: "Reviews System",      description: "Ratings, comments, approvals",             icon: MessageSquare,  color: "from-amber-500 to-amber-600",   table: undefined,             badge: "PUBLIC" },
  { id: "licenses",   label: "License System",      description: "Generate keys, assign, verify",            icon: KeySquare,      color: "from-rose-500 to-rose-600",     table: "licenses",            badge: "SECURE" },
  { id: "analytics",  label: "Analytics",           description: "Sales, top products, revenue",             icon: BarChart3,      color: "from-cyan-500 to-cyan-600",     table: undefined,             badge: "INSIGHT" },
];

const MPModules = () => {
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const failSafe = setTimeout(() => !cancelled && setLoading(false), 2000);
    (async () => {
      const next: Record<string, number> = {};
      for (const m of DEFAULT_MODULES) {
        if (!m.table) { next[m.id] = 0; continue; }
        try {
          const { count } = await supabase.from(m.table as any).select("*", { count: "exact", head: true });
          next[m.id] = count || 0;
        } catch {
          next[m.id] = 0;
        }
      }
      if (!cancelled) { setCounts(next); setLoading(false); }
    })();
    return () => { cancelled = true; clearTimeout(failSafe); };
  }, []);

  return (
    <ScrollArea className="h-screen">
      <div className="p-6 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-indigo-600 flex items-center justify-center">
            <Layers className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground">Manage Modules</h1>
            <p className="text-sm text-muted-foreground">Marketplace Manager · default system modules</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {DEFAULT_MODULES.map((m) => {
            const Icon = m.icon;
            const count = counts[m.id] ?? 0;
            return (
              <Card key={m.id} className="bg-card/60 border-border/60 hover:border-primary/40 transition-all">
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-start justify-between">
                    <div className={`w-11 h-11 rounded-lg bg-gradient-to-br ${m.color} flex items-center justify-center shadow-lg`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <Badge variant="outline" className="text-[10px]">{m.badge}</Badge>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{m.label}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{m.description}</p>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-border/40">
                    <span className="text-xs text-muted-foreground">Items</span>
                    <span className="text-lg font-bold text-foreground">
                      {loading ? "…" : count}
                    </span>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </ScrollArea>
  );
};

export default MPModules;
