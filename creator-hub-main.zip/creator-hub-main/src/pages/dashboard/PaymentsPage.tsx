import { CreditCard, Search, Filter, Download, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const payments = [
  { id: 'PAY001', student: 'Alex Thompson', method: 'Credit Card', amount: '$499', date: 'Jan 15, 2026', status: 'Completed', type: 'income' },
  { id: 'PAY002', student: 'Maria Garcia', method: 'Bank Transfer', amount: '$350', date: 'Jan 20, 2026', status: 'Completed', type: 'income' },
  { id: 'PAY003', student: 'Refund - James W.', method: 'Bank Transfer', amount: '$199', date: 'Feb 05, 2026', status: 'Processed', type: 'refund' },
  { id: 'PAY004', student: 'Sarah Lee', method: 'PayPal', amount: '$299', date: 'Feb 10, 2026', status: 'Completed', type: 'income' },
  { id: 'PAY005', student: 'David Brown', method: 'Credit Card', amount: '$300', date: 'Feb 15, 2026', status: 'Pending', type: 'income' },
];

const PaymentsPage = () => {
  const [search, setSearch] = useState('');
  const filtered = payments.filter(p => p.student.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Payments</h1>
          <p className="text-sm text-muted-foreground">Track all payment transactions</p>
        </div>
        <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" />Export</Button>
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search payments..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-border bg-muted/50">
              {['Transaction', 'Method', 'Amount', 'Date', 'Status'].map(h => (
                <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtered.map(p => (
                <tr key={p.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${p.type === 'income' ? 'bg-primary/10' : 'bg-destructive/10'}`}>
                        {p.type === 'income' ? <ArrowDownRight className="h-4 w-4 text-primary" /> : <ArrowUpRight className="h-4 w-4 text-destructive" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{p.student}</p>
                        <p className="text-xs text-muted-foreground">{p.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{p.method}</td>
                  <td className="px-4 py-3 text-sm font-semibold text-foreground">{p.amount}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{p.date}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      p.status === 'Completed' ? 'bg-primary/10 text-primary' :
                      p.status === 'Pending' ? 'bg-accent/20 text-accent-foreground' :
                      'bg-secondary/10 text-secondary'
                    }`}>{p.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PaymentsPage;
