import { Plus, Search, Filter, Calendar, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const workshops = [
  { id: 1, title: 'UI/UX Design Sprint', date: 'Mar 15, 2026', time: '10:00 AM - 4:00 PM', location: 'Online', instructor: 'Mark Stevens', seats: 30, enrolled: 22, status: 'Upcoming' },
  { id: 2, title: 'Python Data Visualization', date: 'Mar 20, 2026', time: '9:00 AM - 1:00 PM', location: 'Online', instructor: 'Dr. Emily Chen', seats: 25, enrolled: 25, status: 'Full' },
  { id: 3, title: 'React Performance Workshop', date: 'Mar 25, 2026', time: '2:00 PM - 6:00 PM', location: 'Online', instructor: 'Prof. Robert Miller', seats: 40, enrolled: 18, status: 'Upcoming' },
  { id: 4, title: 'AWS Cloud Bootcamp', date: 'Apr 1, 2026', time: '9:00 AM - 5:00 PM', location: 'Hybrid', instructor: 'Lisa Park', seats: 20, enrolled: 12, status: 'Upcoming' },
];

const WorkshopsPage = () => {
  const [search, setSearch] = useState('');
  const filtered = workshops.filter(w => w.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Workshops</h1>
          <p className="text-sm text-muted-foreground">Manage workshops and webinars</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Schedule Workshop</Button>
      </div>
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search workshops..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map(w => (
          <div key={w.id} className="bg-card rounded-xl p-5 shadow-card border border-border hover:shadow-card-hover transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-display font-semibold text-foreground">{w.title}</h3>
                <p className="text-xs text-muted-foreground">{w.instructor}</p>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${w.status === 'Full' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'}`}>{w.status}</span>
            </div>
            <div className="space-y-2 text-sm text-muted-foreground mb-4">
              <div className="flex items-center gap-2"><Calendar className="h-3.5 w-3.5" />{w.date} • {w.time}</div>
              <div className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5" />{w.location}</div>
              <div className="flex items-center gap-2"><Users className="h-3.5 w-3.5" />{w.enrolled}/{w.seats} seats filled</div>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden mb-3">
              <div className="h-full gradient-primary rounded-full" style={{ width: `${(w.enrolled / w.seats) * 100}%` }} />
            </div>
            <Button size="sm" variant="outline" className="w-full">View Details</Button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkshopsPage;
