import { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowLeft, Plus, GripVertical, Trash2, ChevronDown, ChevronUp,
  Video, FileText, ClipboardList, HelpCircle, Upload, Image, Save,
  Eye, Settings, BookOpen, Clock, Users, Play, PenLine
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { toast } from 'sonner';

type LessonType = 'video' | 'document' | 'quiz' | 'assignment';

interface Lesson {
  id: string;
  title: string;
  type: LessonType;
  duration: string;
  content: string;
  videoUrl: string;
  quizQuestions: QuizQuestion[];
  assignmentDescription: string;
}

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
}

interface Module {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
  expanded: boolean;
}

const createLesson = (type: LessonType = 'video'): Lesson => ({
  id: `lesson-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  title: '',
  type,
  duration: '',
  content: '',
  videoUrl: '',
  quizQuestions: [],
  assignmentDescription: '',
});

const createModule = (): Module => ({
  id: `module-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  title: '',
  description: '',
  lessons: [createLesson()],
  expanded: true,
});

const createQuizQuestion = (): QuizQuestion => ({
  id: `q-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
  question: '',
  options: ['', '', '', ''],
  correctIndex: 0,
});

const lessonTypeConfig: Record<LessonType, { icon: React.ElementType; label: string; color: string }> = {
  video: { icon: Video, label: 'Video', color: 'bg-primary/10 text-primary' },
  document: { icon: FileText, label: 'Document', color: 'bg-secondary/10 text-secondary' },
  quiz: { icon: HelpCircle, label: 'Quiz', color: 'bg-accent/20 text-accent-foreground' },
  assignment: { icon: ClipboardList, label: 'Assignment', color: 'bg-crimson/10 text-crimson' },
};

const CourseBuilderPage = () => {
  const [courseTitle, setCourseTitle] = useState('');
  const [courseDescription, setCourseDescription] = useState('');
  const [courseCategory, setCourseCategory] = useState('');
  const [courseLevel, setCourseLevel] = useState('');
  const [coursePrice, setCoursePrice] = useState('');
  const [courseThumbnail, setCourseThumbnail] = useState('');
  const [isPublished, setIsPublished] = useState(false);
  const [modules, setModules] = useState<Module[]>([createModule()]);
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [draggedLesson, setDraggedLesson] = useState<{ moduleId: string; lessonId: string } | null>(null);

  const addModule = () => {
    setModules(prev => [...prev, createModule()]);
    toast.success('Module added');
  };

  const removeModule = (moduleId: string) => {
    if (modules.length <= 1) {
      toast.error('Course must have at least one module');
      return;
    }
    setModules(prev => prev.filter(m => m.id !== moduleId));
    toast.success('Module removed');
  };

  const updateModule = (moduleId: string, updates: Partial<Module>) => {
    setModules(prev => prev.map(m => m.id === moduleId ? { ...m, ...updates } : m));
  };

  const toggleModule = (moduleId: string) => {
    setModules(prev => prev.map(m => m.id === moduleId ? { ...m, expanded: !m.expanded } : m));
  };

  const addLesson = (moduleId: string, type: LessonType = 'video') => {
    setModules(prev => prev.map(m =>
      m.id === moduleId ? { ...m, lessons: [...m.lessons, createLesson(type)] } : m
    ));
  };

  const removeLesson = (moduleId: string, lessonId: string) => {
    setModules(prev => prev.map(m =>
      m.id === moduleId
        ? { ...m, lessons: m.lessons.filter(l => l.id !== lessonId) }
        : m
    ));
    if (activeLesson === lessonId) setActiveLesson(null);
  };

  const updateLesson = (moduleId: string, lessonId: string, updates: Partial<Lesson>) => {
    setModules(prev => prev.map(m =>
      m.id === moduleId
        ? { ...m, lessons: m.lessons.map(l => l.id === lessonId ? { ...l, ...updates } : l) }
        : m
    ));
  };

  const reorderModules = (newOrder: Module[]) => {
    setModules(newOrder);
  };

  const reorderLessons = (moduleId: string, newOrder: Lesson[]) => {
    setModules(prev => prev.map(m => m.id === moduleId ? { ...m, lessons: newOrder } : m));
  };

  const handleLessonDragStart = (moduleId: string, lessonId: string) => {
    setDraggedLesson({ moduleId, lessonId });
  };

  const handleLessonDrop = (targetModuleId: string, targetIndex: number) => {
    if (!draggedLesson) return;
    const sourceModule = modules.find(m => m.id === draggedLesson.moduleId);
    const lesson = sourceModule?.lessons.find(l => l.id === draggedLesson.lessonId);
    if (!lesson) return;

    setModules(prev => {
      const updated = prev.map(m => {
        if (m.id === draggedLesson.moduleId) {
          return { ...m, lessons: m.lessons.filter(l => l.id !== draggedLesson.lessonId) };
        }
        return m;
      });
      return updated.map(m => {
        if (m.id === targetModuleId) {
          const newLessons = [...m.lessons];
          newLessons.splice(targetIndex, 0, lesson);
          return { ...m, lessons: newLessons };
        }
        return m;
      });
    });
    setDraggedLesson(null);
  };

  const addQuizQuestion = (moduleId: string, lessonId: string) => {
    updateLesson(moduleId, lessonId, {
      quizQuestions: [
        ...(modules.find(m => m.id === moduleId)?.lessons.find(l => l.id === lessonId)?.quizQuestions || []),
        createQuizQuestion(),
      ],
    });
  };

  const updateQuizQuestion = (moduleId: string, lessonId: string, questionId: string, updates: Partial<QuizQuestion>) => {
    const lesson = modules.find(m => m.id === moduleId)?.lessons.find(l => l.id === lessonId);
    if (!lesson) return;
    updateLesson(moduleId, lessonId, {
      quizQuestions: lesson.quizQuestions.map(q => q.id === questionId ? { ...q, ...updates } : q),
    });
  };

  const removeQuizQuestion = (moduleId: string, lessonId: string, questionId: string) => {
    const lesson = modules.find(m => m.id === moduleId)?.lessons.find(l => l.id === lessonId);
    if (!lesson) return;
    updateLesson(moduleId, lessonId, {
      quizQuestions: lesson.quizQuestions.filter(q => q.id !== questionId),
    });
  };

  const saveCourse = () => {
    if (!courseTitle.trim()) {
      toast.error('Please enter a course title');
      return;
    }
    toast.success(isPublished ? 'Course published successfully!' : 'Course saved as draft!');
  };

  const totalLessons = modules.reduce((sum, m) => sum + m.lessons.length, 0);

  const getActiveLesson = () => {
    for (const m of modules) {
      for (const l of m.lessons) {
        if (l.id === activeLesson) return { module: m, lesson: l };
      }
    }
    return null;
  };

  const activeLessonData = getActiveLesson();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Link to="/dashboard/courses" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
          <ArrowLeft className="h-4 w-4" /> Back to Courses
        </Link>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={saveCourse}>
            <Save className="h-4 w-4 mr-1" /> Save Draft
          </Button>
          <Button size="sm" className="gradient-primary text-primary-foreground" onClick={() => { setIsPublished(true); saveCourse(); }}>
            <Eye className="h-4 w-4 mr-1" /> Publish
          </Button>
        </div>
      </div>

      <Tabs defaultValue="content" className="space-y-6">
        <TabsList className="bg-muted">
          <TabsTrigger value="content"><BookOpen className="h-3.5 w-3.5 mr-1" /> Content</TabsTrigger>
          <TabsTrigger value="settings"><Settings className="h-3.5 w-3.5 mr-1" /> Settings</TabsTrigger>
        </TabsList>

        {/* SETTINGS TAB */}
        <TabsContent value="settings">
          <div className="bg-card rounded-xl shadow-card border border-border p-6 space-y-6 max-w-2xl">
            <h2 className="font-display text-lg font-bold text-foreground">Course Settings</h2>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Course Title</label>
                <Input value={courseTitle} onChange={e => setCourseTitle(e.target.value)} placeholder="e.g. Advanced React & TypeScript" />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Description</label>
                <Textarea value={courseDescription} onChange={e => setCourseDescription(e.target.value)} placeholder="Describe what students will learn..." rows={4} />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Category</label>
                  <Select value={courseCategory} onValueChange={setCourseCategory}>
                    <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="web-dev">Web Development</SelectItem>
                      <SelectItem value="data-science">Data Science</SelectItem>
                      <SelectItem value="design">Design</SelectItem>
                      <SelectItem value="ai-ml">AI / Machine Learning</SelectItem>
                      <SelectItem value="cloud">Cloud Computing</SelectItem>
                      <SelectItem value="security">Cybersecurity</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Level</label>
                  <Select value={courseLevel} onValueChange={setCourseLevel}>
                    <SelectTrigger><SelectValue placeholder="Select level" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Price ($)</label>
                  <Input type="number" value={coursePrice} onChange={e => setCoursePrice(e.target.value)} placeholder="0 for free" />
                </div>
                <div>
                  <label className="text-sm font-medium text-foreground mb-1.5 block">Thumbnail</label>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Upload className="h-3.5 w-3.5 mr-1" /> Upload Image
                    </Button>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                <div>
                  <p className="text-sm font-medium text-foreground">Publish Course</p>
                  <p className="text-xs text-muted-foreground">Make this course visible to students</p>
                </div>
                <Switch checked={isPublished} onCheckedChange={setIsPublished} />
              </div>
            </div>
          </div>
        </TabsContent>

        {/* CONTENT TAB */}
        <TabsContent value="content">
          <div className="grid lg:grid-cols-5 gap-6">
            {/* Left Panel - Module/Lesson Tree */}
            <div className="lg:col-span-2 space-y-4">
              {/* Course Overview Card */}
              <div className="bg-card rounded-xl p-4 shadow-card border border-border">
                <Input
                  value={courseTitle}
                  onChange={e => setCourseTitle(e.target.value)}
                  placeholder="Course Title"
                  className="font-display text-lg font-bold border-none bg-transparent px-0 focus-visible:ring-0 placeholder:text-muted-foreground/50"
                />
                <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><BookOpen className="h-3 w-3" /> {modules.length} modules</span>
                  <span className="flex items-center gap-1"><Play className="h-3 w-3" /> {totalLessons} lessons</span>
                </div>
              </div>

              {/* Modules List - Drag & Drop */}
              <Reorder.Group axis="y" values={modules} onReorder={reorderModules} className="space-y-3">
                {modules.map((mod, modIndex) => (
                  <Reorder.Item key={mod.id} value={mod} className="list-none">
                    <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
                      {/* Module Header */}
                      <div className="flex items-center gap-2 p-3 bg-muted/30">
                        <GripVertical className="h-4 w-4 text-muted-foreground/50 cursor-grab active:cursor-grabbing flex-shrink-0" />
                        <span className="text-xs font-bold text-muted-foreground w-6">M{modIndex + 1}</span>
                        <Input
                          value={mod.title}
                          onChange={e => updateModule(mod.id, { title: e.target.value })}
                          placeholder="Module title..."
                          className="flex-1 h-8 text-sm font-semibold border-none bg-transparent px-1 focus-visible:ring-0"
                        />
                        <button onClick={() => toggleModule(mod.id)} className="text-muted-foreground hover:text-foreground p-1">
                          {mod.expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                        </button>
                        <button onClick={() => removeModule(mod.id)} className="text-muted-foreground hover:text-destructive p-1">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      {/* Lessons */}
                      <AnimatePresence>
                        {mod.expanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="overflow-hidden"
                          >
                            <Reorder.Group axis="y" values={mod.lessons} onReorder={order => reorderLessons(mod.id, order)} className="border-t border-border">
                              {mod.lessons.map((lesson, lessonIndex) => {
                                const cfg = lessonTypeConfig[lesson.type];
                                return (
                                  <Reorder.Item key={lesson.id} value={lesson} className="list-none">
                                    <div
                                      className={`flex items-center gap-2 px-3 py-2.5 border-b border-border last:border-b-0 cursor-pointer transition-colors ${
                                        activeLesson === lesson.id ? 'bg-primary/5 border-l-2 border-l-primary' : 'hover:bg-muted/30'
                                      }`}
                                      onClick={() => setActiveLesson(lesson.id)}
                                    >
                                      <GripVertical className="h-3.5 w-3.5 text-muted-foreground/40 cursor-grab active:cursor-grabbing flex-shrink-0" />
                                      <div className={`w-6 h-6 rounded flex items-center justify-center flex-shrink-0 ${cfg.color}`}>
                                        <cfg.icon className="h-3 w-3" />
                                      </div>
                                      <span className="flex-1 text-sm text-foreground truncate">
                                        {lesson.title || `Untitled ${cfg.label}`}
                                      </span>
                                      <button
                                        onClick={e => { e.stopPropagation(); removeLesson(mod.id, lesson.id); }}
                                        className="text-muted-foreground/40 hover:text-destructive p-0.5 opacity-0 group-hover:opacity-100"
                                      >
                                        <Trash2 className="h-3 w-3" />
                                      </button>
                                    </div>
                                  </Reorder.Item>
                                );
                              })}
                            </Reorder.Group>

                            {/* Add Lesson Buttons */}
                            <div className="p-2 border-t border-border flex flex-wrap gap-1">
                              {(Object.entries(lessonTypeConfig) as [LessonType, typeof lessonTypeConfig.video][]).map(([type, cfg]) => (
                                <button
                                  key={type}
                                  onClick={() => addLesson(mod.id, type)}
                                  className={`flex items-center gap-1 text-[11px] px-2 py-1 rounded-md ${cfg.color} hover:opacity-80 transition-opacity`}
                                >
                                  <Plus className="h-3 w-3" /> {cfg.label}
                                </button>
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </Reorder.Item>
                ))}
              </Reorder.Group>

              <Button variant="outline" className="w-full border-dashed" onClick={addModule}>
                <Plus className="h-4 w-4 mr-1" /> Add Module
              </Button>
            </div>

            {/* Right Panel - Lesson Editor */}
            <div className="lg:col-span-3">
              {activeLessonData ? (
                <LessonEditor
                  module={activeLessonData.module}
                  lesson={activeLessonData.lesson}
                  onUpdate={(updates) => updateLesson(activeLessonData.module.id, activeLessonData.lesson.id, updates)}
                  onAddQuestion={() => addQuizQuestion(activeLessonData.module.id, activeLessonData.lesson.id)}
                  onUpdateQuestion={(qId, updates) => updateQuizQuestion(activeLessonData.module.id, activeLessonData.lesson.id, qId, updates)}
                  onRemoveQuestion={(qId) => removeQuizQuestion(activeLessonData.module.id, activeLessonData.lesson.id, qId)}
                />
              ) : (
                <div className="bg-card rounded-xl shadow-card border border-border p-12 flex flex-col items-center justify-center text-center min-h-[400px]">
                  <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
                    <PenLine className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="font-display font-semibold text-foreground mb-2">Select a Lesson to Edit</h3>
                  <p className="text-sm text-muted-foreground max-w-sm">
                    Click on any lesson from the module tree on the left to start editing its content, or add a new lesson.
                  </p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

/* ---------- Lesson Editor Component ---------- */

interface LessonEditorProps {
  module: Module;
  lesson: Lesson;
  onUpdate: (updates: Partial<Lesson>) => void;
  onAddQuestion: () => void;
  onUpdateQuestion: (questionId: string, updates: Partial<QuizQuestion>) => void;
  onRemoveQuestion: (questionId: string) => void;
}

const LessonEditor = ({ module, lesson, onUpdate, onAddQuestion, onUpdateQuestion, onRemoveQuestion }: LessonEditorProps) => {
  const cfg = lessonTypeConfig[lesson.type];

  return (
    <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-border">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${cfg.color}`}>
            <cfg.icon className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{module.title || 'Untitled Module'}</p>
            <Select value={lesson.type} onValueChange={(v: LessonType) => onUpdate({ type: v })}>
              <SelectTrigger className="h-6 w-auto border-none bg-transparent p-0 text-xs font-medium text-muted-foreground focus:ring-0">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="video">Video Lesson</SelectItem>
                <SelectItem value="document">Document</SelectItem>
                <SelectItem value="quiz">Quiz</SelectItem>
                <SelectItem value="assignment">Assignment</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Input
          value={lesson.title}
          onChange={e => onUpdate({ title: e.target.value })}
          placeholder="Lesson title..."
          className="font-display text-lg font-bold border-none bg-transparent px-0 focus-visible:ring-0"
        />
      </div>

      {/* Content based on type */}
      <div className="p-5 space-y-5">
        {lesson.type === 'video' && (
          <>
            {/* Video Upload Area */}
            <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Upload className="h-7 w-7 text-primary" />
              </div>
              <p className="font-medium text-foreground text-sm">Upload Video</p>
              <p className="text-xs text-muted-foreground mt-1">Drag & drop or click to browse. MP4, WebM, up to 500MB</p>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Or paste video URL</label>
              <Input
                value={lesson.videoUrl}
                onChange={e => onUpdate({ videoUrl: e.target.value })}
                placeholder="https://youtube.com/... or https://vimeo.com/..."
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Duration</label>
                <Input
                  value={lesson.duration}
                  onChange={e => onUpdate({ duration: e.target.value })}
                  placeholder="e.g. 45:00"
                />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Lesson Notes / Description</label>
              <Textarea
                value={lesson.content}
                onChange={e => onUpdate({ content: e.target.value })}
                placeholder="Add notes, key takeaways, or a description for this lesson..."
                rows={6}
              />
            </div>
          </>
        )}

        {lesson.type === 'document' && (
          <>
            <div className="border-2 border-dashed border-border rounded-xl p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <div className="w-14 h-14 rounded-2xl bg-secondary/10 flex items-center justify-center mx-auto mb-3">
                <FileText className="h-7 w-7 text-secondary" />
              </div>
              <p className="font-medium text-foreground text-sm">Upload Document</p>
              <p className="text-xs text-muted-foreground mt-1">PDF, DOCX, PPTX, up to 50MB</p>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Content</label>
              <Textarea
                value={lesson.content}
                onChange={e => onUpdate({ content: e.target.value })}
                placeholder="Write or paste lesson content here. Supports rich text..."
                rows={12}
              />
            </div>
          </>
        )}

        {lesson.type === 'quiz' && (
          <>
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-foreground text-sm">Quiz Questions</h4>
                <p className="text-xs text-muted-foreground">{lesson.quizQuestions.length} questions</p>
              </div>
              <Button size="sm" variant="outline" onClick={onAddQuestion}>
                <Plus className="h-3.5 w-3.5 mr-1" /> Add Question
              </Button>
            </div>

            {lesson.quizQuestions.length === 0 && (
              <div className="border-2 border-dashed border-border rounded-xl p-8 text-center">
                <HelpCircle className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">No questions yet. Click "Add Question" to start building your quiz.</p>
              </div>
            )}

            <div className="space-y-4">
              {lesson.quizQuestions.map((q, qIdx) => (
                <div key={q.id} className="bg-muted/30 rounded-xl p-4 border border-border space-y-3">
                  <div className="flex items-start gap-2">
                    <span className="text-xs font-bold text-muted-foreground mt-2.5 w-6">Q{qIdx + 1}</span>
                    <Input
                      value={q.question}
                      onChange={e => onUpdateQuestion(q.id, { question: e.target.value })}
                      placeholder="Enter your question..."
                      className="flex-1"
                    />
                    <button onClick={() => onRemoveQuestion(q.id)} className="text-muted-foreground hover:text-destructive p-1 mt-1">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="space-y-2 ml-8">
                    {q.options.map((opt, optIdx) => (
                      <div key={optIdx} className="flex items-center gap-2">
                        <button
                          onClick={() => onUpdateQuestion(q.id, { correctIndex: optIdx })}
                          className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                            q.correctIndex === optIdx
                              ? 'border-primary bg-primary text-primary-foreground'
                              : 'border-muted-foreground/30 hover:border-primary/50'
                          }`}
                        >
                          {q.correctIndex === optIdx && <span className="text-[8px] font-bold">✓</span>}
                        </button>
                        <Input
                          value={opt}
                          onChange={e => {
                            const newOptions = [...q.options];
                            newOptions[optIdx] = e.target.value;
                            onUpdateQuestion(q.id, { options: newOptions });
                          }}
                          placeholder={`Option ${String.fromCharCode(65 + optIdx)}`}
                          className="flex-1 h-9 text-sm"
                        />
                      </div>
                    ))}
                    <p className="text-[10px] text-muted-foreground ml-7">Click the circle to mark the correct answer</p>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {lesson.type === 'assignment' && (
          <>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Assignment Instructions</label>
              <Textarea
                value={lesson.assignmentDescription}
                onChange={e => onUpdate({ assignmentDescription: e.target.value })}
                placeholder="Describe the assignment, requirements, deliverables, and grading criteria..."
                rows={8}
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-1.5 block">Duration / Time Limit</label>
                <Input
                  value={lesson.duration}
                  onChange={e => onUpdate({ duration: e.target.value })}
                  placeholder="e.g. 60 minutes or 1 week"
                />
              </div>
            </div>
            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <Upload className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Upload reference files (optional)</p>
              <p className="text-xs text-muted-foreground/60 mt-0.5">PDF, ZIP, images, up to 100MB</p>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default CourseBuilderPage;
