import { Search, Plus, Filter, Clock, FileText, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const exams = [
  { id: 'EX001', title: 'React Midterm Exam', course: 'Advanced React', date: 'Mar 20, 2026', duration: '90 min', questions: 50, attempts: 42, avgScore: 78, status: 'Upcoming' },
  { id: 'EX002', title: 'Python Final Assessment', course: 'Data Science', date: 'Mar 22, 2026', duration: '120 min', questions: 80, attempts: 0, avgScore: 0, status: 'Scheduled' },
  { id: 'EX003', title: 'Design Principles Quiz', course: 'UI/UX Design', date: 'Mar 8, 2026', duration: '45 min', questions: 30, attempts: 55, avgScore: 85, status: 'Completed' },
  { id: 'EX004', title: 'ML Algorithms Test', course: 'Machine Learning', date: 'Mar 25, 2026', duration: '120 min', questions: 60, attempts: 0, avgScore: 0, status: 'Draft' },
  { id: 'EX005', title: 'Cloud Certification Mock', course: 'Cloud Architecture', date: 'Mar 5, 2026', duration: '180 min', questions: 100, attempts: 30, avgScore: 72, status: 'Completed' },
];

const ExamsPage = () => {
  const [search, setSearch] = useState('');
  const filtered = exams.filter(e => e.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Exams & Tests</h1>
          <p className="text-sm text-muted-foreground">Create and manage online examinations</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Create Exam</Button>
      </div>
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search exams..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>
      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                {['Exam', 'Course', 'Date', 'Duration', 'Questions', 'Attempts', 'Avg Score', 'Status'].map(h => (
                  <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => (
                <tr key={e.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-foreground">{e.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{e.course}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{e.date}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground flex items-center gap-1"><Clock className="h-3 w-3" />{e.duration}</td>
                  <td className="px-4 py-3 text-sm text-foreground font-medium">{e.questions}</td>
                  <td className="px-4 py-3 text-sm text-foreground">{e.attempts}</td>
                  <td className="px-4 py-3 text-sm font-medium text-foreground">{e.avgScore > 0 ? `${e.avgScore}%` : '-'}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      e.status === 'Completed' ? 'bg-primary/10 text-primary' :
                      e.status === 'Upcoming' ? 'bg-secondary/10 text-secondary' :
                      e.status === 'Scheduled' ? 'bg-accent/20 text-accent-foreground' :
                      'bg-muted text-muted-foreground'
                    }`}>{e.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ExamsPage;
