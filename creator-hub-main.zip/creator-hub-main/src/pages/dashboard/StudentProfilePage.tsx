import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, MapPin, Calendar, BookOpen, ClipboardList, Award, TrendingUp, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, BarChart, Bar } from 'recharts';

const student = {
  name: 'Alex Thompson',
  email: 'alex@mail.com',
  phone: '+1 (555) 123-4567',
  location: 'San Francisco, CA',
  enrolled: 'Sep 15, 2025',
  id: 'STU001',
  status: 'Active',
  overallProgress: 78,
  totalCourses: 5,
  completedCourses: 3,
  certificates: 3,
  avgScore: 85,
  totalHours: 120,
  attendance: 94,
};

const enrolledCourses = [
  { title: 'Advanced React & TypeScript', progress: 65, grade: 'A-', status: 'In Progress', instructor: 'Dr. Emily Chen' },
  { title: 'Python for Data Science', progress: 100, grade: 'A+', status: 'Completed', instructor: 'Prof. Robert Miller' },
  { title: 'UI/UX Design Masterclass', progress: 100, grade: 'A', status: 'Completed', instructor: 'Mark Stevens' },
  { title: 'Machine Learning Fundamentals', progress: 35, grade: 'B+', status: 'In Progress', instructor: 'Dr. Sarah Johnson' },
  { title: 'Cloud Architecture with AWS', progress: 100, grade: 'A-', status: 'Completed', instructor: 'Lisa Park' },
];

const assignments = [
  { title: 'React Component Architecture', course: 'Advanced React', dueDate: 'Mar 15, 2026', score: null, status: 'Pending' },
  { title: 'Data Visualization Project', course: 'Data Science', dueDate: 'Feb 28, 2026', score: 92, status: 'Submitted' },
  { title: 'Wireframing Exercise', course: 'UI/UX Design', dueDate: 'Feb 20, 2026', score: 88, status: 'Graded' },
  { title: 'Neural Network Implementation', course: 'Machine Learning', dueDate: 'Mar 22, 2026', score: null, status: 'Pending' },
  { title: 'Cloud Deployment Lab', course: 'Cloud Architecture', dueDate: 'Feb 10, 2026', score: 95, status: 'Graded' },
  { title: 'Python Data Structures', course: 'Data Science', dueDate: 'Jan 15, 2026', score: 90, status: 'Graded' },
];

const progressData = [
  { month: 'Oct', score: 72 },
  { month: 'Nov', score: 75 },
  { month: 'Dec', score: 78 },
  { month: 'Jan', score: 82 },
  { month: 'Feb', score: 85 },
  { month: 'Mar', score: 88 },
];

const skillData = [
  { subject: 'React', A: 90 },
  { subject: 'Python', A: 85 },
  { subject: 'Design', A: 75 },
  { subject: 'ML/AI', A: 60 },
  { subject: 'Cloud', A: 80 },
  { subject: 'Data Analysis', A: 78 },
];

const weeklyHours = [
  { day: 'Mon', hours: 3.5 },
  { day: 'Tue', hours: 2.0 },
  { day: 'Wed', hours: 4.0 },
  { day: 'Thu', hours: 1.5 },
  { day: 'Fri', hours: 3.0 },
  { day: 'Sat', hours: 5.0 },
  { day: 'Sun', hours: 2.5 },
];

const StudentProfilePage = () => {
  return (
    <div className="space-y-6">
      <Link to="/dashboard/students" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1">
        <ArrowLeft className="h-4 w-4" /> Back to Students
      </Link>

      {/* Profile Header */}
      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="h-24 gradient-dark" />
        <div className="px-6 pb-6 -mt-10">
          <div className="flex flex-col sm:flex-row items-start gap-4">
            <div className="w-20 h-20 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-2xl border-4 border-card shadow-card">
              {student.name.charAt(0)}
            </div>
            <div className="flex-1 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h1 className="font-display text-xl font-bold text-foreground">{student.name}</h1>
                  <p className="text-sm text-muted-foreground">Student ID: {student.id}</p>
                </div>
                <span className="text-xs px-3 py-1 rounded-full bg-primary/10 text-primary font-medium self-start">{student.status}</span>
              </div>
              <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Mail className="h-3.5 w-3.5" />{student.email}</span>
                <span className="flex items-center gap-1"><Phone className="h-3.5 w-3.5" />{student.phone}</span>
                <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{student.location}</span>
                <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" />Enrolled: {student.enrolled}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { icon: BookOpen, label: 'Courses', value: `${student.completedCourses}/${student.totalCourses}`, color: 'bg-primary/10 text-primary' },
          { icon: TrendingUp, label: 'Progress', value: `${student.overallProgress}%`, color: 'bg-secondary/10 text-secondary' },
          { icon: Award, label: 'Certificates', value: student.certificates.toString(), color: 'bg-accent/20 text-accent-foreground' },
          { icon: ClipboardList, label: 'Avg Score', value: `${student.avgScore}%`, color: 'bg-primary/10 text-primary' },
          { icon: Clock, label: 'Total Hours', value: student.totalHours.toString(), color: 'bg-secondary/10 text-secondary' },
          { icon: Calendar, label: 'Attendance', value: `${student.attendance}%`, color: 'bg-accent/20 text-accent-foreground' },
        ].map(s => (
          <div key={s.label} className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
            <div className={`w-9 h-9 rounded-lg ${s.color} flex items-center justify-center mx-auto mb-2`}>
              <s.icon className="h-4 w-4" />
            </div>
            <p className="font-display text-lg font-bold text-foreground">{s.value}</p>
            <p className="text-[10px] text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Main Content */}
      <Tabs defaultValue="courses" className="space-y-4">
        <TabsList className="bg-muted">
          <TabsTrigger value="courses">Enrolled Courses</TabsTrigger>
          <TabsTrigger value="assignments">Assignments</TabsTrigger>
          <TabsTrigger value="progress">Progress & Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="courses" className="space-y-3">
          {enrolledCourses.map(c => (
            <div key={c.title} className="bg-card rounded-xl p-5 shadow-card border border-border hover:shadow-card-hover transition-shadow">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${c.status === 'Completed' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'}`}>
                    {c.status === 'Completed' ? <CheckCircle className="h-5 w-5" /> : <BookOpen className="h-5 w-5" />}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{c.title}</p>
                    <p className="text-xs text-muted-foreground">{c.instructor}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-sm font-bold text-foreground">{c.grade}</p>
                    <p className="text-[10px] text-muted-foreground">Grade</p>
                  </div>
                  <div className="w-24">
                    <div className="flex justify-between text-[10px] text-muted-foreground mb-0.5">
                      <span>Progress</span><span>{c.progress}%</span>
                    </div>
                    <Progress value={c.progress} className="h-1.5" />
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full font-medium ${c.status === 'Completed' ? 'bg-primary/10 text-primary' : 'bg-secondary/10 text-secondary'}`}>{c.status}</span>
                </div>
              </div>
            </div>
          ))}
        </TabsContent>

        <TabsContent value="assignments" className="space-y-2">
          <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    {['Assignment', 'Course', 'Due Date', 'Score', 'Status'].map(h => (
                      <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {assignments.map(a => (
                    <tr key={a.title} className="border-b border-border hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-foreground">{a.title}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{a.course}</td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{a.dueDate}</td>
                      <td className="px-4 py-3 text-sm font-medium text-foreground">{a.score !== null ? `${a.score}%` : '-'}</td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                          a.status === 'Graded' ? 'bg-primary/10 text-primary' :
                          a.status === 'Submitted' ? 'bg-secondary/10 text-secondary' :
                          'bg-accent/20 text-accent-foreground'
                        }`}>{a.status}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <div className="bg-card rounded-xl p-6 shadow-card border border-border">
              <h3 className="font-display font-semibold text-foreground mb-4">Score Progression</h3>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
                  <XAxis dataKey="month" stroke="hsl(215,15%,47%)" fontSize={12} />
                  <YAxis stroke="hsl(215,15%,47%)" fontSize={12} domain={[60, 100]} />
                  <Tooltip />
                  <Area type="monotone" dataKey="score" stroke="hsl(350,76%,57%)" fill="hsl(350,76%,57%,0.1)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-card border border-border">
              <h3 className="font-display font-semibold text-foreground mb-4">Skill Assessment</h3>
              <ResponsiveContainer width="100%" height={250}>
                <RadarChart data={skillData}>
                  <PolarGrid stroke="hsl(220,15%,90%)" />
                  <PolarAngleAxis dataKey="subject" stroke="hsl(215,15%,47%)" fontSize={11} />
                  <PolarRadiusAxis stroke="hsl(220,15%,90%)" fontSize={10} domain={[0, 100]} />
                  <Radar dataKey="A" stroke="hsl(214,55%,26%)" fill="hsl(214,55%,26%,0.2)" strokeWidth={2} />
                </RadarChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-card rounded-xl p-6 shadow-card border border-border lg:col-span-2">
              <h3 className="font-display font-semibold text-foreground mb-4">Weekly Study Hours</h3>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={weeklyHours}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
                  <XAxis dataKey="day" stroke="hsl(215,15%,47%)" fontSize={12} />
                  <YAxis stroke="hsl(215,15%,47%)" fontSize={12} />
                  <Tooltip />
                  <Bar dataKey="hours" fill="hsl(350,76%,57%)" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default StudentProfilePage;
