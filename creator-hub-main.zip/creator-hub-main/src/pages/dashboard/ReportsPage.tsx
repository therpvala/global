import { BarChart3, Download, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const enrollmentData = [
  { month: 'Sep', count: 120 }, { month: 'Oct', count: 145 }, { month: 'Nov', count: 160 },
  { month: 'Dec', count: 130 }, { month: 'Jan', count: 180 }, { month: 'Feb', count: 210 },
];
const courseDistribution = [
  { name: 'Web Dev', value: 35 }, { name: 'Data Science', value: 25 },
  { name: 'Design', value: 20 }, { name: 'Cloud', value: 12 }, { name: 'Security', value: 8 },
];
const COLORS = ['hsl(350,76%,57%)', 'hsl(214,55%,26%)', 'hsl(43,100%,69%)', 'hsl(215,80%,12%)', 'hsl(350,76%,40%)'];

const reportCards = [
  { label: 'Total Students', value: '3,892', change: '+22%' },
  { label: 'Active Courses', value: '248', change: '+12%' },
  { label: 'Revenue (MTD)', value: '$45,280', change: '+18%' },
  { label: 'Completion Rate', value: '78%', change: '+5%' },
];

const ReportsPage = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Reports</h1>
          <p className="text-sm text-muted-foreground">Comprehensive platform reports</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Filter className="h-4 w-4 mr-2" />Filter</Button>
          <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" />Export</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {reportCards.map(r => (
          <div key={r.label} className="bg-card rounded-xl p-5 shadow-card border border-border">
            <p className="text-sm text-muted-foreground">{r.label}</p>
            <p className="font-display text-2xl font-bold text-foreground mt-1">{r.value}</p>
            <span className="text-xs text-primary font-medium">{r.change}</span>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Student Enrollment Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={enrollmentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
              <XAxis dataKey="month" stroke="hsl(215,15%,47%)" fontSize={12} />
              <YAxis stroke="hsl(215,15%,47%)" fontSize={12} />
              <Tooltip />
              <Bar dataKey="count" fill="hsl(350,76%,57%)" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Course Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={courseDistribution} cx="50%" cy="50%" innerRadius={60} outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {courseDistribution.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default ReportsPage;
