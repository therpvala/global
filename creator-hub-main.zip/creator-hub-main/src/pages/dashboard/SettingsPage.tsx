import { Settings as SettingsIcon, User, Bell, Shield, Palette, Globe, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const SettingsPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">Manage system configuration</p>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="bg-muted">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
            <h3 className="font-display font-semibold text-foreground flex items-center gap-2"><Globe className="h-4 w-4" />Platform Settings</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <div><Label>Platform Name</Label><Input defaultValue="E-Learning Content Provider" className="mt-1.5" /></div>
              <div><Label>Contact Email</Label><Input defaultValue="info@elearnprovider.com" className="mt-1.5" /></div>
              <div><Label>Default Language</Label><Input defaultValue="English" className="mt-1.5" /></div>
              <div><Label>Timezone</Label><Input defaultValue="UTC-8 (Pacific Time)" className="mt-1.5" /></div>
            </div>
            <Button className="gradient-primary text-primary-foreground">Save Changes</Button>
          </div>

          <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
            <h3 className="font-display font-semibold text-foreground flex items-center gap-2"><Database className="h-4 w-4" />Data Management</h3>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-foreground">Auto Backup</p><p className="text-xs text-muted-foreground">Daily automatic database backups</p></div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-foreground">Data Retention</p><p className="text-xs text-muted-foreground">Keep deleted records for 30 days</p></div>
              <Switch defaultChecked />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
            <h3 className="font-display font-semibold text-foreground flex items-center gap-2"><Bell className="h-4 w-4" />Notification Preferences</h3>
            {['Email Notifications', 'SMS Alerts', 'Push Notifications', 'Assignment Reminders', 'Payment Alerts', 'Course Updates'].map(n => (
              <div key={n} className="flex items-center justify-between py-2">
                <p className="text-sm text-foreground">{n}</p>
                <Switch defaultChecked />
              </div>
            ))}
            <Button className="gradient-primary text-primary-foreground">Save Preferences</Button>
          </div>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
            <h3 className="font-display font-semibold text-foreground flex items-center gap-2"><Shield className="h-4 w-4" />Security Settings</h3>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-foreground">Two-Factor Authentication</p><p className="text-xs text-muted-foreground">Add extra security to your account</p></div>
              <Switch />
            </div>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-foreground">Session Timeout</p><p className="text-xs text-muted-foreground">Auto logout after 30 minutes of inactivity</p></div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between py-2">
              <div><p className="text-sm font-medium text-foreground">IP Whitelist</p><p className="text-xs text-muted-foreground">Restrict access to specific IP addresses</p></div>
              <Switch />
            </div>
            <Button className="gradient-primary text-primary-foreground">Save Security Settings</Button>
          </div>
        </TabsContent>

        <TabsContent value="appearance" className="space-y-6">
          <div className="bg-card rounded-xl p-6 shadow-card border border-border space-y-4">
            <h3 className="font-display font-semibold text-foreground flex items-center gap-2"><Palette className="h-4 w-4" />Theme & Appearance</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl border-2 border-primary bg-muted cursor-pointer">
                <div className="h-20 bg-background rounded-lg mb-2 border border-border" />
                <p className="text-sm font-medium text-foreground text-center">Light Mode</p>
              </div>
              <div className="p-4 rounded-xl border-2 border-border bg-muted cursor-pointer">
                <div className="h-20 bg-deep-azure rounded-lg mb-2" />
                <p className="text-sm font-medium text-foreground text-center">Dark Mode</p>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SettingsPage;
