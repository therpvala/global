import { Bell, Check, MessageCircle, ClipboardList, BookOpen, DollarSign, Clock, Info, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNotifications, NotificationType } from '@/contexts/NotificationContext';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const typeIcons: Record<NotificationType, React.ElementType> = {
  discussion: MessageCircle, assignment: ClipboardList, course: BookOpen,
  payment: DollarSign, reminder: Clock, system: Info,
};
const typeBg: Record<NotificationType, string> = {
  discussion: 'bg-primary/10 text-primary', assignment: 'bg-crimson/10 text-crimson',
  course: 'bg-secondary/10 text-secondary', payment: 'bg-accent/20 text-accent-foreground',
  reminder: 'bg-accent/20 text-accent-foreground', system: 'bg-muted text-muted-foreground',
};

const timeAgo = (date: Date) => {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
};

const NotificationsPage = () => {
  const { notifications, unreadCount, markAsRead, markAllAsRead, clearNotification } = useNotifications();
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Notifications</h1>
          <p className="text-sm text-muted-foreground">Stay updated with latest activities • {unreadCount} unread</p>
        </div>
        <Button variant="outline" size="sm" onClick={markAllAsRead} disabled={unreadCount === 0}>
          <Check className="h-4 w-4 mr-2" />Mark All Read
        </Button>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="bg-muted">
          <TabsTrigger value="all">All ({notifications.length})</TabsTrigger>
          <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
          <TabsTrigger value="discussion">Discussions</TabsTrigger>
          <TabsTrigger value="assignment">Assignments</TabsTrigger>
          <TabsTrigger value="course">Courses</TabsTrigger>
        </TabsList>

        {['all', 'unread', 'discussion', 'assignment', 'course'].map(tab => (
          <TabsContent key={tab} value={tab} className="space-y-2">
            <AnimatePresence>
              {notifications
                .filter(n =>
                  tab === 'all' ? true :
                  tab === 'unread' ? !n.read :
                  n.type === tab
                )
                .map(n => {
                  const Icon = typeIcons[n.type] || Bell;
                  return (
                    <motion.div
                      key={n.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 10 }}
                      layout
                      onClick={() => {
                        markAsRead(n.id);
                        if (n.link) navigate(n.link);
                      }}
                      className={`bg-card rounded-xl p-4 shadow-card border border-border flex items-start gap-4 hover:shadow-card-hover transition-shadow cursor-pointer group ${!n.read ? 'border-l-4 border-l-primary' : ''}`}
                    >
                      <div className={`w-10 h-10 rounded-lg ${typeBg[n.type]} flex items-center justify-center flex-shrink-0`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${!n.read ? 'font-semibold' : 'font-medium'} text-foreground`}>{n.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{n.description}</p>
                        <p className="text-[10px] text-muted-foreground mt-1">{timeAgo(n.timestamp)}</p>
                      </div>
                      <div className="flex items-center gap-1">
                        {!n.read && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />}
                        <button
                          onClick={e => { e.stopPropagation(); clearNotification(n.id); }}
                          className="text-muted-foreground/30 hover:text-destructive p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
            </AnimatePresence>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default NotificationsPage;
