import { MessageSquare, Plus, ThumbsUp, MessageCircle, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const threads = [
  { id: 1, title: 'Best practices for React state management?', author: 'Alex Thompson', category: 'Web Development', replies: 24, likes: 45, time: '3 hours ago', solved: true },
  { id: 2, title: 'How to handle large datasets in Python?', author: 'Maria Garcia', category: 'Data Science', replies: 18, likes: 32, time: '5 hours ago', solved: false },
  { id: 3, title: 'Figma vs Sketch: Which is better for prototyping?', author: 'James Wilson', category: 'Design', replies: 35, likes: 67, time: '1 day ago', solved: true },
  { id: 4, title: 'Understanding neural network backpropagation', author: 'Sarah Lee', category: 'AI/ML', replies: 12, likes: 28, time: '1 day ago', solved: false },
  { id: 5, title: 'AWS Lambda vs Azure Functions comparison', author: 'David Brown', category: 'Cloud', replies: 22, likes: 41, time: '2 days ago', solved: true },
];

const ForumPage = () => {
  const [search, setSearch] = useState('');
  const filtered = threads.filter(t => t.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Discussion Forum</h1>
          <p className="text-sm text-muted-foreground">Ask questions and share knowledge</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />New Thread</Button>
      </div>
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search discussions..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
      </div>
      <div className="space-y-3">
        {filtered.map(t => (
          <div key={t.id} className="bg-card rounded-xl p-5 shadow-card border border-border hover:shadow-card-hover transition-shadow">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-bold text-sm flex-shrink-0">{t.author.charAt(0)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-foreground">{t.title}</h3>
                  {t.solved && <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-medium">Solved</span>}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{t.author}</span>
                  <span className="px-2 py-0.5 bg-muted rounded-full">{t.category}</span>
                  <span>{t.time}</span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><ThumbsUp className="h-3.5 w-3.5" />{t.likes}</span>
                <span className="flex items-center gap-1"><MessageCircle className="h-3.5 w-3.5" />{t.replies}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ForumPage;
