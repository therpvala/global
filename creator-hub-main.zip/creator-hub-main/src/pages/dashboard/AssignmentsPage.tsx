import { useState } from 'react';
import { Search, Plus, Filter, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const assignments = [
  { id: 'ASG001', title: 'React Component Architecture', course: 'Advanced React', dueDate: 'Mar 15, 2026', submissions: 45, total: 60, status: 'Active' },
  { id: 'ASG002', title: 'Data Analysis Project', course: 'Python for Data Science', dueDate: 'Mar 18, 2026', submissions: 72, total: 80, status: 'Active' },
  { id: 'ASG003', title: 'Wireframing Exercise', course: 'UI/UX Design', dueDate: 'Mar 10, 2026', submissions: 55, total: 55, status: 'Completed' },
  { id: 'ASG004', title: 'Neural Network Implementation', course: 'Machine Learning', dueDate: 'Mar 22, 2026', submissions: 30, total: 50, status: 'Active' },
  { id: 'ASG005', title: 'Cloud Deployment Lab', course: 'Cloud Architecture', dueDate: 'Mar 12, 2026', submissions: 28, total: 35, status: 'Overdue' },
  { id: 'ASG006', title: 'Security Audit Report', course: 'Cybersecurity', dueDate: 'Mar 25, 2026', submissions: 15, total: 40, status: 'Active' },
];

const AssignmentsPage = () => {
  const [search, setSearch] = useState('');
  const filtered = assignments.filter(a => a.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Assignments</h1>
          <p className="text-sm text-muted-foreground">Create and track student assignments</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Create Assignment</Button>
      </div>
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search assignments..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>
      <div className="space-y-3">
        {filtered.map(a => (
          <div key={a.id} className="bg-card rounded-xl p-5 shadow-card border border-border hover:shadow-card-hover transition-shadow flex flex-col sm:flex-row sm:items-center gap-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              a.status === 'Completed' ? 'bg-primary/10 text-primary' :
              a.status === 'Overdue' ? 'bg-destructive/10 text-destructive' :
              'bg-secondary/10 text-secondary'
            }`}>
              {a.status === 'Completed' ? <CheckCircle className="h-5 w-5" /> :
               a.status === 'Overdue' ? <AlertCircle className="h-5 w-5" /> :
               <Clock className="h-5 w-5" />}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-foreground">{a.title}</h3>
              <p className="text-xs text-muted-foreground">{a.course} • Due: {a.dueDate}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className="font-display font-bold text-foreground">{a.submissions}/{a.total}</p>
                <p className="text-[10px] text-muted-foreground">Submissions</p>
              </div>
              <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full gradient-primary rounded-full" style={{ width: `${(a.submissions / a.total) * 100}%` }} />
              </div>
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                a.status === 'Completed' ? 'bg-primary/10 text-primary' :
                a.status === 'Overdue' ? 'bg-destructive/10 text-destructive' :
                'bg-secondary/10 text-secondary'
              }`}>{a.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AssignmentsPage;
