import { Search, Plus, Filter, FileText, Video, BookOpen, Download, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const content = [
  { id: 1, title: 'React Fundamentals Guide', type: 'PDF', size: '2.4 MB', course: 'Web Development', downloads: 342, date: '2025-12-15' },
  { id: 2, title: 'Python Data Structures', type: 'Video', size: '156 MB', course: 'Data Science', downloads: 567, date: '2025-11-20' },
  { id: 3, title: 'Design Thinking E-Book', type: 'E-Book', size: '8.2 MB', course: 'UI/UX Design', downloads: 234, date: '2025-10-10' },
  { id: 4, title: 'ML Algorithms Explained', type: 'Video', size: '280 MB', course: 'Machine Learning', downloads: 412, date: '2026-01-05' },
  { id: 5, title: 'AWS Best Practices', type: 'PDF', size: '4.1 MB', course: 'Cloud Computing', downloads: 189, date: '2026-01-20' },
  { id: 6, title: 'Security Handbook', type: 'E-Book', size: '5.6 MB', course: 'Cybersecurity', downloads: 156, date: '2026-02-01' },
  { id: 7, title: 'CSS Animation Workshop', type: 'Video', size: '210 MB', course: 'Web Development', downloads: 298, date: '2026-02-15' },
  { id: 8, title: 'SQL Quick Reference', type: 'PDF', size: '1.2 MB', course: 'Data Science', downloads: 445, date: '2025-09-30' },
];

const typeIcons: Record<string, React.ElementType> = { PDF: FileText, Video: Video, 'E-Book': BookOpen };
const typeColors: Record<string, string> = { PDF: 'bg-primary/10 text-primary', Video: 'bg-secondary/10 text-secondary', 'E-Book': 'bg-accent/20 text-accent-foreground' };

const ContentLibraryPage = () => {
  const [search, setSearch] = useState('');
  const filtered = content.filter(c => c.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Content Library</h1>
          <p className="text-sm text-muted-foreground">Videos, PDFs, E-Books and learning resources</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Upload Content</Button>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="bg-muted">
          <TabsTrigger value="all">All ({content.length})</TabsTrigger>
          <TabsTrigger value="pdf">PDFs</TabsTrigger>
          <TabsTrigger value="video">Videos</TabsTrigger>
          <TabsTrigger value="ebook">E-Books</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search content..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {filtered.map(c => {
          const Icon = typeIcons[c.type] || FileText;
          return (
            <div key={c.id} className="bg-card rounded-xl shadow-card border border-border hover:shadow-card-hover transition-shadow overflow-hidden">
              <div className="h-28 bg-muted flex items-center justify-center">
                <Icon className="h-10 w-10 text-muted-foreground/40" />
              </div>
              <div className="p-4">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${typeColors[c.type]}`}>{c.type}</span>
                <h3 className="font-semibold text-sm text-foreground mt-2 mb-1">{c.title}</h3>
                <p className="text-xs text-muted-foreground mb-3">{c.course} • {c.size}</p>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Download className="h-3 w-3" />{c.downloads}</span>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><Eye className="h-3.5 w-3.5" /></Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0"><Download className="h-3.5 w-3.5" /></Button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ContentLibraryPage;
