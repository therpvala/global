import { Play, Clock, Users, Search, Filter, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const videos = [
  { id: 1, title: 'React Hooks Deep Dive', instructor: 'Dr. Emily Chen', duration: '45:30', views: 1240, category: 'Web Development' },
  { id: 2, title: 'Python Pandas Tutorial', instructor: 'Prof. Robert Miller', duration: '62:15', views: 2100, category: 'Data Science' },
  { id: 3, title: 'Figma for Beginners', instructor: 'Mark Stevens', duration: '38:45', views: 890, category: 'Design' },
  { id: 4, title: 'TensorFlow Introduction', instructor: 'Dr. Sarah Johnson', duration: '55:00', views: 1560, category: 'AI/ML' },
  { id: 5, title: 'Docker & Kubernetes', instructor: 'Lisa Park', duration: '72:20', views: 780, category: 'DevOps' },
  { id: 6, title: 'Ethical Hacking Basics', instructor: 'Dr. Ahmed Hassan', duration: '48:10', views: 1100, category: 'Security' },
];

const VideoPortalPage = () => {
  const [search, setSearch] = useState('');
  const filtered = videos.filter(v => v.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Video Portal</h1>
          <p className="text-sm text-muted-foreground">Stream and manage video content</p>
        </div>
      </div>
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search videos..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(v => (
          <div key={v.id} className="bg-card rounded-xl shadow-card border border-border overflow-hidden hover:shadow-card-hover transition-shadow group">
            <div className="h-40 gradient-dark flex items-center justify-center relative cursor-pointer">
              <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary/40 transition-colors">
                <Play className="h-6 w-6 text-primary-foreground ml-1" />
              </div>
              <span className="absolute bottom-2 right-2 text-xs bg-deep-azure/80 text-pale-azure px-2 py-0.5 rounded">{v.duration}</span>
              <span className="absolute top-2 left-2 text-xs bg-secondary/80 text-secondary-foreground px-2 py-0.5 rounded">{v.category}</span>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-foreground mb-1">{v.title}</h3>
              <p className="text-xs text-muted-foreground mb-3">{v.instructor}</p>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Users className="h-3 w-3" />{v.views} views</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VideoPortalPage;
