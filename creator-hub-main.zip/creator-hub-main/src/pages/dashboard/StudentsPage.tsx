import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, MoreVertical, Download, Trash2, Edit } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';
import AddStudentDialog from '@/components/ui/AddStudentDialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

interface Student {
  id: string; name: string; email: string; course: string; status: string; progress: number; joined: string;
}

const initialStudents: Student[] = [
  { id: 'STU001', name: 'Alex Thompson', email: 'alex@mail.com', course: 'Web Development', status: 'Active', progress: 78, joined: '2025-09-15' },
  { id: 'STU002', name: 'Maria Garcia', email: 'maria@mail.com', course: 'Data Science', status: 'Active', progress: 92, joined: '2025-08-20' },
  { id: 'STU003', name: 'James Wilson', email: 'james@mail.com', course: 'UI/UX Design', status: 'Inactive', progress: 45, joined: '2025-10-01' },
  { id: 'STU004', name: 'Sarah Lee', email: 'sarah@mail.com', course: 'Python Basics', status: 'Active', progress: 88, joined: '2025-07-12' },
  { id: 'STU005', name: 'David Brown', email: 'david@mail.com', course: 'Machine Learning', status: 'Active', progress: 65, joined: '2025-11-05' },
  { id: 'STU006', name: 'Emma Davis', email: 'emma@mail.com', course: 'React Advanced', status: 'On Leave', progress: 55, joined: '2025-06-18' },
  { id: 'STU007', name: 'Chris Johnson', email: 'chris@mail.com', course: 'Cloud Computing', status: 'Active', progress: 71, joined: '2025-09-22' },
  { id: 'STU008', name: 'Lisa Wang', email: 'lisa@mail.com', course: 'Cybersecurity', status: 'Active', progress: 83, joined: '2025-08-30' },
];

const StudentsPage = () => {
  const [search, setSearch] = useState('');
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const filtered = students.filter(s => s.name.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = (data: { name: string; email: string; course: string }) => {
    const newId = `STU${String(students.length + 1).padStart(3, '0')}`;
    setStudents(prev => [...prev, { ...data, id: newId, status: 'Active', progress: 0, joined: new Date().toISOString().split('T')[0] }]);
  };

  const handleDelete = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
    toast.success('Student removed');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Students</h1>
          <p className="text-sm text-muted-foreground">Manage student admissions, profiles and progress</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" />Export</Button>
          <AddStudentDialog onAdd={handleAdd} />
        </div>
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search students..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">ID</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">Student</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3 hidden md:table-cell">Course</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">Status</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3 hidden sm:table-cell">Progress</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3 hidden lg:table-cell">Joined</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <motion.tr key={s.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-b border-border hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-sm text-muted-foreground">{s.id}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-xs font-bold">{s.name.charAt(0)}</div>
                      <div>
                        <Link to={`/dashboard/students/${s.id}`} className="text-sm font-medium text-foreground hover:text-primary transition-colors">{s.name}</Link>
                        <p className="text-xs text-muted-foreground">{s.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-foreground hidden md:table-cell">{s.course}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      s.status === 'Active' ? 'bg-primary/10 text-primary' :
                      s.status === 'Inactive' ? 'bg-muted text-muted-foreground' :
                      'bg-accent/20 text-accent-foreground'
                    }`}>{s.status}</span>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden max-w-[100px]">
                        <div className="h-full rounded-full gradient-primary" style={{ width: `${s.progress}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground">{s.progress}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground hidden lg:table-cell">{s.joined}</td>
                  <td className="px-4 py-3">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="text-muted-foreground hover:text-foreground"><MoreVertical className="h-4 w-4" /></button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDelete(s.id)} className="text-destructive"><Trash2 className="h-4 w-4 mr-2" />Remove</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StudentsPage;
