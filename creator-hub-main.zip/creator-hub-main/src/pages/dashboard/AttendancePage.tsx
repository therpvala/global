import { Calendar as CalIcon, ChevronLeft, ChevronRight, Check, X, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

const attendanceData = [
  { name: 'Alex Thompson', course: 'Web Development', mon: 'present', tue: 'present', wed: 'absent', thu: 'present', fri: 'late' },
  { name: 'Maria Garcia', course: 'Data Science', mon: 'present', tue: 'present', wed: 'present', thu: 'present', fri: 'present' },
  { name: 'James Wilson', course: 'UI/UX Design', mon: 'absent', tue: 'present', wed: 'present', thu: 'absent', fri: 'present' },
  { name: 'Sarah Lee', course: 'Python Basics', mon: 'present', tue: 'late', wed: 'present', thu: 'present', fri: 'present' },
  { name: 'David Brown', course: 'Machine Learning', mon: 'present', tue: 'present', wed: 'present', thu: 'late', fri: 'present' },
  { name: 'Emma Davis', course: 'React Advanced', mon: 'absent', tue: 'absent', wed: 'present', thu: 'present', fri: 'present' },
];

const statusIcon = (s: string) => {
  if (s === 'present') return <Check className="h-4 w-4 text-primary" />;
  if (s === 'absent') return <X className="h-4 w-4 text-destructive" />;
  return <Clock className="h-4 w-4 text-accent-foreground" />;
};

const statusBg = (s: string) => {
  if (s === 'present') return 'bg-primary/10';
  if (s === 'absent') return 'bg-destructive/10';
  return 'bg-accent/20';
};

const AttendancePage = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Attendance</h1>
          <p className="text-sm text-muted-foreground">Track daily attendance records</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon"><ChevronLeft className="h-4 w-4" /></Button>
          <span className="text-sm font-medium text-foreground px-3">March 3 - 7, 2026</span>
          <Button variant="outline" size="icon"><ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-primary">92%</p>
          <p className="text-xs text-muted-foreground">Overall Attendance</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-secondary">28</p>
          <p className="text-xs text-muted-foreground">Present Today</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-destructive">2</p>
          <p className="text-xs text-muted-foreground">Absent Today</p>
        </div>
      </div>

      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/50">
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">Student</th>
                <th className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">Course</th>
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map(d => (
                  <th key={d} className="text-center text-xs font-semibold text-muted-foreground px-4 py-3">{d}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {attendanceData.map(a => (
                <tr key={a.name} className="border-b border-border hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-xs font-bold">{a.name.charAt(0)}</div>
                      <span className="text-sm font-medium text-foreground">{a.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{a.course}</td>
                  {[a.mon, a.tue, a.wed, a.thu, a.fri].map((s, i) => (
                    <td key={i} className="px-4 py-3 text-center">
                      <div className={`w-8 h-8 rounded-lg ${statusBg(s)} flex items-center justify-center mx-auto`}>
                        {statusIcon(s)}
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AttendancePage;
