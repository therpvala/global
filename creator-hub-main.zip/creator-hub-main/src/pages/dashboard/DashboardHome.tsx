import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { BookOpen, Users, FileText, TrendingUp, Award, DollarSign, ClipboardList, Calendar, Video, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area } from 'recharts';

const barData = [
  { name: 'Jan', courses: 30, workshops: 12 },
  { name: 'Feb', courses: 45, workshops: 18 },
  { name: 'Mar', courses: 38, workshops: 22 },
  { name: 'Apr', courses: 52, workshops: 28 },
  { name: 'May', courses: 60, workshops: 35 },
  { name: 'Jun', courses: 48, workshops: 30 },
];
const lineData = [
  { name: 'Week 1', engagement: 65, completion: 45 },
  { name: 'Week 2', engagement: 72, completion: 52 },
  { name: 'Week 3', engagement: 68, completion: 58 },
  { name: 'Week 4', engagement: 80, completion: 65 },
];
const pieData = [
  { name: 'Videos', value: 45 },
  { name: 'PDFs', value: 25 },
  { name: 'E-Books', value: 20 },
  { name: 'Quizzes', value: 10 },
];
const COLORS = ['hsl(350,76%,57%)', 'hsl(214,55%,26%)', 'hsl(43,100%,69%)', 'hsl(215,80%,12%)'];

const recentActivities = [
  { text: 'New course "Advanced React" published', time: '2 hours ago', color: 'bg-primary' },
  { text: 'Student Alex completed "Python Basics"', time: '3 hours ago', color: 'bg-secondary' },
  { text: 'Assignment deadline extended for "Data Science"', time: '5 hours ago', color: 'bg-accent' },
  { text: 'New workshop "UI/UX Design" scheduled', time: '1 day ago', color: 'bg-deep-azure' },
];

const announcements = [
  { title: 'Platform Maintenance', desc: 'Scheduled for March 15, 2026', type: 'info' },
  { title: 'New Feature: AI Grading', desc: 'Auto-grade assignments with AI', type: 'new' },
  { title: 'Webinar: Content Strategy', desc: 'Join us on March 20, 2026', type: 'event' },
];

interface StatCardProps {
  icon: React.ElementType;
  label: string;
  value: string;
  change: string;
  color: string;
  iconBg: string;
}

const StatCard = ({ icon: Icon, label, value, change, color, iconBg }: StatCardProps) => (
  <motion.div whileHover={{ y: -2 }} className="bg-card rounded-xl p-5 shadow-card border border-border">
    <div className="flex items-center justify-between mb-3">
      <div className={`w-10 h-10 rounded-lg ${iconBg} flex items-center justify-center`}>
        <Icon className="h-5 w-5" />
      </div>
      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${color}`}>{change}</span>
    </div>
    <p className="font-display text-2xl font-bold text-foreground">{value}</p>
    <p className="text-sm text-muted-foreground">{label}</p>
  </motion.div>
);

const DashboardHome = () => {
  const { user } = useAuth();
  const role = user?.role || 'student';

  const allStats: StatCardProps[] = [
    { icon: BookOpen, label: 'Total Courses', value: '248', change: '+12%', color: 'bg-primary/10 text-primary', iconBg: 'bg-primary/10 text-primary' },
    { icon: Users, label: 'Active Creators', value: '56', change: '+8%', color: 'bg-secondary/10 text-secondary', iconBg: 'bg-secondary/10 text-secondary' },
    { icon: FileText, label: 'Learning Materials', value: '5,240', change: '+18%', color: 'bg-accent/20 text-accent-foreground', iconBg: 'bg-accent/20 text-accent-foreground' },
    { icon: TrendingUp, label: 'Student Enrollment', value: '3,892', change: '+22%', color: 'bg-primary/10 text-primary', iconBg: 'gradient-primary text-primary-foreground' },
    { icon: ClipboardList, label: 'Assignments', value: '1,456', change: '+5%', color: 'bg-secondary/10 text-secondary', iconBg: 'bg-secondary/10 text-secondary' },
    { icon: Award, label: 'Certificates Issued', value: '2,180', change: '+15%', color: 'bg-accent/20 text-accent-foreground', iconBg: 'bg-accent/20 text-accent-foreground' },
  ];

  const roleStats: Record<string, StatCardProps[]> = {
    superadmin: allStats,
    admin: allStats.slice(0, 5),
    instructor: [allStats[0], allStats[2], allStats[4], allStats[5]],
    student: [
      { icon: BookOpen, label: 'My Courses', value: '12', change: 'Active', color: 'bg-primary/10 text-primary', iconBg: 'bg-primary/10 text-primary' },
      { icon: ClipboardList, label: 'Pending Assignments', value: '5', change: 'Due Soon', color: 'bg-accent/20 text-accent-foreground', iconBg: 'bg-accent/20 text-accent-foreground' },
      { icon: Award, label: 'Certificates', value: '8', change: 'Earned', color: 'bg-secondary/10 text-secondary', iconBg: 'bg-secondary/10 text-secondary' },
      { icon: TrendingUp, label: 'Progress', value: '78%', change: '+5%', color: 'bg-primary/10 text-primary', iconBg: 'gradient-primary text-primary-foreground' },
    ],
    parent: [
      { icon: Users, label: 'Children', value: '2', change: 'Enrolled', color: 'bg-primary/10 text-primary', iconBg: 'bg-primary/10 text-primary' },
      { icon: Calendar, label: 'Attendance', value: '94%', change: 'This Month', color: 'bg-secondary/10 text-secondary', iconBg: 'bg-secondary/10 text-secondary' },
      { icon: ClipboardList, label: 'Assignments Due', value: '3', change: 'Upcoming', color: 'bg-accent/20 text-accent-foreground', iconBg: 'bg-accent/20 text-accent-foreground' },
      { icon: DollarSign, label: 'Fee Status', value: 'Paid', change: '✓', color: 'bg-primary/10 text-primary', iconBg: 'gradient-primary text-primary-foreground' },
    ],
  };

  const stats = roleStats[role] || allStats;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-foreground">Welcome back, {user?.name?.split(' ')[0]}!</h1>
        <p className="text-muted-foreground text-sm">Here's what's happening with your platform today.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {stats.map(s => <StatCard key={s.label} {...s} />)}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Content Usage Analytics</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={barData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
              <XAxis dataKey="name" stroke="hsl(215,15%,47%)" fontSize={12} />
              <YAxis stroke="hsl(215,15%,47%)" fontSize={12} />
              <Tooltip />
              <Bar dataKey="courses" fill="hsl(350,76%,57%)" radius={[4,4,0,0]} />
              <Bar dataKey="workshops" fill="hsl(214,55%,26%)" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Student Progress & Engagement</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={lineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
              <XAxis dataKey="name" stroke="hsl(215,15%,47%)" fontSize={12} />
              <YAxis stroke="hsl(215,15%,47%)" fontSize={12} />
              <Tooltip />
              <Area type="monotone" dataKey="engagement" stroke="hsl(350,76%,57%)" fill="hsl(350,76%,57%,0.1)" strokeWidth={2} />
              <Area type="monotone" dataKey="completion" stroke="hsl(214,55%,26%)" fill="hsl(214,55%,26%,0.1)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Content Distribution */}
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Content Distribution</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Recent Activities */}
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Recent Activities</h3>
          <div className="space-y-4">
            {recentActivities.map((a, i) => (
              <div key={i} className="flex items-start gap-3">
                <div className={`w-2 h-2 rounded-full mt-2 ${a.color} flex-shrink-0`} />
                <div>
                  <p className="text-sm text-foreground">{a.text}</p>
                  <p className="text-xs text-muted-foreground">{a.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Announcements */}
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Announcements</h3>
          <div className="space-y-4">
            {announcements.map((a, i) => (
              <div key={i} className="p-3 rounded-lg bg-muted">
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    a.type === 'new' ? 'bg-primary/10 text-primary' :
                    a.type === 'event' ? 'bg-accent/20 text-accent-foreground' :
                    'bg-secondary/10 text-secondary'
                  }`}>{a.type}</span>
                </div>
                <p className="text-sm font-medium text-foreground">{a.title}</p>
                <p className="text-xs text-muted-foreground">{a.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
