import { TrendingUp, Users, BookOpen, Award, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts';

const engagementData = [
  { day: 'Mon', views: 1200, interactions: 800 },
  { day: 'Tue', views: 1400, interactions: 950 },
  { day: 'Wed', views: 1100, interactions: 700 },
  { day: 'Thu', views: 1600, interactions: 1100 },
  { day: 'Fri', views: 1300, interactions: 900 },
  { day: 'Sat', views: 800, interactions: 500 },
  { day: 'Sun', views: 600, interactions: 350 },
];
const skillData = [
  { subject: 'Programming', A: 85 },
  { subject: 'Design', A: 70 },
  { subject: 'Data Analysis', A: 78 },
  { subject: 'Communication', A: 90 },
  { subject: 'Problem Solving', A: 82 },
  { subject: 'Creativity', A: 75 },
];
const topCourses = [
  { name: 'Advanced React', students: 156, rating: 4.9 },
  { name: 'Python Data Science', students: 289, rating: 4.7 },
  { name: 'UI/UX Masterclass', students: 204, rating: 4.8 },
  { name: 'Machine Learning', students: 178, rating: 4.6 },
  { name: 'Cloud Architecture', students: 120, rating: 4.5 },
];

const AnalyticsPage = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold text-foreground">Analytics</h1>
        <p className="text-sm text-muted-foreground">Deep insights into platform performance</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Users, label: 'Daily Active Users', value: '1,284', change: '+12%', color: 'bg-primary/10 text-primary' },
          { icon: Clock, label: 'Avg. Session Time', value: '42 min', change: '+8%', color: 'bg-secondary/10 text-secondary' },
          { icon: BookOpen, label: 'Content Views', value: '8,456', change: '+25%', color: 'bg-accent/20 text-accent-foreground' },
          { icon: Award, label: 'Course Completions', value: '342', change: '+15%', color: 'bg-primary/10 text-primary' },
        ].map(s => (
          <div key={s.label} className="bg-card rounded-xl p-4 shadow-card border border-border">
            <div className={`w-9 h-9 rounded-lg ${s.color} flex items-center justify-center mb-3`}>
              <s.icon className="h-4 w-4" />
            </div>
            <p className="font-display text-xl font-bold text-foreground">{s.value}</p>
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <span className="text-xs text-primary font-medium">{s.change}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">User Engagement</h3>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={engagementData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
              <XAxis dataKey="day" stroke="hsl(215,15%,47%)" fontSize={12} />
              <YAxis stroke="hsl(215,15%,47%)" fontSize={12} />
              <Tooltip />
              <Area type="monotone" dataKey="views" stroke="hsl(350,76%,57%)" fill="hsl(350,76%,57%,0.1)" strokeWidth={2} />
              <Area type="monotone" dataKey="interactions" stroke="hsl(214,55%,26%)" fill="hsl(214,55%,26%,0.1)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-xl p-6 shadow-card border border-border">
          <h3 className="font-display font-semibold text-foreground mb-4">Skill Distribution</h3>
          <ResponsiveContainer width="100%" height={280}>
            <RadarChart data={skillData}>
              <PolarGrid stroke="hsl(220,15%,90%)" />
              <PolarAngleAxis dataKey="subject" stroke="hsl(215,15%,47%)" fontSize={11} />
              <PolarRadiusAxis stroke="hsl(220,15%,90%)" fontSize={10} />
              <Radar dataKey="A" stroke="hsl(350,76%,57%)" fill="hsl(350,76%,57%,0.2)" strokeWidth={2} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card rounded-xl p-6 shadow-card border border-border">
        <h3 className="font-display font-semibold text-foreground mb-4">Top Performing Courses</h3>
        <div className="space-y-3">
          {topCourses.map((c, i) => (
            <div key={c.name} className="flex items-center gap-4">
              <span className="font-display font-bold text-muted-foreground w-6">#{i + 1}</span>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{c.name}</p>
                <div className="h-2 bg-muted rounded-full mt-1 overflow-hidden">
                  <div className="h-full gradient-primary rounded-full" style={{ width: `${(c.students / 300) * 100}%` }} />
                </div>
              </div>
              <span className="text-sm text-muted-foreground">{c.students} students</span>
              <span className="text-sm font-medium text-accent-foreground">⭐ {c.rating}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPage;
