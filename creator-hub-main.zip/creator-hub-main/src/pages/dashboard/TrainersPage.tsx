import { useState } from 'react';
import { Search, Filter, Star, MoreVertical, Edit, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import AddTrainerDialog from '@/components/ui/AddTrainerDialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

interface Trainer {
  id: string; name: string; specialty: string; courses: number; rating: number; students: number; status: string;
}

const initialTrainers: Trainer[] = [
  { id: 'TR001', name: 'Dr. Emily Chen', specialty: 'Data Science & AI', courses: 12, rating: 4.9, students: 340, status: 'Active' },
  { id: 'TR002', name: 'Prof. Robert Miller', specialty: 'Web Development', courses: 8, rating: 4.7, students: 280, status: 'Active' },
  { id: 'TR003', name: 'Dr. Sarah Johnson', specialty: 'Machine Learning', courses: 6, rating: 4.8, students: 195, status: 'Active' },
  { id: 'TR004', name: 'Mark Stevens', specialty: 'UI/UX Design', courses: 10, rating: 4.6, students: 420, status: 'Active' },
  { id: 'TR005', name: 'Lisa Park', specialty: 'Cloud Computing', courses: 5, rating: 4.5, students: 150, status: 'On Leave' },
  { id: 'TR006', name: 'Dr. Ahmed Hassan', specialty: 'Cybersecurity', courses: 7, rating: 4.8, students: 210, status: 'Active' },
];

const TrainersPage = () => {
  const [search, setSearch] = useState('');
  const [trainers, setTrainers] = useState<Trainer[]>(initialTrainers);
  const filtered = trainers.filter(t => t.name.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = (data: { name: string; email: string; specialty: string }) => {
    const newId = `TR${String(trainers.length + 1).padStart(3, '0')}`;
    setTrainers(prev => [...prev, { id: newId, name: data.name, specialty: data.specialty, courses: 0, rating: 0, students: 0, status: 'Active' }]);
  };

  const handleDelete = (id: string) => {
    setTrainers(prev => prev.filter(t => t.id !== id));
    toast.success('Trainer removed');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Trainers & Content Creators</h1>
          <p className="text-sm text-muted-foreground">Manage instructors and content creators</p>
        </div>
        <AddTrainerDialog onAdd={handleAdd} />
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search trainers..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(t => (
          <div key={t.id} className="bg-card rounded-xl p-5 shadow-card border border-border hover:shadow-card-hover transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-bold">{t.name.charAt(0)}</div>
                <div>
                  <p className="font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.specialty}</p>
                </div>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-muted-foreground hover:text-foreground"><MoreVertical className="h-4 w-4" /></button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem><Edit className="h-4 w-4 mr-2" />Edit</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDelete(t.id)} className="text-destructive"><Trash2 className="h-4 w-4 mr-2" />Remove</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="text-center p-2 bg-muted rounded-lg">
                <p className="font-display font-bold text-foreground">{t.courses}</p>
                <p className="text-[10px] text-muted-foreground">Courses</p>
              </div>
              <div className="text-center p-2 bg-muted rounded-lg">
                <p className="font-display font-bold text-foreground">{t.students}</p>
                <p className="text-[10px] text-muted-foreground">Students</p>
              </div>
              <div className="text-center p-2 bg-muted rounded-lg">
                <div className="flex items-center justify-center gap-1">
                  <Star className="h-3 w-3 text-accent fill-accent" />
                  <p className="font-display font-bold text-foreground">{t.rating || '-'}</p>
                </div>
                <p className="text-[10px] text-muted-foreground">Rating</p>
              </div>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full font-medium ${t.status === 'Active' ? 'bg-primary/10 text-primary' : 'bg-accent/20 text-accent-foreground'}`}>{t.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrainersPage;
