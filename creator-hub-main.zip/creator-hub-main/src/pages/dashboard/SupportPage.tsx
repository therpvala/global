import { HelpCircle, Plus, Search, Clock, CheckCircle, AlertCircle, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const tickets = [
  { id: 'TKT001', subject: 'Cannot access course materials', user: 'Alex Thompson', priority: 'High', status: 'Open', created: 'Mar 5, 2026', replies: 3 },
  { id: 'TKT002', subject: 'Payment not reflecting', user: 'Maria Garcia', priority: 'Medium', status: 'In Progress', created: 'Mar 4, 2026', replies: 5 },
  { id: 'TKT003', subject: 'Certificate download issue', user: 'James Wilson', priority: 'Low', status: 'Resolved', created: 'Mar 3, 2026', replies: 2 },
  { id: 'TKT004', subject: 'Video playback error', user: 'Sarah Lee', priority: 'High', status: 'Open', created: 'Mar 6, 2026', replies: 1 },
  { id: 'TKT005', subject: 'Account login problems', user: 'David Brown', priority: 'Medium', status: 'In Progress', created: 'Mar 2, 2026', replies: 4 },
];

const SupportPage = () => {
  const [search, setSearch] = useState('');
  const filtered = tickets.filter(t => t.subject.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Support Tickets</h1>
          <p className="text-sm text-muted-foreground">Help desk and issue management</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />New Ticket</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-primary">{tickets.filter(t => t.status === 'Open').length}</p>
          <p className="text-xs text-muted-foreground">Open</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-secondary">{tickets.filter(t => t.status === 'In Progress').length}</p>
          <p className="text-xs text-muted-foreground">In Progress</p>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border text-center">
          <p className="font-display text-2xl font-bold text-accent-foreground">{tickets.filter(t => t.status === 'Resolved').length}</p>
          <p className="text-xs text-muted-foreground">Resolved</p>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search tickets..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
      </div>

      <div className="space-y-2">
        {filtered.map(t => (
          <div key={t.id} className="bg-card rounded-xl p-4 shadow-card border border-border hover:shadow-card-hover transition-shadow flex items-center gap-4">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
              t.status === 'Open' ? 'bg-primary/10 text-primary' :
              t.status === 'In Progress' ? 'bg-secondary/10 text-secondary' :
              'bg-accent/20 text-accent-foreground'
            }`}>
              {t.status === 'Open' ? <AlertCircle className="h-5 w-5" /> :
               t.status === 'In Progress' ? <Clock className="h-5 w-5" /> :
               <CheckCircle className="h-5 w-5" />}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground">{t.subject}</p>
              <p className="text-xs text-muted-foreground">{t.user} • {t.created}</p>
            </div>
            <span className={`text-xs px-2 py-1 rounded-full font-medium ${
              t.priority === 'High' ? 'bg-destructive/10 text-destructive' :
              t.priority === 'Medium' ? 'bg-accent/20 text-accent-foreground' :
              'bg-muted text-muted-foreground'
            }`}>{t.priority}</span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground"><MessageSquare className="h-3 w-3" />{t.replies}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SupportPage;
