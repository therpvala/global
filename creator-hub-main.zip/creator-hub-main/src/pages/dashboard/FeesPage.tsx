import { DollarSign, Search, Filter, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const fees = [
  { id: 'FEE001', student: 'Alex Thompson', course: 'Web Development', amount: '$499', paid: '$499', balance: '$0', status: 'Paid', date: 'Jan 15, 2026' },
  { id: 'FEE002', student: 'Maria Garcia', course: 'Data Science', amount: '$699', paid: '$350', balance: '$349', status: 'Partial', date: 'Jan 20, 2026' },
  { id: 'FEE003', student: 'James Wilson', course: 'UI/UX Design', amount: '$399', paid: '$0', balance: '$399', status: 'Unpaid', date: 'Feb 01, 2026' },
  { id: 'FEE004', student: 'Sarah Lee', course: 'Python Basics', amount: '$299', paid: '$299', balance: '$0', status: 'Paid', date: 'Feb 10, 2026' },
  { id: 'FEE005', student: 'David Brown', course: 'Machine Learning', amount: '$599', paid: '$300', balance: '$299', status: 'Partial', date: 'Feb 15, 2026' },
  { id: 'FEE006', student: 'Emma Davis', course: 'React Advanced', amount: '$449', paid: '$449', balance: '$0', status: 'Paid', date: 'Feb 20, 2026' },
];

const FeesPage = () => {
  const [search, setSearch] = useState('');
  const filtered = fees.filter(f => f.student.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Fees & Billing</h1>
          <p className="text-sm text-muted-foreground">Manage student fees and scholarships</p>
        </div>
        <Button variant="outline" size="sm"><Download className="h-4 w-4 mr-2" />Export Report</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card rounded-xl p-4 shadow-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center"><DollarSign className="h-5 w-5" /></div>
            <div>
              <p className="font-display text-xl font-bold text-foreground">$12,450</p>
              <p className="text-xs text-muted-foreground">Total Collected</p>
            </div>
          </div>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/20 text-accent-foreground flex items-center justify-center"><DollarSign className="h-5 w-5" /></div>
            <div>
              <p className="font-display text-xl font-bold text-foreground">$1,047</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </div>
          </div>
        </div>
        <div className="bg-card rounded-xl p-4 shadow-card border border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-secondary/10 text-secondary flex items-center justify-center"><DollarSign className="h-5 w-5" /></div>
            <div>
              <p className="font-display text-xl font-bold text-foreground">$580</p>
              <p className="text-xs text-muted-foreground">Scholarships</p>
            </div>
          </div>
        </div>
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-border bg-muted/50">
              {['Student', 'Course', 'Amount', 'Paid', 'Balance', 'Status', 'Date'].map(h => (
                <th key={h} className="text-left text-xs font-semibold text-muted-foreground px-4 py-3">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {filtered.map(f => (
                <tr key={f.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                  <td className="px-4 py-3 text-sm font-medium text-foreground">{f.student}</td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{f.course}</td>
                  <td className="px-4 py-3 text-sm font-medium text-foreground">{f.amount}</td>
                  <td className="px-4 py-3 text-sm text-primary font-medium">{f.paid}</td>
                  <td className="px-4 py-3 text-sm text-foreground">{f.balance}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                      f.status === 'Paid' ? 'bg-primary/10 text-primary' :
                      f.status === 'Partial' ? 'bg-accent/20 text-accent-foreground' :
                      'bg-destructive/10 text-destructive'
                    }`}>{f.status}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-muted-foreground">{f.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default FeesPage;
