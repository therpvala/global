import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, Pause, CheckCircle, Circle, Lock, Clock, Users, Star, BookOpen, Award, ChevronDown, ChevronUp, ThumbsUp, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion, AnimatePresence } from 'framer-motion';

const courseData = {
  title: 'Advanced React & TypeScript',
  instructor: 'Dr. Emily Chen',
  category: 'Web Development',
  level: 'Advanced',
  students: 156,
  rating: 4.9,
  reviews: 48,
  duration: '40 hrs',
  modules: 8,
  description: 'Master modern React patterns, TypeScript integration, performance optimization, and advanced state management. Build production-ready applications with best practices.',
  progress: 65,
  lastAccessed: 'Module 5 - Lesson 2',
};

const modules = [
  {
    id: 1, title: 'Getting Started with React & TypeScript', duration: '4 hrs', completed: true, expanded: false,
    lessons: [
      { id: 1, title: 'Setting Up Your Development Environment', duration: '25:00', completed: true, type: 'video' },
      { id: 2, title: 'TypeScript Fundamentals for React', duration: '40:00', completed: true, type: 'video' },
      { id: 3, title: 'Your First React + TS Component', duration: '35:00', completed: true, type: 'video' },
      { id: 4, title: 'Module Quiz', duration: '15:00', completed: true, type: 'quiz' },
    ],
  },
  {
    id: 2, title: 'Component Patterns & Props', duration: '5 hrs', completed: true, expanded: false,
    lessons: [
      { id: 5, title: 'Typing Props and State', duration: '30:00', completed: true, type: 'video' },
      { id: 6, title: 'Generic Components', duration: '45:00', completed: true, type: 'video' },
      { id: 7, title: 'Compound Components Pattern', duration: '50:00', completed: true, type: 'video' },
      { id: 8, title: 'Render Props & HOC Patterns', duration: '40:00', completed: true, type: 'video' },
      { id: 9, title: 'Practice Assignment', duration: '60:00', completed: true, type: 'assignment' },
    ],
  },
  {
    id: 3, title: 'Hooks Deep Dive', duration: '6 hrs', completed: true, expanded: false,
    lessons: [
      { id: 10, title: 'useState & useReducer with TypeScript', duration: '35:00', completed: true, type: 'video' },
      { id: 11, title: 'useEffect Best Practices', duration: '40:00', completed: true, type: 'video' },
      { id: 12, title: 'Custom Hooks Architecture', duration: '55:00', completed: true, type: 'video' },
      { id: 13, title: 'useCallback & useMemo Optimization', duration: '45:00', completed: true, type: 'video' },
    ],
  },
  {
    id: 4, title: 'State Management Solutions', duration: '5 hrs', completed: true, expanded: false,
    lessons: [
      { id: 14, title: 'Context API Patterns', duration: '40:00', completed: true, type: 'video' },
      { id: 15, title: 'Redux Toolkit with TypeScript', duration: '55:00', completed: true, type: 'video' },
      { id: 16, title: 'Zustand & Jotai', duration: '45:00', completed: true, type: 'video' },
      { id: 17, title: 'State Management Quiz', duration: '20:00', completed: true, type: 'quiz' },
    ],
  },
  {
    id: 5, title: 'Performance Optimization', duration: '5 hrs', completed: false, expanded: true,
    lessons: [
      { id: 18, title: 'React DevTools Profiler', duration: '30:00', completed: true, type: 'video' },
      { id: 19, title: 'Code Splitting & Lazy Loading', duration: '45:00', completed: false, type: 'video', active: true },
      { id: 20, title: 'Virtualization Techniques', duration: '50:00', completed: false, type: 'video' },
      { id: 21, title: 'Bundle Size Optimization', duration: '40:00', completed: false, type: 'video' },
    ],
  },
  {
    id: 6, title: 'Testing React Applications', duration: '6 hrs', completed: false, expanded: false,
    lessons: [
      { id: 22, title: 'Testing Library Setup', duration: '25:00', completed: false, type: 'video' },
      { id: 23, title: 'Component Testing Strategies', duration: '50:00', completed: false, type: 'video' },
      { id: 24, title: 'Integration & E2E Testing', duration: '55:00', completed: false, type: 'video' },
    ],
  },
  {
    id: 7, title: 'Server-Side Rendering & SSG', duration: '5 hrs', completed: false, expanded: false,
    lessons: [
      { id: 25, title: 'SSR Concepts', duration: '35:00', completed: false, type: 'video' },
      { id: 26, title: 'Data Fetching Patterns', duration: '45:00', completed: false, type: 'video' },
    ],
  },
  {
    id: 8, title: 'Final Project', duration: '4 hrs', completed: false, expanded: false,
    lessons: [
      { id: 27, title: 'Project Requirements', duration: '15:00', completed: false, type: 'video' },
      { id: 28, title: 'Build & Submit Project', duration: '180:00', completed: false, type: 'assignment' },
      { id: 29, title: 'Final Exam', duration: '60:00', completed: false, type: 'quiz' },
    ],
  },
];

const reviews = [
  { id: 1, name: 'Alex Thompson', rating: 5, date: 'Feb 28, 2026', text: 'Incredible course! The TypeScript integration examples are extremely practical. Dr. Chen explains complex concepts in a very approachable way.', helpful: 24 },
  { id: 2, name: 'Sarah Lee', rating: 5, date: 'Feb 20, 2026', text: 'Best React course I\'ve taken. The performance optimization module alone is worth the price. Highly recommended for senior developers.', helpful: 18 },
  { id: 3, name: 'David Brown', rating: 4, date: 'Feb 15, 2026', text: 'Great content overall. Some advanced topics could use more real-world examples. The custom hooks section was my favorite.', helpful: 12 },
  { id: 4, name: 'Maria Garcia', rating: 5, date: 'Feb 10, 2026', text: 'Thorough and well-structured. The assignments are challenging but rewarding. I feel much more confident with TypeScript now.', helpful: 15 },
  { id: 5, name: 'James Wilson', rating: 4, date: 'Jan 30, 2026', text: 'Very comprehensive. Would love to see more content on React Server Components. Otherwise excellent.', helpful: 8 },
];

const discussions = [
  {
    id: 1, lessonId: 19, author: 'Alex Thompson', role: 'student' as 'student' | 'instructor', avatar: 'AT',
    date: 'Mar 5, 2026', text: 'Can someone explain the difference between React.lazy and dynamic imports with Webpack? I\'m confused about when to use each approach.',
    replies: [
      { id: 11, author: 'Dr. Emily Chen', role: 'instructor' as const, avatar: 'EC', date: 'Mar 5, 2026', text: 'Great question! React.lazy is specifically for component-level code splitting. Dynamic imports with Webpack can be used for any module. React.lazy wraps the dynamic import and works with Suspense for a seamless loading experience.' },
      { id: 12, author: 'Sarah Lee', role: 'student' as const, avatar: 'SL', date: 'Mar 6, 2026', text: 'Thanks Dr. Chen! That makes it much clearer. So React.lazy is basically a convenience wrapper for components?' },
    ],
  },
  {
    id: 2, lessonId: 19, author: 'David Brown', role: 'student' as const, avatar: 'DB',
    date: 'Mar 4, 2026', text: 'Is there a recommended minimum bundle size threshold before you should consider code splitting? I don\'t want to over-optimize.',
    replies: [
      { id: 21, author: 'Dr. Emily Chen', role: 'instructor' as const, avatar: 'EC', date: 'Mar 4, 2026', text: 'Good rule of thumb: if a route or feature adds more than 30KB gzipped to your main bundle, consider splitting it. Use Webpack Bundle Analyzer to identify the biggest chunks first.' },
    ],
  },
  {
    id: 3, lessonId: 18, author: 'Maria Garcia', role: 'student' as const, avatar: 'MG',
    date: 'Mar 3, 2026', text: 'The React Profiler flame chart is really helpful! I found a component that was re-rendering 50+ times on a single interaction. Fixed it with useMemo.',
    replies: [],
  },
  {
    id: 4, lessonId: 19, author: 'James Wilson', role: 'student' as const, avatar: 'JW',
    date: 'Mar 2, 2026', text: 'How does code splitting interact with SSR? Do we need to handle it differently on the server side?',
    replies: [
      { id: 41, author: 'Dr. Emily Chen', role: 'instructor' as const, avatar: 'EC', date: 'Mar 2, 2026', text: 'Yes! With SSR, you\'ll want to use a library like @loadable/component instead of React.lazy, since React.lazy doesn\'t support SSR yet. We cover this in Module 7.' },
    ],
  },
];

const CourseDetailPage = () => {
  const [expandedModules, setExpandedModules] = useState<number[]>([5]);
  const [playing, setPlaying] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState('');

  const toggleModule = (id: number) => {
    setExpandedModules(prev => prev.includes(id) ? prev.filter(m => m !== id) : [...prev, id]);
  };

  const completedLessons = modules.flatMap(m => m.lessons).filter(l => l.completed).length;
  const totalLessons = modules.flatMap(m => m.lessons).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <Link to="/dashboard/courses" className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1 mb-4">
          <ArrowLeft className="h-4 w-4" /> Back to Courses
        </Link>
        <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
          <div className="gradient-dark p-6 lg:p-8">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-primary/20 text-primary-foreground font-medium">{courseData.category}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-secondary/60 text-secondary-foreground font-medium">{courseData.level}</span>
                </div>
                <h1 className="font-display text-2xl lg:text-3xl font-bold text-pale-azure mb-2">{courseData.title}</h1>
                <p className="text-pale-azure/70 text-sm max-w-xl">{courseData.description}</p>
                <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-pale-azure/60">
                  <span className="flex items-center gap-1"><Users className="h-4 w-4" />{courseData.students} students</span>
                  <span className="flex items-center gap-1"><Clock className="h-4 w-4" />{courseData.duration}</span>
                  <span className="flex items-center gap-1"><BookOpen className="h-4 w-4" />{courseData.modules} modules</span>
                  <span className="flex items-center gap-1"><Star className="h-4 w-4 text-accent fill-accent" />{courseData.rating} ({courseData.reviews} reviews)</span>
                </div>
              </div>
              <div className="text-center lg:text-right flex-shrink-0">
                <div className="w-20 h-20 rounded-full border-4 border-primary/30 flex items-center justify-center mx-auto lg:ml-auto">
                  <span className="font-display text-xl font-bold text-pale-azure">{courseData.progress}%</span>
                </div>
                <p className="text-xs text-pale-azure/50 mt-2">Course Progress</p>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="px-6 py-3 bg-card border-t border-border flex items-center gap-4">
            <Progress value={courseData.progress} className="flex-1 h-2" />
            <span className="text-xs text-muted-foreground">{completedLessons}/{totalLessons} lessons</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Left - Video Player & Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Video Player */}
          <div className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
            <div className="aspect-video gradient-dark flex items-center justify-center relative cursor-pointer" onClick={() => setPlaying(!playing)}>
              <motion.div
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="w-20 h-20 rounded-full bg-primary/30 flex items-center justify-center backdrop-blur-sm"
              >
                {playing ? (
                  <Pause className="h-8 w-8 text-primary-foreground" />
                ) : (
                  <Play className="h-8 w-8 text-primary-foreground ml-1" />
                )}
              </motion.div>
              <div className="absolute bottom-4 left-4 right-4 flex items-center gap-3">
                <div className="flex-1 h-1 bg-pale-azure/20 rounded-full overflow-hidden">
                  <div className="h-full w-[35%] bg-primary rounded-full" />
                </div>
                <span className="text-xs text-pale-azure/70">15:45 / 45:00</span>
              </div>
              <div className="absolute top-4 left-4">
                <p className="text-xs text-pale-azure/70">Now Playing</p>
                <p className="text-sm font-medium text-pale-azure">Code Splitting & Lazy Loading</p>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="modules" className="space-y-4">
            <TabsList className="bg-muted w-full justify-start">
              <TabsTrigger value="modules">Modules</TabsTrigger>
              <TabsTrigger value="discussion">Discussion ({discussions.length})</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({reviews.length})</TabsTrigger>
              <TabsTrigger value="resources">Resources</TabsTrigger>
            </TabsList>

            <TabsContent value="modules" className="space-y-2">
              {modules.map(mod => (
                <div key={mod.id} className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
                  <button
                    onClick={() => toggleModule(mod.id)}
                    className="w-full flex items-center justify-between p-4 hover:bg-muted/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${mod.completed ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                        {mod.completed ? <CheckCircle className="h-4 w-4" /> : mod.id}
                      </div>
                      <div className="text-left">
                        <p className={`text-sm font-medium ${mod.completed ? 'text-foreground' : 'text-foreground'}`}>{mod.title}</p>
                        <p className="text-xs text-muted-foreground">{mod.lessons.length} lessons • {mod.duration}</p>
                      </div>
                    </div>
                    {expandedModules.includes(mod.id) ? <ChevronUp className="h-4 w-4 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 text-muted-foreground" />}
                  </button>

                  <AnimatePresence>
                    {expandedModules.includes(mod.id) && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="border-t border-border overflow-hidden"
                      >
                        {mod.lessons.map(lesson => (
                          <div
                            key={lesson.id}
                            className={`flex items-center gap-3 px-4 py-3 text-sm hover:bg-muted/30 transition-colors cursor-pointer ${
                              (lesson as any).active ? 'bg-primary/5 border-l-2 border-l-primary' : ''
                            }`}
                          >
                            {lesson.completed ? (
                              <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                            ) : (lesson as any).active ? (
                              <Play className="h-4 w-4 text-primary flex-shrink-0" />
                            ) : mod.completed || modules.findIndex(m => m.id === mod.id) <= 4 ? (
                              <Circle className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                            ) : (
                              <Lock className="h-4 w-4 text-muted-foreground/50 flex-shrink-0" />
                            )}
                            <span className={`flex-1 ${lesson.completed ? 'text-muted-foreground' : (lesson as any).active ? 'text-primary font-medium' : 'text-foreground'}`}>
                              {lesson.title}
                            </span>
                            <span className={`text-xs px-1.5 py-0.5 rounded ${
                              lesson.type === 'quiz' ? 'bg-accent/20 text-accent-foreground' :
                              lesson.type === 'assignment' ? 'bg-secondary/10 text-secondary' :
                              'bg-transparent text-muted-foreground'
                            }`}>
                              {lesson.type === 'video' ? lesson.duration : lesson.type}
                            </span>
                          </div>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="discussion" className="space-y-4">
              {/* New Comment */}
              <div className="bg-card rounded-xl p-5 shadow-card border border-border">
                <h4 className="font-semibold text-foreground text-sm mb-3">Ask a Question</h4>
                <textarea
                  value={newComment}
                  onChange={e => setNewComment(e.target.value)}
                  placeholder="Ask a question about the current lesson..."
                  className="w-full min-h-[80px] rounded-lg border border-border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                />
                <div className="flex justify-end mt-2">
                  <Button size="sm" className="gradient-primary text-primary-foreground" disabled={!newComment.trim()}>
                    <MessageCircle className="h-3.5 w-3.5 mr-1" /> Post Question
                  </Button>
                </div>
              </div>

              {/* Discussion Threads */}
              {discussions.map(d => (
                <div key={d.id} className="bg-card rounded-xl shadow-card border border-border overflow-hidden">
                  <div className="p-5">
                    <div className="flex items-start gap-3">
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${d.role === 'instructor' ? 'gradient-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                        {d.avatar}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-semibold text-foreground">{d.author}</span>
                          {d.role === 'instructor' && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium">Instructor</span>}
                          <span className="text-xs text-muted-foreground">{d.date}</span>
                        </div>
                        <p className="text-sm text-muted-foreground leading-relaxed">{d.text}</p>
                        <div className="flex items-center gap-3 mt-3">
                          <button onClick={() => setReplyingTo(replyingTo === d.id ? null : d.id)} className="flex items-center gap-1 text-xs text-muted-foreground hover:text-primary transition-colors">
                            <MessageCircle className="h-3 w-3" /> Reply ({d.replies.length})
                          </button>
                          <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                            <ThumbsUp className="h-3 w-3" /> Helpful
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Replies */}
                  {d.replies.length > 0 && (
                    <div className="border-t border-border bg-muted/30">
                      {d.replies.map(reply => (
                        <div key={reply.id} className="px-5 py-4 ml-8 border-b border-border last:border-b-0">
                          <div className="flex items-start gap-3">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${reply.role === 'instructor' ? 'gradient-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'}`}>
                              {reply.avatar}
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-sm font-semibold text-foreground">{reply.author}</span>
                                {reply.role === 'instructor' && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium">Instructor</span>}
                                <span className="text-xs text-muted-foreground">{reply.date}</span>
                              </div>
                              <p className="text-sm text-muted-foreground leading-relaxed">{reply.text}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reply Input */}
                  {replyingTo === d.id && (
                    <div className="border-t border-border p-4 ml-8">
                      <textarea
                        value={replyText}
                        onChange={e => setReplyText(e.target.value)}
                        placeholder="Write a reply..."
                        className="w-full min-h-[60px] rounded-lg border border-border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                      />
                      <div className="flex justify-end gap-2 mt-2">
                        <Button size="sm" variant="ghost" onClick={() => { setReplyingTo(null); setReplyText(''); }}>Cancel</Button>
                        <Button size="sm" className="gradient-primary text-primary-foreground" disabled={!replyText.trim()}>Reply</Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </TabsContent>

            <TabsContent value="reviews" className="space-y-4">
              {/* Rating Summary */}
              <div className="bg-card rounded-xl p-6 shadow-card border border-border flex items-center gap-8">
                <div className="text-center">
                  <p className="font-display text-4xl font-bold text-foreground">{courseData.rating}</p>
                  <div className="flex items-center gap-0.5 mt-1">
                    {[1,2,3,4,5].map(i => <Star key={i} className="h-4 w-4 text-accent fill-accent" />)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{courseData.reviews} reviews</p>
                </div>
                <div className="flex-1 space-y-1.5">
                  {[5,4,3,2,1].map(star => {
                    const count = reviews.filter(r => r.rating === star).length;
                    const pct = (count / reviews.length) * 100;
                    return (
                      <div key={star} className="flex items-center gap-2 text-xs">
                        <span className="text-muted-foreground w-3">{star}</span>
                        <Star className="h-3 w-3 text-accent fill-accent" />
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div className="h-full bg-accent rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-muted-foreground w-6 text-right">{count}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Review List */}
              {reviews.map(r => (
                <div key={r.id} className="bg-card rounded-xl p-5 shadow-card border border-border">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-secondary-foreground font-bold text-sm flex-shrink-0">{r.name.charAt(0)}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <div>
                          <p className="text-sm font-semibold text-foreground">{r.name}</p>
                          <div className="flex items-center gap-1 mt-0.5">
                            {[1,2,3,4,5].map(i => <Star key={i} className={`h-3 w-3 ${i <= r.rating ? 'text-accent fill-accent' : 'text-muted-foreground'}`} />)}
                          </div>
                        </div>
                        <span className="text-xs text-muted-foreground">{r.date}</span>
                      </div>
                      <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{r.text}</p>
                      <button className="flex items-center gap-1 mt-3 text-xs text-muted-foreground hover:text-foreground">
                        <ThumbsUp className="h-3 w-3" /> Helpful ({r.helpful})
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </TabsContent>

            <TabsContent value="resources" className="space-y-3">
              {[
                { title: 'React + TypeScript Cheatsheet', type: 'PDF', size: '1.2 MB' },
                { title: 'Course Source Code', type: 'ZIP', size: '24 MB' },
                { title: 'Performance Optimization Guide', type: 'PDF', size: '3.4 MB' },
                { title: 'Supplementary Reading List', type: 'PDF', size: '0.8 MB' },
              ].map(r => (
                <div key={r.title} className="bg-card rounded-xl p-4 shadow-card border border-border flex items-center justify-between hover:shadow-card-hover transition-shadow">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
                      <BookOpen className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{r.title}</p>
                      <p className="text-xs text-muted-foreground">{r.type} • {r.size}</p>
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="text-xs">Download</Button>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Instructor */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-display font-semibold text-foreground mb-4">Instructor</h3>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">EC</div>
              <div>
                <p className="font-semibold text-foreground">{courseData.instructor}</p>
                <p className="text-xs text-muted-foreground">Senior Developer & Educator</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="p-2 bg-muted rounded-lg">
                <p className="font-display font-bold text-foreground text-sm">12</p>
                <p className="text-[10px] text-muted-foreground">Courses</p>
              </div>
              <div className="p-2 bg-muted rounded-lg">
                <p className="font-display font-bold text-foreground text-sm">340</p>
                <p className="text-[10px] text-muted-foreground">Students</p>
              </div>
            </div>
          </div>

          {/* Progress Overview */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <h3 className="font-display font-semibold text-foreground mb-4">Your Progress</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Completed</span>
                <span className="font-medium text-foreground">{completedLessons}/{totalLessons} lessons</span>
              </div>
              <Progress value={(completedLessons / totalLessons) * 100} className="h-2" />
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Time Spent</span>
                <span className="font-medium text-foreground">26 hrs</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Quizzes Passed</span>
                <span className="font-medium text-foreground">2/3</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Assignments</span>
                <span className="font-medium text-foreground">1/2</span>
              </div>
            </div>
          </div>

          {/* Certificate */}
          <div className="bg-card rounded-xl p-5 shadow-card border border-border">
            <div className="flex items-center gap-3 mb-3">
              <Award className="h-8 w-8 text-accent" />
              <div>
                <p className="font-semibold text-foreground text-sm">Certificate</p>
                <p className="text-xs text-muted-foreground">Complete 100% to earn your certificate</p>
              </div>
            </div>
            <Button className="w-full gradient-primary text-primary-foreground" disabled>
              Complete Course to Unlock
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailPage;
