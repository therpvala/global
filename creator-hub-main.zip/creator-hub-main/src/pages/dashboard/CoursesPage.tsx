import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, Filter, Clock, Users, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';

const courses = [
  { id: 1, title: 'Advanced React & TypeScript', category: 'Web Development', instructor: 'Dr. Emily Chen', students: 156, duration: '40 hrs', level: 'Advanced', status: 'Published', price: '$99' },
  { id: 2, title: 'Python for Data Science', category: 'Data Science', instructor: 'Prof. Robert Miller', students: 289, duration: '60 hrs', level: 'Intermediate', status: 'Published', price: '$129' },
  { id: 3, title: 'UI/UX Design Masterclass', category: 'Design', instructor: 'Mark Stevens', students: 204, duration: '35 hrs', level: 'Beginner', status: 'Published', price: '$79' },
  { id: 4, title: 'Machine Learning Fundamentals', category: 'AI/ML', instructor: 'Dr. Sarah Johnson', students: 178, duration: '55 hrs', level: 'Advanced', status: 'Draft', price: '$149' },
  { id: 5, title: 'Cloud Architecture with AWS', category: 'Cloud', instructor: 'Lisa Park', students: 120, duration: '45 hrs', level: 'Intermediate', status: 'Published', price: '$119' },
  { id: 6, title: 'Cybersecurity Essentials', category: 'Security', instructor: 'Dr. Ahmed Hassan', students: 95, duration: '30 hrs', level: 'Beginner', status: 'Published', price: '$89' },
];

const CoursesPage = () => {
  const [search, setSearch] = useState('');
  const { user } = useAuth();
  const filtered = courses.filter(c => c.title.toLowerCase().includes(search.toLowerCase()));
  const canCreate = user?.role === 'superadmin' || user?.role === 'admin' || user?.role === 'instructor';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Courses</h1>
          <p className="text-sm text-muted-foreground">Manage courses and programs</p>
        </div>
        {canCreate && (
          <Link to="/dashboard/course-builder">
            <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Create Course</Button>
          </Link>
        )}
      </div>

      <div className="flex gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search courses..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Button variant="outline" size="icon"><Filter className="h-4 w-4" /></Button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(c => (
          <motion.div key={c.id} whileHover={{ y: -3 }} className="bg-card rounded-xl shadow-card border border-border overflow-hidden hover:shadow-card-hover transition-shadow">
            <div className="h-32 gradient-dark flex items-center justify-center relative">
              <BookOpen className="h-10 w-10 text-pale-azure/30" />
              <span className={`absolute top-3 right-3 text-xs px-2 py-1 rounded-full font-medium ${c.status === 'Published' ? 'bg-primary/20 text-primary-foreground' : 'bg-accent/30 text-accent-foreground'}`}>{c.status}</span>
              <span className="absolute bottom-3 left-3 text-xs px-2 py-1 rounded-full bg-secondary/80 text-secondary-foreground font-medium">{c.category}</span>
            </div>
            <div className="p-4">
              <h3 className="font-display font-semibold text-foreground mb-1">{c.title}</h3>
              <p className="text-xs text-muted-foreground mb-3">{c.instructor}</p>
              <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                <span className="flex items-center gap-1"><Users className="h-3 w-3" />{c.students}</span>
                <span className="flex items-center gap-1"><Clock className="h-3 w-3" />{c.duration}</span>
                <span className="px-2 py-0.5 bg-muted rounded-full">{c.level}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-display font-bold text-primary">{c.price}</span>
                <Link to={`/dashboard/courses/${c.id}`}><Button size="sm" variant="outline" className="text-xs">View Details</Button></Link>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CoursesPage;
