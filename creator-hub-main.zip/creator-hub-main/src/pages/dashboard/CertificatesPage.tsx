import { Search, Download, Award, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';

const certificates = [
  { id: 'CERT001', student: 'Alex Thompson', course: 'Web Development Bootcamp', date: 'Feb 15, 2026', grade: 'A', status: 'Issued' },
  { id: 'CERT002', student: 'Maria Garcia', course: 'Data Science Fundamentals', date: 'Feb 20, 2026', grade: 'A+', status: 'Issued' },
  { id: 'CERT003', student: 'Sarah Lee', course: 'Python Basics', date: 'Mar 1, 2026', grade: 'B+', status: 'Issued' },
  { id: 'CERT004', student: 'David Brown', course: 'Machine Learning', date: 'Mar 5, 2026', grade: 'A', status: 'Pending' },
  { id: 'CERT005', student: 'Emma Davis', course: 'React Advanced', date: 'Mar 8, 2026', grade: 'B', status: 'Pending' },
];

const CertificatesPage = () => {
  const [search, setSearch] = useState('');
  const filtered = certificates.filter(c => c.student.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-foreground">Certificates</h1>
          <p className="text-sm text-muted-foreground">Generate and manage course certificates</p>
        </div>
        <Button size="sm" className="gradient-primary text-primary-foreground"><Plus className="h-4 w-4 mr-2" />Generate Certificate</Button>
      </div>
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search certificates..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(c => (
          <div key={c.id} className="bg-card rounded-xl shadow-card border border-border p-5 hover:shadow-card-hover transition-shadow">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-xl gradient-dark flex items-center justify-center">
                <Award className="h-6 w-6 text-accent" />
              </div>
              <div>
                <p className="font-semibold text-foreground">{c.student}</p>
                <p className="text-xs text-muted-foreground">{c.course}</p>
              </div>
            </div>
            <div className="flex items-center justify-between text-sm mb-3">
              <span className="text-muted-foreground">Grade: <span className="font-semibold text-foreground">{c.grade}</span></span>
              <span className="text-muted-foreground">{c.date}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className={`text-xs px-2 py-1 rounded-full font-medium ${c.status === 'Issued' ? 'bg-primary/10 text-primary' : 'bg-accent/20 text-accent-foreground'}`}>{c.status}</span>
              <Button size="sm" variant="outline" className="text-xs"><Download className="h-3 w-3 mr-1" />Download</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CertificatesPage;
