import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import loginImg from '@/assets/login-illustration.png';

const roleButtons: { role: UserRole; label: string; email: string; color: string }[] = [
  { role: 'superadmin', label: 'Super Admin', email: 'superadmin@elearn.com', color: 'gradient-dark' },
  { role: 'admin', label: 'Admin', email: 'admin@elearn.com', color: 'bg-secondary text-secondary-foreground' },
  { role: 'instructor', label: 'Instructor', email: 'instructor@elearn.com', color: 'gradient-primary' },
  { role: 'student', label: 'Student', email: 'student@elearn.com', color: 'bg-accent text-accent-foreground' },
  { role: 'parent', label: 'Parent', email: 'parent@elearn.com', color: 'bg-muted text-foreground' },
];

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
    navigate('/dashboard');
  };

  const fillRole = (em: string) => {
    setEmail(em);
    setPassword('password123');
  };

  return (
    <div className="min-h-screen flex">
      {/* Left */}
      <div className="hidden lg:flex lg:w-1/2 gradient-dark relative items-center justify-center p-12">
        <Link to="/" className="absolute top-6 left-6 text-pale-azure/70 hover:text-pale-azure flex items-center gap-2 text-sm">
          <ArrowLeft className="h-4 w-4" /> Back to Home
        </Link>
        <div className="text-center">
          <img src={loginImg} alt="E-Learning" className="w-80 mx-auto mb-8 animate-float-slow" />
          <h2 className="font-display text-3xl font-bold text-pale-azure mb-3">Welcome Back!</h2>
          <p className="text-pale-azure/60 max-w-sm mx-auto">
            Access your courses, manage content, and track learning progress all in one place.
          </p>
        </div>
      </div>

      {/* Right */}
      <div className="flex-1 flex items-center justify-center p-6 bg-background">
        <div className="w-full max-w-md">
          <Link to="/" className="lg:hidden flex items-center gap-2 text-muted-foreground hover:text-foreground text-sm mb-6">
            <ArrowLeft className="h-4 w-4" /> Back to Home
          </Link>

          <div className="flex items-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center">
              <span className="font-display font-bold text-primary-foreground text-sm">EL</span>
            </div>
            <div>
              <h1 className="font-display font-bold text-xl text-foreground">Login</h1>
              <p className="text-xs text-muted-foreground">E-Learning Content Provider</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <Label htmlFor="email" className="text-foreground">Email</Label>
              <Input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" className="mt-1.5" required />
            </div>
            <div>
              <Label htmlFor="password" className="text-foreground">Password</Label>
              <div className="relative mt-1.5">
                <Input id="password" type={showPw ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Checkbox id="remember" />
                <Label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">Remember me</Label>
              </div>
              <a href="#" className="text-sm text-primary hover:underline">Forgot Password?</a>
            </div>
            <Button type="submit" className="w-full gradient-primary text-primary-foreground font-semibold h-11 hover:opacity-90 transition-opacity">
              Login
            </Button>
          </form>

          <div className="mt-8">
            <p className="text-xs text-muted-foreground mb-3 text-center">Quick Role Login</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {roleButtons.map(r => (
                <button
                  key={r.role}
                  onClick={() => fillRole(r.email)}
                  className={`${r.color} px-4 py-2 rounded-lg text-xs font-semibold hover:opacity-80 transition-opacity`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-8">Powered by Software Vala™</p>
        </div>
      </div>
    </div>
  );
};

export default Login;
