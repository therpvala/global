import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import Index from "./pages/Index";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import CourseDetailPage from "./pages/dashboard/CourseDetailPage";
import CourseBuilderPage from "./pages/dashboard/CourseBuilderPage";
import StudentProfilePage from "./pages/dashboard/StudentProfilePage";
import DashboardLayout from "./components/layout/DashboardLayout";
import DashboardHome from "./pages/dashboard/DashboardHome";
import StudentsPage from "./pages/dashboard/StudentsPage";
import TrainersPage from "./pages/dashboard/TrainersPage";
import CoursesPage from "./pages/dashboard/CoursesPage";
import WorkshopsPage from "./pages/dashboard/WorkshopsPage";
import ContentLibraryPage from "./pages/dashboard/ContentLibraryPage";
import AssignmentsPage from "./pages/dashboard/AssignmentsPage";
import ExamsPage from "./pages/dashboard/ExamsPage";
import AttendancePage from "./pages/dashboard/AttendancePage";
import CertificatesPage from "./pages/dashboard/CertificatesPage";
import FeesPage from "./pages/dashboard/FeesPage";
import PaymentsPage from "./pages/dashboard/PaymentsPage";
import ReportsPage from "./pages/dashboard/ReportsPage";
import AnalyticsPage from "./pages/dashboard/AnalyticsPage";
import SettingsPage from "./pages/dashboard/SettingsPage";
import NotificationsPage from "./pages/dashboard/NotificationsPage";
import VideoPortalPage from "./pages/dashboard/VideoPortalPage";
import ForumPage from "./pages/dashboard/ForumPage";
import SupportPage from "./pages/dashboard/SupportPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <NotificationProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/dashboard" element={<DashboardLayout />}>
                <Route index element={<DashboardHome />} />
                <Route path="students" element={<StudentsPage />} />
                <Route path="students/:id" element={<StudentProfilePage />} />
                <Route path="trainers" element={<TrainersPage />} />
                <Route path="courses" element={<CoursesPage />} />
                <Route path="courses/:id" element={<CourseDetailPage />} />
                <Route path="course-builder" element={<CourseBuilderPage />} />
                <Route path="workshops" element={<WorkshopsPage />} />
                <Route path="content-library" element={<ContentLibraryPage />} />
                <Route path="assignments" element={<AssignmentsPage />} />
                <Route path="exams" element={<ExamsPage />} />
                <Route path="attendance" element={<AttendancePage />} />
                <Route path="certificates" element={<CertificatesPage />} />
                <Route path="fees" element={<FeesPage />} />
                <Route path="payments" element={<PaymentsPage />} />
                <Route path="video-portal" element={<VideoPortalPage />} />
                <Route path="forum" element={<ForumPage />} />
                <Route path="support" element={<SupportPage />} />
                <Route path="notifications" element={<NotificationsPage />} />
                <Route path="reports" element={<ReportsPage />} />
                <Route path="analytics" element={<AnalyticsPage />} />
                <Route path="settings" element={<SettingsPage />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
        </NotificationProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
