import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'sonner';

export type NotificationType = 'discussion' | 'assignment' | 'course' | 'payment' | 'reminder' | 'system';

export interface Notification {
  id: string;
  title: string;
  description: string;
  type: NotificationType;
  read: boolean;
  timestamp: Date;
  link?: string;
}

interface NotificationContextType {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotification: (id: string) => void;
}

const NotificationContext = createContext<NotificationContextType | null>(null);

const initialNotifications: Notification[] = [
  { id: 'n1', title: 'New Discussion Reply', description: 'Dr. Emily Chen replied to your question about React.lazy vs dynamic imports', type: 'discussion', read: false, timestamp: new Date(Date.now() - 1000 * 60 * 15), link: '/dashboard/courses/1' },
  { id: 'n2', title: 'Assignment Due Tomorrow', description: 'React Component Architecture - Advanced React & TypeScript', type: 'assignment', read: false, timestamp: new Date(Date.now() - 1000 * 60 * 60), link: '/dashboard/assignments' },
  { id: 'n3', title: 'Course Updated', description: 'New module added to "Advanced React & TypeScript"', type: 'course', read: false, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3), link: '/dashboard/courses/1' },
  { id: 'n4', title: 'Payment Confirmed', description: '$499 payment for Cloud Architecture course received', type: 'payment', read: true, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), link: '/dashboard/payments' },
  { id: 'n5', title: 'Workshop Reminder', description: 'UI/UX Design Sprint starts tomorrow at 10 AM', type: 'reminder', read: false, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), link: '/dashboard/workshops' },
  { id: 'n6', title: 'System Maintenance', description: 'Platform maintenance scheduled for March 15, 2026', type: 'system', read: true, timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48) },
];

const simulatedEvents: Omit<Notification, 'id' | 'read' | 'timestamp'>[] = [
  { title: 'New Discussion Reply', description: 'Sarah Lee replied: "Thanks, that makes it much clearer!"', type: 'discussion', link: '/dashboard/courses/1' },
  { title: 'Assignment Submitted', description: 'David Brown submitted "Neural Network Implementation"', type: 'assignment', link: '/dashboard/assignments' },
  { title: 'Course Progress Update', description: 'You\'ve completed 70% of Advanced React & TypeScript!', type: 'course', link: '/dashboard/courses/1' },
  { title: 'New Discussion Question', description: 'James Wilson asked: "How does tree shaking work with dynamic imports?"', type: 'discussion', link: '/dashboard/courses/1' },
  { title: 'Assignment Deadline Approaching', description: 'Data Visualization Project due in 2 hours', type: 'assignment', link: '/dashboard/assignments' },
  { title: 'New Course Available', description: '"Docker & Kubernetes Mastery" just launched!', type: 'course', link: '/dashboard/courses' },
  { title: 'Instructor Feedback', description: 'Dr. Emily Chen graded your assignment: 95/100', type: 'assignment', link: '/dashboard/assignments' },
];

const typeEmoji: Record<NotificationType, string> = {
  discussion: '💬',
  assignment: '📋',
  course: '📚',
  payment: '💳',
  reminder: '⏰',
  system: 'ℹ️',
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const eventIndexRef = useRef(0);

  const addNotification = useCallback((event: Omit<Notification, 'id' | 'read' | 'timestamp'>) => {
    const newNotif: Notification = {
      ...event,
      id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      read: false,
      timestamp: new Date(),
    };
    setNotifications(prev => [newNotif, ...prev]);

    toast(event.title, {
      description: event.description,
      icon: typeEmoji[event.type],
      duration: 5000,
      action: event.link ? { label: 'View', onClick: () => { window.location.hash = ''; } } : undefined,
    });
  }, []);

  // Simulate real-time notifications every 20-40 seconds
  useEffect(() => {
    const scheduleNext = () => {
      const delay = 20000 + Math.random() * 20000;
      return setTimeout(() => {
        const event = simulatedEvents[eventIndexRef.current % simulatedEvents.length];
        eventIndexRef.current++;
        addNotification(event);
        timerRef.current = scheduleNext();
      }, delay);
    };

    const timerRef = { current: scheduleNext() };
    return () => clearTimeout(timerRef.current);
  }, [addNotification]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const clearNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, markAsRead, markAllAsRead, clearNotification }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error('useNotifications must be used within NotificationProvider');
  return ctx;
};
