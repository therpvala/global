import React, { createContext, useContext, useState, useCallback } from 'react';

export type UserRole = 'superadmin' | 'admin' | 'instructor' | 'student' | 'parent';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const mockUsers: Record<UserRole, User> = {
  superadmin: { id: '1', name: 'James Anderson', email: 'superadmin@elearn.com', role: 'superadmin' },
  admin: { id: '2', name: 'Sarah Mitchell', email: 'admin@elearn.com', role: 'admin' },
  instructor: { id: '3', name: 'Dr. Emily Chen', email: 'instructor@elearn.com', role: 'instructor' },
  student: { id: '4', name: 'Alex Thompson', email: 'student@elearn.com', role: 'student' },
  parent: { id: '5', name: 'Michael Roberts', email: 'parent@elearn.com', role: 'parent' },
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback((email: string, _password: string) => {
    const found = Object.values(mockUsers).find(u => u.email === email);
    if (found) setUser(found);
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
