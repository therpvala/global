import { useAuth, UserRole } from '@/contexts/AuthContext';
import {
  LayoutDashboard, Users, GraduationCap, BookOpen, Calendar, ClipboardList,
  FileText, Award, DollarSign, CreditCard, BarChart3, TrendingUp, Settings,
  Bell, HelpCircle, MessageSquare, Library, Video, Briefcase, LogOut, Moon, Sun, ChevronLeft, ChevronRight
} from 'lucide-react';
import { NavLink as RouterNavLink, useNavigate } from 'react-router-dom';
import { useTheme } from '@/contexts/ThemeContext';
import { useState } from 'react';

interface MenuItem {
  icon: React.ElementType;
  label: string;
  path: string;
  roles: UserRole[];
}

const menuItems: MenuItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/dashboard', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: Users, label: 'Students', path: '/dashboard/students', roles: ['superadmin','admin','instructor','parent'] },
  { icon: GraduationCap, label: 'Trainers', path: '/dashboard/trainers', roles: ['superadmin','admin'] },
  { icon: BookOpen, label: 'Courses', path: '/dashboard/courses', roles: ['superadmin','admin','instructor','student'] },
  { icon: Briefcase, label: 'Workshops', path: '/dashboard/workshops', roles: ['superadmin','admin','instructor','student'] },
  { icon: Library, label: 'Content Library', path: '/dashboard/content-library', roles: ['superadmin','admin','instructor','student'] },
  { icon: ClipboardList, label: 'Assignments', path: '/dashboard/assignments', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: FileText, label: 'Exams', path: '/dashboard/exams', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: Calendar, label: 'Attendance', path: '/dashboard/attendance', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: Award, label: 'Certificates', path: '/dashboard/certificates', roles: ['superadmin','admin','instructor','student'] },
  { icon: DollarSign, label: 'Fees', path: '/dashboard/fees', roles: ['superadmin','admin','parent','student'] },
  { icon: CreditCard, label: 'Payments', path: '/dashboard/payments', roles: ['superadmin','admin'] },
  { icon: Video, label: 'Video Portal', path: '/dashboard/video-portal', roles: ['superadmin','admin','instructor','student'] },
  { icon: MessageSquare, label: 'Forum', path: '/dashboard/forum', roles: ['superadmin','admin','instructor','student'] },
  { icon: HelpCircle, label: 'Support', path: '/dashboard/support', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: Bell, label: 'Notifications', path: '/dashboard/notifications', roles: ['superadmin','admin','instructor','student','parent'] },
  { icon: BarChart3, label: 'Reports', path: '/dashboard/reports', roles: ['superadmin','admin','instructor'] },
  { icon: TrendingUp, label: 'Analytics', path: '/dashboard/analytics', roles: ['superadmin','admin'] },
  { icon: Settings, label: 'Settings', path: '/dashboard/settings', roles: ['superadmin','admin'] },
];

const DashboardSidebar = () => {
  const { user, logout } = useAuth();
  const { isDark, toggle } = useTheme();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const role = user?.role || 'student';
  const filtered = menuItems.filter(m => m.roles.includes(role));

  return (
    <aside className={`${collapsed ? 'w-16' : 'w-64'} min-h-screen bg-sidebar flex flex-col transition-all duration-300 flex-shrink-0`}>
      {/* Logo */}
      <div className="h-16 flex items-center justify-between px-3 border-b border-sidebar-border">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center">
              <span className="font-display font-bold text-xs text-primary-foreground">EL</span>
            </div>
            <span className="font-display font-bold text-sm text-sidebar-foreground truncate">E-Learning</span>
          </div>
        )}
        <button onClick={() => setCollapsed(!collapsed)} className="text-sidebar-foreground/60 hover:text-sidebar-foreground p-1">
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {filtered.map(item => (
          <RouterNavLink
            key={item.path}
            to={item.path}
            end={item.path === '/dashboard'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                  : 'text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent'
              }`
            }
          >
            <item.icon className="h-4 w-4 flex-shrink-0" />
            {!collapsed && <span className="truncate">{item.label}</span>}
          </RouterNavLink>
        ))}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-sidebar-border space-y-2">
        <button onClick={toggle} className="flex items-center gap-3 px-3 py-2 rounded-lg text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent w-full text-sm">
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          {!collapsed && <span>{isDark ? 'Light Mode' : 'Dark Mode'}</span>}
        </button>
        <button onClick={() => { logout(); navigate('/'); }} className="flex items-center gap-3 px-3 py-2 rounded-lg text-sidebar-foreground/70 hover:text-primary hover:bg-sidebar-accent w-full text-sm">
          <LogOut className="h-4 w-4" />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
};

export default DashboardSidebar;
