import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { toast } from 'sonner';

interface AddTrainerDialogProps {
  onAdd?: (trainer: { name: string; email: string; specialty: string }) => void;
}

const AddTrainerDialog = ({ onAdd }: AddTrainerDialogProps) => {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [specialty, setSpecialty] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !specialty) return;
    onAdd?.({ name, email, specialty });
    toast.success('Trainer added successfully!');
    setName(''); setEmail(''); setSpecialty('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gradient-primary text-primary-foreground">
          <Plus className="h-4 w-4 mr-2" />Add Trainer
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">Add New Trainer</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="trainerName">Full Name</Label>
            <Input id="trainerName" value={name} onChange={e => setName(e.target.value)} placeholder="Dr. Jane Smith" className="mt-1.5" required />
          </div>
          <div>
            <Label htmlFor="trainerEmail">Email</Label>
            <Input id="trainerEmail" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="jane@elearn.com" className="mt-1.5" required />
          </div>
          <div>
            <Label htmlFor="trainerSpec">Specialty</Label>
            <Select value={specialty} onValueChange={setSpecialty}>
              <SelectTrigger className="mt-1.5"><SelectValue placeholder="Select specialty" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Web Development">Web Development</SelectItem>
                <SelectItem value="Data Science & AI">Data Science & AI</SelectItem>
                <SelectItem value="UI/UX Design">UI/UX Design</SelectItem>
                <SelectItem value="Machine Learning">Machine Learning</SelectItem>
                <SelectItem value="Cloud Computing">Cloud Computing</SelectItem>
                <SelectItem value="Cybersecurity">Cybersecurity</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button type="submit" className="gradient-primary text-primary-foreground">Add Trainer</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddTrainerDialog;
