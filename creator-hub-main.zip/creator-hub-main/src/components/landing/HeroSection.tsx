import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { BookOpen, Users, FileText, TrendingUp } from 'lucide-react';
import heroImg from '@/assets/hero-illustration.png';

const stats = [
  { icon: BookOpen, label: 'Courses', value: '200+', color: 'bg-primary text-primary-foreground' },
  { icon: Users, label: 'Content Creators', value: '50+', color: 'bg-secondary text-secondary-foreground' },
  { icon: FileText, label: 'Learning Materials', value: '5000+', color: 'bg-accent text-accent-foreground' },
  { icon: TrendingUp, label: 'Learner Satisfaction', value: '95%', color: 'bg-deep-azure text-pale-azure' },
];

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
      {/* Background */}
      <div className="absolute inset-0 bg-background">
        <div className="absolute top-0 right-0 w-[60%] h-full opacity-[0.04]" style={{ background: 'var(--gradient-primary)' }} />
        <div className="absolute bottom-0 left-0 w-96 h-96 rounded-full bg-accent/10 blur-3xl" />
        <div className="absolute top-20 right-20 w-72 h-72 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7 }}
          >
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary rounded-full px-4 py-1.5 text-sm font-medium mb-6">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse-soft" />
              Powered by Software Vala™
            </div>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-foreground mb-6">
              Create, Share &{' '}
              <span className="text-gradient-primary">Manage</span> Your Digital
              Learning Content
            </h1>
            <p className="text-lg text-muted-foreground max-w-lg mb-8 leading-relaxed">
              Build comprehensive online courses, manage resources, and empower content creators with powerful tools for digital education.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/login">
                <Button size="lg" className="gradient-primary text-primary-foreground font-semibold px-8 h-12 text-base hover:opacity-90 transition-opacity">
                  Sign Up Now
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="font-semibold px-8 h-12 text-base border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground">
                Explore Content
              </Button>
            </div>
          </motion.div>

          {/* Right Image */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative"
          >
            <img src={heroImg} alt="E-Learning Platform" className="w-full rounded-2xl" />
          </motion.div>
        </div>

        {/* Floating Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 lg:mt-20"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              whileHover={{ y: -4, boxShadow: 'var(--shadow-card-hover)' }}
              className="bg-card rounded-xl p-5 shadow-card border border-border flex items-center gap-4 cursor-default"
            >
              <div className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center flex-shrink-0`}>
                <stat.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="font-display font-bold text-xl text-foreground">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
