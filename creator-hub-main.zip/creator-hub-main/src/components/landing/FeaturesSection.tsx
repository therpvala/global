import { motion } from 'framer-motion';
import { BookOpen, Video, FileText, Award, Users, BarChart3, Shield, Zap } from 'lucide-react';

const features = [
  { icon: BookOpen, title: 'Course Management', desc: 'Create and organize comprehensive courses with modules, quizzes, and assessments.', color: 'bg-primary/10 text-primary' },
  { icon: Video, title: 'Video Learning Portal', desc: 'Stream video lessons, webinars, and recorded sessions with progress tracking.', color: 'bg-secondary/10 text-secondary' },
  { icon: FileText, title: 'Content Library', desc: 'Manage PDFs, e-books, presentations, and digital resources in one place.', color: 'bg-accent/20 text-accent-foreground' },
  { icon: Award, title: 'Certificates', desc: 'Auto-generate professional certificates upon course completion.', color: 'bg-primary/10 text-primary' },
  { icon: Users, title: 'Multi-Role Access', desc: 'Role-based dashboards for admins, instructors, students, and parents.', color: 'bg-secondary/10 text-secondary' },
  { icon: BarChart3, title: 'Analytics & Reports', desc: 'Track student progress, engagement, and content performance with rich dashboards.', color: 'bg-accent/20 text-accent-foreground' },
  { icon: Shield, title: 'Skill Assessment', desc: 'Evaluate student skills with customizable tests and grading rubrics.', color: 'bg-primary/10 text-primary' },
  { icon: Zap, title: 'Real-time Notifications', desc: 'Instant alerts for assignments, deadlines, announcements, and updates.', color: 'bg-secondary/10 text-secondary' },
];

const FeaturesSection = () => {
  return (
    <section id="resources" className="py-24 bg-background relative">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Features</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mt-2">
            Everything You Need for Digital Education
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            A comprehensive suite of tools to create, manage, and deliver exceptional learning experiences.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-card rounded-xl p-6 shadow-card border border-border hover:shadow-card-hover transition-shadow cursor-default group"
            >
              <div className={`w-12 h-12 rounded-xl ${f.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="font-display font-semibold text-foreground mb-2">{f.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
