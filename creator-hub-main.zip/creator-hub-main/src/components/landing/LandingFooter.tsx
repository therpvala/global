import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin } from 'lucide-react';

const LandingFooter = () => {
  return (
    <footer id="contact" className="gradient-dark text-pale-azure py-16">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid md:grid-cols-4 gap-10">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg gradient-warm flex items-center justify-center">
                <span className="font-display font-bold text-sm text-foreground">EL</span>
              </div>
              <span className="font-display font-bold text-lg">E-Learning Content Provider</span>
            </div>
            <p className="text-sm opacity-70 leading-relaxed mb-4">
              Empowering educators and learners with cutting-edge digital content creation and management tools.
            </p>
            <p className="text-xs opacity-50">Powered by Software Vala™</p>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4">Quick Links</h4>
            <div className="flex flex-col gap-2 text-sm opacity-70">
              <a href="#resources" className="hover:opacity-100 transition-opacity">Features</a>
              <a href="#pricing" className="hover:opacity-100 transition-opacity">Pricing</a>
              <a href="#testimonials" className="hover:opacity-100 transition-opacity">Testimonials</a>
              <a href="#contact" className="hover:opacity-100 transition-opacity">Contact</a>
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4">Support</h4>
            <div className="flex flex-col gap-2 text-sm opacity-70">
              <a href="#" className="hover:opacity-100 transition-opacity">Help Center</a>
              <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
              <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
              <Link to="/login" className="hover:opacity-100 transition-opacity">Login</Link>
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold mb-4">Contact</h4>
            <div className="flex flex-col gap-3 text-sm opacity-70">
              <div className="flex items-center gap-2"><Mail className="h-4 w-4" /> info@elearnprovider.com</div>
              <div className="flex items-center gap-2"><Phone className="h-4 w-4" /> +1 (555) 012-3456</div>
              <div className="flex items-center gap-2"><MapPin className="h-4 w-4" /> San Francisco, CA</div>
            </div>
          </div>
        </div>
        <div className="border-t border-pale-azure/10 mt-10 pt-6 text-center text-xs opacity-50">
          © 2026 E-Learning Content Provider. All rights reserved. Powered by Software Vala™
        </div>
      </div>
    </footer>
  );
};

export default LandingFooter;
