import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

const CTASection = () => {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 gradient-dark" />
      <div className="absolute top-10 left-10 w-64 h-64 rounded-full bg-primary/10 blur-3xl" />
      <div className="absolute bottom-10 right-10 w-80 h-80 rounded-full bg-accent/10 blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center max-w-3xl mx-auto"
        >
          <motion.div
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            className="w-16 h-16 rounded-2xl gradient-warm flex items-center justify-center mx-auto mb-6"
          >
            <Sparkles className="h-8 w-8 text-foreground" />
          </motion.div>

          <h2 className="font-display text-3xl md:text-5xl font-bold text-pale-azure mb-4">
            Ready to Transform Your Learning Experience?
          </h2>
          <p className="text-pale-azure/60 text-lg mb-8 max-w-xl mx-auto">
            Join thousands of educators and learners already using our platform to create, share, and manage digital education content.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/login">
              <Button size="lg" className="gradient-warm text-foreground font-semibold px-8 h-12 text-base hover:opacity-90 transition-opacity">
                Start Free Trial <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="font-semibold px-8 h-12 text-base border-pale-azure/20 text-pale-azure hover:bg-pale-azure/10">
              Schedule a Demo
            </Button>
          </div>

          <div className="flex flex-wrap justify-center gap-8 mt-12 text-pale-azure/50 text-sm">
            <span>✓ No credit card required</span>
            <span>✓ 14-day free trial</span>
            <span>✓ Cancel anytime</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CTASection;
