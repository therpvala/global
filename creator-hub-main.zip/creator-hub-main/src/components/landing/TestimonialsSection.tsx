import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Dr. Priya Sharma',
    role: 'Content Creator',
    text: 'This platform transformed how I deliver my Data Science courses. The video portal and assignment tools are incredibly intuitive.',
    rating: 5,
    avatar: 'PS',
  },
  {
    name: 'Marcus Chen',
    role: 'Student',
    text: 'The learning experience is unmatched. Progress tracking, certificates, and the discussion forum keep me motivated and engaged.',
    rating: 5,
    avatar: 'MC',
  },
  {
    name: 'Sarah Williams',
    role: 'Administrator',
    text: 'Managing 500+ students across 50 courses has never been easier. The analytics dashboard gives us insights we never had before.',
    rating: 5,
    avatar: 'SW',
  },
];

const TestimonialsSection = () => {
  return (
    <section id="testimonials" className="py-24 bg-muted/50 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 left-0 w-80 h-80 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-accent/10 blur-3xl" />

      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-primary font-semibold text-sm uppercase tracking-wider">Testimonials</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mt-2">
            Trusted by Educators & Learners
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            See what our community has to say about their experience.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              whileHover={{ y: -6, boxShadow: 'var(--shadow-card-hover)' }}
              className="bg-card rounded-2xl p-6 shadow-card border border-border relative"
            >
              <Quote className="h-8 w-8 text-primary/10 absolute top-4 right-4" />
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
                  {t.avatar}
                </div>
                <div>
                  <p className="font-display font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
              <div className="flex gap-0.5 mb-3">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="h-4 w-4 text-accent fill-accent" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{t.text}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
